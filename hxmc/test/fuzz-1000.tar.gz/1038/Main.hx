import H;
using p.Ext;

enum E0 {
	E0A;
	E0B(a1:Bool, a2:Int);
	E0C(a3:Int);
}

enum E4 {
	E4A;
	E4B(a5:Int);
	E4C(a6:Bool);
}

enum E7 {
	E7A;
	E7B(a8:Float, a9:Bool);
}

typedef S10 = {x11:Int, x12:Float, x13:Int};

typedef S14 = {x15:Int, x16:Int};

abstract A17(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A17, b:A17):A17
		return new A17(a.get() + b.get());

	@:op(A * B) public static function mul(a:A17, b:A17):A17
		return new A17(a.get() * b.get());

	@:op(-A) public static function neg(a:A17):A17
		return new A17(-a.get());
}

enum abstract K18(Int) to Int {
	var K18A = 1;
	var K18B = 4;
	var K18C = 7;
	var K18D = 10;
}

interface I19 {
	function m20(a21:E0, a22:Int):Bool;
}

interface I23 {
	function m24(a25:Int):String;
	function m26(a27:A17, a28:E0):Bool;
}

class C29 {
	public var f30:Float;
	public var f31:S14;
	public var f32:E4;
	public var cb33:(Int) -> Int;
	public function new(a34:Int) {
		this.f30 = 2.5e-3;
		this.f31 = ({x15: a34, x16: 206} : S14);
		this.f32 = E4C(true);
		this.cb33 = (p79:Int) -> p79;
	}
	public function m35(...r36:Int):Bool {
		H.tick();
		var v80:Map<Int, Bool> = new Map<Int, Bool>();
		final lf81:(Float, Int) -> Int = (p82:Float, p83:Int) -> (172 + (Std.parseInt(Std.string(p83)) ?? 0));
		final v84:S14 = (cast (({x15: 295, x16: 238} : S14)) : S14);
		return ({ var v85 = (true ? 41 : (Std.parseInt(Std.string(199)) ?? 0)); (false ? (E4.E4A).match(E4B(_)) : true); });
	}
	public function m37(a38:Float, a39:Int):K18 {
		H.tick();
		var w86 = 0;
while (w86 < 5 && (a39 < a39)) {
			w86++;
			H.tick();
			switch (true) {
				case true: {
					var v87:Float = 0.5;
				};
				case false: {
					H.out("o88 " + Std.string(a39));
					H.out("o89 " + Std.string(new C43()));
				};
			}
			{ var dyn90:Dynamic = ({x11: 229, x12: a38, x13: (-1604192229)} : S10); H.out("dyn " + Std.string(dyn90.x11) + " " + Std.string(Reflect.field(dyn90, "x11"))); }
		}
		var v91 = (Reflect.compare(a39, 265) % H.nz(a39));
		var v92 = (Reflect.compare(a39, a39) * v91);
		H.out("o93 " + Std.string(((true ? ({x15: 32, x16: 128} : S14) : ({x15: v92, x16: v92} : S14)) : S14)));
		v91 += (new C43()).m45(Math.round(a38));
		switch ((a39 + 941181760)) {
			case 0: {
				var v94:Int = a39;
				if (true) {
					var v95:Int = 274;
					H.out("o96 " + Std.string(E7B(v92, false)));
					(new C43()).m44();
				} else {
					var v97:Map<Int, Int> = new Map<Int, Int>();
					(new C47(false, 46)).m44();
				}
			};
			case 1 | 5: {
				H.out("o98 " + Std.string(({x11: a39, x12: a39, x13: 0x7FFFFFFF} : S10)));
				final v99:A17 = new A17(v91);
			};
			case _: {
				var v100:C43 = new C47(false, v91);
				switch (E0C(2)) {
					case E0A: {
						var v101:Float = a39;
					};
					case E0B(_, _): {
						m40();
					};
					case E0C(c102): {
						var v103 = v92;
						var v104 = v103;
					};
				}
			};
		}
		var v105:S14 = ({x16: v92, x15: 32} : S14);
		H.out("o106 " + Std.string(v92));
		var v107:E7 = E7.E7B(1.25, true);
		return K18.K18C;
	}
	public function m40():Int {
		H.tick();
		for (i108 in 1...2) {
			H.tick();
			final lf109:(Bool) -> Void = function(p110:Bool):Void {
				H.tick();
				(new C29(i108)).m35(i108, i108);
			};
			if (true) {
				(new C47(false, i108)).m26(new A17(i108), E0A);
				var v111:Int = i108;
			}
		}
		final v112:K18 = K18.K18C;
		final v113:Bool = (0.5 >= (-2.5));
		{
			final v114:Bool = (E4.E4A).match(E4A);
			for (i115 in 0...2) {
				H.tick();
				var v116:Map<String, Bool> = new Map<String, Bool>();
			}
			(new C47(v114, 253)).m26(new A17(292), E0.E0B(v114, 114));
		}
		if (v113) {
			var v117 = ((["k0" => 393131546, "k1" => 288] : Map<String, Int>)).exists("k0");
		} else {
			var v118:K18 = K18.K18C;
		}
		return (cast ((if (true) 875935529 else (-1111857860))) : Int);
	}
	public function m41(?a42:Null<Int>):Int {
		H.tick();
		H.out("o119 " + Std.string(m40()));
		H.out("o120 " + Std.string(new C47(false, Math.ceil(123456.789))));
		var v121:Map<Int, Int> = (cast (new Map<Int, Int>()) : Map<Int, Int>);
		for (i122 in 0...2) {
			H.tick();
			if ((E4C(false)).match(E4A)) {
				var v123:Int = 0xFFFFFFFF;
				var v124:Int = 1758705944;
				var v125:Null<Int> = v123;
			}
			var v126:Map<String, Int> = new Map<String, Int>();
		}
		var w127 = 0;
while (w127 < 3 && (this.f30 > (-2147483647))) {
			w127++;
			H.tick();
			H.out("o128 " + Std.string((((-10) : A17) : Int)));
			final v129:A17 = new A17(206);
		}
		return 228;
	}
}

class C43 implements I23 {
	public function new() {}
	public function m24(a25:Int):String {
		H.tick();
		H.out("o130 " + Std.string(new C47((new Map<String, Int>()).exists("k2"), a25)));
		var w131 = 0;
while (w131 < 2 && m26(((-15) : A17), E0C((-2147483647)))) {
			w131++;
			H.tick();
			a25 = H.id(a25);
			a25 = 121;
			for (i132 in 0...H.lim(181)) {
				H.tick();
				if (false) continue;
				a25 = H.id(a25);
			}
		}
		var v133:E4 = E4C((Std.downcast((new C29(a25) : C29), C29) != null));
		var v134:K18 = ((true ? K18.K18D : K18.K18D) : K18);
		var v135 = (100 * (({x11: a25, x12: a25, x13: 38} : S10)).x13);
		return (' = ${Std.string(false)}' + 147);
	}
	public function m26(a27:A17, a28:E0):Bool {
		H.tick();
		H.out("o136 " + Std.string(((-new A17(0x5F2F)) : Int)));
		if (true) {
			var v137:Int = 203;
			H.out("o138 " + Std.string(Std.isOfType(new C47(false, v137), I23)));
			var v139:Int = (({x15: v137, x16: v137} : S14)).x16;
		}
		final v140:() -> String = () -> "hello world";
		for (i141 in 0...1) {
			H.tick();
			if ((new Map<String, Int>()).exists("k0")) return true;
		}
		switch (K18.K18C) {
			case K18.K18A: {
				final v142:C43 = new C43();
				final v143:Int = 0x65D8;
			};
			case K18.K18B: {
				H.out("o144 " + Std.string(239));
			};
			case K18.K18C: {
				var v145:Map<Int, Bool> = ([-3 => true] : Map<Int, Bool>);
				if ((a28).match(E0A)) {
					final v146 = 69;
					var v147 = v146;
				}
			};
			case K18.K18D: {
				final v148:() -> Int = () -> 0x80000000;
				H.out("o149 " + Std.string(E4A));
			};
			case _: {
				var v150:Map<String, Float> = (["k0" => 2.5e-3] : Map<String, Float>);
			};
		}
		final v151 = (Std.parseInt("q") ?? 0);
		return false;
	}
	public function m44():Bool {
		H.tick();
		for (i152 in 0...3) {
			H.tick();
			(new C47(true, 261)).m26((i152 : A17), E0.E0A);
		}
		if (!(E0A).match(E0C(_))) {
			switch (E0A) {
				case E0A: {
					var v153:E4 = E4.E4B(263);
					(new C29(63)).m35(289);
				};
				case E0B(_, c154): {
					var v155:Map<Int, Bool> = ([-3 => true] : Map<Int, Bool>);
					H.out("o156 " + Std.string(112));
				};
				case _: {
					var v157:K18 = K18.K18D;
				};
			}
			final v158:Map<Int, Int> = new Map<Int, Int>();
		}
		final v159:A17 = new A17(((new Map<String, Int>()).get("zz") ?? 0));
		var w160 = 0;
do {
			w160++;
			H.tick();
			var w161 = 0;
while (w161 < 2 && (E4C(false)).match(E4A)) {
				w161++;
				H.tick();
				H.out("o162 " + Std.string(1382210702));
				var v163:Int = 793779566;
			}
			switch (E7B(3.0, false)) {
				case E7A: {
					H.out("o164 " + Std.string(1565549597));
					H.out("o165 " + Std.string((new A17(256) : Int)));
				};
				case E7B(c166, c167): {
					H.out("o168 " + Std.string((K18.K18A : Int)));
					H.out("o169 " + Std.string(E0A));
				};
			}
			switch (E0A) {
				case E0A: {
					var v170 = 47;
				};
				case E0B(c171, _): {
					var v172:Int = 38;
				};
				case E0C(_): {
					var v173:Int = 209;
				};
			}
		} while (w160 < 4 && this.m26(new A17(65535), E0.E0A));
		final v174:Int = 219;
		var w175 = 0;
while (w175 < 4 && ((v159).twice <= 1137742390)) {
			w175++;
			H.tick();
			for (i176 in 2...H.lim((({x16: v174, x15: v174} : S14)).x15)) {
				H.tick();
				var v177:Int = i176;
			}
		}
		var v178:I23 = ((true ? new C47(true, v174) : new C43()) : I23);
		switch (E4.E4B(v174)) {
			case E4A: {
				H.out("o179 " + Std.string((E0B(true, v174)).match(E0C(_))));
				final v180 = Math.round(v174);
			};
			case E4B(_): {
				(new C29(91)).m35((v159 : Int));
			};
			case E4C(_): {
				m26(v159, E0C(v174));
				var v181:Float = 179;
			};
			case _: {
				H.out("o182 " + Std.string(null));
				var v183:Float = v174;
			};
		}
		return (false && ((E4B(v174)).match(E4A) && false));
	}
	public function m45(a46:Int):Int {
		H.tick();
		a46 = H.id(a46);
		(new C47((Std.downcast((new C43() : I23), I23) != null), 133)).m44();
		final lf184:() -> Bool = function():Bool {
			H.tick();
			H.out("o185 " + Std.string(178));
			(new C47(true, 100)).m44();
			final v186:(Bool, String) -> Bool = (p187:Bool, p188:String) -> p187;
			return (E0.E0C(a46)).match(E0C(_));
		};
		if ((146 < Lambda.count(([] : Array<Int>), v189 -> Std.isOfType(null, I19)))) {
			switch (E7.E7A) {
				case E7A: {
					final v190 = a46;
				};
				case E7B(c191, _): {
					var v192:Null<Int> = null;
				};
			}
			var v193:C29 = new C29((-2147483647));
			H.out("o194 " + Std.string(a46));
		}
		a46++;
		try {
			if (false) {
				var v195:E0 = E0A;
			}
			final lf196:(Int, Bool) -> Void = function(p197:Int, p198:Bool):Void {
				H.tick();
				var v199:K18 = K18.K18A;
				final v200:Float = 1e-7;
			};
			if ((E7.E7B(a46, false)).match(E7A)) throw "\"q\"";
		} catch (ex201:Err) {
			H.out("caught Err " + ex201.errCode);
			var v202:C47 = new C47(false, a46);
			for (i203 in 2...H.lim(259)) {
				H.tick();
				H.out("o204 " + Std.string(i203));
			}
		} catch (ex205:haxe.Exception) {
			H.out("caught " + H.exn(ex205));
			var v206:I23 = new C47(false, (-615436985));
			var w207 = 0;
while (w207 < 4 && (([-3 => 282, 4 => a46] : Map<Int, Int>)).exists(a46)) {
				w207++;
				H.tick();
				H.out("o208 " + Std.string(false));
			}
		}
		a46 = ((new A17(a46)).get() - Lambda.count([a46, 0xC851], v209 -> (E0B(true, 192)).match(E0C(_))));
		(new C29(a46)).m40();
		return (K18.K18A : Int);
	}
}

class C47 extends C43 {
	public final f48:Int;
	public var f49:Float;
	public final f50:Int;
	public var cb51:(Int) -> Int;
	public function new(a52:Bool, a53:Int) {
		super();
		this.f48 = Math.floor(a53);
		this.f49 = 1.25;
		this.f50 = (Std.parseInt("\t") ?? 0);
		this.cb51 = (p210:Int) -> a53;
	}
	override public function m44():Bool {
		H.tick();
		H.out("o211 " + Std.string((({x15: 79, x16: 104} : S14)).x16));
		switch (K18.K18D) {
			case K18.K18A: {
				final v212:(Float, Bool) -> Bool = function(p213:Float, p214:Bool):Bool {
					H.tick();
					H.out("o215 " + Std.string(p213));
					var v216 = p214;
					H.out("o217 " + Std.string(109));
					return false;
				};
				for (i218 in 0...H.lim((K18.K18C : Int))) {
					H.tick();
					var v219 = i218;
					H.out("o220 " + Std.string(false));
				}
			};
			case K18.K18B: {
				var v221:Map<String, Float> = (["k0" => 1e-7, "k1" => 7.0, "k2" => 100.75] : Map<String, Float>);
				final v222 = (({x13: 220, x11: 290, x12: 1e-7} : S10)).x13;
			};
			case K18.K18C: {
				final lf223:() -> Int = () -> 0x88E;
			};
			case K18.K18D: {
				try {
					if ((E0A).match(E0B(_, _))) throw "boom";
					H.out("o224 " + Std.string(271));
					var v225:Map<String, Bool> = (["k0" => false, "k1" => true] : Map<String, Bool>);
					final v226:Float = 1e3;
				} catch (ex227:Dynamic) {
					H.out("caught " + H.exn(ex227));
					H.out("o228 " + Std.string(266));
				}
			};
			case _: {
				(new C29(275)).m35(0x7FFFFFFF, (({x15: 0x86A8, x16: 121} : S14)).x16);
			};
		}
		H.out("o229 " + Std.string((({x11: 264, x12: 1.25, x13: (-2)} : S10)).x11));
		switch (E0.E0A) {
			case E0A: {
				final v230:Map<String, Int> = (["k0" => (-629364812)] : Map<String, Int>);
				var v231:Int = 99;
			};
			case E0B(c232, c233): {
				H.out("o234 " + Std.string(E7B(123456.789, false)));
			};
			case E0C(c235) if (c235 > 0): {
				if (false) return true;
				H.out("o236 " + Std.string(c235));
			};
			case _: {
				switch (E7B(0.5, true)) {
					case E7A: {
						(new C29(148)).m40();
					};
					case E7B(c237, _): {
						final v238:C43 = new C43();
					};
				}
			};
		}
		final v239:(Int) -> Int = function(p240:Int):Int {
			H.tick();
			(new C29(274)).m35(0x7FFFFFFF);
			return p240;
		};
		if ((true && false)) return ((-20) == 124);
		try {
			var w241 = 0;
do {
				w241++;
				H.tick();
				var v242:Float = 1e3;
				var v243 = true;
				final v244:Int = 44;
			} while (w241 < 4 && (E0A).match(E0A));
			if (({ var v245 = (E7.E7B(0.1, false)).match(E7B(_, _)); (E0.E0B(v245, 921400508)).match(E0A); })) throw "boom";
		} catch (ex246:Dynamic) {
			H.out("caught " + H.exn(ex246));
			H.out("o247 " + Std.string((E7.E7B(2.5e-3, true)).match(E7A)));
		}
		var v248:Int = (new C29((-2147483647))).m40();
		return ((E4C(true)).match(E4C(_)) || (E0.E0A).match(E0C(_)));
	}
	override public function m45(a46:Int):Int {
		H.tick();
		((cast (new C29(a46)) : C29)).m35(a46);
		a46 *= a46;
		(new C29(12)).m35();
		for (i249 in 0...3) {
			H.tick();
			H.out("o250 " + Std.string(a46));
			a46 -= a46;
		}
		H.out("o251 " + Std.string(a46));
		return a46;
	}
}

class Main {
	public static function fn54(a55:Float, a56:Int):Void {
		H.tick();
		switch (E4A) {
			case E4A: {
				switch (false) {
					case true: {
						H.out("o252 " + Std.string(false));
					};
					case false: {
						var v253:Bool = true;
						a56 = H.id(a56);
					};
				}
				(new C29(10)).m35();
			};
			case E4B(c254) if (c254 > 1): {
				a56--;
			};
			case _: {
				var v255 = 66;
				switch (a56) {
					case 0: {
						var v256 = false;
					};
					case 3 | 6: {
						a56 = H.id(a56);
						H.out("o257 " + "\t");
					};
					case _: {
						final v258:(Int, Int) -> String = (p259:Int, p260:Int) -> "\n";
					};
				}
			};
		}
		var v261:E7 = E7.E7B(a56, false);
		var w262 = 0;
while (w262 < 5 && (new C47(false, a56)).m44()) {
			w262++;
			H.tick();
			switch (K18.K18C) {
				case K18.K18A: {
					(new C43()).m26(new A17(120), E0A);
				};
				case K18.K18B: {
					var v263:K18 = K18.K18A;
				};
				case K18.K18C: {
					a56 = H.id(a56);
				};
				case K18.K18D: {
					H.out("o264 " + Std.string((K18.K18C : Int)));
				};
			}
			(new C47(false, a56)).m44();
		}
	}
	public static function fn57(a58:Bool, a59:Int, a60:Bool):Int {
		H.tick();
		var v265:K18 = K18.K18B;
		switch (E4B(a59)) {
			case E4A: {
				var v266:Map<String, Float> = (["k0" => 100.75, "k1" => 2.5e-3] : Map<String, Float>);
				H.out("o267 " + Std.string(E4.E4B(a59)));
			};
			case E4B(_): {
				var w268 = 0;
while (w268 < 5 && a58) {
					w268++;
					H.tick();
					H.out("o269 " + Std.string(199));
					H.out("o270 " + Std.string(a59));
					(new C47(a60, 66)).m44();
				}
				try {
					H.out("o271 " + Std.string(({x11: a59, x12: a59, x13: a59} : S10)));
					final v272:Map<String, String> = new Map<String, String>();
					a59 = H.id(a59);
					if (a60) throw new Err(a59);
				} catch (ex273:Err) {
					H.out("caught Err " + ex273.errCode);
					H.out("o274 " + Std.string(E0.E0C(a59)));
				} catch (ex275:haxe.Exception) {
					H.out("caught " + H.exn(ex275));
					var v276 = a59;
					(new C29((-8))).m35(0x7FFFFFFF);
				}
			};
			case E4C(c277): {
				var v278:C47 = new C47(true, a59);
			};
			case _: {
				H.out("o279 " + Std.string(Std.int(a59)));
			};
		}
		switch (E7.E7A) {
			case E7A: {
				var v280:A17 = new A17(a59);
			};
			case E7B(c281, c282): {
				var v283:Float = c281;
				var v284:Int = Type.enumIndex(E7.E7B(0.5, true));
			};
			case _: {
				H.out("o285 " + Std.string(112));
				{
					H.out("o286 " + Std.string(a58));
				}
			};
		}
		switch ((new C29(a59)).m40()) {
			case 0: {
				switch (E7.E7A) {
					case E7A: {
						H.out("o287 " + Std.string(a58));
					};
					case E7B(c288, c289): {
						var v290:K18 = v265;
					};
				}
			};
			case 3 | 5: {
				(new C29(a59)).m40();
				var v291:S14 = ({x15: 159, x16: a59} : S14);
			};
			case _: {
				switch (E4.E4C(false)) {
					case E4A: {
						H.out("o292 " + Std.string(a59));
						var v293:Int = 30;
					};
					case E4B(_): {
						H.out("o294 " + Std.string(a59));
					};
					case E4C(c295): {
						var v296:E7 = E7.E7B(a59, a60);
						var v297:Int = 175;
					};
				}
				var w298 = 0;
do {
					w298++;
					H.tick();
					H.out("o299 " + Std.string(a59));
				} while (w298 < 3 && true);
			};
		}
		var v300:Int = (new C29(a59)).m40();
		return 1815607341;
	}
	public static function fn61(a62:Float):C43 {
		H.tick();
		switch (E7.E7B(1.25, true)) {
			case E7A: {
				var v301:E4 = E4C(true);
			};
			case E7B(c302, c303): {
				if (c303) {
					final v304:(Bool) -> Int = (p305:Bool) -> 127;
				}
			};
		}
		final v306:Int = (switch (0x79BC) {
			case 0: 172;
			case 1 | 5: 156;
			case c307 if (c307 > 10): Reflect.compare(c307, 249);
			case _: (-1769123448);
		});
		try {
			final v308:S10 = ({x11: v306, x12: v306, x13: v306} : S10);
			var v309 = v306;
			if ((new C47(true, v309)).m26(new A17(0x9EB0), E0C(v306))) throw '<${Std.string(117)}-${Std.string(true)}';
		} catch (ex310:Err) {
			H.out("caught Err " + ex310.errCode);
			H.out("o311 " + Std.string(82));
		} catch (ex312:haxe.Exception) {
			H.out("caught " + H.exn(ex312));
			var v313 = v306;
			H.out("o314 " + Std.string((Std.parseInt(Std.string(v306)) ?? 0)));
		}
		(new C29(v306)).m40();
		return (((true ? true : true) ? new C43() : new C43()) : C43);
	}
	public static function fn63(a64:Bool, a65:Float):String {
		H.tick();
		(new C29(Reflect.compare(0xAD4F, 150))).m40();
		H.out("o315 " + Std.string((6 < 90)));
		fn61(a65);
		final v316:Map<Int, Int> = ([-3 => 209] : Map<Int, Int>);
		final v317:C43 = new C47(false, (({x11: 272, x12: 7.0, x13: 123} : S10)).x11);
		return (a64 + (false ? Std.string(294) : "42"));
	}
	public static function fn66(a67:Int, a68:Int, a69:E7):S10 {
		H.tick();
		final v318:Map<Int, Int> = ((true ? new Map<Int, Int>() : ([-3 => a67] : Map<Int, Int>)) : Map<Int, Int>);
		var w319 = 0;
while (w319 < 5 && (Lambda.fold([a67], (v320:Int, v321:Int) -> Math.floor(a68), 0) > a68)) {
			w319++;
			H.tick();
			var v322:Map<String, Int> = (["k0" => a68] : Map<String, Int>);
			final v323:Map<String, Float> = (["k0" => a68] : Map<String, Float>);
			switch (E4.E4C(true)) {
				case E4A: {
					var v324 = a68;
					if (true) break;
				};
				case E4B(_): {
					H.out("o325 " + Std.string(E4A));
					final v326 = true;
				};
				case E4C(c327): {
					H.out("o328 " + Std.string(new C47(c327, a67)));
					var v329:Int = a67;
				};
				case _: {
					var v330 = false;
				};
			}
		}
		var v331 = (a68 * (K18.K18C : Int));
		a68 = 56;
		H.out("o332 " + Std.string((cast (a68) : Int)));
		v331 += (27 * ((v318).get(11) ?? 0));
		(new C43()).m45(a67);
		return ({x12: v331, x13: (0x7FFFFFFF % H.nz(Lambda.count([a67], v333 -> (E4B(v331)).match(E4B(_))))), x11: ({ var v334 = v331; (Std.parseInt(Std.string(0xE63)) ?? 0); })} : S10);
	}
	public static function fn70():Float {
		H.tick();
		try {
			var v335:Int = 141;
			v335 = H.id(v335);
			H.out("o336 " + Std.string(1.7976931348623157e308));
			if ((new Map<String, Int>()).exists("zz")) throw "boom";
		} catch (ex337:String) {
			H.out("caught String " + ex337);
			(new C43()).m44();
			(new C47(false, 182)).m44();
		} catch (ex338:Int) {
			H.out("caught Int " + ex338);
			if ((E4.E4C(false)).match(E4B(_))) {
				var v339:A17 = new A17(1403834633);
			} else {
				H.out("o340 " + Std.string(ex338));
			}
			for (i341 in 0...3) {
				H.tick();
				var v342:K18 = K18.K18B;
				final v343:Int = 1127303213;
				H.out("o344 " + Std.string(v343));
			}
		} catch (ex345:Err) {
			H.out("caught Err " + ex345.errCode);
			var v346 = (K18.K18B : Int);
			var v347:Map<String, Float> = (["k0" => v346] : Map<String, Float>);
		} catch (ex348:Dynamic) {
			H.out("caught " + H.exn(ex348));
			function lf349(n350:Int):Int {
				H.tick();
				return n350 <= 0 ? 246 : (lf349(n350 - 1) + ((n350 : A17) : Int));
			}
			H.out("lf349 " + lf349(3));
		}
		final v351:Map<Int, Bool> = new Map<Int, Bool>();
		var v352:E0 = E0A;
		var v353:Int = (new C47(true, 0x80000000)).m45((K18.K18C : Int));
		H.out("o354 " + Std.string(Math.floor(2.5e-3)));
		try {
			for (i355 in 1...4) {
				H.tick();
				H.out("o356 " + Std.string(true));
				H.out("o357 " + Std.string(false));
				var v358:Map<String, Int> = new Map<String, Int>();
			}
			if ((switch (E4B(59)) {
				case E4A: false;
				case E4B(_): false;
				case E4C(_): true;
			})) throw 68;
		} catch (ex359:String) {
			H.out("caught String " + ex359);
			var v360 = (-1473060694);
			(new C47(false, v360)).m26((v353 : A17), v352);
		} catch (ex361:Int) {
			H.out("caught Int " + ex361);
			var w362 = 0;
while (w362 < 2 && Math.isNaN(v353)) {
				w362++;
				H.tick();
				var v363:Null<Int> = v353;
				if (true) break;
				H.out("o364 " + Std.string(new C47(true, ex361)));
			}
			v353 -= 0xADAC;
		} catch (ex365:Err) {
			H.out("caught Err " + ex365.errCode);
			var v366 = (K18.K18A : Int);
		} catch (ex367:Dynamic) {
			H.out("caught " + H.exn(ex367));
			switch (true) {
				case true: {
					H.out("o368 " + Std.string(110));
				};
				case false: {
					H.out("o369 " + Std.string(v353));
					final v370:C29 = new C29(105);
				};
			}
			var v371 = v353;
		}
		H.out("o372 " + Std.string((v353 + (new A17(227)).twice)));
		switch ((switch (Lambda.count([271, v353], v373 -> (E7.E7A).match(E7B(_, _)))) {
			case 0: Lambda.count([v353, v353, 87], v374 -> true);
			case 2 | 6: (Std.parseInt(Std.string(v353)) ?? 0);
			case c375 if (c375 > 10): Reflect.compare(179, v353);
			case _: Type.enumIndex(E4B(v353));
		})) {
			case 0: {
				var v376:Null<Int> = v353;
				switch (v352) {
					case E0A: {
						(new C43()).m24(v353);
					};
					case E0B(_, _): {
						v353 += v353;
					};
					case E0C(c377) if (c377 > 0): {
						var v378 = c377;
						(new C29((-1312528128))).m37(7.0, v378);
					};
					case _: {
						var v379:S14 = ({x15: v353, x16: v353} : S14);
					};
				}
			};
			case 1 | 5: {
				var w380 = 0;
while (w380 < 4 && ((["k0" => true, "k1" => false, "k2" => false] : Map<String, Bool>)).exists("k3")) {
					w380++;
					H.tick();
					fn54(v353, v353);
					var v381:C47 = new C47(false, v353);
					(new C29(v353)).m41(264);
				}
				H.out("o382 " + Std.string(v353));
			};
			case c383 if (c383 > 10): {
				H.out("o384 " + Std.string(true));
			};
			case _: {
				switch (true) {
					case true: {
						var v385:E4 = E4B(v353);
					};
					case false: {
						var v386:Null<Int> = v353;
						Main.fn66(v353, v353, E7A);
					};
				}
			};
		}
		H.out("o387 " + Std.string(new C47((E7B(v353, false)).match(E7A), 120)));
		return v353;
	}
	public static function fn71(...r72:Int):E0 {
		H.tick();
		var v388:Int = Reflect.compare(Std.int((-2.5)), (({x12: 0.1, x11: 226, x13: 0xAFD5} : S10)).x13);
		try {
			if ((287 >= (Std.parseInt("zz") ?? 0))) throw ((new Map<String, Float>()).exists("  pad  ") ? Std.string(0x6087) : "\t");
			var v389:Float = v388;
		} catch (ex390:Dynamic) {
			H.out("caught " + H.exn(ex390));
			var w391 = 0;
do {
				w391++;
				H.tick();
				H.out("o392 " + Std.string(E4B(v388)));
				var v393:Map<String, Int> = (["k0" => v388, "k1" => 54165145, "k2" => v388] : Map<String, Int>);
				var v394 = true;
			} while (w391 < 2 && (Std.downcast((null : I19), I19) != null));
		}
		final v395:Float = (Reflect.compare(v388, v388) - 5e-324);
		H.out("o396 " + Std.string(((cast (K18.K18B) : K18) : Int)));
		var v397:Map<String, Float> = new Map<String, Float>();
		var v398:Int = (((new Map<Int, Int>()).get(4) ?? 0) - v388);
		try {
			if ((new C47(true, v388)).m44()) throw new Err((0xBB15 - (-19)));
			var v399:Int = (((["k0" => v388, "k1" => v398] : Map<String, Int>)).get("ab") ?? 0);
		} catch (ex400:String) {
			H.out("caught String " + ex400);
			var w401 = 0;
while (w401 < 3 && (([-3 => false, 4 => false, 11 => false] : Map<Int, Bool>)).exists(18)) {
				w401++;
				H.tick();
				v398 = H.id(v398);
				var v402:E4 = E4A;
				Main.fn61(v398);
			}
			var v403 = Math.round(v388);
		} catch (ex404:Int) {
			H.out("caught Int " + ex404);
			v398 -= 12;
		} catch (ex405:Err) {
			H.out("caught Err " + ex405.errCode);
			for (i406 in 0...1) {
				H.tick();
				(new C47(false, v388)).m26((i406 : A17), E0.E0C(284));
				(r72.toArray()).ext78(v388);
			}
			var v407:Int = (Std.parseInt("hello world") ?? 0);
		} catch (ex408:Dynamic) {
			H.out("caught " + H.exn(ex408));
			H.out("o409 " + Std.string(new C43()));
			v398 = Lambda.fold(r72.toArray(), (v410:Int, v411:Int) -> (-2147483647), 0);
		}
		return E0A;
	}
	public static function fn73(a74:Int, a75:Bool):E0 {
		H.tick();
		(new C29((({x13: a74, x12: a74, x11: a74} : S10)).x11)).m37(a74, Reflect.compare(169, a74));
		if (false) {
			for (k412 => v413 in new Map<String, Int>()) {
				H.tick();
				var v414:Int = v413;
				a74 = v414;
				var v415 = false;
			}
			var v416 = (-2147483647);
			try {
				var v417:Int = a74;
				H.out("o418 " + Std.string(a75));
				if (false) throw new Err(222);
			} catch (ex419:Dynamic) {
				H.out("caught " + H.exn(ex419));
				H.out("o420 " + "");
				v416 = a74;
			}
		}
		a74 = H.id(a74);
		final v421:A17 = new A17((K18.K18C : Int));
		var w422 = 0;
while (w422 < 3 && Std.isOfType(new C43(), C43)) {
			w422++;
			H.tick();
			a74 -= Reflect.compare(a74, 242);
			var v423:Map<String, String> = new Map<String, String>();
		}
		(new C47(true, 65535)).m26(v421, fn71(a74, 133));
		{
			var v424:Null<Int> = null;
			for (i425 in 2...H.lim((Std.parseInt(Std.string(a74)) ?? 0))) {
				H.tick();
				var v426 = a74;
			}
			if (a75) return E0B(a75, a74);
		}
		return E0.E0C((Std.isOfType(new C43(), I23) ? 0x1DFB : a74));
	}
	public static function section0():Void {
		H.tick();
		Main.fn57((new C47(true, 281)).m44(), ((Std.parseInt("\"q\"") ?? 0) + ((new Map<String, Int>()).get("k2") ?? 0)), (14 <= 1e-7));
		try {
			if (!true) throw new Err((52 % H.nz((new A17((-301184383))).twice)));
			try {
				if (false) throw 43;
				var v430:A17 = new A17(217);
				final v431:(Int, String) -> Float = function(p432:Int, p433:String):Float {
					H.tick();
					final v434 = p432;
					return p432;
				};
			} catch (ex435:Dynamic) {
				H.out("caught " + H.exn(ex435));
				H.out("o436 " + Std.string((-784698911)));
				H.out("o437 " + Std.string((K18.K18D : Int)));
			}
			for (i438 in 0...0) {
				H.tick();
				(new C47(false, i438)).m44();
			}
			if (true) {
				H.out("o439 " + Std.string((new A17(23) : Int)));
			} else {
				var v440:Map<String, Bool> = new Map<String, Bool>();
			}
		} catch (ex441:Dynamic) {
			H.out("caught " + H.exn(ex441));
			for (i442 in 2...6) {
				H.tick();
				final v443 = i442;
				final v444:(Int) -> Bool = (p445:Int) -> false;
				final v446:S14 = ({x15: v443, x16: v443} : S14);
			}
		}
		fn57((cast (false) : Bool), (Math.round(1e-7) + (-8)), (switch (Std.int(1.25)) {
			case 0: false;
			case 2 | 6: false;
			case _: false;
		}));
		var v447:A17 = (31 : A17);
		(Main.fn61(1e3)).m44();
		for (i448 in 0...H.lim((51 + Reflect.compare(217, 61)))) {
			H.tick();
			H.out("o449 " + Std.string(E7.E7A));
			var v450:Map<Int, Int> = ([-3 => 0x7FFFFFFF, 4 => i448] : Map<Int, Int>);
		}
		Main.fn61((1e-7 - 0.1));
		{ var dyn451:Dynamic = ({x15: (new A17(208)).twice, x16: (({x11: (-1897062326), x12: 7.0, x13: 166} : S10)).x11} : S14); H.out("dyn " + Std.string(dyn451.x15) + " " + Std.string(Reflect.field(dyn451, "x15"))); }
		var v452:Int = (new C47(true, 63)).m45(Math.ceil(1e21));
	}
	public static function section1():Void {
		H.tick();
		{
			var v453:E4 = E4A;
			(new C47(true, (-2147483647))).m45(115);
			var w454 = 0;
do {
				w454++;
				H.tick();
				final v455:C29 = new C29(289);
			} while (w454 < 2 && true);
		}
		(new C29((-17))).m35((Std.parseInt("zz") ?? 0));
		final v456:Float = (204 / 62);
		(((switch (K18.K18A) {
			case K18.K18A: new C43();
			case K18.K18B: new C43();
			case K18.K18C: new C47(true, 0xA7EF);
			case K18.K18D: new C43();
		}) : C43)).m24(11);
		{
			H.out("o457 " + Std.string(v456));
			var v458:Float = 0.5;
		}
		var v459:C29 = new C29((new A17(0xD400)).twice);
		var v460:Map<String, Int> = new Map<String, Int>();
		var w461 = 0;
while (w461 < 1 && (Std.isOfType(new C47(true, 1628417812), C43) && (v460).exists("k3"))) {
			w461++;
			H.tick();
			H.out("o462 " + Std.string(((0xEE14 : A17)).get()));
			var v463:Int = (({x15: 1942578577, x16: 253} : S14)).x15;
		}
		for (i464 in 2...4) {
			H.tick();
			H.out("o465 " + Std.string((K18.K18D : Int)));
			var v466:I23 = new C43();
		}
	}
	public static function section2():Void {
		H.tick();
		var v467 = (-17);
		v467 = (-2144728748);
		switch ((new C29(0x8D45)).m37(Math.sin(1e21), Lambda.fold([v467], (v468:Int, v469:Int) -> (Std.parseInt("\t") ?? 0), 0))) {
			case K18.K18A: {
				var v470:C47 = new C47(false, v467);
			};
			case K18.K18B: {
				Main.fn73(71, false);
			};
			case K18.K18C: {
				{
					var v471:Map<Int, Int> = ([-3 => v467, 4 => v467] : Map<Int, Int>);
					final v472:C29 = new C29(225);
				}
				H.out("o473 " + Std.string(false));
			};
			case K18.K18D: {
				H.out("o474 " + Std.string(v467));
				final v475 = Type.enumIndex(E0C(v467));
			};
		}
		H.out("o476 " + Std.string((Std.parseInt(Std.string(v467)) ?? 0)));
		var v477:E7 = E7.E7A;
		for (i478 in 0...0) {
			H.tick();
			var v479:Bool = Std.isOfType(new C47(false, i478), I23);
		}
	}
	public static function section3():Void {
		H.tick();
		if ((Std.downcast((new C47(false, 277) : C47), C47) != null)) {
			(new C47(false, 11)).m44();
			Main.fn57(Math.isNaN(2.5e-3), (K18.K18A : Int), (E7.E7B((-2.5), true)).match(E7A));
		}
		var v480:S14 = ({x15: Math.ceil(1.25), x16: 93} : S14);
		{ var dyn481:Dynamic = fn66((((["k0" => 0xFE71, "k1" => 262] : Map<String, Int>)).get("k0") ?? 0), 260, E7.E7B((-2.5), false)); H.out("dyn " + Std.string(dyn481.x11) + " " + Std.string(Reflect.field(dyn481, "x11"))); }
		var v482:Int = (({x11: 191, x12: 1e3, x13: 269} : S10)).x13;
		H.out("o483 " + "42");
		var v484 = ((({x11: v482, x12: 1.7976931348623157e308, x13: v482} : S10)).x11 % H.nz(3));
		if ((false && true)) {
			v482 = H.id(v482);
		} else {
			for (i485 in 0...H.lim(0xFB2B)) {
				H.tick();
				(new C47(true, 188)).m45(v482);
				v482 = H.id(v482);
				var v486:Map<String, Bool> = new Map<String, Bool>();
			}
			{ var dyn487:Dynamic = ({x15: 63, x16: v484} : S14); H.out("dyn " + Std.string(dyn487.x15) + " " + Std.string(Reflect.field(dyn487, "x15"))); }
		}
	}
	public static function section4():Void {
		H.tick();
		var v488:E7 = (cast (E7B(5e-324, true)) : E7);
		var v489 = ({ var v490 = ((([-3 => 156] : Map<Int, Int>)).get(66) ?? 0); (-2147483647); });
		H.out("o491 " + Std.string(({x15: (({x15: 174, x16: v489} : S14)).x15, x16: v489} : S14)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
