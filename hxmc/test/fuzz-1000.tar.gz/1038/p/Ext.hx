package p;

import Main;
import H;

class Ext {
	public static function ext78(a76:Array<Int>, a77:Int):Bool {
		H.tick();
		var v427:E4 = E4.E4A;
		for (i428 in 0...H.lim(((K18.K18A : Int) - ((([-3 => 290, 4 => a77, 11 => a77] : Map<Int, Int>)).get(4) ?? 0)))) {
			H.tick();
			H.out("o429 " + Std.string(true));
			Main.fn61(i428);
		}
		{
			a77 -= (K18.K18C : Int);
		}
		return false;
	}
}
