package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

class C25 extends C16 {
	public function new(a26:Int, a27:Int) {
		super((new A3(a26)).get());
	}
	override public function m12():Int {
		H.tick();
		switch (H.id(([0x7FFFFFFF]).copy())) {
			case []: {
				for (k169 => x168 in [0x996, 0x7FFFFFFF]) {
					H.tick();
					(new C5()).m9(true, k169);
				}
				this.f7 = H.capa([297, 53]);
			};
			case [c170]: {
				m9(Std.isOfType(new C25(c170, 299), C5), (({x2: c170, x1: "0"} : S0)).x2);
				H.out("o171 " + Std.string(c170));
			};
			case [_, c172]: {
				switch ((K4.K4A : Int)) {
					case 0: {
						this.f19 = c172;
					};
					case 3 | 4: {
						var v173:S0 = ({x1: "a", x2: c172} : S0);
					};
					case c174 if (c174 > 10): {
						this.f7 = H.capa(([] : Array<Int>));
						(new C5()).m9(false, c174);
					};
					case _: {
						var v175 = false;
						var v176:Map<String, Int> = new Map<String, Int>();
					};
				}
				if (true) {
					H.out("o177 " + Std.string(true));
					this.f19 &= c172;
				} else {
					this.m9(false, c172);
				}
			};
			case _: {
				for (k178 => v179 in new Map<String, Int>()) {
					H.tick();
					this.f19 ^= v179;
				}
				H.out("o180 " + Std.string(this.f19));
			};
		}
		function lf181(n182:Int):Int {
			H.tick();
			return n182 <= 0 ? 116 : (lf181(n182 - 1) + n182);
		}
		H.out("lf181 " + lf181(4));
		this.f19 *= ((new A3(65535)).twice % H.nz(Reflect.compare(38, 263)));
		return (this.f17).x2;
	}
	override public function m13(a14:Int, a15:C5):String {
		H.tick();
		H.out("o183 " + Std.string(([K4.K4B] : Array<K4>)));
		var v184:Map<String, Array<Int>> = ((switch (K4.K4A) {
			case K4.K4A: new Map<String, Array<Int>>();
			case K4.K4B: (["k0" => this.f7, "k1" => [a14, a14, a14]] : Map<String, Array<Int>>);
			case K4.K4C: new Map<String, Array<Int>>();
			case _: (["k0" => [a14, a14]] : Map<String, Array<Int>>);
		}) : Map<String, Array<Int>>);
		var v185:Map<Int, S0> = new Map<Int, S0>();
		return (((("  pad  ").charCodeAt((-2147483647)) ?? -1) < 157) ? (0x80000000 + "  pad  ") : (this.f18).replace("a", "b"));
	}
	public function m28(a29:String, a30:Array<Int>):S0 {
		H.tick();
		var v186:Int = 203;
		function lf187(n188:Int):Int {
			H.tick();
			return n188 <= 0 ? this.f19 : (lf187(n188 - 1) + ((new Map<String, Int>()).get("k3") ?? 0));
		}
		H.out("lf187 " + lf187(3));
		for (i189 in 0...H.lim((~this.f19))) {
			H.tick();
			switch (H.id([v186, 1196551208])) {
				case []: {
					v186 <<= (v186 & 7);
				};
				case [c190]: {
					var v191:Array<String> = ("42").split(",");
					var v192:Map<Int, Int> = new Map<Int, Int>();
				};
				case [_, c193]: {
					v186++;
					final v194:Bool = false;
				};
				case _: {
					H.out("o195 " + Std.string((K4.K4B : Int)));
					var v196:Int = 0xD4A3;
				};
			}
		}
		try {
			if (false) throw 27;
			var v197:Map<Int, String> = new Map<Int, String>();
			final v198 = this.f19;
			(new C25(v186, 170)).m12();
		} catch (ex199:String) {
			H.out("caught String " + ex199);
			if (true) {
				var v200 = a29;
				H.out("o201 " + Std.string(((78 : A3) : Int)));
			}
		} catch (ex202:Int) {
			H.out("caught Int " + ex202);
			if (StringTools.endsWith("a", a29)) {
				var v203:A3 = new A3(ex202);
				var v204:C16 = new C16(206);
			} else {
				var v205:C5 = new C16(237);
			}
		} catch (ex206:Err) {
			H.out("caught Err " + ex206.errCode);
			var v207 = StringTools.startsWith(a29, a29);
		} catch (ex208:Dynamic) {
			H.out("caught " + H.exn(ex208));
			final lf209:() -> Int = () -> ((v186 : A3) : Int);
			v186--;
		}
		m21((new Map<Int, C38>()).exists(65535), this.f18, v186);
		return ({x1: a29, x2: v186} : S0);
	}
	public function m31():Bool {
		H.tick();
		final v210 = (((new Map<String, Int>()).get("k0") ?? 0) - (["\"q\""]).indexOf('$$'));
		H.out("o211 " + Std.string((K4.K4B : Int)));
		for (i212 in 0...H.lim((Std.parseInt(StringTools.hex((v210) & 0xFFFF, 4)) ?? 0))) {
			H.tick();
			H.out("o213 " + Std.string(i212));
			for (i214 in 0...H.lim(v210)) {
				H.tick();
				if (false) break;
				Ext.ext82("0");
			}
			var v215:Int = 0xFFFFFFFF;
		}
		Ext.ext85(148, v210);
		switch (({x1: "x,y,z", x2: (new A3(137)).get()} : S0)) {
			case {x1: c216}: {
				var v217:Array<String> = ["\\", c216];
			};
		}
		switch ((switch (Std.string(v210)) {
			case "a" | "b": "A-B-C";
			case "Haxe": Std.string(v210);
			case _: Std.string(v210);
		})) {
			case "a" | "b": {
				H.out("o218 " + Std.string(false));
				var v219:Array<Int> = [v210, v210, v210];
			};
			case "Haxe": {
				H.out("o220 " + Std.string(new C25(204, v210)));
			};
			case "": {
				if (true) {
					var v221:K4 = K4.K4B;
				} else {
					H.out("o222 " + Std.string(({x1: "42", x2: 0xF00} : S0)));
				}
			};
			case _: {
				var v223:Int = this.f19;
			};
		}
		if (([v210, 170, v210]).contains((-2147483647))) {
			var v224:Array<A3> = ([new A3(115)] : Array<A3>);
			var v225:Array<Bool> = [false, false, false];
		} else {
			for (x226 in ([] : Array<Int>)) {
				H.tick();
				var v227:Array<Int> = ([] : Array<Int>);
				var v228 = "a";
			}
		}
		return false;
	}
	public function m32(a33:Int, ...r34:Int):A3 {
		H.tick();
		H.out("o229 " + (cast (this.f18) : String));
		{
			var v230 = a33;
		}
		switch ((-2)) {
			case 0: {
				for (x231 in [a33]) {
					H.tick();
					a33 = x231;
				}
			};
			case 3 | 4: {
				(new C5()).m9(false, (K4.K4C : Int));
			};
			case _: {
				this.f6 = StringTools.contains("\\", "hello world");
				var w232 = 0;
do {
					w232++;
					H.tick();
					var v233 = a33;
					H.out("o234 " + Std.string(a33));
				} while (w232 < 4 && StringTools.startsWith("A-B-C", "\\"));
			};
		}
		switch (!(Std.downcast((new C16(188) : C16), C16) != null)) {
			case true: {
				this.m28("0", [a33, 77, a33]);
				H.out("o235 " + Std.string(true));
			};
			case false: {
				switch ("x,y,z") {
					case "a" | "b": {
						this.f19++;
						m13(0x5161, new C25(a33, a33));
					};
					case "Haxe": {
						this.m13(165, new C16(a33));
						var v236:Map<String, String> = (["k0" => "\\", "k1" => "-7", "k2" => "0"] : Map<String, String>);
					};
					case _: {
						var v237:Map<Int, Int> = new Map<Int, Int>();
					};
				}
				for (i238 in 0...2) {
					H.tick();
					a33 = 59;
				}
			};
		}
		if (false) {
			a33 = H.id(a33);
		}
		a33 *= 0xB80A;
		var w239 = 0;
do {
			w239++;
			H.tick();
			m12();
			if (false) {
				H.out("o240 " + Std.string(new C5()));
				if (false) break;
				m12();
			} else {
				this.f19 = a33;
			}
		} while (w239 < 2 && Std.isOfType(null, C51));
		for (i241 in 0...1) {
			H.tick();
			m12();
			final lf242:() -> Void = function():Void {
				H.tick();
				var v243:Int = a33;
				H.out("o244 " + Std.string(new C16(i241)));
			};
			H.out("o245 " + ("ab").substring((i241 & 7), (i241 & 7)));
		}
		return ((("q" < this.f18) ? new A3(a33) : new A3(a33)) : A3);
	}
	public function m35(a36:String, a37:Bool):Void {
		H.tick();
		var w246 = 0;
while (w246 < 3 && (new C25(0x2EE4, (-1710906611))).m31()) {
			w246++;
			H.tick();
			var v247:Array<Map<Int, String>> = ([new Map<Int, String>()] : Array<Map<Int, String>>);
		}
		this.f19 = 292;
		for (i248 in 1...H.lim(((([] : Array<Bool>)).indexOf(false) * (Std.parseInt(Std.string(0x49B9)) ?? 0)))) {
			H.tick();
			H.out("o249 " + Std.string(239));
			final lf250:() -> Int = () -> i248;
		}
		this.f19 = (this.f19 & (({x1: "\t", x2: 296} : S0)).x2);
		try {
			if ((new C25(65, 135)).m31()) throw new Err(((a36).charCodeAt((Std.parseInt(a36) ?? 0)) ?? -1));
			try {
				this.f19 = 205;
				this.f19 = 0x6036;
				this.f19 = 162;
				if (a37) throw new Err(155);
			} catch (ex251:String) {
				H.out("caught String " + ex251);
				a37 = true;
				H.out("o252 " + Std.string(false));
			} catch (ex253:Int) {
				H.out("caught Int " + ex253);
				Main.fn68(K4.K4B, true);
			} catch (ex254:Err) {
				H.out("caught Err " + ex254.errCode);
				var v255:K4 = K4.K4B;
			} catch (ex256:Dynamic) {
				H.out("caught " + H.exn(ex256));
				this.f19 |= 76;
			}
		} catch (ex257:Err) {
			H.out("caught Err " + ex257.errCode);
			var v258:S0 = this.f17;
			this.f19 ^= this.f19;
		} catch (ex259:haxe.Exception) {
			H.out("caught " + H.exn(ex259));
			Main.fn71(new C56(), a37, Reflect.compare(240, 105));
		}
	}
}
