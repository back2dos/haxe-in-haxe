package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext82(a81:String):Int {
		H.tick();
		for (k362 => v363 in new Map<String, Int>()) {
			H.tick();
			if (true) {
				if (false) break;
			}
			var v364:C5 = new C25(v363, 286);
		}
		H.out("o365 " + Std.string((((Std.isOfType(new C25((-10), 163), C5) ? ((-17) : A3) : new A3(0x6C86)) : A3) : Int)));
		var v366:K4 = K4.K4B;
		for (i367 in 0...0) {
			H.tick();
			(new C25(i367, i367)).m32((({x1: a81, x2: 52} : S0)).x2, i367, 279);
			switch ((a81).indexOf(a81)) {
				case 0: {
					var v368 = a81;
				};
				case 1 | 5: {
					var v369:K4 = v366;
				};
				case _: {
					var v370:Int = i367;
				};
			}
		}
		H.out("o371 " + Std.string(((K4.K4C : Int) + 180)));
		try {
			final v372:Null<Int> = 269;
			if (true) throw 76;
		} catch (ex373:Dynamic) {
			H.out("caught " + H.exn(ex373));
			var v374:A3 = new A3(26);
			(new C38((-9), [true, true, true])).m49(([a81]).length);
		}
		return 1785442213;
	}
	public static function ext85(a83:Int, a84:Int):Array<Int> {
		H.tick();
		var v375:Bool = false;
		((new C5()).m9(true, (("a").charCodeAt(a83) ?? -1))).m9(((({x1: "Haxe", x2: a84} : S0)).x2 >= (({x1: "", x2: a84} : S0)).x2), Main.fn65(("q").toUpperCase(), v375));
		a84 &= (switch (("zz").toUpperCase()) {
			case "a" | "b": 241;
			case "Haxe": (Std.parseInt(Std.string(a84)) ?? 0);
			case "": 171;
			case _: 0x7FFFFFFF;
		});
		var v376 = Std.string(StringTools.endsWith("zz", ""));
		var w377 = 0;
do {
			w377++;
			H.tick();
			var v378:A3 = new A3(142);
		} while (w377 < 4 && (switch (v376) {
			case "a" | "b": v375;
			case "Haxe": v375;
			case _: v375;
		}));
		v376 += "abc";
		final v379:C25 = new C25(a84, a84);
		var v380:Array<String> = [v376];
		a83 = (Std.parseInt(Std.string((({x1: v376, x2: 0xA2E9} : S0)).x2)) ?? 0);
		return [(a84 ^ a83), (cast (("  pad  ").lastIndexOf(v376)) : Int), a84];
	}
	public static function ext88(a86:String, a87:Int):String {
		H.tick();
		for (i381 in 0...0) {
			H.tick();
			a87 ^= i381;
			var v382:C16 = new C25(a87, a87);
			var v383:Int = (-1071632020);
		}
		var w384 = 0;
while (w384 < 3 && false) {
			w384++;
			H.tick();
			switch (144) {
				case 0: {
					H.out("o385 " + Std.string(true));
					var v386:A3 = new A3(180);
				};
				case 2 | 6: {
					final v387 = 169;
					if (false) break;
				};
				case _: {
					if (true) continue;
				};
			}
			a87 = (((["k0" => a87] : Map<String, Int>)).get("k2") ?? 0);
			var v388:Array<String> = ([] : Array<String>);
		}
		a87 = (new C25(a87, a87)).m12();
		for (i389 in 0...H.lim((a87 << (a87 & 31)))) {
			H.tick();
			switch (H.id([i389])) {
				case []: {
					final v390 = 138;
					var v391:Array<Int> = [v390, (-1381437143), i389];
				};
				case [c392]: {
					if (false) continue;
				};
				case [_, c393]: {
					var v394:Array<Int> = [276];
				};
				case _: {
					a87 = H.id(a87);
					H.out("o395 " + Std.string(i389));
				};
			}
			(new C38(154, [false, true, false])).m46();
		}
		a87 -= a87;
		for (i396 in 2...H.lim(Ext.ext82(a86))) {
			H.tick();
			switch ((K4.K4B : Int)) {
				case 0: {
					if (false) break;
					var v397:A3 = (a87 : A3);
				};
				case 2 | 5: {
					var v398:Map<String, Int> = new Map<String, Int>();
					var v399:Map<Int, Int> = ([-3 => a87, 4 => 0x5F15] : Map<Int, Int>);
				};
				case _: {
					final v400:Map<String, Int> = new Map<String, Int>();
				};
			}
		}
		var v401:C38 = (cast (new C38(a87, ([] : Array<Bool>))) : C38);
		a87 -= (false ? a87 : H.at([280, 299, a87], a87, 0));
		return ("q" + a86);
	}
}
