import H;
import p.M1;
using p.Ext;
using StringTools;

typedef S0 = {x1:String, x2:Int};

abstract A3(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A3, b:A3):A3
		return new A3(a.get() + b.get());

	@:op(A * B) public static function mul(a:A3, b:A3):A3
		return new A3(a.get() * b.get());

	@:op(-A) public static function neg(a:A3):A3
		return new A3(-a.get());
}

enum abstract K4(Int) to Int {
	var K4A = 1;
	var K4B = 4;
	var K4C = 7;
}

class C5 {
	public var f6:Bool;
	public var f7:Array<Int>;
	public var f8:Bool;
	public function new() {
		this.f6 = (new Map<String, C38>()).exists("k0");
		this.f7 = [76];
		this.f8 = false;
	}
	public function m9(a10:Bool, a11:Int):C5 {
		H.tick();
		final v89:Array<Int> = [(new A3(a11)).get(), 0xA59C];
		for (i90 in 0...H.lim((a11 * 277))) {
			H.tick();
			var w91 = 0;
do {
				w91++;
				H.tick();
				var v92:Array<Int> = ([] : Array<Int>);
				var v93:K4 = K4.K4B;
			} while (w91 < 3 && this.f6);
		}
		for (i94 in 0...H.lim((~47))) {
			H.tick();
			a11 <<= ((([] : Array<Bool>)).indexOf(a10) & 7);
			try {
				var v95 = a11;
				H.out("o96 " + "zz");
				var v97 = a10;
				if (a10) throw "abc";
			} catch (ex98:Dynamic) {
				H.out("caught " + H.exn(ex98));
				a11 &= i94;
			}
		}
		return new C5();
	}
	public function m12():Int {
		H.tick();
		var v99:Array<String> = ((Std.isOfType(new C5(), C16) ? ["hello world"] : ["\\", "  pad  ", "zz"]) : Array<String>);
		switch (62) {
			case 0: {
				var w100 = 0;
while (w100 < 3 && this.f8) {
					w100++;
					H.tick();
					H.out("o101 " + Std.string(new C25(190, 224)));
				}
				var v102:Map<String, Int> = (["k0" => 0x995A] : Map<String, Int>);
			};
			case 3 | 6: {
				if (false) {
					(new C25(122, (-8))).m9(true, 137);
				}
				var v103 = this.f8;
			};
			case _: {
				try {
					final v104 = 0xAE71;
					if (StringTools.endsWith("0", "42")) throw new Err(("").lastIndexOf("\t"));
				} catch (ex105:Dynamic) {
					H.out("caught " + H.exn(ex105));
					var v106:A3 = new A3(155);
				}
				for (i107 in 1...1) {
					H.tick();
					(new C16(i107)).m9(false, i107);
				}
			};
		}
		var v108:C5 = new C5();
		var v109:C16 = new C25(246, 17);
		var v110:S0 = ((switch (this.f6) {
			case true: ({x1: "ab", x2: 42} : S0);
			case false: ({x2: (-5), x1: "hello world"} : S0);
		}) : S0);
		var v111:Int = ((Std.parseInt(Std.string(0x9F80)) ?? 0) >> (8 & 31));
		for (x112 in ({ var v113 = ("hello world").charAt(3); [v111, v111, v111]; })) {
			H.tick();
			var v114 = false;
			H.out("o115 " + Std.string(v114));
		}
		switch (v110) {
			case {x1: c116}: {
				var v117 = (("abc").charCodeAt(v111) ?? -1);
				var v118:C25 = new C25(v111, 219);
			};
		}
		var w119 = 0;
while (w119 < 5 && Std.isOfType(new C16(v111), C25)) {
			w119++;
			H.tick();
			var w120 = 0;
do {
				w120++;
				H.tick();
				m9(true, v111);
				final v121:String = "Haxe";
				v111 = H.id(v111);
			} while (w120 < 4 && StringTools.endsWith("  pad  ", "42"));
			var v122:Bool = true;
		}
		return ((this.f6 || ([v111, v111, v111]).contains(66)) ? (Std.parseInt(Std.string((Std.parseInt("  pad  ") ?? 0))) ?? 0) : v111);
	}
	public function m13(a14:Int, a15:C5):String {
		H.tick();
		try {
			for (i123 in 0...H.lim((new A3(a14)).twice)) {
				H.tick();
				var v124 = "A-B-C";
				H.out("o125 " + Std.string(i123));
			}
			if (this.f6) throw new Err((({x1: "42", x2: a14} : S0)).x2);
		} catch (ex126:Err) {
			H.out("caught Err " + ex126.errCode);
			var v127:String = "hello world";
			(new C25(a14, a14)).m12();
		} catch (ex128:haxe.Exception) {
			H.out("caught " + H.exn(ex128));
			var v129:Int = ("\n").lastIndexOf("x,y,z");
			function lf130(n131:Int):Int {
				H.tick();
				return n131 <= 0 ? a14 : (lf130(n131 - 1) + a14);
			}
			H.out("lf130 " + lf130(5));
		}
		var v132 = (H.at([a14, a14, a14], a14, 0) >= (Std.parseInt(Std.string(163)) ?? 0));
		var w133 = 0;
while (w133 < 4 && (switch (1653200362) {
			case 0: true;
			case 3 | 6: StringTools.endsWith("\\", "hello world");
			case _: StringTools.endsWith("-7", "abc");
		})) {
			w133++;
			H.tick();
			final v134:Map<String, Int> = new Map<String, Int>();
			var w135 = 0;
do {
				w135++;
				H.tick();
				var v136 = a14;
				var v137:Bool = v132;
				if (false) break;
			} while (w135 < 1 && true);
		}
		var v138 = (this.f8 ? (["\n", "-7"]).join(" ") : "abc");
		final v139:Map<String, Int> = (["k0" => (v138).length] : Map<String, Int>);
		var v140:Array<Bool> = [false, true, false];
		return (((-977135779) != 62) ? "x,y,z" : v138);
	}
}

class C16 extends C5 {
	public var f17:S0;
	public var f18:String;
	public var f19:Int;
	public function new(a20:Int) {
		super();
		this.f17 = ({x1: "abc", x2: a20} : S0);
		this.f18 = StringTools.trim("\\");
		this.f19 = a20;
	}
	override public function m12():Int {
		H.tick();
		this.m9(true, this.f19);
		H.out("o141 " + Std.string(((Std.parseInt(Std.string(120)) ?? 0) >>> (this.f19 & 31))));
		var w142 = 0;
while (w142 < 4 && (cast (true) : Bool)) {
			w142++;
			H.tick();
			H.out("o143 " + Std.string(new C38(23, [false, true])));
		}
		this.f19 <<= (this.f19 & 7);
		switch (StringTools.hex((this.f19) & 0xFFFF, 4)) {
			case "a" | "b": {
				switch (38) {
					case 0: {
						var v144:Int = 82;
					};
					case 3 | 6: {
						this.f19 = 0x8439;
					};
					case c145 if (c145 > 10): {
						H.out("o146 " + Std.string(this.f17));
					};
					case _: {
						this.m9(true, 0x7FFFFFFF);
						this.m9(false, 116);
					};
				}
				if (true) return 264;
			};
			case "Haxe": {
				if (Std.isOfType(new C25(203, 228), C16)) {
					final v147:Int = 252;
					this.f19 = v147;
				}
				{
					this.f17 = ({x1: "0", x2: 53} : S0);
					var v148:S0 = this.f17;
					++this.f19;
				}
			};
			case "": {
				H.out("o149 " + Std.string(31));
				this.m9(true, (Std.parseInt(Std.string(205)) ?? 0));
			};
			case _: {
				switch ((K4.K4C : Int)) {
					case 0: {
						final v150 = 138;
						H.out("o151 " + Std.string(v150));
					};
					case 1 | 6: {
						var v152 = true;
					};
					case _: {
						var v153:C5 = new C25(1697855600, (-420138487));
					};
				}
				try {
					this.f18 += "\\";
					if (false) throw "a";
				} catch (ex154:Dynamic) {
					H.out("caught " + H.exn(ex154));
					H.out("o155 " + Std.string([246, 226]));
					H.out("o156 " + Std.string(0xAEA0));
				}
			};
		}
		return (-2147483647);
	}
	public function m21(a22:Bool, a23:String, ...r24:Int):Int {
		H.tick();
		this.f19 = m12();
		H.out("o157 " + Std.string((([a22]).length | this.f19)));
		switch (this.m12()) {
			case 0: {
				final v158 = 68;
			};
			case 3 | 6: {
				var v159:K4 = K4.K4C;
				H.out("o160 " + Std.string(((new Map<String, Int>()).get("k3") ?? 0)));
			};
			case c161 if (c161 > 10): {
				var w162 = 0;
while (w162 < 2 && true) {
					w162++;
					H.tick();
					H.out("o163 " + Std.string(new C56()));
					var v164 = c161;
				}
			};
			case _: {
				try {
					if (this.f6) throw "boom";
					var v165 = 119;
				} catch (ex166:Dynamic) {
					H.out("caught " + H.exn(ex166));
					final v167 = "\t";
				}
			};
		}
		this.f19 = m12();
		return ((a23).charCodeAt(this.m12()) ?? -1);
	}
}

class C38 {
	public final f39:Int;
	public var f40:Int;
	public var f41:Int;
	public function new(a42:Int, a43:Array<Bool>) {
		this.f39 = ("  pad  ").lastIndexOf("\t");
		this.f40 = ("x,y,z").length;
		this.f41 = (K4.K4B : Int);
	}
	public function m44(a45:Int):A3 {
		H.tick();
		final v260 = Ext.ext88("0", 262);
		a45 = (new C16(a45)).m21(true, "ab");
		var v261:C5 = new C16((-1694581085));
		var v262:Int = this.f41;
		return (-(new A3(273) * new A3(a45)));
	}
	public function m46():Int {
		H.tick();
		var v263:Map<String, Bool> = ((false ? (["k0" => true, "k1" => false, "k2" => false] : Map<String, Bool>) : new Map<String, Bool>()) : Map<String, Bool>);
		final v264:Null<Int> = ((([-3 => 252] : Map<Int, Int>)).get(4) ?? 0);
		(((false ? new C25((-1), (-1459627518)) : new C25(0x3986, 92)) : C25)).m13(203, new C5());
		var v265:Map<Int, String> = ([-3 => "a", 4 => ("zz").replace("a", "b"), 11 => "0"] : Map<Int, String>);
		H.out("o266 " + (false ? Std.string(false) : StringTools.lpad("hello world", "*", 0)));
		if ((165 >= ("\n").lastIndexOf("q"))) {
			(new C25(131684934, 14)).m12();
			switch (this.f41) {
				case 0: {
					var v267:Map<String, Int> = new Map<String, Int>();
				};
				case 3 | 4: {
					(new C25(110, (-2))).m28("  pad  ", [27, 238]);
				};
				case _: {
					var v268:C25 = new C25(165, 272);
					var v269:String = "\\";
				};
			}
		}
		var v270 = (Std.parseInt("\\") ?? 0);
		return (new C16((-6))).m21(!StringTools.endsWith("-7", "x,y,z"), "\t");
	}
	public function m47(a48:Bool):String {
		H.tick();
		var v271 = ((((["k0" => 237] : Map<String, Int>)).get("k3") ?? 0) * (("q").charCodeAt(132) ?? -1));
		for (k273 => x272 in ((switch (181) {
			case 0: ["", "q"];
			case 1 | 6: ([] : Array<String>);
			case _: ["A-B-C", "\t", ""];
		}) : Array<String>)) {
			H.tick();
			var v274:Int = (({x1: x272, x2: 80} : S0)).x2;
			switch ("\\") {
				case "a" | "b": {
					var v275:Map<String, A3> = (["k0" => new A3(113)] : Map<String, A3>);
					H.out("o276 " + x272);
				};
				case "Haxe": {
					var v277:S0 = ({x1: "x,y,z", x2: k273} : S0);
					if (false) break;
				};
				case "": {
					final v278 = 120;
					this.f40 = v271;
				};
				case _: {
					H.out("o279 " + Std.string([a48, a48]));
				};
			}
			var v280:Map<Int, Int> = ([-3 => v271, 4 => v271, 11 => k273] : Map<Int, Int>);
		}
		(new C25(v271, ((([-3 => 277, 4 => v271, 11 => 149] : Map<Int, Int>)).get(-3) ?? 0))).m35(("-7").charAt(((Std.parseInt(Std.string(v271)) ?? 0) & 7)), (false ? StringTools.endsWith("Haxe", "\t") : false));
		switch (((("abc").split("-")).join("|")).toUpperCase()) {
			case "a" | "b": {
				var v281:C16 = new C16(v271);
			};
			case "Haxe": {
				var v282:String = ('$$').charAt((v271 & 7));
				if (StringTools.contains(v282, "\"q\"")) return v282;
			};
			case _: {
				H.out("o283 " + Std.string(([new C25(v271, v271)] : Array<C5>)));
			};
		}
		return ([v271, v271]).join("");
	}
	public function m49(a50:Int):Void {
		H.tick();
		a50 = H.id(a50);
		(new C25(a50, a50)).m12();
		a50 &= ((new A3(a50)).twice & (Std.parseInt('$$') ?? 0));
		H.out("o284 " + Std.string(({ var v285 = this.f40; false; })));
		for (i286 in 0...H.lim((-2147483647))) {
			H.tick();
			for (i287 in 1...1) {
				H.tick();
				var v288:C56 = new C56();
				var v289:Array<String> = ([] : Array<String>);
				H.out("o290 " + Std.string(a50));
			}
			this.f41 *= this.f40;
			H.out("o291 " + Std.string(new C56()));
		}
		var v292:Array<Int> = ((switch (({x1: "\"q\"", x2: a50} : S0)) {
			case {x1: c293}: ([] : Array<Int>);
		}) : Array<Int>);
		H.out("o294 " + Std.string((new C25(0xE2C2, a50)).m28("0", ([] : Array<Int>))));
		H.out("o295 " + Std.string(0xFFFFFFFF));
	}
}

abstract class C51 {
	public var f52:Int;
	public var f53:String;
	public function new(a54:Bool, a55:Array<String>) {
		this.f52 = 281;
		this.f53 = ("x,y,z").toLowerCase();
	}
}

class C56 {
	public var f57:Int;
	public var f58:Bool;
	public final f59:String;
	public function new() {
		this.f57 = (Std.parseInt("A-B-C") ?? 0);
		this.f58 = true;
		this.f59 = "-7";
	}
	public function m60():Int {
		H.tick();
		H.out("o296 " + ({ var v297 = StringTools.trim("-7"); this.f59; }));
		H.out("o298 " + Std.string((cast ((([] : Array<String>)).length) : Int)));
		var v299:Int = (((["k0" => 0xD6FF, "k1" => 430373841, "k2" => 31] : Map<String, Int>)).get("k1") ?? 0);
		H.out("o300 " + Std.string((v299 << (("ab").length & 31))));
		for (x301 in [(Std.parseInt(Std.string(v299)) ?? 0)]) {
			H.tick();
			(new C38(v299, [true, false, true])).m44(v299);
			H.out("o302 " + this.f59);
			this.f57 = ((v299 : A3) : Int);
		}
		return 206;
	}
	public function m61():K4 {
		H.tick();
		final lf303:() -> Int = () -> (new A3(0x7FFFFFFF)).twice;
		if ((('$$').length == (new A3(101)).twice)) {
			H.out("o304 " + Std.string(this.f57));
			H.out("o305 " + Std.string(new C16(274)));
			H.out("o306 " + Std.string(([78, 124]).indexOf(94)));
		}
		final v307:Array<Int> = ([] : Array<Int>);
		for (x308 in v307) {
			H.tick();
			if ((([-3 => new C25(x308, x308), 4 => new C25(34, x308)] : Map<Int, C25>)).exists(-3)) {
				final v309:Int = 94;
				var v310:Int = 243;
			} else {
				this.f57 *= x308;
			}
		}
		return K4.K4C;
	}
	public function m62(a63:String, a64:C25):Int {
		H.tick();
		switch (this.f58) {
			case true: {
				var v311:Array<String> = ([] : Array<String>);
				var w312 = 0;
while (w312 < 4 && (Std.downcast((null : C51), C51) != null)) {
					w312++;
					H.tick();
					var v313 = true;
					var v314 = (-2147483647);
				}
			};
			case false: {
				var v315:Map<String, Int> = new Map<String, Int>();
				var v316:C16 = a64;
			};
		}
		var v317:String = (a63).substr(4, (45 & 7));
		var v318 = this.f58;
		H.out("o319 " + Std.string(v318));
		switch (((([] : Array<Bool>)).indexOf(v318) ^ 0x4035)) {
			case 0: {
				for (x320 in ([] : Array<Int>)) {
					H.tick();
					H.out("o321 " + Std.string(((x320 : A3) : Int)));
					(new C25(x320, 81)).m35(a63, v318);
					var v322:Array<Int> = [x320, x320, x320];
				}
			};
			case 3 | 4: {
				this.f57 = (new A3(17) : Int);
			};
			case _: {
				var v323 = v318;
			};
		}
		for (i324 in 0...H.lim((this.f57 << (205 & 31)))) {
			H.tick();
			final v325:Array<Int> = [i324, i324];
		}
		return (String.fromCharCode(65 + ((((([-3 => (-2147483647)] : Map<Int, Int>)).get(18) ?? 0)) & 15))).indexOf(((v317).replace("a", "b")).substring(3, (219 & 7)));
	}
}

class Main {
	public static function fn65(a66:String, a67:Bool):Int {
		H.tick();
		H.out("o326 " + '$$');
		final v327:Int = H.at(([] : Array<Int>), (K4.K4B : Int), 0);
		if (!(([] : Array<Int>)).contains(v327)) {
			var v328 = v327;
			H.out("o329 " + Std.string(v327));
		}
		return (cast (v327) : Int);
	}
	public static function fn68(a69:K4, a70:Bool):Int {
		H.tick();
		final v330:Array<Bool> = ([] : Array<Bool>);
		var v331:A3 = new A3(65535);
		H.out("o332 " + Std.string(('$$').lastIndexOf((["0"]).join("|"))));
		for (i333 in 0...4) {
			H.tick();
			H.out("o334 " + Std.string(true));
		}
		if ((78 == (-1497872661))) {
			for (x335 in v330) {
				H.tick();
				(new C25(224, 133)).m12();
				var v336:K4 = a69;
			}
		} else {
			var v337:Array<String> = ["42"];
			for (x338 in ["a"]) {
				H.tick();
				H.out("o339 " + Std.string(new C56()));
			}
		}
		return ((new C38(285, v330)).m46() >> (72 & 31));
	}
	public static function fn71(a72:C56, a73:Bool, a74:Int):S0 {
		H.tick();
		var v340 = (new C16(a74)).m12();
		for (i341 in 0...1) {
			H.tick();
			var v342:C25 = new C25(a74, a74);
			v340 += 297;
			if (true) {
				if (a73) continue;
				v340 -= a74;
			} else {
				a74 = v340;
			}
		}
		if (a73) {
			if (a73) {
				var v343:Int = a74;
				var v344:Map<String, String> = (["k0" => "-7", "k1" => "zz", "k2" => "abc"] : Map<String, String>);
				a74 <<= (a74 & 7);
			} else {
				H.out("o345 " + Std.string(([v340] : Array<Null<Int>>)));
			}
			switch (a74) {
				case 0: {
					var v346:A3 = new A3(v340);
				};
				case 3 | 6: {
					var v347 = 287;
				};
				case _: {
					var v348 = 116;
					var v349 = 14;
				};
			}
			(new C25(v340, a74)).m13(Reflect.compare(a74, a74), new C25(a74, 0x80000000));
		}
		v340 = ((([] : Array<Int>)).contains(a74) ? 279 : 53);
		(new C16(a74)).m12();
		return ({x1: (([a74, v340, v340]).contains(146) + (([] : Array<Bool>)).join(",")), x2: (a74 | (K4.K4A : Int))} : S0);
	}
	public static function fn75(a76:Array<Int>):Array<String> {
		H.tick();
		H.out("o350 " + Std.string(new C38(H.at([118, 95, 34], 129, 0), ([] : Array<Bool>))));
		if ((((0xA76F : A3)).get() != 65535)) {
			var v351:C5 = new C5();
			(new C25(127, 18)).m12();
		}
		H.out("o352 " + Std.string(([] : Array<String>)));
		return [({ var v353 = (Std.parseInt(Std.string(299)) ?? 0); Std.string(true); }), StringTools.hex((139) & 0xFFFF, 4)];
	}
	public static function fn77(a78:String, a79:String, a80:Null<Int>):Void {
		H.tick();
		H.out("o354 " + Std.string((true || ([232]).contains(0x833A))));
		H.out("o355 " + Std.string(((new A3(9) : Int) > 210)));
		for (i356 in 0...1) {
			H.tick();
			var v357 = '$$';
		}
		var v358:Int = (((([-3 => 35] : Map<Int, Int>)).get(248) ?? 0) + 215);
		for (k360 => x359 in ((StringTools.endsWith(a78, a79) ? [v358, v358] : [v358, v358]) : Array<Int>)) {
			H.tick();
			H.out("o361 " + Std.string([k360, x359, 131]));
		}
	}
	public static function section0():Void {
		H.tick();
		switch (K4.K4C) {
			case K4.K4A: {
				H.out("o402 " + Std.string(({x1: "x,y,z", x2: 0xC037} : S0)));
				final v403:A3 = (154 : A3);
			};
			case K4.K4B: {
				fn68(K4.K4B, false);
			};
			case K4.K4C: {
				for (i404 in 0...H.lim((K4.K4B : Int))) {
					H.tick();
					H.out("o405 " + Std.string(i404));
					var v406:C38 = new C38(i404, ([] : Array<Bool>));
				}
			};
		}
		var w407 = 0;
while (w407 < 4 && false) {
			w407++;
			H.tick();
			H.out("o408 " + Std.string((new A3(192) : Int)));
		}
		var v409:C5 = new C16(222);
		var v410:String = (("0").toUpperCase() + "-7");
		H.out("o411 " + (new C38(95, [false, true, false])).m47(true));
	}
	public static function section1():Void {
		H.tick();
		H.out("o412 " + Std.string(new C25(("\"q\"").lastIndexOf("0"), H.at(([] : Array<Int>), 267, 0))));
		for (i413 in 0...2) {
			H.tick();
			(new C5()).m13(([0xA790]).length, new C5());
			(new C25(i413, i413)).m13(H.at([i413], i413, 0), new C16(i413));
		}
		var w414 = 0;
while (w414 < 1 && (false ? StringTools.contains("  pad  ", "  pad  ") : false)) {
			w414++;
			H.tick();
			(new C25(194, 0xA81F)).m28(("0").toUpperCase(), ([] : Array<Int>));
			(new C56()).m61();
			fn65("  pad  ", StringTools.startsWith("0", "\\"));
		}
		H.out("o415 " + Std.string(([K4.K4A, K4.K4B, K4.K4B] : Array<K4>)));
		var w416 = 0;
while (w416 < 5 && StringTools.contains("a", ("").replace("a", "b"))) {
			w416++;
			H.tick();
			{
				final v417:Array<Int> = [962070011];
			}
		}
		var v418:Int = 136;
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
