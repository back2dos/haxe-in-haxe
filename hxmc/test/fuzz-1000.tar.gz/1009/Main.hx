import H;
import p.M1;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Int, a2:String);
	E0C(a3:String, a4:String);
}

class Main {
	public static inline function fn6(a7:Bool):Int {
		H.tick();
		function lf26(n27:Int):Int {
			H.tick();
			return n27 <= 0 ? Reflect.compare((("\u{1F600}").charCodeAt(n27) ?? -1), (Std.parseInt("q") ?? 0)) : (lf26(n27 - 1) + ((-1661130696) >>> (((new Map<Int, Int>()).get(n27) ?? 0) & 31)));
		}
		H.out("lf26 " + lf26(5));
		final v28:(Int, Int) -> Int = (((E0.E0C("\u{1F600}", "42")).match(E0B(_, _)) ? function(p29:Int, p30:Int):Int {
			H.tick();
			var v31 = (-832282110);
			final v32 = (-1778799708);
			return 257;
		} : (p33:Int, p34:Int) -> p34) : (Int, Int) -> Int);
		var v35:String = "\n";
		final v36:Int = Type.enumIndex(E0A);
		for (i37 in 2...H.lim(v36)) {
			H.tick();
			H.out("o38 " + Std.string(111));
		}
		var v39:Int = ((v35).indexOf(v35) + v36);
		return v28((v39 >>> (((v35).charCodeAt(v36) ?? -1) & 31)), v36);
	}
	public static function fn8(a9:Bool, a10:Int):Void {
		H.tick();
		var v40 = (switch (false) {
			case true: ("\t").lastIndexOf("hello world");
			case false: 98;
		});
		var v41 = ("  pad  ").toLowerCase();
		H.out("o42 " + Std.string((a10 <= (v41).lastIndexOf("\n"))));
		if (a9) {
			if ((E0B(v40, v41)).match(E0B(_, _))) {
				var v43:String = "\\";
				var v44 = 532082754;
				fn6(a9);
			}
		} else {
			var w45 = 0;
while (w45 < 3 && ([a10, a10]).contains(288)) {
				w45++;
				H.tick();
				a10 |= v40;
				H.out("o46 " + Std.string(true));
			}
			switch (v40) {
				case 0: {
					H.out("o47 " + Std.string(true));
				};
				case 3 | 6: {
					H.out("o48 " + Std.string(E0.E0C(v41, "a\rb")));
				};
				case _: {
					var v49:Bool = a9;
				};
			}
		}
	}
	public static inline function fn11():Void {
		H.tick();
		for (x50 in [65535, 0xFB92]) {
			H.tick();
			if (false) {
				fn8(true, x50);
				var v51:Array<Bool> = [false];
				var v52:Array<E0> = ([E0.E0C("  pad  ", "q"), E0B((-2147483647), "é"), E0C("\n", "Haxe")] : Array<E0>);
			}
		}
		if ((new Map<Int, String>()).exists(11)) {
			H.out("o53 " + Std.string((E0A).match(E0C(_, _))));
			var v54:Map<String, Int> = (["k0" => 0xDB25, "k1" => (-114701623), "k2" => 108] : Map<String, Int>);
		} else {
			if (true) {
				var v55 = 57;
				v55 -= v55;
				var v56:Map<String, Int> = new Map<String, Int>();
			} else {
				var v57 = "hello world";
			}
		}
		final lf58:() -> Int = () -> ((((["k0" => 27] : Map<String, Int>)).get("k2") ?? 0) << ((([] : Array<String>)).indexOf("a") & 31));
		var v59:Map<String, Int> = (["k0" => (K5.K5C : Int), "k1" => (("\x41\x42").charCodeAt(168) ?? -1)] : Map<String, Int>);
		Main.fn6((StringTools.trim("a") != (([] : Array<Bool>)).join("")));
	}
	public static function fn12(a13:String, a14:Int = -2):String {
		H.tick();
		for (i60 in 0...H.lim((208 >> (81 & 31)))) {
			H.tick();
			var w61 = 0;
while (w61 < 2 && true) {
				w61++;
				H.tick();
				var v62:String = "a\rb";
			}
		}
		var v63:Map<Int, Int> = new Map<Int, Int>();
		switch (Main.fn6(((["k0" => a14] : Map<String, Int>)).exists("k2"))) {
			case 0: {
				if (true) {
					var v64:String = a13;
					H.out("o65 " + Std.string(([] : Array<Bool>)));
				}
				if (StringTools.startsWith(a13, a13)) return "a";
			};
			case 2 | 4: {
				a14--;
				final v66:Map<String, Bool> = new Map<String, Bool>();
			};
			case _: {
				var v67:E0 = E0.E0A;
			};
		}
		H.out("o68 " + "ünï");
		H.out("o69 " + Std.string(true));
		H.out("o70 " + Std.string((194 * a14)));
		switch ((StringTools.contains(a13, a13) ? StringTools.endsWith(a13, a13) : true)) {
			case true: {
				var v71 = Std.string(a14);
			};
			case false: {
				var v72 = Reflect.compare(a14, a14);
				if (((["k0" => "", "k1" => a13] : Map<String, String>)).exists("k0")) return ((a13).split(",")).join(" ");
			};
		}
		H.out("o73 " + "Haxe");
		return (a13 + a13);
	}
	public static function fn15():String {
		H.tick();
		H.out("o74 " + Std.string((true ? ((["k0" => null, "k1" => 0x7F32, "k2" => null] : Map<String, Null<Int>>)).exists("k1") : false)));
		switch (E0.E0C("\t", "x,y,z")) {
			case E0A: {
				var v75:Map<Int, Int> = new Map<Int, Int>();
			};
			case E0B(c76, c77) if (c76 > 4): {
				final v78 = StringTools.endsWith("A-B-C", "hello world");
			};
			case E0C(c79, _): {
				if (true) {
					Ext.ext23(229, (p80:Int) -> c79);
					var v81:String = c79;
				} else {
					H.out("o82 " + c79);
				}
			};
			case _: {
				final lf83:(Int, Int) -> Bool = (p84:Int, p85:Int) -> StringTools.contains("\x41\x42", "a\rb");
				var v86:Array<Bool> = [true, false, true];
			};
		}
		var w87 = 0;
do {
			w87++;
			H.tick();
			for (i88 in 0...1) {
				H.tick();
				(87).ext25();
				var v89:Array<Int> = [i88, i88, i88];
			}
			for (i90 in 0...H.lim(("A-B-C").indexOf("\t"))) {
				H.tick();
				final v91:() -> Int = () -> i90;
				H.out("o92 " + Std.string(false));
				var v93:Bool = true;
			}
		} while (w87 < 1 && ((("\\").split("-")).indexOf("hello world") != ("abc").length));
		switch (E0A) {
			case E0A: {
				final v94 = 135;
				switch ("a\rb") {
					case "a" | "b": {
						var v95 = "abc";
						var v96:Array<Int> = ([] : Array<Int>);
					};
					case "Haxe": {
						var v97 = "q";
						var v98:Array<Box<Bool>> = ([new Box(false), new Box(true)] : Array<Box<Bool>>);
					};
					case _: {
						var v99:Array<Array<E0>> = ([([E0A, E0A] : Array<E0>), ([E0C("\u{1F600}", "abc")] : Array<E0>), ([] : Array<E0>)] : Array<Array<E0>>);
						(v94).ext25();
					};
				}
			};
			case E0B(_, c100): {
				final v101:() -> Int = function():Int {
					H.tick();
					final v102:(String) -> String = (p103:String) -> "  pad  ";
					var v104 = false;
					var v105:Int = 89;
					return v105;
				};
				var v106:Array<Array<Int>> = ([([] : Array<Int>), [5, 51, 57], [107, 282]] : Array<Array<Int>>);
			};
			case E0C(c107, c108): {
				if (true) {
					final v109:Int = 65535;
				} else {
					final v110:Box<E0> = new Box<E0>(E0.E0A);
					var v111:Map<String, Int> = (["k0" => 89, "k1" => 201, "k2" => 261] : Map<String, Int>);
				}
				fn6(([266]).contains(287));
			};
			case _: {
				switch (H.id([12, 106, 1246978353])) {
					case []: {
						fn8(true, 228);
						var v112 = 241;
					};
					case [c113]: {
						var v114 = "hello world";
					};
					case [_, c115]: {
						Main.fn8(false, c115);
						H.out("o116 " + "\t");
					};
					case _: {
						var v117:Array<() -> Int> = ([function():Int {
							H.tick();
							H.out("o118 " + Std.string(193));
							var v119:Int = 298;
							v119++;
							return 0x7FFFFFFF;
						}] : Array<() -> Int>);
					};
				}
			};
		}
		var v120:K5 = K5.K5C;
		switch (E0.E0A) {
			case E0A: {
				function lf121(n122:Int):Int {
					H.tick();
					return n122 <= 0 ? n122 : (lf121(n122 - 1) + Lambda.fold([n122, (-16), 160], (v123:Int, v124:Int) -> (v120 : Int), 0));
				}
				H.out("lf121 " + lf121(3));
				if (((["k0" => 125] : Map<String, Int>)).exists("k2")) {
					H.out("o125 " + Std.string(135));
				} else {
					H.out("o126 " + Std.string((-855989024)));
					var v127:Int = 274;
				}
			};
			case E0B(c128, c129) if (c128 > 4): {
				final v130:Null<Int> = c128;
				Main.fn8(([c128]).contains(c128), (Std.parseInt(Std.string(c128)) ?? 0));
			};
			case E0C(c131, c132): {
				var v133:Bool = StringTools.startsWith(c131, c132);
			};
			case _: {
				var v134:Int = (Std.parseInt(Std.string(47)) ?? 0);
			};
		}
		H.out("o135 " + fn12("0", 28));
		var v136:Map<String, String> = new Map<String, String>();
		var w137 = 0;
while (w137 < 5 && (StringTools.startsWith("ab", "a") || (E0A).match(E0A))) {
			w137++;
			H.tick();
			Main.fn8(true, ((new Map<Int, Int>()).get(11) ?? 0));
			final v138:Array<String> = ["\"q\"", "a", "A-B-C"];
			final v139 = false;
		}
		return (switch (Std.string(E0.E0C("é", "\n"))) {
			case "a" | "b": Std.string(274);
			case "Haxe": "\t";
			case "": Std.string(0x45B9);
			case _: Std.string((-2000396593));
		});
	}
	public static function fn16(a17:Int, a18:Bool):String {
		H.tick();
		switch (E0B((Std.parseInt(Std.string(a17)) ?? 0), "\u{1F600}")) {
			case E0A: {
				a17 -= a17;
			};
			case E0B(_, c140): {
				H.out("o141 " + Std.string([a17]));
				final lf142:(Bool) -> String = function(p143:Bool):String {
					H.tick();
					Ext.ext25(a17);
					H.out("o144 " + "\"q\"");
					var v145:Map<String, Int> = new Map<String, Int>();
					return (c140).toUpperCase();
				};
			};
			case E0C(_, c146): {
				a17 = H.id(a17);
				H.out("o147 " + StringTools.hex((74) & 0xFFFF, 4));
			};
		}
		H.out("o148 " + Std.string(E0.E0B(Type.enumIndex(E0B(a17, "A-B-C")), "é")));
		(a17).ext23(((switch (0x8CB4) {
			case 0: function(p149:Int):String {
				H.tick();
				var v150 = 168;
				return "q";
			};
			case 3 | 6: (p151:Int) -> "-7";
			case c152 if (c152 > 10): (p153:Int) -> "é";
			case _: (p154:Int) -> "x,y,z";
		}) : (Int) -> String));
		fn12((a18 ? "\n" : ("abc").toUpperCase()), 814665579);
		fn12("42", a17);
		Main.fn6(([a17, 260, a17]).contains(a17));
		if (a18) {
			fn6((E0.E0B(295, "")).match(E0B(_, _)));
			H.out("o155 " + "0");
			final v156 = ("日本語").substr((a17 & 7), (a17 & 7));
		}
		for (x157 in [("-7").replace("a", "b"), "ab", Std.string(E0C("hello world", "x,y,z"))]) {
			H.tick();
			var v158:Bool = a18;
			for (k160 => x159 in [a18]) {
				H.tick();
				H.out("o161 " + x157);
			}
		}
		Main.fn6(a18);
		return (String.fromCharCode(65 + ((107) & 15)) + ([a18, true]).join(","));
	}
	public static function fn19(a20:String):Int {
		H.tick();
		for (i162 in 2...4) {
			H.tick();
			if (([184]).contains(i162)) {
				var v163 = i162;
				var v164:Array<E0> = ([E0B(v163, a20)] : Array<E0>);
				Main.fn16(v163, true);
			}
			H.out("o165 " + Std.string(E0A));
			var v166 = Std.string(E0C("-7", a20));
		}
		final v167 = (([false]).join(",") + ([0x7FFFFFFF, 0x1E6D]).length);
		H.out("o168 " + Std.string((false || (E0A).match(E0A))));
		final lf169:() -> Int = function():Int {
			H.tick();
			var v170:Map<Int, Bool> = new Map<Int, Bool>();
			var v171 = 0x491D;
			return (v171 & (-932865345));
		};
		var v172 = ([155, 270]).contains(([v167, a20]).indexOf(v167));
		if (v172) {
			if (((["k0" => 203, "k1" => 296, "k2" => 203] : Map<String, Int>)).exists("k3")) {
				final v173:(Int) -> String = function(p174:Int):String {
					H.tick();
					var v175:Map<Int, Int> = ([-3 => p174] : Map<Int, Int>);
					var v176:Int = 279;
					return v167;
				};
				H.out("o177 " + Std.string(1458359079));
			} else {
				H.out("o178 " + Std.string(42));
				(809589857).ext25();
			}
			for (i179 in 0...3) {
				H.tick();
				var v180 = a20;
				final v181:Box<String> = new Box(a20);
			}
			(251).ext25();
		} else {
			var v182:Map<String, Int> = new Map<String, Int>();
			var v183:E0 = E0A;
		}
		return (Std.parseInt(Std.string((Std.parseInt("\\") ?? 0))) ?? 0);
	}
	public static function section0():Void {
		H.tick();
		switch ((false ? "\\" : (("42").split("-")).join(" "))) {
			case "a" | "b": {
				(Type.enumIndex(E0A)).ext23((p200:Int) -> "hello world");
			};
			case "Haxe": {
				var v201:Array<String> = ["\u{1F600}", "a", "abc"];
			};
			case "": {
				var v202:Box<String> = new Box<String>("a\rb");
				var v203:Box<String> = v202;
			};
			case _: {
				(Lambda.fold([346404032, 64], (v204:Int, v205:Int) -> 173, 0)).ext23(function(p206:Int):String {
					H.tick();
					final v207:(Int) -> Bool = (p208:Int) -> false;
					return "abc";
				});
				H.out("o209 " + Std.string(275));
			};
		}
		for (k210 => v211 in new Map<String, Int>()) {
			H.tick();
			final v212:Array<String> = ["-7", k210, k210];
			var v213:String = k210;
			var v214 = k210;
		}
		var v215:Map<Int, Box<Int>> = ([-3 => new Box(65535), 4 => new Box<Int>(240)] : Map<Int, Box<Int>>);
		var v216 = Lambda.fold(([] : Array<Int>), (v217:Int, v218:Int) -> (("42").charCodeAt(267) ?? -1), 0);
	}
	public static function section1():Void {
		H.tick();
		H.out("o219 " + Std.string(true));
		H.out("o220 " + Std.string(E0A));
		final v221:() -> String = function():String {
			H.tick();
			var v222:Box<String> = new Box("x,y,z");
			return "\x41\x42";
		};
		if ((StringTools.endsWith("ünï", "\n") ? false : true)) {
			switch (Lambda.fold([110, 263], (v223:Int, v224:Int) -> Lambda.count(([] : Array<Int>), v225 -> false), 0)) {
				case 0: {
					final v226:Array<Int> = [0xB13, 148];
					var v227:Map<String, String> = (["k0" => "-7", "k1" => "a", "k2" => "a"] : Map<String, String>);
				};
				case 2 | 5: {
					final v228:(Bool, Int) -> Int = function(p229:Bool, p230:Int):Int {
						H.tick();
						final v231:Bool = p229;
						(0x9646).ext23((p232:Int) -> "Haxe");
						return 492789875;
					};
				};
				case _: {
					var v233 = 787770833;
				};
			}
			H.out("o234 " + Std.string(([] : Array<Int>)));
			fn19(StringTools.trim(""));
		} else {
			final lf235:(Int) -> Int = function(p236:Int):Int {
				H.tick();
				var v237:Map<Int, Int> = new Map<Int, Int>();
				var v238:Box<Bool> = new Box<Bool>(false);
				return (K5.K5B : Int);
			};
		}
		var v239:String = "-7";
		var v240 = (-(-1146585614));
	}
	public static function section2():Void {
		H.tick();
		final lf241:(Int) -> String = (p242:Int) -> ("zz" + "zz");
		final v243:(Int, Int) -> Bool = (p244:Int, p245:Int) -> true;
		var v246 = fn6(false);
		var v247 = (StringTools.contains("x,y,z", "zz") ? Std.string(E0.E0C("日本語", "")) : "Haxe");
		var v248 = (E0C("Haxe", v247)).match(E0B(_, _));
		var v249:String = (v247 + Type.enumIndex(E0B(v246, v247)));
		Ext.ext23(Main.fn6(([v246, v246, v246]).contains(v246)), lf241);
		var v250 = v246;
	}
	public static function section3():Void {
		H.tick();
		var v251:Array<Int> = [((new Map<String, Int>()).get("\x41\x42") ?? 0), 0x7FFFFFFF];
		final v252:Int = (K5.K5D : Int);
		{
			var v253:String = StringTools.hex((186) & 0xFFFF, 4);
		}
		H.out("o254 " + Std.string(v252));
	}
	public static function section4():Void {
		H.tick();
		var v255:E0 = E0.E0A;
		switch (E0.E0C(StringTools.hex((0xC2C3) & 0xFFFF, 4), "x,y,z")) {
			case E0A: {
				final v256:Map<Int, Int> = ([-3 => 0x33D, 4 => 233] : Map<Int, Int>);
				if (([11, (-6)]).contains(133)) {
					H.out("o257 " + "\"q\"");
					var v258:Box<Box<String>> = new Box<Box<String>>(new Box("0"));
					fn11();
				}
			};
			case E0B(_, c259): {
				var v260:Map<String, Array<Int>> = new Map<String, Array<Int>>();
			};
			case E0C(c261, c262): {
				Main.fn16(((([-3 => 271] : Map<Int, Int>)).get(4) ?? 0), true);
				for (x263 in ([] : Array<Bool>)) {
					H.tick();
					H.out("o264 " + Std.string(27));
					H.out("o265 " + Std.string(147));
				}
			};
			case _: {
				var v266:Map<String, Int> = new Map<String, Int>();
			};
		}
		var v267:Array<String> = ((true ? ["日本語", "0", ""] : ["\t", "q", "ünï"]) : Array<String>);
		final lf268:() -> Bool = () -> (switch (v255) {
			case E0A: true;
			case E0B(c269, c270): ([c269]).contains(c269);
			case E0C(c271, c272): ([(-18), 89]).contains(56);
		});
		var v273 = (0x7FFFFFFF - ("ab").indexOf("\u{1F600}"));
		final v274:(String, String) -> Bool = (p275:String, p276:String) -> ([v273]).contains(v273);
		switch (v255) {
			case E0A: {
				v273 = H.id(v273);
				for (i277 in 0...H.lim(v273)) {
					H.tick();
					var v278:K5 = K5.K5C;
				}
			};
			case E0B(c279, c280) if (c279 > 2): {
				var v281:Map<String, Int> = (["k0" => 0xAEB4, "k1" => v273] : Map<String, Int>);
				var v282:E0 = E0.E0B(89, "ab");
			};
			case E0C(c283, c284): {
				var v285:Int = (("hello world").charCodeAt(v273) ?? -1);
				for (i286 in 2...H.lim(("\x41\x42").indexOf("\x41\x42"))) {
					H.tick();
					var v287:Int = i286;
					v285 += v287;
				}
			};
			case _: {
				switch (v255) {
					case E0A: {
						var v288 = "\"q\"";
					};
					case E0B(_, c289): {
						Main.fn8(false, 0x91F5);
						var v290:Array<Int> = [v273, v273, v273];
					};
					case E0C(c291, _): {
						final v292:Array<E0> = ([v255, E0.E0A] : Array<E0>);
					};
				}
				var v293:Array<Int> = ([] : Array<Int>);
			};
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
