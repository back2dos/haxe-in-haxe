package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

enum abstract K5(Int) to Int {
	var K5A = 1;
	var K5B = 4;
	var K5C = 7;
	var K5D = 10;
}
