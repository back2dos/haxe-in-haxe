package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext23(a21:Int, a22:(Int) -> String):String {
		H.tick();
		var v184:Int = (([] : Array<Int>)).length;
		final lf185:(String, Bool) -> Int = function(p186:String, p187:Bool):Int {
			H.tick();
			a21 = (Std.parseInt(p186) ?? 0);
			return (Std.parseInt(Std.string(0x69F0)) ?? 0);
		};
		for (i188 in 0...2) {
			H.tick();
			v184 = ([true, true]).length;
		}
		{
			for (i189 in 1...H.lim((Std.parseInt("\x41\x42") ?? 0))) {
				H.tick();
				var v190:Int = a21;
				H.out("o191 " + "a");
				final v192 = "é";
			}
		}
		var v193:Array<Map<Int, String>> = ([] : Array<Map<Int, String>>);
		return StringTools.trim(("\n" + ("  pad  ").length));
	}
	public static function ext25(a24:Int):Int {
		H.tick();
		final v194:(Int, Bool) -> Bool = function(p195:Int, p196:Bool):Bool {
			H.tick();
			final v197:Array<Int> = [p195];
			return p196;
		};
		H.out("o198 " + Std.string(((false ? new Box<E0>(E0.E0C("ünï", "\x41\x42")) : new Box<E0>(E0.E0B(a24, "ab"))) : Box<E0>)));
		H.out("o199 " + Std.string(new Box<String>(StringTools.hex((a24) & 0xFFFF, 4))));
		return (("x,y,z").charCodeAt(a24) ?? -1);
	}
}
