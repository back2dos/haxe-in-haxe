import H;
import p.M1;
using p.Ext;

enum E4 {
	E4A;
	E4B(a5:E4, a6:E4);
}

typedef S7 = {x8:Int, x9:Float};

typedef S10 = {x11:Int, x12:Int};

class Main {
	public static function fn48(a49:S10):Int {
		H.tick();
		var v170:Bool = Math.isNaN(Math.pow(0.1, 2));
		final lf171:(Bool) -> Bool = (p172:Bool) -> (v170 ? false : v170);
		{ var dyn173:Dynamic = ((switch (Lambda.fold([285], (v174:Int, v175:Int) -> 41, 0)) {
			case 0: ({x8: 266, x9: 0.1} : S7);
			case 3 | 6: ({x8: (-18), x9: (-2.5)} : S7);
			case _: ({x8: 69, x9: 0.1} : S7);
		}) : S7); H.out("dyn " + Std.string(dyn173.x8) + " " + Std.string(Reflect.field(dyn173, "x8"))); }
		return ({ var v176 = v170; (K14.K14A : Int); });
	}
	public static function fn50():Void {
		H.tick();
		C44.f46 = H.id(C44.f46);
		final v177:E3 = E3.E3B;
		var v178 = (-2147483647);
		var w179 = 0;
while (w179 < 4 && (false && false)) {
			w179++;
			H.tick();
			if ((([-3 => new C15(), 4 => new C24(v178, v178), 11 => new C15()] : Map<Int, C15>)).exists(-3)) break;
			{
				Main.fn48(({x11: v178, x12: v178} : S10));
			}
		}
		H.out("o180 " + Std.string((K14.K14B : Int)));
		for (i181 in 0...H.lim(((new Map<Int, Int>()).get(C44.f46) ?? 0))) {
			H.tick();
			(new C24(v178, v178)).m36((new Map<String, Int>()).exists("k3"));
			C44.f46++;
		}
	}
	public static function fn51(a52:Bool, a53:Int):Bool {
		H.tick();
		var v182:Map<Int, String> = ([-3 => Std.string(a52), 4 => "a"] : Map<Int, String>);
		final lf183:(String, Bool) -> Void = function(p184:String, p185:Bool):Void {
			H.tick();
			if ((new Map<String, K14>()).exists(p184)) {
				v182.set(11, p184);
			}
			if (a52) {
				([a53]).ext70();
				([a53, a53]).ext70();
			}
		};
		final lf186:() -> Int = function():Int {
			H.tick();
			H.out("o187 " + Std.string((new A13(19) : Int)));
			return C44.f46;
		};
		for (k188 => v189 in H.id(new Map<String, Int>())) {
			H.tick();
			var v190:S10 = ({x11: v189, x12: 271} : S10);
			final v191:Bool = a52;
			H.out("o192 " + Std.string((K14.K14C : Int)));
		}
		for (k193 => v194 in new Map<String, Int>()) {
			H.tick();
			var w195 = 0;
while (w195 < 4 && false) {
				w195++;
				H.tick();
				var v196 = false;
				H.out("o197 " + Std.string(E3.E3B));
				var v198:Null<Int> = v194;
			}
			try {
				if (false) throw new Err(Lambda.count([a53, a53, v194], v199 -> true));
				a53 -= v194;
				var v200:C15 = new C24(a53, 154);
				a52 = H.id(a52);
			} catch (ex201:Dynamic) {
				H.out("caught " + H.exn(ex201));
				H.out("o202 " + Std.string(299));
				var v203:Bool = a52;
			}
			var w204 = 0;
while (w204 < 2 && a52) {
				w204++;
				H.tick();
				C44.f46 = a53;
				H.out("o205 " + Std.string(v194));
			}
		}
		return (cast ((a52 || a52)) : Bool);
	}
	public static function fn54():Void {
		H.tick();
		var v206:E3 = ((switch (K14.K14C) {
			case K14.K14A: E3.E3A;
			case K14.K14B: E3.E3A;
			case K14.K14C: E3.E3B;
			case K14.K14D: E3.E3A;
		}) : E3);
		if (!true) {
			var v207:S7 = ({x8: 86, x9: 1e3} : S7);
		}
		H.out("o208 " + Std.string((true || false)));
		H.out("o209 " + Std.string(fn48(({x12: 55, x11: 1781158506} : S10))));
		H.out("o210 " + Std.string(104));
		var v211:Int = 282;
		{
			var v212:Int = Reflect.compare(0x7FFFFFFF, v211);
		}
		H.out("o213 " + Std.string(E4.E4B(E4A, E4.E4A)));
	}
	public static function fn55(a56:E0, a57:String, a58:Int = 0):Int {
		H.tick();
		H.out("o214 " + Std.string(((switch (Std.int(a58)) {
			case 0: ({x8: 150, x9: 1.7976931348623157e308} : S7);
			case 2 | 6: ({x8: 183, x9: a58} : S7);
			case _: ({x9: 0.1, x8: 95} : S7);
		}) : S7)));
		(new C24((Std.parseInt(Std.string(a58)) ?? 0), a58)).m35();
		for (i215 in 0...H.lim((Type.enumIndex(a56) - Lambda.fold([a58, a58, a58], (v216:Int, v217:Int) -> Lambda.count([v216, a58], v218 -> true), 0)))) {
			H.tick();
			var v219:Bool = (Std.downcast((new C44() : C44), C44) != null);
		}
		if (Main.fn51((([-3 => a58] : Map<Int, Int>)).exists(74), 283)) {
			final v220:A13 = new A13(a58);
			for (i221 in 0...0) {
				H.tick();
				a58 *= 298;
				var v222:E0 = a56;
			}
		} else {
			H.out("o223 " + Std.string(new C24(98, a58)));
			if (true) return a58;
		}
		C44.f46 *= (-a58);
		var v224 = a58;
		a58 *= v224;
		([for (i225 in [v224]) if (true) i225]).ext73((({x12: v224, x11: v224} : S10)).x11);
		{
			H.out("o226 " + Std.string(E3.E3B));
			final v227:(Bool) -> Float = (p228:Bool) -> v224;
		}
		return 70;
	}
	public static function fn59():Float {
		H.tick();
		var v229:Int = ((Std.downcast((new C38(1e100, "\t") : C38), C38) != null) ? 27 : Lambda.count([195, 114], v230 -> (new Map<Int, E3>()).exists(4)));
		H.out("o231 " + Std.string((0.1 - v229)));
		var v232:K14 = (((Std.downcast((new C15() : C15), C15) != null) ? K14.K14B : K14.K14A) : K14);
		return 100.75;
	}
	public static function fn60(a61:E4):Bool {
		H.tick();
		try {
			if (({ var v233 = (({x8: 635765327, x9: 3.0} : S7)).x8; false; })) throw new Err((-20));
			try {
				H.out("o234 " + Std.string(214));
				if (false) throw 6;
			} catch (ex235:String) {
				H.out("caught String " + ex235);
				C44.f46 = 74;
				C44.f46--;
			} catch (ex236:Int) {
				H.out("caught Int " + ex236);
				var v237:Box<S7> = new Box<S7>(({x9: ex236, x8: ex236} : S7));
				var v238:Map<String, Int> = new Map<String, Int>();
			} catch (ex239:Err) {
				H.out("caught Err " + ex239.errCode);
				C44.f46 *= (-14);
				var v240:E0 = E0.E0C(0.5);
			} catch (ex241:Dynamic) {
				H.out("caught " + H.exn(ex241));
				C44.f46 += 65;
			}
		} catch (ex242:Err) {
			H.out("caught Err " + ex242.errCode);
			C44.f46 += 23;
			fn50();
		} catch (ex243:haxe.Exception) {
			H.out("caught " + H.exn(ex243));
			var v244 = (({x11: 243, x12: 238} : S10)).x12;
			if (true) {
				v244 += 242;
				var v245:Map<Int, Float> = ([-3 => v244, 4 => v244, 11 => v244] : Map<Int, Float>);
			} else {
				var v246:Float = (-2.5);
			}
		}
		var w247 = 0;
while (w247 < 2 && fn51((Std.downcast((new C44() : C44), C44) != null), C44.f46)) {
			w247++;
			H.tick();
			C15.m18(a61, a61);
			final lf248:(Float, Float) -> Bool = (p249:Float, p250:Float) -> Math.isNaN(100.75);
		}
		if ((247 >= C44.f46)) {
			var v251:Int = (K14.K14C : Int);
			if (true) return true;
		} else {
			C44.f46 = (K14.K14D : Int);
			try {
				final v252:Float = 2.5e-3;
				if (Std.isOfType(new C24(54, 0xFED2), C15)) throw Std.string(v252);
			} catch (ex253:Err) {
				H.out("caught Err " + ex253.errCode);
				var v254:Map<Int, S7> = ([-3 => ({x8: 95, x9: 2.5e-3} : S7)] : Map<Int, S7>);
				var v255:Map<String, Int> = (["k0" => 0x7FFFFFFF] : Map<String, Int>);
			} catch (ex256:haxe.Exception) {
				H.out("caught " + H.exn(ex256));
				var v257:Int = 81;
			}
		}
		C44.f46++;
		return (((Std.parseInt("é") ?? 0) > 0xF696) && (false || false));
	}
	public static function fn62(a63:Int, a64:Bool = true):Void {
		H.tick();
		var v258 = a64;
		H.out("o259 " + Std.string(false));
		for (k260 => v261 in new Map<String, Int>()) {
			H.tick();
			var v262 = a63;
			var v263:A13 = new A13(v261);
		}
		var v264 = (C44.f46 - (new A13(a63)).get());
		final lf265:() -> Bool = () -> false;
		var v266:S10 = ({x11: C44.f46, x12: C44.f46} : S10);
		var v267:A13 = new A13(Math.ceil(a63));
		switch ((switch (E4A) {
			case E4A: v264;
			case E4B(c268, c269): C44.f46;
			case _: v264;
		})) {
			case 0: {
				try {
					if (a64) throw "q";
					var v270:Float = 123456.789;
					H.out("o271 " + Std.string(97));
				} catch (ex272:Err) {
					H.out("caught Err " + ex272.errCode);
					a63 = v264;
				} catch (ex273:haxe.Exception) {
					H.out("caught " + H.exn(ex273));
					H.out("o274 " + Std.string((v267 : Int)));
					final v275:Map<String, Int> = new Map<String, Int>();
				}
				for (i276 in 0...H.lim(230)) {
					H.tick();
					("Haxe").ext76(i276);
					var v277 = 287;
					var v278 = a64;
				}
			};
			case 2 | 4: {
				var v279:Box<C38> = new Box<C38>(new C38(a63, "abc"));
			};
			case _: {
				H.out("o280 " + Std.string(E3.E3A));
			};
		}
	}
	public static function fn65(a66:Int, a67:Int, a68:String = "d"):Void {
		H.tick();
		{
			if (false) {
				H.out("o281 " + a68);
			} else {
				C44.f46 = 201;
			}
			Ext.ext70(([] : Array<Int>));
		}
		H.out("o282 " + Std.string(new C24((({x12: a67, x11: a67} : S10)).x11, a67)));
		var v283:C44 = new C44();
		a66++;
	}
	public static function section0():Void {
		H.tick();
		H.out("o315 " + Std.string((-983454889)));
		if (false) {
			var v316 = false;
			var w317 = 0;
while (w317 < 2 && false) {
				w317++;
				H.tick();
				H.out("o318 " + Std.string((-4)));
				final v319:Int = 2;
			}
		} else {
			H.out("o320 " + Std.string(0xFFFFFFFF));
		}
		final v321:A13 = (-new A13((-13)));
		var v322:C44 = new C44();
	}
	public static function section1():Void {
		H.tick();
		var v323:Int = 235;
		C44.f46 = (Math.round(v323) + (K14.K14A : Int));
		for (i324 in 0...0) {
			H.tick();
			v323 += i324;
			for (i325 in 2...5) {
				H.tick();
				(new C24(v323, i324)).m36(false);
				H.out("o326 " + Std.string(({x11: i324, x12: i325} : S10)));
				(new C24(i324, (-2147483647))).m30(true, 112);
			}
			switch (K14.K14D) {
				case K14.K14A: {
					fn62(v323, true);
				};
				case K14.K14B: {
					H.out("o327 " + Std.string(true));
					final v328:Float = v323;
				};
				case K14.K14C: {
					final v329:A13 = new A13((-961048486));
				};
				case K14.K14D: {
					fn62(256);
					Main.fn65((-2), i324, "Haxe");
				};
			}
		}
		var v330:Bool = ("q").ext76(v323);
		Main.fn48(({x11: v323, x12: Lambda.fold([v323, 300], (v331:Int, v332:Int) -> 256, 0)} : S10));
		if ((137 < Type.enumIndex(E0.E0B))) {
			if (false) {
				H.out("o333 " + Std.string(v323));
				H.out("o334 " + Std.string(0x5FAE));
			}
			var v335:Float = C44.f46;
		}
	}
	public static function section2():Void {
		H.tick();
		if ((Math.sin(5e-324) >= 285)) {
			H.out("o336 " + Std.string(C44.f46));
			H.out("o337 " + Std.string(0x1D33));
			if (false) {
				H.out("o338 " + Std.string(({x8: 0x8DC, x9: 2.5e-3} : S7)));
				H.out("o339 " + Std.string(3.0));
			} else {
				H.out("o340 " + Std.string(0x7FFFFFFF));
			}
		}
		switch (fn55(E0.E0D, "\x41\x42", 163)) {
			case 0: {
				final lf341:(Int, Float) -> Void = function(p342:Int, p343:Float):Void {
					H.tick();
					Main.fn48(({x12: p342, x11: 95} : S10));
					(new C24(p342, p342)).m33(p342, p342);
				};
				var v344:C15 = new C24(288, 145);
			};
			case 2 | 5: {
				final v345:Float = 7.0;
			};
			case _: {
				try {
					H.out("o346 " + Std.string(({x8: 188, x9: 2.5e-3} : S7)));
					C44.f46 = 154;
					if (false) throw "boom";
				} catch (ex347:Err) {
					H.out("caught Err " + ex347.errCode);
					var v348:E0 = E0.E0C(123456.789);
					var v349:Map<Int, Bool> = ([-3 => false] : Map<Int, Bool>);
				} catch (ex350:haxe.Exception) {
					H.out("caught " + H.exn(ex350));
					C44.f46 *= (-335734970);
				}
				try {
					if (false) throw "é";
					C44.f46 -= 180;
				} catch (ex351:String) {
					H.out("caught String " + ex351);
					fn55(E0.E0B, "ünï");
					var v352:E4 = E4.E4A;
				} catch (ex353:Int) {
					H.out("caught Int " + ex353);
					H.out("o354 " + Std.string(ex353));
					H.out("o355 " + Std.string(ex353));
				} catch (ex356:Err) {
					H.out("caught Err " + ex356.errCode);
					final v357:Float = 1e-7;
				} catch (ex358:Dynamic) {
					H.out("caught " + H.exn(ex358));
					C44.f46 = 61;
					var v359:Int = (-18);
				}
			};
		}
		final lf360:(Float) -> Int = (p361:Float) -> C44.f46;
		var v362:C38 = new C38(Math.pow(0.5, 2), "zz");
		H.out("o363 " + Std.string((((Std.isOfType(new C44(), C44) ? K14.K14B : K14.K14C) : K14) : Int)));
		{
			H.out("o364 " + Std.string(E0.E0B));
		}
	}
	public static function section3():Void {
		H.tick();
		H.out("o365 " + Std.string(new C38(3.0, Std.string(2.5e-3))));
		var v366:Map<String, Int> = ((true ? new Map<String, Int>() : (["k0" => 111, "k1" => (-2147483647), "k2" => 0x1190] : Map<String, Int>)) : Map<String, Int>);
		H.out("o367 " + Std.string(((K14.K14A : Int) >= Type.enumIndex(E3.E3B))));
		C44.f46 += 95;
		if ((((new Map<Int, Int>()).get(18) ?? 0) == Type.enumIndex(E3.E3B))) {
			switch (0x80000000) {
				case 0: {
					H.out("o368 " + Std.string(false));
				};
				case 2 | 6: {
					H.out("o369 " + Std.string(false));
					var v370:E4 = E4.E4A;
				};
				case _: {
					H.out("o371 " + Std.string(299));
					var v372:E0 = E0.E0B;
				};
			}
			for (i373 in 1...3) {
				H.tick();
				var v374:Box<Int> = new Box(171);
				var v375:E4 = E4.E4A;
				final v376:K14 = K14.K14A;
			}
			var v377:Float = 209;
		}
		C44.f46 -= Main.fn55(E0.E0A, Std.string(157));
		var v378:Int = (switch (E0.E0A) {
			case E0A: 205;
			case E0B: C44.f46;
			case E0D: 1513313888;
			case _: 0x806B;
		});
		try {
			var v379:Null<Int> = v378;
			if (true) throw "boom";
		} catch (ex380:String) {
			H.out("caught String " + ex380);
			var w381 = 0;
while (w381 < 2 && true) {
				w381++;
				H.tick();
				C44.f46 += v378;
				(new C24((-1406591286), 31)).m36(false);
				(new C24(163, v378)).m33();
			}
			(new C15()).m21(v378);
		} catch (ex382:Int) {
			H.out("caught Int " + ex382);
			for (i383 in 0...3) {
				H.tick();
				final v384:Int = i383;
				var v385:E0 = E0.E0B;
				H.out("o386 " + Std.string(86));
			}
		} catch (ex387:Err) {
			H.out("caught Err " + ex387.errCode);
			H.out("o388 " + Std.string(1700946423));
		} catch (ex389:Dynamic) {
			H.out("caught " + H.exn(ex389));
			C44.f46 -= 0x80000000;
			H.out("o390 " + Std.string((Std.parseInt(Std.string(v378)) ?? 0)));
		}
		(new C24(v378, v378)).m30((cast (true) : Bool), ((Std.parseInt(Std.string(v378)) ?? 0) + (K14.K14B : Int)));
	}
	public static function section4():Void {
		H.tick();
		H.out("o391 " + Std.string(Reflect.compare(0x976F, 0x7DC)));
		H.out("o392 " + Std.string(new Box((new A13((-1512862787)) : Int))));
		var v393:Box<Int> = ((false ? new Box(213) : new Box(0x9CC9)) : Box<Int>);
		var v394 = ((new Map<String, Int>()).get("k3") ?? 0);
		var w395 = 0;
do {
			w395++;
			H.tick();
			var v396 = v394;
			v396 = v394;
		} while (w395 < 4 && ((new A13(v394)).get() >= 220));
		var v397 = v394;
		(((switch (E0.E0B) {
			case E0A: new C24(v397, 78);
			case E0B: new C24(v397, v394);
			case E0C(_): new C24(6, v394);
			case E0D: new C24(v397, 24);
			case _: new C24(v394, v394);
		}) : C24)).m36(!true);
		fn54();
		function lf398(n399:Int):Int {
			H.tick();
			return n399 <= 0 ? v394 : (lf398(n399 - 1) + v397);
		}
		H.out("lf398 " + lf398(3));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
