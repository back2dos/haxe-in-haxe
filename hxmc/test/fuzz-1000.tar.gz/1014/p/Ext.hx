package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext70(a69:Array<Int>):Float {
		H.tick();
		C44.f46 -= ((-1480543213) + (((["k0" => 65535] : Map<String, Int>)).get("k3") ?? 0));
		var v284:C15 = new C15();
		var v285 = Math.ceil(94);
		var v286:C24 = (new Box<C24>(new C24(v285, 215))).value;
		final v287:Int = Main.fn48(({x11: v285, x12: v285} : S10));
		{
			H.out("o288 " + Std.string(new C44()));
			Main.fn48(({x11: v287, x12: v287} : S10));
		}
		return Math.fceil((C44.f46 * Std.parseFloat("abc")));
	}
	public static function ext73(a71:Array<Int>, a72:Int):Int {
		H.tick();
		final v289:(Bool, Int) -> Int = (p290:Bool, p291:Int) -> a72;
		C44.f46 = a72;
		final v292 = C44.f46;
		a72 = v292;
		Main.fn48(((true ? ({x11: v292, x12: 169} : S10) : ({x11: 160, x12: 17} : S10)) : S10));
		{
			var v293:Bool = true;
		}
		if ((switch (K14.K14B) {
			case K14.K14A: false;
			case K14.K14B: true;
			case K14.K14C: Std.isOfType(new C44(), C44);
			case K14.K14D: true;
		})) {
			H.out("o294 " + Std.string(0.1));
			H.out("o295 " + Std.string(a72));
			{ var dyn296:Dynamic = ({x8: 248, x9: a72} : S7); H.out("dyn " + Std.string(dyn296.x8) + " " + Std.string(Reflect.field(dyn296, "x8"))); }
		}
		return C44.f46;
	}
	public static function ext76(a74:String, a75:Float):Bool {
		H.tick();
		for (i297 in 0...H.lim((Std.parseInt(Std.string(((new Map<String, Int>()).get("k0") ?? 0))) ?? 0))) {
			H.tick();
			var w298 = 0;
while (w298 < 1 && (new Map<String, Int>()).exists("k0")) {
				w298++;
				H.tick();
				Ext.ext73(([] : Array<Int>), (-499754026));
			}
			var v299:Int = i297;
		}
		H.out("o300 " + Std.string(Type.enumIndex(E0.E0C(a75))));
		var v301:Int = (if (false) (new A13(199) : Int) else Reflect.compare(46, 0xFFFFFFFF));
		for (k302 => v303 in new Map<String, Int>()) {
			H.tick();
			Ext.ext73([v301, v303, 0x7FFFFFFF], Type.enumIndex(E3.E3A));
			var v304:S10 = ({x11: v303, x12: v303} : S10);
			{ var dyn305:Dynamic = ({x11: 258, x12: v301} : S10); H.out("dyn " + Std.string(dyn305.x11) + " " + Std.string(Reflect.field(dyn305, "x11"))); }
		}
		var v306:C15 = new C15();
		var w307 = 0;
while (w307 < 3 && true) {
			w307++;
			H.tick();
			if (false) {
				final v308:Float = 1e-7;
				var v309 = v301;
			} else {
				(new C24(28, 233)).m33((-1615735229), v301);
			}
		}
		v301 = Reflect.compare((({x11: 105, x12: v301} : S10)).x12, v301);
		for (i310 in 0...H.lim(173)) {
			H.tick();
			var v311:E3 = E3.E3A;
			{ var dyn312:Dynamic = ({x9: v301, x8: i310} : S7); H.out("dyn " + Std.string(dyn312.x8) + " " + Std.string(Reflect.field(dyn312, "x8"))); }
			var w313 = 0;
do {
				w313++;
				H.tick();
				(new C24(v301, v301)).m33(v301);
				H.out("o314 " + Std.string(new C44()));
			} while (w313 < 1 && true);
		}
		return ((cast ((new A13(0xFFFFFFFF)).get()) : Int) != ((Std.parseInt(a74) ?? 0) % H.nz(67)));
	}
}
