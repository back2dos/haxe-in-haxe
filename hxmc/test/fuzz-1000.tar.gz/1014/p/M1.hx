package p;

import Main;
import H;
import p.M1;
using p.Ext;

class M1 {}

enum E0 {
	E0A;
	E0B;
	E0C(a2:Float);
	E0D;
}

enum E3 {
	E3A;
	E3B;
}

abstract A13(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A13, b:A13):A13
		return new A13(a.get() + b.get());

	@:op(A * B) public static function mul(a:A13, b:A13):A13
		return new A13(a.get() * b.get());

	@:op(-A) public static function neg(a:A13):A13
		return new A13(-a.get());
}

enum abstract K14(Int) to Int {
	var K14A = 1;
	var K14B = 4;
	var K14C = 7;
	var K14D = 10;
}

class C15 {
	public var f16:Int;
	public var cb17:(Int) -> Int;
	public function new() {
		this.f16 = C44.f46;
		this.cb17 = function(p77:Int):Int {
			H.tick();
			var v78:Float = 3.0;
			H.out("o79 " + Std.string(new Box<Bool>(true)));
			return p77;
		};
	}
	public static function m18(a19:E4, a20:E4):Map<String, A13> {
		H.tick();
		var w80 = 0;
do {
			w80++;
			H.tick();
			var v81:Float = 7.0;
			C44.f46 -= 0xFFFFFFFF;
			for (i82 in 1...4) {
				H.tick();
				var v83 = i82;
				H.out("o84 " + Std.string(111));
			}
		} while (w80 < 2 && ("").ext76(1e-7));
		var v85 = (C44.f46 + C44.f46);
		var v86:Map<Int, Int> = ([-3 => v85] : Map<Int, Int>);
		H.out("o87 " + Std.string(v85));
		return (((Std.int(1e21) != ((([-3 => 165] : Map<Int, Int>)).get(4) ?? 0)) ? (["k0" => new A13(v85)] : Map<String, A13>) : (["k0" => (v85 : A13), "k1" => new A13(v85), "k2" => new A13(v85)] : Map<String, A13>)) : Map<String, A13>);
	}
	public function m21(a22:Int, ?a23:Null<Int>):Bool {
		H.tick();
		final v88:Map<String, Int> = (["k0" => Std.int(1.25)] : Map<String, Int>);
		H.out("o89 " + Std.string(E0.E0A));
		var v90:Box<Null<Int>> = new Box<Null<Int>>(258);
		return ((a22 - a22) < Math.floor(1e-7));
	}
}

class C24 extends C15 {
	public var f25:Int;
	public var f26:String;
	public var f27:Int;
	public function new(a28:Int, a29:Int) {
		super();
		this.f25 = 1366154138;
		this.f26 = "ünï";
		this.f27 = 151;
	}
	public function m30(a31:Bool, a32:Int):Int {
		H.tick();
		var v91 = 0x3BF8;
		H.out("o92 " + Std.string(new C24(0x4C, this.f27)));
		var w93 = 0;
do {
			w93++;
			H.tick();
			H.out("o94 " + Std.string(({x12: v91, x11: v91} : S10)));
			switch (Type.enumIndex(E3B)) {
				case 0: {
					C44.f46++;
					H.out("o95 " + Std.string(a31));
				};
				case 1 | 6: {
					++this.f27;
				};
				case _: {
					this.m21(v91, 0xF9FB);
					var v96:S7 = ({x8: v91, x9: a32} : S7);
				};
			}
		} while (w93 < 2 && ("x,y,z").ext76(a32));
		H.out("o97 " + Std.string(new C24(this.f16, ((([-3 => a32, 4 => (-1792948097)] : Map<Int, Int>)).get(133) ?? 0))));
		for (i98 in 0...4) {
			H.tick();
			for (i99 in 0...2) {
				H.tick();
				Ext.ext76("Haxe", 7.0);
				var v100:Int = a32;
			}
			m36(true);
			final v101:S10 = ({x11: (-2147483647), x12: a32} : S10);
		}
		return 133;
	}
	public function m33(...r34:Int):Void {
		H.tick();
		var v102:Map<String, S7> = new Map<String, S7>();
		final v103:Map<String, Int> = (["k0" => this.f16, "k1" => 213] : Map<String, Int>);
		if (((K14.K14C : Int) <= 274)) {
			if (Math.isNaN(100.75)) {
				H.out("o104 " + Std.string(201));
				H.out("o105 " + Std.string(E4.E4A));
			} else {
				var v106:E4 = E4.E4A;
			}
			var w107 = 0;
while (w107 < 1 && (Std.downcast((new C15() : C15), C24) != null)) {
				w107++;
				H.tick();
				this.f16 *= 236;
			}
			var v108:E0 = E0A;
		}
		H.out("o109 " + Std.string(44));
	}
	public function m35():Int {
		H.tick();
		var v110:Map<Int, Int> = (cast (new Map<Int, Int>()) : Map<Int, Int>);
		var v111 = (new C24(909843021, 0x1B63)).m30(false, this.f27);
		C44.f46++;
		var v112:Int = (switch (K14.K14B) {
			case K14.K14A: this.f27;
			case K14.K14B: (Std.parseInt(Std.string(v111)) ?? 0);
			case K14.K14C: Type.enumIndex(E4.E4A);
			case K14.K14D: 222;
		});
		if ((true ? false : true)) {
			switch (E4.E4A) {
				case E4A: {
					m30(false, v112);
				};
				case _: {
					H.out("o113 " + Std.string(((v112 : A13) : Int)));
					H.out("o114 " + Std.string(false));
				};
			}
			var v115:A13 = new A13(1139486873);
			var v116:Null<Int> = null;
		} else {
			this.f25 = v111;
		}
		var w117 = 0;
while (w117 < 2 && false) {
			w117++;
			H.tick();
			H.out("o118 " + Std.string(v112));
		}
		var w119 = 0;
while (w119 < 4 && (v111 < v111)) {
			w119++;
			H.tick();
			H.out("o120 " + Std.string(271));
			var v121:C24 = new C24(v112, v112);
			final lf122:() -> Float = () -> 1e3;
		}
		final v123:E4 = E4.E4A;
		var w124 = 0;
while (w124 < 5 && (([-3 => new C15(), 4 => new C24(v111, 215)] : Map<Int, C15>)).exists(Type.enumIndex(E4.E4A))) {
			w124++;
			H.tick();
			H.out("o125 " + Std.string(E4.E4A));
			final v126:Null<Int> = v111;
			switch (E4.E4A) {
				case E4A: {
					var v127:Null<Int> = v126;
					H.out("o128 " + Std.string(v112));
				};
				case E4B(_, _): {
					var v129 = v112;
					([65535, v111, v112]).ext73(v111);
				};
			}
		}
		return v112;
	}
	public function m36(a37:Bool):Int {
		H.tick();
		m33();
		switch (H.id((({x11: 289, x12: 194} : S10)).x11)) {
			case 0: {
				C44.f46--;
			};
			case 2 | 5: {
				final v130:A13 = new A13(202);
				H.out("o131 " + Std.string((K14.K14C : Int)));
			};
			case _: {
				var v132:Float = (-2.5);
				var v133:K14 = K14.K14B;
			};
		}
		H.out("o134 " + Std.string(((false ? E3.E3A : E3.E3A) : E3)));
		H.out("o135 " + Std.string(new C15()));
		return ((211 % H.nz(((293 : A13) : Int))) - 29);
	}
}

class C38 {
	public var f39:Float;
	public function new(a40:Float, a41:String) {
		this.f39 = a40;
	}
	public static function m42(a43:Int):Bool {
		H.tick();
		switch (E0C(a43)) {
			case E0A: {
				H.out("o136 " + Std.string(new C24(a43, a43)));
				{ var dyn137:Dynamic = ({x11: a43, x12: a43} : S10); H.out("dyn " + Std.string(dyn137.x11) + " " + Std.string(Reflect.field(dyn137, "x11"))); }
			};
			case E0B: {
				final v138 = (Std.parseInt("Haxe") ?? 0);
				var v139:Float = C44.f46;
			};
			case E0C(c140): {
				final lf141:() -> String = function():String {
					H.tick();
					var v142:Map<Int, Float> = new Map<Int, Float>();
					return Std.string(true);
				};
				C44.f46 = (((["k0" => a43] : Map<String, Int>)).get("k3") ?? 0);
			};
			case _: {
				H.out("o143 " + Std.string((K14.K14B : Int)));
			};
		}
		var v144:E0 = E0.E0D;
		a43 = Reflect.compare(a43, a43);
		H.out("o145 " + Std.string((C44.f46 % H.nz((new A13(a43)).get()))));
		switch (C44.f46) {
			case 0: {
				try {
					if (Math.isNaN(a43)) throw 82;
					C44.f46 = 257;
					H.out("o146 " + Std.string(a43));
				} catch (ex147:String) {
					H.out("caught String " + ex147);
					final v148 = a43;
					a43--;
				} catch (ex149:Int) {
					H.out("caught Int " + ex149);
					C44.f46 = (-1252036731);
				} catch (ex150:Err) {
					H.out("caught Err " + ex150.errCode);
					C44.f46 = a43;
				} catch (ex151:Dynamic) {
					H.out("caught " + H.exn(ex151));
					a43 = H.id(a43);
					v144 = H.id(v144);
				}
			};
			case 1 | 6: {
				final v152:E4 = E4.E4A;
				try {
					if (true) throw "boom";
					var v153:Bool = true;
					var v154:K14 = K14.K14C;
					(new C15()).m21(a43);
				} catch (ex155:Dynamic) {
					H.out("caught " + H.exn(ex155));
					final v156 = false;
				}
			};
			case _: {
				(new C24(0x9F58, a43)).m36((new Map<Int, C44>()).exists(a43));
			};
		}
		var v157:A13 = new A13(18);
		var w158 = 0;
while (w158 < 1 && (new C15()).m21(208, 213)) {
			w158++;
			H.tick();
			C44.f46 = Type.enumIndex(E0A);
			if (Std.isOfType(new C24(a43, a43), C15)) {
				H.out("o159 " + Std.string(a43));
				var v160:Float = 0.1;
			} else {
				var v161:Float = a43;
			}
			for (i162 in 2...3) {
				H.tick();
				([i162, i162, i162]).ext70();
				var v163 = i162;
				var v164:Bool = false;
			}
		}
		switch (K14.K14C) {
			case K14.K14A: {
				Main.fn50();
				C44.f46 = (({x8: 94, x9: a43} : S7)).x8;
			};
			case K14.K14B: {
				(new C15()).m21((-16));
				var v165:C15 = new C24(a43, a43);
			};
			case K14.K14C: {
				H.out("o166 " + Std.string(new C38(a43, "a")));
				var v167:Float = 2.5e-3;
			};
			case K14.K14D: {
				H.out("o168 " + Std.string((K14.K14A : Int)));
			};
		}
		return (([-3 => new C15()] : Map<Int, C15>)).exists((({x11: (-20), x12: a43} : S10)).x11);
	}
}

class C44 {
	public var f45:Float;
	public static var f46:Int = 262;
	public var cb47:(Int) -> Int;
	public function new() {
		this.f45 = 3.0;
		this.cb47 = (p169:Int) -> 0xEAD;
	}
}
