import H;
using p.Ext;
using StringTools;

abstract A0(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A0, b:A0):A0
		return new A0(a.get() + b.get());

	@:op(A * B) public static function mul(a:A0, b:A0):A0
		return new A0(a.get() * b.get());

	@:op(-A) public static function neg(a:A0):A0
		return new A0(-a.get());
}

enum abstract K1(Int) to Int {
	var K1A = 1;
	var K1B = 4;
	var K1C = 7;
}

interface I2 {
	function m3(a4:Int):Int;
	function m5():Int;
}

class C6 {
	public var cb7:(Int) -> Int;
	public function new() {
		this.cb7 = function(p70:Int):Int {
			H.tick();
			final v71:Map<Int, Bool> = ([-3 => false, 4 => false, 11 => false] : Map<Int, Bool>);
			return 67;
		};
	}
	public static function m8():String {
		H.tick();
		var v72 = C36.f37;
		if (C25.f27) {
			var v73:K1 = K1.K1C;
		}
		if (false) return ("abc" + (Std.downcast((new C25(v72) : C25), C25) != null));
		var v74 = (new Box(false)).value;
		H.out("o75 " + Std.string(0xF44));
		switch ((156 - v72)) {
			case 0: {
				H.out("o76 " + Std.string(new C46(53, "abc")));
				v74 = H.id(v74);
			};
			case 2 | 4: {
				switch (("0").lastIndexOf("42")) {
					case 0: {
						H.out("o77 " + Std.string(new Box("a")));
						H.out("o78 " + Std.string(v72));
					};
					case 2 | 5: {
						var v79:String = "Haxe";
						v72 = H.id(v72);
					};
					case _: {
						H.out("o80 " + Std.string(new C25(0xCFE8)));
					};
				}
			};
			case _: {
				{
					final v81:Bool = true;
				}
				H.out("o82 " + ("ab").substring(-2, (v72 & 7)));
			};
		}
		(H.apply(StringTools.replace("hello world", "a", "\\"), (v83:String) -> new C14(256))).m3((new C14(v72)).m3(v72));
		return ((switch (298) {
			case 0: ("hello world").toLowerCase();
			case 1 | 5: ("Haxe").replace("a", "b");
			case _: "\\";
		}) + (StringTools.startsWith("hello world", "42") ? "A-B-C" : ('$$').substr(4, 4)));
	}
	public function m9(a10:Int):Int {
		H.tick();
		a10 = H.id(a10);
		var v84:Map<Int, Bool> = new Map<Int, Bool>();
		final v85 = (switch (K1.K1A) {
			case K1.K1A: 98;
			case K1.K1B: 282;
			case K1.K1C: a10;
		});
		final v86:Map<String, Int> = new Map<String, Int>();
		final v87:K1 = K1.K1C;
		(new C14(v85)).m3(270);
		if ((254 == (v87 : Int))) {
			var v88 = ("  pad  ").replace("a", "b");
		}
		C36.f37 -= a10;
		final v89 = (290 * C14.f17);
		return (-a10);
	}
	public function m11(a12:Map<Int, Int>, a13:Int):Void {
		H.tick();
		C36.f37 += (a13 + a13);
		{
			if ((new Map<String, String>()).exists("k0")) {
				H.out("o90 " + Std.string(new C14(a13)));
				H.out("o91 " + "hello world");
			} else {
				Main.fn53(true, '$$', a13, a13);
			}
			H.out("o92 " + Std.string((-10)));
		}
		(new C14(a13)).m23((switch (K1.K1B) {
			case K1.K1A: "  pad  ";
			case K1.K1B: ("-7").toUpperCase();
			case K1.K1C: "A-B-C";
		}));
		H.out("o93 " + "");
		C36.f37++;
	}
}

class C14 implements I2 {
	public final f15:String;
	public var f16:String;
	public static var f17:Int = 65535;
	public function new(a18:Int) {
		this.f15 = "42";
		this.f16 = StringTools.trim("-7");
	}
	public function m3(a4:Int):Int {
		H.tick();
		H.out("o94 " + "zz");
		try {
			if ((Std.string(0x6105) <= this.f16)) throw (Std.string(133)).replace("a", "b");
			var v95:Map<Int, Int> = ([-3 => a4, 4 => 0x5E03, 11 => a4] : Map<Int, Int>);
		} catch (ex96:Dynamic) {
			H.out("caught " + H.exn(ex96));
			H.out("o97 " + Std.string((new A0(a4) : Int)));
		}
		if ((StringTools.endsWith("-7", '$$') ? (new Map<String, Int>()).exists("k0") : true)) {
			final v98 = 0xAFE9;
		} else {
			switch (true) {
				case true: {
					final v99:(Int) -> Bool = function(p100:Int):Bool {
						H.tick();
						final v101:Int = p100;
						H.out("o102 " + Std.string(a4));
						return false;
					};
				};
				case false: {
					var v103 = 248;
					C14.f17 = v103;
				};
			}
		}
		return C36.f37;
	}
	public function m5():Int {
		H.tick();
		this.m3((if (true) (Std.parseInt(Std.string(254)) ?? 0) else (new A0(1124595174)).twice));
		(new C14(Lambda.count([0xA66B], v104 -> Std.isOfType(new C14(v104), I2)))).m3((Std.parseInt(Std.string(280)) ?? 0));
		var v105:C46 = new C46((K1.K1A : Int), StringTools.lpad("hello world", "*", 6));
		H.out("o106 " + Std.string((new C14(0x80000000)).m3(80)));
		switch ((Std.parseInt("hello world") ?? 0)) {
			case 0: {
				C14.f17 += 144;
			};
			case 1 | 6: {
				H.out("o107 " + ("hello world").substr(6, 4));
			};
			case _: {
				var v108 = (K1.K1A : Int);
				if ((([-3 => new A0(58)] : Map<Int, A0>)).exists(-3)) {
					H.out("o109 " + Std.string(v108));
				}
			};
		}
		switch (Std.string(C36.f37)) {
			case "a" | "b": {
				H.out("o110 " + Std.string(new C46(266, "a")));
				switch ("zz") {
					case "a" | "b": {
						H.out("o111 " + Std.string(false));
						C14.f17 = 31;
					};
					case "Haxe": {
						H.out("o112 " + Std.string(new C6()));
					};
					case _: {
						var v113 = "\n";
					};
				}
			};
			case "Haxe": {
				H.out("o114 " + Std.string((-2147483647)));
				final v115:K1 = K1.K1C;
			};
			case _: {
				m3(("abc").lastIndexOf("q"));
			};
		}
		C14.f17 = (switch ((Std.parseInt(Std.string(281)) ?? 0)) {
			case 0: ("").indexOf("-7");
			case 3 | 5: 0x4B2F;
			case _: C36.f37;
		});
		final v116:Int = (-877666351);
		return v116;
	}
	public function m19():Bool {
		H.tick();
		H.out("o117 " + Std.string(new C6()));
		{
			final v118 = (Std.parseInt(Std.string(261)) ?? 0);
			var v119:Map<String, Int> = (["k0" => v118, "k1" => 196, "k2" => v118] : Map<String, Int>);
		}
		if (C25.f27) {
			this.m5();
		} else {
			var v120:Int = Reflect.compare("q", "Haxe");
		}
		var v121 = C6.m8();
		if ((0x2C1B >= (new A0(168) : Int))) {
			H.out("o122 " + Std.string(65535));
		}
		return (C6.m8() < '${Std.string(StringTools.endsWith(v121, "\"q\""))}-${Std.string(false)}');
	}
	public function m20(a21:String, a22:K1):Void {
		H.tick();
		(new C6()).m9(this.m5());
		if (true) {
			C36.f37 = (a22 : Int);
			C14.f17 -= 21;
			switch (185) {
				case 0: {
					this.m19();
					H.out("o123 " + "");
				};
				case 2 | 4: {
					H.out("o124 " + Std.string(false));
					var v125 = (-1741108187);
				};
				case _: {
					var v126:K1 = a22;
					H.out("o127 " + a21);
				};
			}
		} else {
			var v128:Map<String, String> = (["k0" => '$$'] : Map<String, String>);
		}
		var v129:C25 = new C25((new A0((-8))).get());
	}
	public function m23(a24:String):Int {
		H.tick();
		H.out("o130 " + Std.string((99 - (Std.parseInt(Std.string(135)) ?? 0))));
		H.out("o131 " + ({ var sb132 = new StringBuf(); sb132.add(Std.string(C25.f27)); sb132.toString(); }));
		{ var dyn133:Dynamic = (5 % H.nz(98)); H.out("dyn " + Std.string(dyn133 + 1)); }
		if (C25.f27) return 34;
		return (new Box(C36.f37)).value;
	}
}

class C25 {
	public var f26:Box<Int>;
	public static var f27:Bool = true;
	public var f28:Bool;
	public function new(a29:Int) {
		this.f26 = new Box(a29);
		this.f28 = (([-3 => "", 4 => "\"q\"", 11 => "A-B-C"] : Map<Int, String>)).exists(74);
	}
	public function m30(a31:String):String {
		H.tick();
		C14.f17 += (false ? (a31).indexOf("abc") : (("q").charCodeAt((-2147483647)) ?? -1));
		C36.f37 = 26;
		switch (238) {
			case 0: {
				C14.f17 = 184;
				H.out("o134 " + ("abc").substr((264 & 7), 0));
			};
			case 3 | 6: {
				(new C14(200)).m19();
				H.out("o135 " + "zz");
			};
			case _: {
				(new C14((-6))).m3(253);
			};
		}
		switch ((a31 + a31)) {
			case "a" | "b": {
				var v136:Box<Int> = new Box(16);
			};
			case "Haxe": {
				if (true) return Std.string(1295437668);
				(new C6()).m9((new A0(34)).twice);
			};
			case _: {
				var v137 = this.f28;
			};
		}
		final v138:() -> Int = ((switch (StringTools.hex((61) & 0xFFFF, 4)) {
			case "a" | "b": () -> (-1422236963);
			case "Haxe": () -> 260;
			case "": () -> 0xFFFFFFFF;
			case _: () -> 65535;
		}) : () -> Int);
		H.out("o139 " + Std.string((Lambda.fold(([] : Array<Int>), (v140:Int, v141:Int) -> Lambda.fold([191, v141], (v142:Int, v143:Int) -> 283, 0), 0) >= 96)));
		return a31;
	}
	public function m32():Void {
		H.tick();
		var v144:I2 = new C14((K1.K1C : Int));
		var v145 = Reflect.compare((-702138444), (new A0((-624408885)) : Int));
		H.out("o146 " + Std.string(new C36('$$', (([-3 => (v145 : A0), 4 => new A0(v145), 11 => new A0(24)] : Map<Int, A0>)).exists(-3))));
		H.out("o147 " + Std.string(161));
		final v148:Int = 0xFFFFFFFF;
	}
	public function m33(a34:String, ...r35:Int):Int {
		H.tick();
		C36.f37++;
		var v149 = (true && Std.isOfType(new C14((-246040236)), C14));
		H.out("o150 " + Std.string(Reflect.compare((a34).toLowerCase(), a34)));
		var v151:String = Std.string(v149);
		switch (((K1.K1B : Int) * ("x,y,z").length)) {
			case 0: {
				var v152 = Std.string(84);
			};
			case 3 | 6: {
				var v153 = (-1883650558);
				(new C14(v153)).m5();
			};
			case _: {
				m32();
			};
		}
		C36.f37 = 187;
		return ((new A0(0x80000000)).twice % H.nz((K1.K1B : Int)));
	}
}

class C36 {
	public static var f37:Int = 0;
	public var f38:Bool;
	public var cb39:(Int) -> Int;
	public function new(a40:String, a41:Bool) {
		this.f38 = false;
		this.cb39 = function(p154:Int):Int {
			H.tick();
			H.out("o155 " + Std.string(p154));
			var v156:Map<Int, Int> = new Map<Int, Int>();
			C36.f37--;
			return p154;
		};
	}
	public function m42():Void {
		H.tick();
		var v157:C14 = new C14((new A0(42) : Int));
		var v158:Int = 106;
		var v159:I2 = new C14(("A-B-C").length);
	}
	public static function m43(a44:Bool, a45:String):Bool {
		H.tick();
		C36.f37 += (Reflect.compare(a45, "x,y,z") - (a45).lastIndexOf(a45));
		H.out("o160 " + Std.string((206 * (((["k0" => 157, "k1" => 69, "k2" => 0xF81C] : Map<String, Int>)).get("k3") ?? 0))));
		var v161:Map<Int, Int> = ([-3 => 65535] : Map<Int, Int>);
		var v162 = StringTools.startsWith(StringTools.replace(a45, "a", "q"), "abc");
		H.out("o163 " + Std.string((16 % H.nz((a45).indexOf(a45)))));
		return a44;
	}
}

class C46 {
	public var cb47:(Int) -> Int;
	public function new(a48:Int, a49:String) {
		this.cb47 = (p164:Int) -> p164;
	}
}

class Main {
	public static function fn50(a51:String, a52:Int):String {
		H.tick();
		if (C36.m43(false, (a51).substr(2, (57 & 7)))) {
			var v165:Bool = true;
		} else {
			var v166:Int = a52;
			var v167:Bool = (new Map<Int, String>()).exists(11);
		}
		switch ((new Box<K1>(K1.K1B)).value) {
			case K1.K1A: {
				if (StringTools.startsWith(a51, a51)) return Std.string(a52);
				(new C14(a52)).m23((a51).replace("a", "b"));
			};
			case K1.K1B: {
				(new C14(a52)).m5();
			};
			case K1.K1C: {
				var v168 = a52;
				H.out("o169 " + ("zz").replace("a", "b"));
			};
		}
		(new C14(65535)).m5();
		var v170:A0 = new A0(a52);
		var v171:Int = a52;
		return (Std.string(Lambda.fold([191, v171], (v172:Int, v173:Int) -> 42, 0))).replace("a", "b");
	}
	public static inline function fn53(a54:Bool, a55:String, ...r56:Int):Bool {
		H.tick();
		H.out("o174 " + Std.string((switch ((K1.K1C : Int)) {
			case 0: ((new Map<Int, Int>()).get(-3) ?? 0);
			case 1 | 5: (new A0(135)).twice;
			case _: 243;
		})));
		C36.f37 += (293 + (Std.parseInt(Std.string(170)) ?? 0));
		H.out("o175 " + Std.string((((32 : A0)).twice * Lambda.count([78, 179], v176 -> true))));
		return (245 >= (a54 ? C36.f37 : (-1864542561)));
	}
	public static function fn57():Int {
		H.tick();
		final v177:Bool = false;
		switch ("x,y,z") {
			case "a" | "b": {
				if (v177) {
					final v178:(String) -> Void = function(p179:String):Void {
						H.tick();
						var v180:Bool = true;
						final v181 = 158;
					};
					var v182:Bool = v177;
					H.out("o183 " + Std.string(v177));
				}
			};
			case "Haxe": {
				H.out("o184 " + Std.string((K1.K1B : Int)));
				if ((new Map<String, Int>()).exists("abc")) {
					var v185 = 133;
					var v186:C14 = new C14(v185);
					var v187:String = "-7";
				} else {
					H.out("o188 " + "x,y,z");
					var v189:Int = 268;
				}
			};
			case "": {
				(new C6()).m11(([-3 => 242] : Map<Int, Int>), ((new Map<Int, Int>()).get(18) ?? 0));
				var v190 = (-201407825);
			};
			case _: {
				C36.f37 += 160;
				var v191:C6 = new C6();
			};
		}
		var v192:Int = (Std.parseInt("\n") ?? 0);
		try {
			final v193:C25 = new C25(v192);
			if (((new A0(v192) : Int) <= v192)) throw new Err(v192);
		} catch (ex194:Dynamic) {
			H.out("caught " + H.exn(ex194));
			H.out("o195 " + Std.string(new Box(v177)));
		}
		var v196 = (-2147483647);
		return (new C14(((new Map<Int, Int>()).get(-3) ?? 0))).m23((v196 + "hello world"));
	}
	public static function fn58(a59:String, a60:Int, a61:Int):Void {
		H.tick();
		a59 = H.cap(a59);
		H.out("o197 " + Std.string((-a61)));
		if ((true || C25.f27)) {
			H.out("o198 " + Std.string(a61));
		} else {
			var v199:Map<String, K1> = (["k0" => K1.K1A, "k1" => K1.K1A] : Map<String, K1>);
		}
		H.out("o200 " + Std.string(new Box(a61)));
		final v201:C46 = new C46((a59).lastIndexOf(""), "zz");
		C25.f27 = !false;
		var v202:Int = a60;
	}
	public static function fn62():Void {
		H.tick();
		H.out("o203 " + Std.string((Std.isOfType(new C46(259, "q"), C46) ? (-1145154866) : 116)));
		H.out("o204 " + Std.string((K1.K1A : Int)));
		switch (240) {
			case 0: {
				C36.f37 *= ("a").length;
				try {
					if (false) throw new Err(("hello world").length);
					H.out("o205 " + Std.string(new C36("zz", true)));
					Main.fn57();
					C14.f17 = 224;
				} catch (ex206:String) {
					H.out("caught String " + ex206);
					H.out("o207 " + ex206);
				} catch (ex208:Int) {
					H.out("caught Int " + ex208);
					var v209 = "0";
					H.out("o210 " + Std.string(ex208));
				} catch (ex211:Err) {
					H.out("caught Err " + ex211.errCode);
					var v212:Map<String, C36> = (["k0" => new C36("\n", true), "k1" => new C36("", false)] : Map<String, C36>);
					H.out("o213 " + Std.string(new C6()));
				} catch (ex214:Dynamic) {
					H.out("caught " + H.exn(ex214));
					C14.f17 = 74;
					(new C14(0xE1F1)).m23("A-B-C");
				}
			};
			case 3 | 5: {
				try {
					if (true) throw "boom";
					var v215 = "abc";
				} catch (ex216:Err) {
					H.out("caught Err " + ex216.errCode);
					(new C25(2092821435)).m30("\t");
				} catch (ex217:haxe.Exception) {
					H.out("caught " + H.exn(ex217));
					C36.f37 += 45;
				}
			};
			case _: {
				switch (K1.K1B) {
					case K1.K1A: {
						H.out("o218 " + Std.string((K1.K1C : Int)));
					};
					case K1.K1B: {
						var v219:String = "hello world";
						final v220:() -> String = () -> v219;
					};
					case K1.K1C: {
						H.out("o221 " + Std.string(44));
					};
				}
			};
		}
		final v222 = (((0x7FFFFFFF : A0)).get() - ("").length);
		if (false) {
			H.out("o223 " + Std.string(v222));
			fn58(("zz").replace("a", "b"), 225, C14.f17);
		} else {
			C36.f37 *= v222;
			if ((([-3 => new A0(v222), 4 => new A0(v222), 11 => new A0(v222)] : Map<Int, A0>)).exists(v222)) {
				C14.f17 = 71;
				H.out("o224 " + Std.string((K1.K1B : Int)));
				H.out("o225 " + Std.string(true));
			} else {
				C36.f37 = v222;
			}
		}
		if ((new C14(v222)).m19()) {
			switch ((new A0(v222)).get()) {
				case 0: {
					var v226:Map<String, String> = new Map<String, String>();
					var v227:Int = v222;
				};
				case 3 | 6: {
					C36.m43(false, "x,y,z");
				};
				case _: {
					final v228:String = "A-B-C";
					H.out("o229 " + Std.string(new Box<String>(v228)));
				};
			}
			try {
				H.out("o230 " + Std.string(new C14(194)));
				H.out("o231 " + Std.string(false));
				H.out("o232 " + "\n");
				if (Std.isOfType(new C46(v222, "42"), C46)) throw new Err(Reflect.compare(v222, 272));
			} catch (ex233:Err) {
				H.out("caught Err " + ex233.errCode);
				final v234 = "";
			} catch (ex235:haxe.Exception) {
				H.out("caught " + H.exn(ex235));
				(new C14(65535)).m3(114);
				C14.f17 -= v222;
			}
		} else {
			C14.f17 = v222;
			H.out("o236 " + Std.string(C25.f27));
		}
		switch (C14.f17) {
			case 0: {
				(new C36("42", false)).m42();
				var v237:K1 = K1.K1A;
			};
			case 3 | 6: {
				C14.f17++;
			};
			case _: {
				{ var dyn238:Dynamic = v222; H.out("dyn " + Std.string(dyn238 + 1)); }
			};
		}
		final v239:Map<Int, String> = new Map<Int, String>();
	}
	public static function fn63(a64:Bool, a65:Int):Int {
		H.tick();
		final v240 = Std.string(844874275);
		H.out("o241 " + Std.string((a64 ? false : C25.f27)));
		var v242:Box<A0> = new Box<A0>(new A0(a65));
		H.out("o243 " + Std.string((K1.K1C : Int)));
		H.out("o244 " + (v240).charAt(5));
		(((switch ((new Map<Int, A0>()).exists(18)) {
			case true: new C6();
			case false: new C6();
		}) : C6)).m9((41 + ((new Map<String, Int>()).get("\"q\"") ?? 0)));
		(new C14(a65)).m5();
		(new C14(76)).m23("A-B-C");
		return a65;
	}
	public static function fn66():Int {
		H.tick();
		var v245 = 0x9EEB;
		final v246:Bool = (false || StringTools.startsWith("  pad  ", "\"q\""));
		var v247 = H.id(C14.f17);
		v245 = ({ var v248 = 193; v248; });
		H.out("o249 " + Std.string(((((["k0" => 0x3650, "k1" => v247, "k2" => v245] : Map<String, Int>)).get("k0") ?? 0) < C14.f17)));
		if (false) {
			switch (v247) {
				case 0: {
					var v250:Int = (-1245342790);
					Main.fn57();
				};
				case 3 | 6: {
					H.out("o251 " + "a");
					C36.f37 += v245;
				};
				case _: {
					H.out("o252 " + Std.string(v246));
				};
			}
		} else {
			(new C14(v245)).m5();
		}
		final v253:(Bool, String) -> Int = (p254:Bool, p255:String) -> v245;
		return (new C25((-5))).m33((C25.f27 ? ("a").toUpperCase() : String.fromCharCode(65 + ((v245) & 15))), 248, 0xFFFFFFFF);
	}
	public static function fn67():Int {
		H.tick();
		C36.f37--;
		(new C14(260)).m23("A-B-C");
		(new C6()).m11(([-3 => (Std.parseInt(Std.string(294)) ?? 0), 4 => ((68 : A0) : Int)] : Map<Int, Int>), C36.f37);
		if (!false) {
			if (C25.f27) {
				final v256:A0 = new A0((-2147483647));
				C25.f27 = true;
			}
		} else {
			var v257:Bool = StringTools.startsWith("A-B-C", "ab");
		}
		H.out("o258 " + Std.string(new C46(("\\").indexOf("a"), "\\")));
		switch (fn50(Std.string(249), 104)) {
			case "a" | "b": {
				var v259 = StringTools.contains("\"q\"", "  pad  ");
				if (false) {
					H.out("o260 " + "\"q\"");
					final v261 = v259;
				}
			};
			case "Haxe": {
				(new C14(18)).m3(280);
			};
			case "": {
				try {
					if (false) throw "boom";
					final v262:Map<String, Map<String, String>> = new Map<String, Map<String, String>>();
				} catch (ex263:Err) {
					H.out("caught Err " + ex263.errCode);
					var v264 = 281;
					Main.fn63(true, v264);
				} catch (ex265:haxe.Exception) {
					H.out("caught " + H.exn(ex265));
					C14.f17 = 172;
					var v266 = 113;
				}
			};
			case _: {
				H.out("o267 " + Std.string((K1.K1C : Int)));
			};
		}
		return ((true ? 0x4BF : Reflect.compare(257, (-975373797))) + (106 + 267));
	}
	public static function section0():Void {
		H.tick();
		var v272:A0 = (-new A0(278));
		var v273:Int = 207;
		if ((Lambda.count([v273, v273, v273], v274 -> true) == (v272 : Int))) {
			var v275 = "a";
			switch (Reflect.compare(v273, v273)) {
				case 0: {
					var v276:Int = (-807501021);
					H.out("o277 " + Std.string(v273));
				};
				case 1 | 4: {
					H.out("o278 " + v275);
				};
				case _: {
					v273 = H.id(v273);
					H.out("o279 " + Std.string(v273));
				};
			}
		} else {
			C36.m43((new Map<String, Int>()).exists("\n"), "0");
			switch (v273) {
				case 0: {
					H.out("o280 " + Std.string(new C14(101)));
				};
				case 1 | 5: {
					H.out("o281 " + Std.string(81));
					C36.f37 += v273;
				};
				case _: {
					H.out("o282 " + Std.string(v273));
				};
			}
		}
		H.out("o283 " + Std.string(C25.f27));
		if (([290, v273]).ext69()) {
			if (false) {
				H.out("o284 " + Std.string(v273));
				var v285:C46 = new C46(1595365653, "\\");
			}
		} else {
			var v286:Box<Int> = new Box(v273);
			switch (C36.f37) {
				case 0: {
					fn67();
					var v287:C6 = new C6();
				};
				case 3 | 4: {
					var v288:Map<String, Int> = new Map<String, Int>();
					H.out("o289 " + Std.string(new C46(v273, "\t")));
				};
				case _: {
					var v290:C14 = new C14(v273);
					(v290).m19();
				};
			}
		}
		var v291:Map<String, Int> = (["k0" => ("\"q\"").indexOf("0"), "k1" => (Std.parseInt(Std.string(v273)) ?? 0), "k2" => (v272 : Int)] : Map<String, Int>);
		H.out("o292 " + Std.string((v273 > v273)));
	}
	public static function section1():Void {
		H.tick();
		(H.id(new C36("hello world", true))).m42();
		switch ((Lambda.fold(([] : Array<Int>), (v293:Int, v294:Int) -> ("-7").lastIndexOf("-7"), 0) % H.nz((("x,y,z").charCodeAt(295) ?? -1)))) {
			case 0: {
				try {
					C36.f37 = 143;
					if (StringTools.contains("\t", "abc")) throw new Err((Std.parseInt(Std.string(251)) ?? 0));
				} catch (ex295:String) {
					H.out("caught String " + ex295);
					var v296:Map<String, String> = (["k0" => ex295, "k1" => "hello world", "k2" => ex295] : Map<String, String>);
				} catch (ex297:Int) {
					H.out("caught Int " + ex297);
					H.out("o298 " + "-7");
				} catch (ex299:Err) {
					H.out("caught Err " + ex299.errCode);
					H.out("o300 " + "\"q\"");
					H.out("o301 " + Std.string(new C14(0x99CE)));
				} catch (ex302:Dynamic) {
					H.out("caught " + H.exn(ex302));
					H.out("o303 " + "  pad  ");
					fn57();
				}
				var v304 = 2;
			};
			case 3 | 5: {
				C14.f17 = ("\t").length;
			};
			case _: {
				C14.f17 = Lambda.count([24, 54, 213], v305 -> StringTools.startsWith("q", "\"q\""));
			};
		}
		(([23, 281]).filter(v306 -> ((["k0" => new A0(v306), "k1" => new A0(v306), "k2" => (v306 : A0)] : Map<String, A0>)).exists("k1"))).ext69();
		try {
			if (C25.f27) throw ((new Map<Int, Int>()).exists(18) + "A-B-C");
			(new C14(46)).m19();
			if ((new Map<Int, Int>()).exists((-17))) {
				(new C6()).m11(new Map<Int, Int>(), 0x7FFFFFFF);
				final v307 = false;
			} else {
				final v308:Int = 542053332;
			}
		} catch (ex309:Dynamic) {
			H.out("caught " + H.exn(ex309));
			switch (K1.K1B) {
				case K1.K1A: {
					var v310:Int = 223;
				};
				case K1.K1B: {
					var v311:Bool = true;
				};
				case K1.K1C: {
					var v312:A0 = new A0(0xA2BF);
					var v313:Int = (-8);
				};
				case _: {
					H.out("o314 " + Std.string(0x1E2A));
				};
			}
			(new C25(215)).m32();
		}
		final v315:C6 = new C6();
	}
	public static function section2():Void {
		H.tick();
		C36.f37 -= 0xFFFFFFFF;
		switch (fn57()) {
			case 0: {
				var v316:Int = ((new Map<String, Int>()).get("-7") ?? 0);
				switch ((K1.K1A : Int)) {
					case 0: {
						final v317:Int = 162;
					};
					case 3 | 5: {
						var v318:Int = v316;
					};
					case _: {
						var v319 = v316;
						H.out("o320 " + Std.string(new C25(v316)));
					};
				}
			};
			case 3 | 6: {
				C36.f37 *= ("  pad  ").indexOf("-7");
			};
			case _: {
				C36.f37 = 257;
				H.out("o321 " + Std.string(new C14(32)));
			};
		}
		var v322:String = "hello world";
		H.out("o323 " + v322);
		var v324:C6 = new C6();
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
