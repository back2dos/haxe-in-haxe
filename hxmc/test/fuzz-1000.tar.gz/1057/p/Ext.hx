package p;

import Main;
import H;
using StringTools;

class Ext {
	public static function ext69(a68:Array<Int>):Bool {
		H.tick();
		var v268:C46 = ((true ? new C46(147, "hello world") : new C46(0x7FFFFFFF, "0")) : C46);
		var v269:String = '-${"a"}';
		H.out("o270 " + v269);
		C36.f37 *= (new A0(0xFFFFFFFF) : Int);
		var v271:Int = (((["k0" => 156, "k1" => 274] : Map<String, Int>)).get(v269) ?? 0);
		return false;
	}
}
