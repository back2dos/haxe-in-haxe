import H;
import p.M1;

abstract A8(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A8, b:A8):A8
		return new A8(a.get() + b.get());

	@:op(A * B) public static function mul(a:A8, b:A8):A8
		return new A8(a.get() * b.get());

	@:op(-A) public static function neg(a:A8):A8
		return new A8(-a.get());
}

enum abstract K9(Int) to Int {
	var K9A = 1;
	var K9B = 4;
	var K9C = 7;
}

class Main {
	public static function fn10(a11:Bool, a12:E0, a13:String = "d"):Array<String> {
		H.tick();
		H.out("o34 " + a13);
		var v35 = Std.string(a11);
		for (i36 in 0...3) {
			H.tick();
			if (a11) {
				H.out("o37 " + Std.string(i36));
				final v38:K9 = K9.K9B;
				var v39:Int = (-2);
			} else {
				var v40:Int = i36;
			}
		}
		H.out("o41 " + Std.string((105 << ((-10) & 31))));
		for (k42 => v43 in (["k0" => ("日本語").length, "k1" => (new A8(175)).twice, "k2" => H.at(([] : Array<Int>), 287, 0)] : Map<String, Int>)) {
			H.tick();
			var v44 = v43;
			var v45:String = v35;
			var v46:Array<Int> = [v43, v43, v43];
		}
		return (cast ([a13, ("a").toLowerCase()]) : Array<String>);
	}
	public static function fn14():Int {
		H.tick();
		{
			var v47:K9 = K9.K9C;
			final v48:Array<Int> = [249];
		}
		Main.fn10(false, ((false ? E0.E0C : E0.E0A) : E0));
		var v49:A8 = (-(0xF0F1 : A8));
		H.out("o50 " + Std.string([for (i51 in 0...2) (({x5: i51, x6: "hello world", x7: 194} : S4)).x7]));
		if (false) return 0x80000000;
		for (i52 in 0...H.lim((-240))) {
			H.tick();
			final v53:E0 = E0.E0C;
			var v54 = i52;
		}
		return 115;
	}
	public static function fn15(a16:Bool, a17:Int = 4):Int {
		H.tick();
		for (k55 => v56 in ((false ? new Map<String, Int>() : new Map<String, Int>()) : Map<String, Int>)) {
			H.tick();
			fn14();
			final v57:Map<String, String> = (["k0" => k55, "k1" => k55] : Map<String, String>);
		}
		var v58 = a17;
		var v59:Int = a17;
		var v60:Bool = a16;
		return (v58--);
	}
	public static function fn18(a19:Int, a20:S4):Bool {
		H.tick();
		if ((true ? StringTools.contains("  pad  ", "  pad  ") : true)) {
			var v61 = Type.enumIndex(E0.E0A);
			final v62 = 29;
		} else {
			fn10((([] : Array<Int>)).contains(a19), E0.E0A, "\"q\"");
			H.out("o63 " + Std.string(true));
		}
		fn10(true, E0.E0D("a\rb"), 'x${Std.string(true)}${Std.string(((["k0" => 41, "k1" => a19, "k2" => a19] : Map<String, Int>)).exists("k2"))}');
		for (i64 in 0...H.lim(Main.fn15((([-3 => a20, 4 => a20] : Map<Int, S4>)).exists(4), (new A8(a19)).twice))) {
			H.tick();
			H.out("o65 " + "ab");
			var v66:K9 = K9.K9C;
		}
		H.out("o67 " + Std.string(Reflect.compare(StringTools.hex((a19) & 0xFFFF, 4), Std.string(a19))));
		var w68 = 0;
while (w68 < 3 && ("\"q\"" < "")) {
			w68++;
			H.tick();
			a19 = 105;
		}
		return true;
	}
	public static function fn21():Int {
		H.tick();
		if (true) return Main.fn15(false, (Std.parseInt(Std.string(221)) ?? 0));
		fn15(fn18(2, ({x7: 96, x6: "\t", x5: 264} : S4)));
		var v69:Array<Int> = [for (i70 in [false, false]) if (false) 37];
		fn14();
		H.out("o71 " + Std.string(({x5: ("x,y,z").lastIndexOf("ab"), x6: ([false, true]).join(""), x7: (("abc").split(" ")).length} : S4)));
		H.out("o72 " + Std.string((StringTools.startsWith("é", "") ? 168 : Type.enumIndex(E0.E0C))));
		v69.pop();
		return 283;
	}
	public static function fn22(a23:Bool, a24:Int, a25:Bool):Int {
		H.tick();
		H.out("o73 " + Std.string((a24 * Reflect.compare("  pad  ", "\x41\x42"))));
		final v74 = ([a23]).join("");
		H.out("o75 " + Std.string((K9.K9B : Int)));
		var v76:Map<String, Bool> = new Map<String, Bool>();
		return (a24 + ((new Map<String, Int>()).get("zz") ?? 0));
	}
	public static function fn26():E0 {
		H.tick();
		var v77:Array<Int> = [(K9.K9C : Int)];
		fn10(true, E0.E0D("a"), (true ? Std.string(199) : "Haxe"));
		H.out("o78 " + Std.string(null));
		return E0.E0C;
	}
	public static function fn27():Void {
		H.tick();
		final lf79:() -> String = () -> String.fromCharCode(65 + ((135) & 15));
		final v80:Map<Int, Bool> = ((([65, 39, (-438813726)]).contains(18) ? new Map<Int, Bool>() : new Map<Int, Bool>()) : Map<Int, Bool>);
		fn15(fn18(57, ({x7: 251, x5: 168, x6: "\"q\""} : S4)), 125);
		for (x81 in (cast (([] : Array<Int>)) : Array<Int>)) {
			H.tick();
			H.out("o82 " + Std.string([(-1917034406)]));
			if (true) {
				Main.fn15(true);
				fn18(x81, ({x5: x81, x6: "a", x7: x81} : S4));
			} else {
				var v83:Array<Bool> = [true, false];
			}
		}
		H.out("o84 " + Std.string(285));
		final v85:String = String.fromCharCode(65 + ((H.at([65535, 1565914729], 65535, 0)) & 15));
	}
	public static function fn28(?a29:Null<String>):String {
		H.tick();
		H.out("o86 " + Std.string(([null] : Array<Null<Int>>)));
		final v87:Map<Int, Int> = ([-3 => 1555613427, 4 => 0x80000000, 11 => (-1234292965)] : Map<Int, Int>);
		var v88:E0 = E0.E0C;
		return '-${Std.string((106 != Reflect.compare("abc", "ünï")))}';
	}
	public static function fn30(a31:A8, a32:Array<Bool>, a33:A8):K9 {
		H.tick();
		Main.fn15((false ? false : false));
		var v89:Array<Int> = ([] : Array<Int>);
		final v90:Map<Int, Bool> = new Map<Int, Bool>();
		var w91 = 0;
do {
			w91++;
			H.tick();
			var v92:Array<String> = ["\"q\"", "x,y,z"];
			final v93:Map<String, String> = new Map<String, String>();
			for (x94 in a32) {
				H.tick();
				fn18(0xC3F5, ({x5: 110, x6: "a\rb", x7: 30} : S4));
				final v95:E0 = E0.E0C;
			}
		} while (w91 < 2 && !false);
		H.out("o96 " + Std.string((("\t").charCodeAt(19) ?? -1)));
		return K9.K9B;
	}
	public static function section0():Void {
		H.tick();
		H.out("o97 " + Std.string((K9.K9A : Int)));
		var v98:Int = Main.fn22(true, (("a").charCodeAt(0xF24D) ?? -1), true);
		var v99 = "-7";
	}
	public static function section1():Void {
		H.tick();
		fn18(Reflect.compare(("日本語").toLowerCase(), "  pad  "), ({x7: (-6), x6: StringTools.lpad("\\", "*", 4), x5: (Std.parseInt("\x41\x42") ?? 0)} : S4));
		var v100 = 114;
		H.out("o101 " + Std.string((v100 == (("\x41\x42").charCodeAt(v100) ?? -1))));
		var w102 = 0;
while (w102 < 5 && (StringTools.hex((v100) & 0xFFFF, 4) > ("\x41\x42").charAt(6))) {
			w102++;
			H.tick();
			if (false) {
				var v103:Map<String, String> = (["k0" => "-7"] : Map<String, String>);
				Main.fn30(new A8(v100), [false], new A8(v100));
			}
			for (i104 in 0...H.lim(141)) {
				H.tick();
				v100 <<= (120 & 7);
				var v105:Null<Int> = v100;
			}
			var v106:Bool = false;
		}
		var v107:String = (cast ("\u{1F600}") : String);
		if ((false || (([] : Array<Int>)).contains(v100))) {
			H.out("o108 " + Std.string(([v100]).contains(v100)));
		} else {
			for (i109 in 2...H.lim((Std.parseInt(v107) ?? 0))) {
				H.tick();
				var v110 = true;
				final v111:Map<String, Int> = new Map<String, Int>();
			}
			final lf112:() -> String = () -> (v107).toLowerCase();
		}
		fn18(v100, ({x5: (-908035702), x6: v107, x7: v100} : S4));
		final v113:E0 = Main.fn26();
	}
	public static function section2():Void {
		H.tick();
		final lf114:(Int) -> Int = (p115:Int) -> (Std.string(p115)).lastIndexOf(Std.string(E0.E0B(true, p115)));
		final v116:E0 = ({ var v117 = (([-3 => false, 4 => false] : Map<Int, Bool>)).exists(11); E0.E0C; });
		for (i118 in 0...0) {
			H.tick();
			var v119 = i118;
		}
		final v120:Map<Int, Int> = new Map<Int, Int>();
		var v121 = (Std.parseInt(String.fromCharCode(65 + ((0xEE09) & 15))) ?? 0);
		final v122:Array<Bool> = ([] : Array<Bool>);
		v121 = ("  pad  ").indexOf(StringTools.lpad("A-B-C", "*", 1));
		var v123 = (cast (Std.string(v121)) : String);
	}
	public static function section3():Void {
		H.tick();
		var v124:Int = (false ? (({x5: 167, x6: "\u{1F600}", x7: (-1)} : S4)).x7 : Type.enumIndex(E0.E0A));
		for (i125 in 0...0) {
			H.tick();
			var v126:Array<Int> = [v124];
		}
		var v127:Array<Int> = ([v124]).slice(1, 0);
		final v128:Int = (new A8((-325647781)) : Int);
		if (true) {
			if (false) {
				H.out("o129 " + Std.string(104));
			} else {
				final v130:Map<String, String> = new Map<String, String>();
				H.out("o131 " + Std.string(({x5: 188, x6: "abc", x7: v128} : S4)));
			}
		} else {
			fn28("a");
			if ((v127).contains(v124)) {
				final v132:Array<String> = ["-7", "\x41\x42"];
				H.out("o133 " + "abc");
			} else {
				v124 = H.id(v124);
				var v134:Null<Int> = null;
			}
		}
	}
	public static function section4():Void {
		H.tick();
		Main.fn30(((({x7: 0x7FFFFFFF, x5: 0x85D1, x6: "é"} : S4)).x5 : A8), [for (i135 in [0x9517]) if (false) (([-3 => i135, 4 => i135] : Map<Int, Int>)).exists(11)], new A8(145));
		var v136 = (10 << (("A-B-C").indexOf("a\rb") & 31));
		H.out("o137 " + Std.string(fn10(([86]).contains(v136), E0.E0D("\\"), "A-B-C")));
		H.out("o138 " + Std.string(E0.E0B(StringTools.startsWith("é", "0"), (v136 += 3))));
		{
			var v139 = H.at([v136, v136], v136, 0);
			final v140:Array<Int> = [v136, v136];
			Main.fn28("\n");
		}
		if (true) {
			fn26();
			H.out("o141 " + Std.string((K9.K9C : Int)));
		} else {
			var w142 = 0;
do {
				w142++;
				H.tick();
				Main.fn18(v136, ({x5: 87, x6: "\\", x7: v136} : S4));
			} while (w142 < 4 && false);
			for (i143 in 0...3) {
				H.tick();
				v136 = H.id(v136);
				var v144:A8 = (i143 : A8);
				var v145 = i143;
			}
		}
		var v146:Array<String> = [for (i147 in 0...0) StringTools.lpad("ab", "*", 6)];
		for (i148 in 0...H.lim(v136)) {
			H.tick();
			var v149:Int = (("\\").charCodeAt(i148) ?? -1);
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
