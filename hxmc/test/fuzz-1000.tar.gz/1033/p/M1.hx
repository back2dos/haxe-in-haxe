package p;

import Main;
import H;
import p.M1;

class M1 {}

enum E0 {
	E0A;
	E0B(a1:Bool, a2:Int);
	E0C;
	E0D(a3:String);
}

typedef S4 = {x5:Int, x6:String, x7:Int};
