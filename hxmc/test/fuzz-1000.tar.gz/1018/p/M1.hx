package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
	E0B;
	E0C(a1:Int, a2:String);
}

class C58 implements I17 {
	public var f59:Int;
	var _f60:Float;

	public var f60(get, set):Float;

	function get_f60():Float
		return _f60;

	function set_f60(v:Float):Float
		return _f60 = v;
	var _f61:Int;

	public var f61(get, set):Int;

	function get_f61():Int
		return _f61;

	function set_f61(v:Int):Int
		return _f61 = v;
	public function new() {
		this.f59 = (("abc").charCodeAt(39) ?? -1);
		this._f60 = 1e3;
		this._f61 = ("日本語").indexOf("  pad  ");
	}
	public function m18():Array<Int> {
		H.tick();
		if (Main.fn83()) {
			C38.f40 &= Math.floor(1e100);
			final v221:K16 = K16.K16C;
		}
		if (Main.fn83()) {
			var v222:Float = 0xC71F;
			var v223:Int = 208;
		}
		final v224:Int = (Std.string(1e-7)).ext91(266);
		if ((true ? (([-3 => new C31(E0C(v224, "q")), 4 => new C31(E0.E0A), 11 => new C31(E0.E0B)] : Map<Int, C31>)).exists(v224) : ([82]).contains(v224))) {
			H.out("o225 " + Std.string((({x13: v224, x14: v224, x15: 21} : S12)).x15));
			H.out("o226 " + Std.string(({x14: v224, x15: v224, x13: (-1308195707)} : S12)));
			C38.f40 |= ((new Map<String, Int>()).get("k3") ?? 0);
		}
		if (((("Haxe").charCodeAt((-9)) ?? -1) >= v224)) {
			{
				Main.fn72(0xF728, 1.25, "q");
			}
			if (true) {
				H.out("o227 " + Std.string(v224));
				final v228:Array<String> = ("zz").split("a");
				final v229:E0 = E0.E0C(v224, "日本語");
			} else {
				this.m63([true]);
				var v230:Array<Int> = [v224, v224];
			}
			{
				var v231:Array<Bool> = ([] : Array<Bool>);
				var v232:Int = v224;
				this.f61 -= 281;
			}
		}
		return [H.id((Std.parseInt(Std.string(v224)) ?? 0)), ((([v224] : Array<Float>)).length >>> (Reflect.compare(v224, 0xFFFFFFFF) & 31))];
	}
	public function m19():Array<Bool> {
		H.tick();
		H.out("o233 " + Std.string(new C49(true, (["\u{1F600}"]).indexOf("\n"))));
		switch (E7.E7A) {
			case E7A: {
				if (Std.isOfType(new C49(false, (-1583963346)), C49)) return [false, false];
				m62();
			};
			case E7B(_, c234): {
				H.out("o235 " + Std.string(100.75));
				var v236 = this.f59;
			};
			case E7C(c237, c238): {
				(new C58()).m18();
			};
		}
		var v239:Array<String> = [for (i240 in [(-240688786)]) if (StringTools.startsWith("ab", "x,y,z")) ("\x41\x42").substring((i240 & 7), -1)];
		H.out("o241 " + Std.string(new C38(Math.round(1.25))));
		(new C38(Math.round(0.30000000000000004))).m18();
		return (cast ([for (i242 in [111, 130, 164]) if (StringTools.contains("42", "\t")) false]) : Array<Bool>);
	}
	public function m62():Array<I17> {
		H.tick();
		try {
			try {
				C38.f40 *= (-10);
				var v243:Box<Int> = new Box<Int>(36);
				final v244:K16 = K16.K16A;
				if ((([-3 => 1e-7, 4 => 3.0] : Map<Int, Float>)).exists(4)) throw new Err((("hello world").charCodeAt(0xFAE6) ?? -1));
			} catch (ex245:Dynamic) {
				H.out("caught " + H.exn(ex245));
				var v246:K16 = K16.K16D;
			}
			if ((new Map<Int, Int>()).exists(18)) {
				this.f61 &= 30;
				var v247:Int = 154;
			} else {
				(new C49(true, 230)).m52();
			}
			if (false) throw "boom";
		} catch (ex248:Err) {
			H.out("caught Err " + ex248.errCode);
			if (true) {
				var v249:Box<Int> = new Box(132);
				var v250:Map<Int, Int> = ([-3 => (-9), 4 => 1131787105, 11 => 65535] : Map<Int, Int>);
			}
		} catch (ex251:haxe.Exception) {
			H.out("caught " + H.exn(ex251));
			C38.f40 *= (["\n", "ab"]).length;
			H.out("o252 " + Std.string(E0.E0C(0xF390, "abc")));
		}
		H.out("o253 " + Std.string(({ var v254 = (Std.parseInt(Std.string(120)) ?? 0); E0.E0B; })));
		(H.id(new C49(false, (-1069281378)))).m52();
		var v255:Array<String> = ["0", Std.string(true), StringTools.replace("abc", "b", "q")];
		H.out("o256 " + Std.string(125));
		H.out("o257 " + Std.string(this.f60));
		return (([for (i258 in 0...1) new C38(9)] : Array<I17>)).copy();
	}
	public function m63(a64:Array<Bool>):Int {
		H.tick();
		final v259:Array<Int> = (new Box<Array<Int>>(([] : Array<Int>))).get();
		switch ((false ? "é" : ("日本語").toUpperCase())) {
			case "a" | "b": {
				var v260:E3 = E3.E3A;
			};
			case "Haxe": {
				switch ((-1402428312)) {
					case 0: {
						++C38.f39;
					};
					case 1 | 6: {
						(new C49(false, 148)).m52();
					};
					case _: {
						var v261:Array<Array<C53>> = ([([new C53(), new C53(), new C53()] : Array<C53>), ([new C53()] : Array<C53>)] : Array<Array<C53>>);
					};
				}
				H.out("o262 " + ("\u{1F600}").charAt(-1));
			};
			case "": {
				final lf263:() -> Bool = () -> true;
				H.out("o264 " + StringTools.trim("ünï"));
			};
			case _: {
				H.out("o265 " + Std.string(75));
			};
		}
		var v266:Map<Int, Bool> = ((false ? ([-3 => false] : Map<Int, Bool>) : ([-3 => true, 4 => true] : Map<Int, Bool>)) : Map<Int, Bool>);
		var v267:Array<String> = [Std.string(true), "\u{1F600}"];
		m62();
		return this.f59;
	}
	public static function m65():Int {
		H.tick();
		H.out("o268 " + Std.string((new C38(602164775)).m43(C38.f40, C38.f39)));
		C38.f39++;
		var v269:Float = C38.f40;
		{
			if (Math.isNaN(123456.789)) {
				(new C58()).m19();
				var v270:String = "abc";
			} else {
				H.out("o271 " + Std.string(65535));
				var v272:Array<String> = ["", "ünï"];
			}
			var v273:String = Std.string(0.1);
		}
		++C38.f39;
		C38.f40 = (switch (240) {
			case 0: (Std.parseInt(Std.string(257)) ?? 0);
			case 3 | 4: 238;
			case _: 203;
		});
		H.out("o274 " + Std.string(new C31(E0B)));
		H.out("o275 " + Std.string(((switch ("") {
			case "a" | "b": E0.E0A;
			case "Haxe": E0.E0A;
			case _: E0.E0C(0x6A46, "0");
		}) : E0)));
		C38.f40 = ("  pad  ").ext91(C38.f39);
		return (switch (H.id(C38.f40)) {
			case 0: H.id(Reflect.compare("Haxe", "\x41\x42"));
			case 1 | 4: (new C31(E0.E0C(280, "\\"))).m34();
			case _: 65535;
		});
	}
	public function m66(a67:Bool, a68:Bool):Void {
		H.tick();
		this.f59 = this.f61;
		if (((-18) != ("0").indexOf("abc"))) {
			var v276:Map<Int, String> = ([-3 => "\u{1F600}", 4 => "-7"] : Map<Int, String>);
		} else {
			var v277 = ((new Map<String, Int>()).get("abc") ?? 0);
			if (StringTools.contains("a", "ünï")) {
				v277 |= v277;
				H.out("o278 " + Std.string((K16.K16D : Int)));
			}
		}
		this.f59 += (a68 ? (({x13: 186, x14: 100.75, x15: 178} : S12)).x15 : 0xFFFFFFFF);
		var v279:S12 = (cast (({x13: 178, x14: 2.5e-3, x15: 231} : S12)) : S12);
		var v280:Int = (188 * 278);
		try {
			(new C31(E0A)).m35(new C31(E0C(v280, "\u{1F600}")), 3.0);
			var v281 = (([] : Array<Int>)).contains(19);
			C38.f39 = v280;
			if (true) throw ([false, false, true]).join(",");
		} catch (ex282:String) {
			H.out("caught String " + ex282);
			var v283:Map<Int, String> = new Map<Int, String>();
			final v284:Array<Float> = ([v280] : Array<Float>);
		} catch (ex285:Int) {
			H.out("caught Int " + ex285);
			var v286:C31 = new C31(E0.E0C(ex285, "\u{1F600}"));
			var v287:Array<Int> = [ex285, ex285];
		} catch (ex288:Err) {
			H.out("caught Err " + ex288.errCode);
			var v289:String = Std.string(225);
			final lf290:(Bool) -> Int = (p291:Bool) -> 248;
		} catch (ex292:Dynamic) {
			H.out("caught " + H.exn(ex292));
			Main.fn69(true);
			var v293:Int = v280;
		}
		switch (this.f59) {
			case 0: {
				var v294:Array<Bool> = [a67, a67, a68];
				try {
					if (true) throw 76;
					H.out("o295 " + Std.string(a68));
					var v296:Float = 0.1;
				} catch (ex297:String) {
					H.out("caught String " + ex297);
					var v298:E7 = E7.E7A;
				} catch (ex299:Int) {
					H.out("caught Int " + ex299);
					var v300:Array<String> = ["ab", "abc", "\n"];
				} catch (ex301:Err) {
					H.out("caught Err " + ex301.errCode);
					var v302:String = "\"q\"";
					H.out("o303 " + "ab");
				} catch (ex304:Dynamic) {
					H.out("caught " + H.exn(ex304));
					H.out("o305 " + Std.string(v280));
					var v306:S12 = v279;
				}
			};
			case 1 | 4: {
				var v307:Float = 1e-7;
			};
			case _: {
				(new C58()).m62();
			};
		}
		Main.fn72(v280, 3.0, C20.m25(v280, (-2054026009), 0x7404));
		if (Main.fn83()) {
			final v308:Array<Float> = ([v280] : Array<Float>);
		} else {
			this.f61 = ("a\rb").length;
		}
	}
}
