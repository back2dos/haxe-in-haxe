package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext91(a89:String, a90:Int):Int {
		H.tick();
		C38.f39 += C38.f40;
		final v420:Null<Int> = (((new Map<Int, Int>()).exists(4) ? a90 : a90) : Null<Int>);
		var v421:Float = (Math.sin(a90) + a90);
		return a90;
	}
}
