package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

enum E3 {
	E3A;
	E3B(a5:String, a6:Bool);
}

enum E7 {
	E7A;
	E7B(a8:Int, a9:Int);
	E7C(a10:String, a11:Float);
}

typedef S12 = {x13:Int, x14:Float, x15:Int};

class C49 {
	public function new(a50:Bool, a51:Int) {}
	public function m52():Void {
		H.tick();
		final v171:Float = (100.75 * Std.int(0.30000000000000004));
		try {
			if (false) throw "boom";
			C38.f39 |= Math.ceil(v171);
			var v172:String = Std.string(3.0);
			if (true) {
				H.out("o173 " + Std.string(212));
				H.out("o174 " + Std.string(E7.E7B(106, 139)));
				H.out("o175 " + Std.string(166));
			} else {
				H.out("o176 " + "A-B-C");
				H.out("o177 " + Std.string(259));
			}
		} catch (ex178:String) {
			H.out("caught String " + ex178);
			try {
				var v179:Map<String, Int> = new Map<String, Int>();
				if (StringTools.contains("\\", ex178)) throw 15;
			} catch (ex180:String) {
				H.out("caught String " + ex180);
				H.out("o181 " + Std.string(([] : Array<Int>)));
			} catch (ex182:Int) {
				H.out("caught Int " + ex182);
				var v183:Int = (-5);
			} catch (ex184:Err) {
				H.out("caught Err " + ex184.errCode);
				final v185:K16 = K16.K16B;
			} catch (ex186:Dynamic) {
				H.out("caught " + H.exn(ex186));
				var v187:Float = 0.5;
				C38.f40 -= (-1);
			}
			switch (ex178) {
				case "a" | "b": {
					H.out("o188 " + Std.string(23));
					C38.f39 = 143;
				};
				case "Haxe": {
					var v189:E7 = E7C("abc", 1.7976931348623157e308);
					final v190:Array<Int> = ([] : Array<Int>);
				};
				case _: {
					var v191:C58 = new C58();
					H.out("o192 " + Std.string(0x4E98));
				};
			}
		} catch (ex193:Int) {
			H.out("caught Int " + ex193);
			C38.f40 = ex193;
		} catch (ex194:Err) {
			H.out("caught Err " + ex194.errCode);
			var v195:Int = (([] : Array<Bool>)).indexOf(false);
		} catch (ex196:Dynamic) {
			H.out("caught " + H.exn(ex196));
			H.out("o197 " + StringTools.hex((105) & 0xFFFF, 4));
		}
		var v198:Map<String, Int> = (["k0" => Reflect.compare(199, (-706522585)), "k1" => 255, "k2" => (("hello world").charCodeAt(0xFFFFFFFF) ?? -1)] : Map<String, Int>);
		var v199:E7 = E7.E7C(Std.string(252), 1.25);
		C38.f39 <<= (((Std.string(0.1)).charCodeAt(("Haxe").length) ?? -1) & 7);
	}
}
