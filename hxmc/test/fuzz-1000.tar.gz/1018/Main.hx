import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum abstract K16(Int) to Int {
	var K16A = 1;
	var K16B = 4;
	var K16C = 7;
	var K16D = 10;
}

interface I17 {
	function m18():Array<Int>;
	function m19():Array<Bool>;
}

abstract class C20 implements I17 {
	public var f21:Int;
	public var f22:Bool;
	public function new(a23:String, a24:String) {
		this.f21 = 135;
		this.f22 = Std.isOfType(null, I17);
	}
	public function m18():Array<Int> {
		H.tick();
		var v92:Box<C49> = new Box<C49>(new C49(false, 235));
		H.out("o93 " + Std.string(Type.enumIndex(E3.E3A)));
		final lf94:() -> Bool = () -> (1e-7 == Math.PI);
		C38.f40 *= (Std.parseInt(Std.string(Math.round(2.5e-3))) ?? 0);
		Main.fn79((new C58()).m63([false]), 288, (Math.pow(1.7976931348623157e308, 2) != Std.parseFloat("1.5")));
		var v95:Float = (new Box<Float>(123456.789)).get();
		if (Main.fn83()) {
			final v96:Int = H.at([266, 221], 567580491, 0);
			final v97:Array<Float> = ([v95, v96] : Array<Float>);
		} else {
			H.out("o98 " + Std.string(([] : Array<K16>)));
		}
		var v99:Map<String, String> = H.apply(String.fromCharCode(65 + ((213) & 15)), (v100:String) -> (["k0" => v100, "k1" => v100, "k2" => "A-B-C"] : Map<String, String>));
		return ([(([v95] : Array<Float>)).length, (Std.parseInt("abc") ?? 0)]).concat(([0x3490, 169, 186]).concat([185]));
	}
	abstract public function m19():Array<Bool>;
	public static function m25(a26:Int, a27:Int, ...r28:Int):String {
		H.tick();
		var v101:Map<String, String> = (["k0" => "0", "k1" => StringTools.replace("Haxe", ",", "ab"), "k2" => "日本語"] : Map<String, String>);
		if ((switch ((-1)) {
			case 0: (r28.toArray()).contains(a27);
			case 1 | 6: false;
			case _: StringTools.startsWith("a\rb", "\t");
		})) {
			H.out("o102 " + Std.string(("Haxe").indexOf("\"q\"")));
			var v103:E3 = E3.E3B("\u{1F600}", true);
		} else {
			var v104:Array<Bool> = [true, false];
			a27 = a26;
		}
		(new C49(true, a26)).m52();
		H.out("o105 " + Std.string(a26));
		((cast (new C58()) : C58)).m19();
		var v106:Box<C31> = new Box<C31>(new C31(E0.E0A));
		var v107:Bool = !true;
		final v108 = (StringTools.hex((a27) & 0xFFFF, 4)).substr(3, (a27 & 7));
		try {
			if (H.id(v107)) throw "boom";
			var v109 = C38.f39;
		} catch (ex110:Dynamic) {
			H.out("caught " + H.exn(ex110));
			var v111:E7 = E7.E7C("Haxe", 123456.789);
			var v112:Array<String> = [v108];
		}
		return (v108 + v108);
	}
	public function m29(...r30:Int):E7 {
		H.tick();
		final v113:Box<Bool> = new Box(this.f22);
		if ((true || false)) {
			r30.toArray().remove(287);
			H.out("o114 " + Std.string(new C53()));
			C38.f40--;
		} else {
			(new C58()).m62();
		}
		C38.f40 += this.f21;
		C38.f39 = (StringTools.hex(((-1769989459)) & 0xFFFF, 4)).indexOf(("x,y,z").toLowerCase());
		if (this.f22) {
			H.out("o115 " + Std.string(E0.E0C(0x7FFFFFFF, "\t")));
			var v116 = C38.f40;
		}
		var v117:Int = 174;
		var v118:Array<String> = [for (i119 in 0...4) Std.string(v117)];
		v117 = H.id(v117);
		return Main.fn76(v117, C38.f40);
	}
}

class C31 {
	public final f32:String;
	public function new(a33:E0) {
		this.f32 = StringTools.lpad("A-B-C", "*", 3);
	}
	public function m34():Int {
		H.tick();
		C38.f40 = (new C58()).m63([false, false, false]);
		var v120 = (Reflect.compare("A-B-C", "\t") - 2098259578);
		H.out("o121 " + Std.string((199 % H.nz(169))));
		var v122:Map<Int, Int> = ((true ? new Map<Int, Int>() : ([-3 => v120, 4 => (-4)] : Map<Int, Int>)) : Map<Int, Int>);
		var v123:Float = v120;
		H.out("o124 " + Std.string(false));
		return C38.f39;
	}
	public function m35(a36:C31, a37:Float):Bool {
		H.tick();
		final v125:Map<Int, Float> = new Map<Int, Float>();
		a37 = C38.f40;
		Main.fn72((Std.int(a37) * (((["k0" => 8] : Map<String, Int>)).get("k1") ?? 0)), (cast (2.5e-3) : Float), (false + this.f32));
		return false;
	}
}

class C38 implements I17 {
	public static var f39:Int = 263;
	public static var f40:Int = 0x80000000;
	public var f41:Float;
	public function new(a42:Int) {
		this.f41 = 1e21;
	}
	public function m18():Array<Int> {
		H.tick();
		final v126 = (switch (E7.E7A) {
			case E7A: ("\n").replace("a", "b");
			case E7C(c127, c128): (c127).toUpperCase();
			case _: StringTools.trim("q");
		});
		var v129:C31 = new C31(E0.E0A);
		H.out("o130 " + Std.string(0.1));
		var v131 = "hello world";
		var v132:Map<String, Float> = new Map<String, Float>();
		var v133 = 0xFFFFFFFF;
		C38.f40 = (-131);
		Main.fn69(true);
		var v134:Int = ("hello world").lastIndexOf(v131);
		return [74, ((v131).indexOf("\n") - H.at([79], v133, 0))];
	}
	public function m19():Array<Bool> {
		H.tick();
		this.m18();
		H.out("o135 " + Std.string(new C31(E0.E0C(865190424, "a"))));
		H.out("o136 " + Std.string((switch (K16.K16B) {
			case K16.K16A: 155;
			case K16.K16B: C38.f39;
			case K16.K16C: (({x13: 154, x14: 0.30000000000000004, x15: 0xF762} : S12)).x15;
			case K16.K16D: (-1396711351);
		})));
		var v137:Float = C38.f39;
		return [for (i138 in ([] : Array<Float>)) if ((63 != (("").charCodeAt(124) ?? -1))) false];
	}
	public function m43(a44:Int, a45:Int):Int {
		H.tick();
		var v139:Float = ((([78]).contains(a45) ? a45 : a44) : Float);
		var v140:Array<String> = [for (i141 in ([] : Array<Float>)) if (true) ("hello world").replace("a", "b")];
		{
			C20.m25(252, Type.enumIndex(E3.E3B("\n", false)));
			var v142:Map<String, E0> = (["k0" => E0.E0C(a44, "ünï"), "k1" => E0.E0B, "k2" => E0.E0B] : Map<String, E0>);
		}
		final v143:Array<Float> = ([v139, 5e-324, (-2147483647)] : Array<Float>);
		try {
			try {
				H.out("o144 " + Std.string(v140));
				H.out("o145 " + Std.string(false));
				if (false) throw new Err(C38.f40);
			} catch (ex146:Err) {
				H.out("caught Err " + ex146.errCode);
				H.out("o147 " + Std.string(E0.E0B));
			} catch (ex148:haxe.Exception) {
				H.out("caught " + H.exn(ex148));
				C38.f40 |= a45;
				a45 &= 213;
			}
			H.out("o149 " + Std.string(7.0));
			(new C58()).m18();
			if (false) throw 'x${("é").substr(-2, 0)}<${Std.string(true)}';
		} catch (ex150:String) {
			H.out("caught String " + ex150);
			a45 <<= (0xEB5A & 7);
		} catch (ex151:Int) {
			H.out("caught Int " + ex151);
			H.out("o152 " + Std.string(a45));
			var v153 = true;
		} catch (ex154:Err) {
			H.out("caught Err " + ex154.errCode);
			H.out("o155 " + Std.string(([] : Array<Int>)));
		} catch (ex156:Dynamic) {
			H.out("caught " + H.exn(ex156));
			H.out("o157 " + Std.string([153, a45, a45]));
			a44 = (K16.K16A : Int);
		}
		switch (a44) {
			case 0: {
				switch (K16.K16C) {
					case K16.K16A: {
						H.out("o158 " + "  pad  ");
					};
					case K16.K16B: {
						var v159:Array<Int> = [271, a44];
						var v160:I17 = new C58();
					};
					case K16.K16C: {
						H.out("o161 " + Std.string(E7.E7C("42", a45)));
					};
					case K16.K16D: {
						H.out("o162 " + Std.string(178));
						a45 *= a44;
					};
					case _: {
						var v163:Float = 2.5e-3;
						H.out("o164 " + Std.string(a45));
					};
				}
				if (Math.isNaN(a45)) {
					final v165:S12 = ({x15: a44, x13: a44, x14: 1e3} : S12);
					H.out("o166 " + Std.string(a44));
					a44 ^= 295;
				}
			};
			case 2 | 6: {
				final lf167:() -> Bool = () -> (([] : Array<Int>)).contains(53);
			};
			case _: {
				var v168:C31 = new C31(E0.E0C(80, "日本語"));
			};
		}
		return Math.ceil((new C58()).m63([false]));
	}
	public static function m46(a47:Int, a48:Bool):Int {
		H.tick();
		if (a48) {
			C38.f39 = (K16.K16A : Int);
			H.out("o169 " + Std.string(null));
		}
		a48 = true;
		H.out("o170 " + Std.string(a47));
		return (if ((("x,y,z").charAt(1) < "x,y,z")) a47 else H.id(a47));
	}
}

class C53 {
	public var f54:Int;
	public function new() {
		this.f54 = 8;
	}
	public function m55(a56:Float):E7 {
		H.tick();
		try {
			if ((false ? ([0x1D64]).contains((-1690801622)) : Math.isNaN(a56))) throw 53;
			final v200:Map<String, Float> = new Map<String, Float>();
			C38.f40++;
			var v201:Map<String, String> = new Map<String, String>();
		} catch (ex202:Err) {
			H.out("caught Err " + ex202.errCode);
			H.out("o203 " + ("x,y,z").charAt(0));
		} catch (ex204:haxe.Exception) {
			H.out("caught " + H.exn(ex204));
			var v205:String = "A-B-C";
		}
		(new C58()).m63(([] : Array<Bool>));
		var v206:Float = Math.min(0.30000000000000004, (-2.5));
		C38.f40 = Type.enumIndex(E3.E3A);
		if (true) {
			this.f54 = H.at([57, 227], 110, 0);
			function lf207(n208:Int):Int {
				H.tick();
				return n208 <= 0 ? Reflect.compare(n208, 0xFFFFFFFF) : (lf207(n208 - 1) + n208);
			}
			H.out("lf207 " + lf207(4));
		}
		(new C49(true, C38.f39)).m52();
		final v209:Int = ((K16.K16D : Int) | C38.f40);
		if (Main.fn83()) {
			H.out("o210 " + Std.string(("ab").length));
			final v211:Array<String> = ["a", "\"q\"", "日本語"];
		}
		return E7.E7B(v209, Type.enumIndex(E3.E3B("ünï", true)));
	}
	public static function m57():Void {
		H.tick();
		C38.f39 -= Main.fn69(Std.isOfType(null, C20));
		try {
			var v212:E3 = E3.E3A;
			if ((false ? true : ([0x992C, 242]).contains(231))) throw Std.string(C38.f40);
		} catch (ex213:Err) {
			H.out("caught Err " + ex213.errCode);
			if (StringTools.startsWith("q", "a")) {
				C38.f39 = 167;
				var v214:Int = 134;
				C38.f39 -= 261;
			} else {
				H.out("o215 " + Std.string(1.25));
				var v216:Int = 101;
			}
		} catch (ex217:haxe.Exception) {
			H.out("caught " + H.exn(ex217));
			var v218:Map<String, Bool> = new Map<String, Bool>();
		}
		var v219:Int = (0x11C4 >>> (95 & 31));
		H.out("o220 " + Std.string(((false ? new C49(true, v219) : new C49(false, 293)) : C49)));
	}
}

class Main {
	public static function fn69(a70:Bool):Int {
		H.tick();
		var v309 = C38.f39;
		function lf310(n311:Int):Int {
			H.tick();
			return n311 <= 0 ? v309 : (lf310(n311 - 1) + v309);
		}
		H.out("lf310 " + lf310(3));
		var v312:Array<Int> = ((switch (("").toUpperCase()) {
			case "a" | "b": [v309];
			case "Haxe": [v309, v309];
			case _: [(-94230547), 99, v309];
		}) : Array<Int>);
		switch (E0.E0B) {
			case E0A: {
				var v313:Array<String> = ([] : Array<String>);
				{
					var v314:C58 = new C58();
					var v315:Map<String, Int> = new Map<String, Int>();
					++C38.f39;
				}
			};
			case E0B: {
				var v316 = ((["k0" => (-2060954549), "k1" => v309, "k2" => v309] : Map<String, Int>)).exists("  pad  ");
				v309 = H.id(v309);
			};
			case E0C(c317, c318): {
				var v319:E0 = E0.E0B;
			};
		}
		final v320:K16 = K16.K16A;
		var v321:Map<String, Int> = (["k0" => v309, "k1" => v309] : Map<String, Int>);
		return ((Math.isNaN(0.5) || a70) ? Reflect.compare(C38.f40, ("\"q\"").lastIndexOf("a")) : (Reflect.compare(v309, v309) | C38.f40));
	}
	public static inline function fn71():Array<Int> {
		H.tick();
		H.out("o322 " + Std.string(new C31(E0.E0B)));
		H.out("o323 " + Std.string(C38.f39));
		var v324:Int = 174;
		var v325:String = Std.string(C38.f39);
		var v326:Map<String, String> = new Map<String, String>();
		{
			H.out("o327 " + "\n");
			Main.fn69((new Map<Int, C58>()).exists(-3));
		}
		var v328:String = ([237, v324, (-2147483647)]).join("");
		var v329:Array<Int> = ((switch (false) {
			case true: [v324];
			case false: [v324, v324, v324];
		}) : Array<Int>);
		return [v324];
	}
	public static inline function fn72(a73:Int, a74:Float, a75:String):Void {
		H.tick();
		var v330:C58 = new C58();
		switch (false) {
			case true: {
				H.out("o331 " + Std.string((a75).lastIndexOf("a\rb")));
			};
			case false: {
				a75 += "zz";
			};
		}
		final lf332:() -> Bool = function():Bool {
			H.tick();
			function lf333(n334:Int):Int {
				H.tick();
				return n334 <= 0 ? Reflect.compare(a73, n334) : (lf333(n334 - 1) + n334);
			}
			H.out("lf333 " + lf333(0));
			return false;
		};
	}
	public static function fn76(a77:Int, a78:Int):E7 {
		H.tick();
		H.out("o335 " + Std.string((((Std.downcast((new C53() : C53), C53) != null) ? a78 : a77) : Null<Int>)));
		switch ((new Box<String>("a\rb")).value) {
			case "a" | "b": {
				H.out("o336 " + Std.string(StringTools.startsWith("a\rb", "ünï")));
			};
			case "Haxe": {
				var v337:Float = a78;
				var v338:S12 = ({x13: a77, x14: v337, x15: a78} : S12);
			};
			case _: {
				fn72((Std.parseInt(Std.string(a78)) ?? 0), a77, Std.string(false));
			};
		}
		(new C58()).m63([(([] : Array<Int>)).contains(a78), false, false]);
		if ((true && (([] : Array<Int>)).contains(a77))) {
			try {
				if ((([] : Array<Int>)).contains(65535)) throw ([false, true]).join(" ");
				final v339:Map<String, String> = (["k0" => "zz", "k1" => "zz"] : Map<String, String>);
				H.out("o340 " + Std.string(new C49(false, 68)));
				var v341:K16 = K16.K16D;
			} catch (ex342:Err) {
				H.out("caught Err " + ex342.errCode);
				a78--;
			} catch (ex343:haxe.Exception) {
				H.out("caught " + H.exn(ex343));
				H.out("o344 " + Std.string((K16.K16D : Int)));
			}
			fn71();
			var v345:S12 = ({x14: a78, x15: a77, x13: a77} : S12);
		}
		(((switch ("A-B-C") {
			case "a" | "b": new C49(true, 70);
			case "Haxe": new C49(true, 0xBF96);
			case "": new C49(false, a77);
			case _: new C49(true, a77);
		}) : C49)).m52();
		C38.f40 &= a78;
		C38.f40 ^= Main.fn69(false);
		var v346:Int = (({x13: a77, x14: 100.75, x15: a77} : S12)).x13;
		final v347 = (switch (String.fromCharCode(65 + ((a77) & 15))) {
			case "a" | "b": (([] : Array<Int>)).join(",");
			case "Haxe": Std.string(E3.E3B("é", false));
			case _: ([a77, v346, a78]).join(" ");
		});
		return H.id(E7.E7C((v347).toUpperCase(), a77));
	}
	public static function fn79(a80:Float, a81:Int, a82:Bool):String {
		H.tick();
		switch (0xE42) {
			case 0: {
				final v348:Array<String> = ["x,y,z", "日本語"];
			};
			case 2 | 6: {
				H.out("o349 " + Std.string((K16.K16D : Int)));
				final v350 = (("ab").charCodeAt(a81) ?? -1);
			};
			case _: {
				try {
					if (Std.isOfType(new C58(), C38)) throw StringTools.lpad("hello world", "*", (a81 & 7));
					var v351:Array<Bool> = [false, a82, true];
					var v352 = a81;
					a81 ^= v352;
				} catch (ex353:String) {
					H.out("caught String " + ex353);
					var v354:Int = a81;
				} catch (ex355:Int) {
					H.out("caught Int " + ex355);
					(new C58()).m63(([] : Array<Bool>));
					final v356:Map<String, String> = new Map<String, String>();
				} catch (ex357:Err) {
					H.out("caught Err " + ex357.errCode);
					var v358:Float = a81;
				} catch (ex359:Dynamic) {
					H.out("caught " + H.exn(ex359));
					final v360:Int = a81;
					H.out("o361 " + Std.string(a81));
				}
				C38.f39 &= C38.f39;
			};
		}
		C38.f40 = C38.f39;
		H.out("o362 " + Std.string(H.id(E7.E7B(182, 260))));
		switch (E0.E0B) {
			case E0A: {
				if (a82) {
					H.out("o363 " + "é");
					var v364 = "A-B-C";
				}
				H.out("o365 " + Std.string(new Box<E7>(E7.E7C("a\rb", 7.0))));
			};
			case E0B: {
				final v366 = (["a\rb", "A-B-C", "-7"]).join("|");
			};
			case _: {
				(new C58()).m63(([] : Array<Bool>));
			};
		}
		switch (E7.E7B((({x15: a81, x13: a81, x14: 1.7976931348623157e308} : S12)).x13, a81)) {
			case E7A: {
				final v367:Map<String, Bool> = new Map<String, Bool>();
			};
			case E7B(c368, _): {
				try {
					H.out("o369 " + Std.string(new C31(E0.E0B)));
					fn71();
					C38.f40 = c368;
					if (true) throw StringTools.lpad("ünï", "*", 2);
				} catch (ex370:String) {
					H.out("caught String " + ex370);
					H.out("o371 " + Std.string((-2147483647)));
				} catch (ex372:Int) {
					H.out("caught Int " + ex372);
					a81 = ex372;
					var v373:Map<Int, Bool> = ([-3 => a82, 4 => a82, 11 => a82] : Map<Int, Bool>);
				} catch (ex374:Err) {
					H.out("caught Err " + ex374.errCode);
					var v375:String = "Haxe";
				} catch (ex376:Dynamic) {
					H.out("caught " + H.exn(ex376));
					var v377:Array<Float> = ([a80, c368, a80] : Array<Float>);
				}
			};
			case E7C(c378, _): {
				a82 = false;
			};
		}
		var v379 = a81;
		var v380 = (a82 ? false : a82);
		fn69((C38.f40 >= v379));
		return ((switch ("-7") {
			case "a" | "b": a82;
			case "Haxe": false;
			case "": ([v379]).contains(104);
			case _: true;
		}) + (("abc").toUpperCase()).substring((a81 & 7), (v379 & 7)));
	}
	public static function fn83():Bool {
		H.tick();
		switch ((true + "abc")) {
			case "a" | "b": {
				var v381:Bool = true;
				H.out("o382 " + Std.string(((["k0" => K16.K16A, "k1" => K16.K16A] : Map<String, K16>)).exists("A-B-C")));
			};
			case "Haxe": {
				if (StringTools.startsWith("é", "\u{1F600}")) {
					final v383:String = "Haxe";
				}
			};
			case "": {
				var v384:String = ("").substring(4, 1);
			};
			case _: {
				var v385:Float = C38.f40;
			};
		}
		var v386:C38 = (cast (new C38(8)) : C38);
		H.out("o387 " + Std.string((Std.parseInt(Std.string(99)) ?? 0)));
		var v388:Array<Float> = ([16897910, 2.5e-3, 1e-7] : Array<Float>);
		C38.f40 = (Std.parseInt(Std.string(26)) ?? 0);
		{
			v388.unshift(1.25);
		}
		var v389:Box<Int> = ((([68, 1025160202, (-18)]).contains(236) ? new Box<Int>(88) : new Box<Int>(251)) : Box<Int>);
		var v390:Bool = ({ var v391 = "hello world"; ([248]).contains(0x80000000); });
		switch ((Math.round(1.25) - C38.f40)) {
			case 0: {
				var v392:Map<String, Int> = new Map<String, Int>();
			};
			case 3 | 4: {
				var v393:Array<String> = ["Haxe"];
				C38.f39++;
			};
			case _: {
				H.out("o394 " + Std.string(E0.E0A));
			};
		}
		return v390;
	}
	public static function fn84(a85:Array<Float>, a86:Float, a87:E7):Void {
		H.tick();
		var v395:Array<Bool> = ((switch ((("a\rb").charCodeAt(79) ?? -1)) {
			case 0: [false, false, false];
			case 3 | 4: [true, false];
			case _: [false, true];
		}) : Array<Bool>);
		C38.f39 &= (-20);
		H.out("o396 " + Std.string(new C53()));
		C38.f40 |= (StringTools.endsWith("a\rb", "a\rb") ? Math.round(0.1) : ("\t").length);
		C38.f39 = (-22637181);
		H.out("o397 " + Std.string((("x,y,z").charCodeAt(196) ?? -1)));
		switch (a87) {
			case E7A: {
				var v398 = C38.f39;
			};
			case E7B(_, c399): {
				H.out("o400 " + Std.string(c399));
			};
			case E7C(c401, c402): {
				fn72(([1996729436, 0x18DF, 256]).indexOf(120), 2.5e-3, c401);
				C38.f40 = (Std.parseInt(Std.string(72)) ?? 0);
			};
		}
		var v403:String = C20.m25(209, 0x80000000);
		C38.f39 |= (-4);
	}
	public static function fn88():Float {
		H.tick();
		final v404:C31 = new C31(E0.E0C(62, "\n"));
		final v405:Int = (["q", "\"q\"", "\"q\""]).length;
		var v406:Box<E7> = new Box<E7>(E7.E7C("q", v405));
		C38.f39 = C38.f40;
		C38.f39 *= C38.m46(([v405, v405]).length, true);
		if (false) {
			try {
				if (false) throw new Err(v405);
				H.out("o407 " + "Haxe");
				H.out("o408 " + Std.string(E7.E7C("a", v405)));
				var v409 = 32;
			} catch (ex410:String) {
				H.out("caught String " + ex410);
				var v411:Int = 169;
			} catch (ex412:Int) {
				H.out("caught Int " + ex412);
				var v413 = "\t";
			} catch (ex414:Err) {
				H.out("caught Err " + ex414.errCode);
				final v415:Array<Bool> = [true, true, true];
			} catch (ex416:Dynamic) {
				H.out("caught " + H.exn(ex416));
				var v417:Map<String, Int> = (["k0" => v405] : Map<String, Int>);
				var v418:Map<Int, Float> = ([-3 => v405, 4 => v405] : Map<Int, Float>);
			}
			C38.f39 = ((new Map<String, Int>()).get("k0") ?? 0);
			var v419:C58 = new C58();
		}
		return (Math.min(v405, v405) - Math.fceil(v405));
	}
	public static function section0():Void {
		H.tick();
		var v422:Array<String> = [for (i423 in [223, 0x909D, 104]) if (false) "hello world"];
		fn79(100.75, (({x13: 30, x14: 0.1, x15: 245} : S12)).x13, (true && Math.isNaN(1.25)));
		H.out("o424 " + (cast (StringTools.trim("é")) : String));
		switch (E0.E0C((("  pad  ").charCodeAt(253) ?? -1), "-7")) {
			case E0A: {
				var v425:Int = 261;
			};
			case E0B: {
				final v426:C49 = new C49(false, 1380699368);
			};
			case E0C(c427, _): {
				H.out("o428 " + Std.string(c427));
				switch (E7.E7B(c427, c427)) {
					case E7A: {
						var v429:Array<Bool> = [false];
						var v430:Array<Int> = [c427, 188, c427];
					};
					case E7B(c431, c432): {
						final v433:String = "-7";
					};
					case E7C(c434, c435): {
						H.out("o436 " + Std.string(c427));
						H.out("o437 " + "Haxe");
					};
				}
			};
		}
	}
	public static function section1():Void {
		H.tick();
		var v438:Map<String, C49> = (["k0" => new C49(false, 199)] : Map<String, C49>);
		fn79(C38.f39, Ext.ext91(StringTools.hex((238) & 0xFFFF, 4), (Std.parseInt(Std.string((-1391551052))) ?? 0)), Main.fn83());
		Main.fn79(((true ? 1e3 : (-2.5)) : Float), 0x76F4, ((((["k0" => 48] : Map<String, Int>)).get("\\") ?? 0) != 17));
		var v439:E3 = E3.E3B("0", true);
		H.out("o440 " + "-7");
		var v441 = 204;
	}
	public static function section2():Void {
		H.tick();
		switch (' = ${Std.string(false)}x${StringTools.replace("ab", ",", "-7")}-${Std.string(143)}') {
			case "a" | "b": {
				try {
					if (false) throw "boom";
					var v442:S12 = ({x14: 0.1, x15: (-1298956089), x13: 287} : S12);
				} catch (ex443:Dynamic) {
					H.out("caught " + H.exn(ex443));
					final v444:Array<Bool> = [true, true];
					var v445:Int = 254;
				}
			};
			case "Haxe": {
				var v446:String = Std.string(E7.E7C("é", 1e21));
			};
			case _: {
				final lf447:(Int) -> Void = function(p448:Int):Void {
					H.tick();
					var v449:C38 = new C38(p448);
					H.out("o450 " + Std.string(p448));
				};
			};
		}
		final v451 = (1002580603 % H.nz(((new Map<String, Int>()).get("k1") ?? 0)));
		if ((switch (E0.E0B) {
			case E0A: Std.isOfType(new C49(true, v451), C49);
			case E0B: true;
			case E0C(c452, c453): StringTools.startsWith(c453, c453);
			case _: (new Map<String, Int>()).exists("42");
		})) {
			switch (E0.E0B) {
				case E0A: {
					C38.f40 = v451;
				};
				case E0C(c454, c455): {
					var v456:Int = c454;
					var v457:Box<Box<C53>> = new Box<Box<C53>>(new Box<C53>(new C53()));
				};
				case _: {
					fn88();
					var v458 = "hello world";
				};
			}
		}
		Main.fn88();
		function lf459(n460:Int):Int {
			H.tick();
			return n460 <= 0 ? (("\u{1F600}").length * 0x7FFFFFFF) : (lf459(n460 - 1) + C38.f40);
		}
		H.out("lf459 " + lf459(2));
		if (StringTools.contains(("x,y,z").charAt((v451 & 7)), Std.string(v451))) {
			var v461:Null<Int> = v451;
		} else {
			var v462:Float = v451;
			var v463:C31 = new C31(E0.E0B);
		}
		var v464:S12 = ({x13: ("a\rb").indexOf("\u{1F600}"), x14: v451, x15: (("\\").charCodeAt(274) ?? -1)} : S12);
	}
	public static function section3():Void {
		H.tick();
		var v465:String = "zz";
		H.out("o466 " + Std.string(true));
		if (Std.isOfType(new C53(), C53)) {
			var v467:String = v465;
		} else {
			var v468:Null<Int> = 68;
			var v469 = 84;
		}
		C38.f39 = ((Std.parseInt(Std.string(222)) ?? 0) << ((({x13: 114, x14: 1.25, x15: 0xC6C9} : S12)).x13 & 31));
		H.out("o470 " + v465);
	}
	public static function section4():Void {
		H.tick();
		{
			var v471 = 79;
		}
		C38.f40 = (({x14: 1e-7, x15: 153, x13: 0x73A7} : S12)).x15;
		final v472:Bool = ((([] : Array<String>)).indexOf("A-B-C") <= 65535);
		var v473:Array<String> = [Std.string(1.25), ("\x41\x42").substring((28 & 7), 4), Std.string(v472)];
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
