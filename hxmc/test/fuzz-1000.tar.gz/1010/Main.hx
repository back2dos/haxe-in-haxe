import H;
import p.M1;
using p.Ext;

enum E0 {
	E0A;
	E0B;
}

class C7 extends C2 {
	public function new(a8:Bool) {
		super(7.0);
	}
	override public function m4(a5:Int, a6:Float):Int {
		H.tick();
		final v87:Bool = (123456.789 > a5);
		var v88:C9 = new C20(281, a5);
		{
			final v89:Int = (Std.parseInt("\"q\"") ?? 0);
			C9.f10 = 30;
		}
		if (v87) {
			H.out("o90 " + Std.string(new Box<Int>(a5)));
			{
				H.out("o91 " + Std.string(E0B));
				C9.f10 = a5;
				var v92:Int = 65;
			}
		} else {
			var w93 = 0;
while (w93 < 4 && v87) {
				w93++;
				H.tick();
				H.out("o94 " + Std.string(([new C9(E0A, 45), v88, v88] : Array<C2>)));
				H.out("o95 " + Std.string(a5));
				H.out("o96 " + Std.string(a5));
			}
			final v97:Array<Bool> = [v87, v87, v87];
		}
		for (i98 in 0...H.lim(0x80000000)) {
			H.tick();
			a5 &= i98;
		}
		final v99 = (238 >= 120);
		return 256;
	}
}

class C9 extends C7 {
	public static var f10:Int = 104;
	public static var f11:Bool = true;
	public function new(a12:E0, a13:Int) {
		super(false);
	}
	public static function m14(a15:Int, a16:Int):Int {
		H.tick();
		H.out("o100 " + Std.string((-2)));
		for (i101 in 2...6) {
			H.tick();
			if (false) continue;
		}
		var v102 = a15;
		H.out("o103 " + Std.string(65535));
		var v104:Int = a16;
		var v105:Array<Array<Float>> = ([for (i106 in 0...4) ([i106, 1.25, v102] : Array<Float>)] : Array<Array<Float>>);
		var v107:Map<String, Int> = (["k0" => 7] : Map<String, Int>);
		{
			H.out("o108 " + Std.string(false));
		}
		return 122;
	}
	public function m17(a18:String, a19:Int):Float {
		H.tick();
		for (i109 in 1...2) {
			H.tick();
			var v110:Int = 75;
			var v111:Bool = false;
		}
		switch (true) {
			case true: {
				if (true) {
					H.out("o112 " + Std.string(new Box(65535)));
					H.out("o113 " + Std.string(E1.E1A));
				}
			};
			case false: {
				var w114 = 0;
while (w114 < 2 && true) {
					w114++;
					H.tick();
					var v115:Map<String, Int> = (["k0" => a19] : Map<String, Int>);
				}
			};
		}
		H.out("o116 " + Std.string(((switch (H.id(([] : Array<Int>))) {
			case []: E0.E0A;
			case [c117]: E0B;
			case [_, c118]: E0B;
			case _: E0B;
		}) : E0)));
		for (i119 in 1...H.lim(a19)) {
			H.tick();
			H.out("o120 " + Std.string(E1.E1A));
		}
		var v121:Map<Int, C9> = new Map<Int, C9>();
		var v122:E0 = E0.E0A;
		{ var dyn123:Dynamic = a19; H.out("dyn " + Std.string(dyn123 + 1)); }
		m4(a19, (1e-7 * (a19 = 5)));
		var v124 = (a19 + 0xC901);
		return ((switch (E1.E1A) {
			case E1A: a19;
		}) : Float);
	}
}

class Main {
	public static function fn28(a29:Int, a30:Int, a31:Float = 1.5):Int {
		H.tick();
		var v141:Float = a29;
		a30 = (new C2(a31)).m4(a29, a29);
		(((switch (E1.E1A) {
			case E1A: new C20(a30, a30);
			case _: new C9(E0.E0B, a30);
		}) : C7)).m4((-6), v141);
		try {
			if (([a29]).contains(27)) throw Std.string(v141);
			(new C9(E0.E0B, 120)).m4(128, a31);
			H.out("o142 " + Std.string((-18)));
			var v143:Array<Float> = ([100.75, 7.0] : Array<Float>);
		} catch (ex144:String) {
			H.out("caught String " + ex144);
			for (i145 in 1...4) {
				H.tick();
				H.out("o146 " + Std.string(260));
				var v147:E1 = E1.E1A;
				C9.f10 ^= 140;
			}
		} catch (ex148:Int) {
			H.out("caught Int " + ex148);
			for (i149 in 0...0) {
				H.tick();
				H.out("o150 " + Std.string(a30));
			}
		} catch (ex151:Err) {
			H.out("caught Err " + ex151.errCode);
			final v152:Float = a30;
		} catch (ex153:Dynamic) {
			H.out("caught " + H.exn(ex153));
			a30 += 118;
		}
		function lf154(n155:Int):Int {
			H.tick();
			return n155 <= 0 ? ((--a30) ^ 34) : (lf154(n155 - 1) + H.apply("\u{1F600}", (v156:String) -> (++a29)));
		}
		H.out("lf154 " + lf154(4));
		switch (H.apply((([] : Array<Bool>)).join(","), (v157:String) -> a30)) {
			case 0: {
				var v158:Int = a30;
			};
			case 1 | 4: {
				a29 = a30;
			};
			case _: {
				H.out("o159 " + Std.string(a30));
			};
		}
		if ((Std.downcast((new C20(194, 186) : C9), C20) != null)) {
			for (x160 in [false, true, false]) {
				H.tick();
				++C9.f10;
			}
			if (true) {
				final v161:Array<String> = ["abc", "\"q\"", "42"];
				H.out("o162 " + Std.string(false));
				H.out("o163 " + Std.string(new Box(262)));
			}
		}
		if ((true ? C9.f11 : C9.f11)) {
			if (C9.f11) {
				var v164:Int = 22;
			} else {
				(new C20(46, a30)).m17("0", a29);
			}
		}
		return a30;
	}
	public static inline function fn32(a33:E1, a34:Float, a35:Int, ...r36:Int):Void {
		H.tick();
		var v165:C7 = new C7((([-3 => new C9(E0.E0B, 13), 4 => new C20(a35, a35), 11 => new C9(E0B, a35)] : Map<Int, C9>)).exists(-3));
		for (x166 in [for (i167 in r36.toArray()) if (Math.isNaN(123456.789)) C9.f10]) {
			H.tick();
			H.out("o168 " + Std.string(false));
			var v169:Map<String, Int> = new Map<String, Int>();
			for (x170 in [x166]) {
				H.tick();
				var v171:Array<Bool> = [false];
			}
		}
		C9.f11 = (0xC2B9 == (a35 = 5));
		(v165).m4((C9.f10 % H.nz(215)), (v165).m4(0x8152, a35));
		var v172:Bool = ([a35]).contains(a35);
		C9.f10 = (C9.f11 ? (-2) : Reflect.compare(a35, a35));
		final v173 = (r36.toArray()).indexOf(61);
		var v174:C9 = new C9(E0A, v173);
		{
			Main.fn28(C9.f10, v173);
			if ((r36.toArray()).contains(v173)) {
				final v175:C2 = v165;
				final v176:Map<String, Int> = new Map<String, Int>();
			} else {
				a35 *= 277;
				r36.toArray().push(a35);
			}
		}
	}
	public static function fn37(...r38:Int):Bool {
		H.tick();
		Main.fn28(([false]).length, (if ((Std.downcast((new C20(258, 202) : C20), C20) != null)) 160 else (-924654395)));
		var v177:Int = ([true, true, false]).length;
		H.out("o178 " + Std.string((293 < C9.f10)));
		H.out("o179 " + Std.string(C9.f10));
		try {
			final v180 = C9.f10;
			(new C20(v177, 0x80000000)).m25(v180, [v177]);
			r38.toArray().reverse();
			if (({ var v181 = 0x39C4; (new Map<String, Int>()).exists("k0"); })) throw 36;
		} catch (ex182:String) {
			H.out("caught String " + ex182);
			var v183:Map<String, Bool> = (["k0" => false, "k1" => true] : Map<String, Bool>);
			function lf184(n185:Int):Int {
				H.tick();
				return n185 <= 0 ? 12 : (lf184(n185 - 1) + v177);
			}
			H.out("lf184 " + lf184(5));
		} catch (ex186:Int) {
			H.out("caught Int " + ex186);
			{
				var v187:Map<String, Int> = new Map<String, Int>();
				H.out("o188 " + "\"q\"");
				var v189:Int = (-2119120384);
			}
		} catch (ex190:Err) {
			H.out("caught Err " + ex190.errCode);
			var v191:Int = 107;
			final lf192:() -> Float = function():Float {
				H.tick();
				if (r38.toArray().length > 0) r38.toArray()[H.ix(263, r38.toArray().length)] = v177;
				return 0.5;
			};
		} catch (ex193:Dynamic) {
			H.out("caught " + H.exn(ex193));
			if (false) {
				var v194:Map<Int, Array<Int>> = ([-3 => [v177]] : Map<Int, Array<Int>>);
				var v195:Int = v177;
				C9.f10 = v177;
			} else {
				v177 = 65535;
				H.out("o196 " + Std.string(new C20((-903919667), v177)));
			}
			if ((r38.toArray()).contains(258)) {
				v177 = 0xFFFFFFFF;
			} else {
				H.out("o197 " + Std.string(2.5e-3));
			}
		}
		return (Std.downcast((({ var v198 = 57; new C9(E0.E0B, v177); }) : C9), C9) != null);
	}
	public static function fn39(a40:Int, a41:Float, ...r42:Int):Int {
		H.tick();
		var v199:E1 = E1.E1A;
		try {
			if ((false && true)) throw "boom";
			var v200:Map<String, Int> = new Map<String, Int>();
			C9.f10 = (a40 -= 1);
			final v201:E1 = v199;
		} catch (ex202:String) {
			H.out("caught String " + ex202);
			var v203:C7 = new C20(0xA9AC, a40);
			var v204:Float = a40;
		} catch (ex205:Int) {
			H.out("caught Int " + ex205);
			var w206 = 0;
while (w206 < 4 && (Std.downcast((new C20(a40, a40) : C2), C20) != null)) {
				w206++;
				H.tick();
				(new C7(true)).m4(a40, ex205);
			}
			H.out("o207 " + Std.string((E1.E1A).match(E1A)));
		} catch (ex208:Err) {
			H.out("caught Err " + ex208.errCode);
			var v209 = a40;
		} catch (ex210:Dynamic) {
			H.out("caught " + H.exn(ex210));
			H.out("o211 " + Std.string(222));
			final v212:Map<Int, Bool> = new Map<Int, Bool>();
		}
		for (i213 in 0...H.lim((switch (E0.E0B) {
			case E0A: C9.f10;
			case _: Std.int(a41);
		}))) {
			H.tick();
			C9.f10 *= 106;
			var v214:Float = a41;
			if (true) {
				C9.f10 = a40;
				var v215:E1 = v199;
			}
		}
		a40 = (new C20(a40, a40)).m4(H.at(r42.toArray(), 120, 0), 3.0);
		return a40;
	}
	public static function fn43(a44:Bool, a45:E1, a46:Float = 1.5):Float {
		H.tick();
		final v216:E1 = a45;
		H.out("o217 " + Std.string(new Box<E0>(E0.E0A)));
		for (i218 in 0...H.lim((-2147483647))) {
			H.tick();
			C9.f10 -= ([158, i218, i218]).length;
			(new C20(120, i218)).m17("x,y,z", C9.f10);
		}
		{
			H.out("o219 " + Std.string(Std.isOfType(new C9(E0.E0B, 166), C7)));
		}
		final v220:Array<C7> = (([new C7(a44), new C20(186, 36), new C7(a44)] : Array<C7>)).copy();
		var v221:Int = (~Reflect.compare(273, (-1610436608)));
		final v222:Box<Map<Int, Int>> = new Box<Map<Int, Int>>(new Map<Int, Int>());
		var v223:Int = v221;
		return v223;
	}
	public static function fn47(a48:Int, a49:Box<Int>):E0 {
		H.tick();
		C9.f10 &= (Math.isNaN(a48) ? C9.f10 : 81);
		Main.fn32(E1.E1A, C9.f10, a48);
		final v224:E1 = E1.E1A;
		var v225:Bool = (true ? true : ([a48, 183, a48]).contains(a48));
		H.out("o226 " + Std.string((a48 & C9.f10)));
		return E0.E0A;
	}
	public static function fn50(a51:Bool):Int {
		H.tick();
		final v227:Map<String, Float> = (cast (new Map<String, Float>()) : Map<String, Float>);
		var v228 = true;
		a51 = !C9.f11;
		var v229:Map<Int, Float> = ([-3 => 238, 4 => 1e-7, 11 => Std.parseFloat("-0.25")] : Map<Int, Float>);
		fn47(({ var v230 = ([""]).length; H.at([170, 208], v230, 0); }), new Box<Int>(H.at([102, 11, 0x1F07], 294, 0)));
		C9.f10 = H.id(C9.f10);
		{
			var w231 = 0;
while (w231 < 3 && (v229).exists(11)) {
				w231++;
				H.tick();
				var v232:Array<Bool> = [false];
				var v233:Map<Int, Bool> = new Map<Int, Bool>();
				C9.f10 &= 271;
			}
		}
		if (v228) {
			switch (E1.E1A) {
				case E1A: {
					C9.m14((-2119774265), 245);
					C9.f10 = 232;
				};
				case _: {
					C9.f10 = 238;
				};
			}
			for (i234 in 0...4) {
				H.tick();
				H.out("o235 " + Std.string(i234));
				var v236:Float = i234;
			}
			if (true) {
				var v237:Int = 82;
				H.out("o238 " + Std.string(v237));
			} else {
				var v239:Array<Box<Bool>> = ([new Box(a51), new Box<Bool>(true), new Box(v228)] : Array<Box<Bool>>);
			}
		}
		for (k242 => x240 in ([for (i241 in 0...3) 1e3] : Array<Float>)) {
			H.tick();
			(new C20(0xCAA4, 210)).m17(([k242, k242]).join("|"), C9.f10);
			H.out("o243 " + Std.string(([v228, v228, true]).length));
		}
		return ((new Map<String, E1>()).exists("A-B-C") ? (C9.f10 << ((Std.parseInt(Std.string(0x2EBD)) ?? 0) & 31)) : (if (true) 242 else 259));
	}
	public static function fn52(a53:Float, a54:Bool, ?a55:Null<Bool>):Array<String> {
		H.tick();
		for (i244 in 0...1) {
			H.tick();
			C9.f11 = true;
			try {
				final v245:Int = i244;
				C9.f10 *= v245;
				if (false) throw 39;
			} catch (ex246:String) {
				H.out("caught String " + ex246);
				([i244, i244]).ext68(0x7664);
			} catch (ex247:Int) {
				H.out("caught Int " + ex247);
				var v248:E1 = E1.E1A;
			} catch (ex249:Err) {
				H.out("caught Err " + ex249.errCode);
				var v250:Bool = a54;
				var v251:E1 = E1.E1A;
			} catch (ex252:Dynamic) {
				H.out("caught " + H.exn(ex252));
				H.out("o253 " + Std.string(new C20(0xFFFFFFFF, i244)));
			}
			final lf254:(Int, Int) -> Bool = (p255:Int, p256:Int) -> Std.isOfType(new C20(i244, p255), C7);
		}
		final v257:Array<Int> = [for (i258 in [a54, false]) if (false) (Std.parseInt(Std.string(192)) ?? 0)];
		var w259 = 0;
do {
			w259++;
			H.tick();
			for (i260 in 0...3) {
				H.tick();
				C9.f10 = i260;
				var v261:C2 = new C20(i260, (-19));
			}
			if ((v257).contains(0xFFFFFFFF)) {
				H.out("o262 " + Std.string((-6)));
			}
		} while (w259 < 3 && C9.f11);
		final v263 = 0x5FCD;
		C9.f10 <<= (((v257).length * (v257).indexOf(v263)) & 7);
		for (x264 in ({ var v265 = 137; ([] : Array<Bool>); })) {
			H.tick();
			C9.f10 = 72;
			C9.f10 <<= (v263 & 7);
		}
		var v266:Int = Math.floor(v263);
		return [("0" + Std.string((-16)))];
	}
	public static function fn56(a57:Bool, a58:Int, ...r59:Int):Void {
		H.tick();
		if (a57) {
			H.out("o267 " + Std.string(([] : Array<Bool>)));
			H.out("o268 " + Std.string(C9.f11));
		} else {
			var w269 = 0;
while (w269 < 1 && true) {
				w269++;
				H.tick();
				var v270 = a58;
			}
		}
		for (i271 in 0...0) {
			H.tick();
			var w272 = 0;
while (w272 < 3 && true) {
				w272++;
				H.tick();
				r59.toArray().sort((x, y) -> x - y);
			}
		}
		((((([-3 => new C7(a57), 4 => new C7(a57), 11 => new C20(a58, a58)] : Map<Int, C7>)).exists(18) ? new C20(a58, a58) : new C9(E0.E0B, a58)) : C2)).m4(C9.f10, (a58 * C9.f10));
		for (i273 in 0...1) {
			H.tick();
			final v274:Array<Float> = ([a58] : Array<Float>);
			a58 = 160;
		}
		a58 = (((["k0" => 0x10CB, "k1" => 300] : Map<String, Int>)).get("k1") ?? 0);
	}
	public static function fn60(a61:Bool):Bool {
		H.tick();
		(new C20(289, H.at([0xFFFFFFFF, 64, 0x646C], 249, 0))).m17((["é"]).join(","), Ext.ext74("\x41\x42", new C20(292, (-2147483647))));
		H.out("o275 " + Std.string(new C20((((["k0" => 0x7FFFFFFF, "k1" => 157] : Map<String, Int>)).get("k1") ?? 0), 261)));
		var v276:Float = ("Haxe").ext74(new C20(67, 263));
		H.out("o277 " + Std.string(E0.E0A));
		var v278:Int = (new C20(0x6BE9, 0x80000000)).m4(((([-3 => 193, 4 => 125, 11 => 0x5073] : Map<Int, Int>)).get((-4)) ?? 0), 1e3);
		v278 = (new C7(a61)).m4(1228021005, 1e3);
		return false;
	}
	public static function fn62(a63:Int, a64:String, a65:String):Int {
		H.tick();
		H.out("o279 " + Std.string((new C7(false)).m4(226, Std.parseFloat("1.5"))));
		for (i280 in 0...3) {
			H.tick();
			var v281:C20 = new C20(0xD8F1, a63);
		}
		var v282:Array<Int> = [186, 247];
		{
			a63 = H.id(a63);
		}
		C9.f10 *= (([a63, 0.1] : Array<Float>)).length;
		H.out("o283 " + Std.string((true || (([-3 => a63, 4 => a63] : Map<Int, Int>)).exists(-3))));
		var v284:Float = a63;
		return a63;
	}
	public static function section0():Void {
		H.tick();
		for (k311 => x309 in ({ var v310 = false; [v310]; })) {
			H.tick();
			if (true) continue;
			var w312 = 0;
do {
				w312++;
				H.tick();
				([0x770D, (-19), 267]).ext68(k311);
				Main.fn60(x309);
			} while (w312 < 3 && false);
		}
		{
			{ var dyn313:Dynamic = 0x5A4; H.out("dyn " + Std.string(dyn313 + 1)); }
		}
		Ext.ext74(Ext.ext68([262, 264, 65535], C9.f10), new C20(Std.int(0.1), C9.f10));
		if ((new Box<Bool>(true)).get()) {
			var w314 = 0;
while (w314 < 1 && C9.f11) {
				w314++;
				H.tick();
				H.out("o315 " + Std.string(new C7(false)));
				final v316:Map<Int, Float> = new Map<Int, Float>();
				H.out("o317 " + Std.string([175, (-281802300), 246]));
			}
			(new C20(65535, 68)).m25((Std.parseInt(Std.string(122)) ?? 0), ([] : Array<Int>));
		} else {
			if (true) {
				var v318:Map<String, Int> = (["k0" => 136, "k1" => 209, "k2" => 11] : Map<String, Int>);
			}
		}
		var v319:Map<String, Float> = (["k0" => C9.f10] : Map<String, Float>);
		for (x320 in [false, false, C9.f11]) {
			H.tick();
			var v321 = (([] : Array<Float>)).length;
			final lf322:() -> Int = () -> v321;
			if (false) {
				var v323 = x320;
			} else {
				var v324:Int = v321;
			}
		}
		var v325:Int = H.at([235], Reflect.compare(69, 73), 0);
		var v326:Map<String, Int> = new Map<String, Int>();
		switch (E0.E0B) {
			case E0A: {
				{
					H.out("o327 " + Std.string(v325));
				}
			};
			case _: {
				H.out("o328 " + Std.string(new Box(false)));
				if (([257, 58]).contains(v325)) {
					var v329:E0 = E0B;
					(new C9(v329, v325)).m4(69, 0.5);
				}
			};
		}
	}
	public static function section1():Void {
		H.tick();
		H.out("o330 " + Std.string((Math.isNaN(3.0) ? Type.enumIndex(E0.E0B) : 60)));
		try {
			if (false) throw ((E1.E1A).match(E1A) ? "a" : "x,y,z");
			switch (719566893) {
				case 0: {
					final v331:Bool = true;
				};
				case 3 | 4: {
					var v332 = 135;
					v332 *= v332;
				};
				case _: {
					Ext.ext74("ünï", new C20(1609177486, 139));
					var v333:Int = 6;
				};
			}
			C9.f10 &= H.at(([] : Array<Int>), 207, 0);
		} catch (ex334:Dynamic) {
			H.out("caught " + H.exn(ex334));
			switch (Type.enumIndex(E1.E1A)) {
				case 0: {
					C9.f10 = 0x2667;
					var v335:Box<Int> = new Box(103);
				};
				case 2 | 5: {
					Main.fn43(true, E1.E1A);
					H.out("o336 " + Std.string(3.0));
				};
				case _: {
					C9.f10 = 1324352748;
				};
			}
		}
		for (i337 in 0...4) {
			H.tick();
			var v338:Int = (Std.parseInt(Std.string(i337)) ?? 0);
		}
		final lf339:(Bool, Int) -> Int = (p340:Bool, p341:Int) -> Reflect.compare(Math.ceil(p341), C9.f10);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
