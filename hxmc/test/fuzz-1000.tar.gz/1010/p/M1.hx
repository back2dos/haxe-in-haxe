package p;

import Main;
import H;
import p.M1;
using p.Ext;

class M1 {}

enum E1 {
	E1A;
}

class C2 {
	public function new(a3:Float) {}
	public function m4(a5:Int, a6:Float):Int {
		H.tick();
		final v75:Float = C9.f10;
		var v76 = (259 ^ a5);
		H.out("o77 " + Std.string(277));
		H.out("o78 " + Std.string(((switch (E1.E1A) {
			case E1A: new C9(E0.E0A, v76);
			case _: new C9(E0.E0A, a5);
		}) : C2)));
		if ((new Map<Int, Int>()).exists(-3)) {
			H.out("o79 " + Std.string(true));
		} else {
			try {
				v76 <<= (a5 & 7);
				if ((new Map<Int, C2>()).exists(11)) throw new Err((a5 -= 1));
			} catch (ex80:Dynamic) {
				H.out("caught " + H.exn(ex80));
				a5 = H.id(a5);
			}
		}
		for (i81 in 0...H.lim(55)) {
			H.tick();
			var v82:Array<Bool> = [true, false];
			++C9.f10;
			var v83:Map<String, C9> = new Map<String, C9>();
		}
		var v84 = (Type.enumIndex(E1A) - 0xFFFFFFFF);
		{ var dyn85:Dynamic = (C9.f10 & (--v76)); H.out("dyn " + Std.string(dyn85 + 1)); }
		var v86 = (([a5]).contains(v76) ? a5 : v76);
		return ((switch (E0.E0B) {
			case E0A: false;
			case E0B: false;
		}) ? (C9.f11 ? (Std.parseInt(Std.string(0x7FFFFFFF)) ?? 0) : 198) : ([a5, v84, v76]).indexOf(12));
	}
}

class C20 extends C9 {
	public var f21:Bool;
	public var f22:Bool;
	public function new(a23:Int, a24:Int) {
		super(E0.E0A, (Std.parseInt(Std.string(203)) ?? 0));
		this.f21 = C9.f11;
		this.f22 = true;
	}
	override public function m17(a18:String, a19:Int):Float {
		H.tick();
		m4(m4(35, a19), (new C9(E0.E0B, a19)).m4(a19, 1e3));
		var v125:Float = 1e3;
		var v126:C2 = ((switch (E1A) {
			case E1A: new C7(true);
		}) : C2);
		var v127:Array<Bool> = (((E1A).match(E1A) ? [false, false, false] : [false, false]) : Array<Bool>);
		switch (284) {
			case 0: {
				C9.f10 <<= (Type.enumIndex(E1.E1A) & 7);
			};
			case 3 | 4: {
				final v128 = true;
				var v129:Array<Int> = ([] : Array<Int>);
			};
			case _: {
				H.out("o130 " + Std.string(Reflect.compare(0xB4CF, a19)));
				this.m4(C9.f10, Std.parseFloat(a18));
			};
		}
		if ((true && (E0.E0A).match(E0B))) {
			switch (E1.E1A) {
				case E1A: {
					final v131 = a19;
					C9.f10 = v131;
				};
			}
			H.out("o132 " + Std.string(1e3));
			switch (E1.E1A) {
				case E1A: {
					H.out("o133 " + Std.string(105));
					H.out("o134 " + Std.string((-998087521)));
				};
			}
		}
		H.out("o135 " + Std.string(E0.E0A));
		C9.f10 = a19;
		return a19;
	}
	public function m25(a26:Int, a27:Array<Int>):Array<E0> {
		H.tick();
		var v136:Float = a26;
		for (k138 => x137 in [76, (Std.parseInt("\t") ?? 0), (a27).indexOf(65535)]) {
			H.tick();
			H.out("o139 " + Std.string(([new C20(x137, k138)] : Array<C9>)));
		}
		var v140:Map<String, Bool> = new Map<String, Bool>();
		return ([] : Array<E0>);
	}
}
