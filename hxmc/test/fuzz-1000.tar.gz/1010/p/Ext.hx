package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext68(a66:Array<Int>, a67:Int):String {
		H.tick();
		H.out("o285 " + Std.string(new C20(a67, a67)));
		for (k287 => x286 in [(([] : Array<Int>)).contains(a67)]) {
			H.tick();
			var v288:Box<E0> = new Box<E0>(E0.E0A);
			a67 &= (a66).length;
			switch (C9.f10) {
				case 0: {
					var v289 = 145;
					var v290:Int = 291;
				};
				case 3 | 5: {
					(new C20(120, a67)).m25(k287, a66);
				};
				case _: {
					Main.fn37(a67);
				};
			}
		}
		var v291:E0 = E0.E0A;
		if (((a66).contains(a67) && true)) {
			(new C7(false)).m4(59, 1e3);
			var v292 = C9.f11;
			H.out("o293 " + Std.string(v291));
		} else {
			var v294:Array<Bool> = [true, false];
		}
		Main.fn39((false ? a67 : Type.enumIndex(E0.E0B)), a67, 0xFFFFFFFF, (new C20(a67, 253)).m4(C9.f10, (-2.5)));
		a67 <<= (Type.enumIndex(E0.E0B) & 7);
		return "日本語";
	}
	public static function ext71(a69:String, a70:Bool):Bool {
		H.tick();
		var v295:Int = ((Std.parseInt(Std.string(0x80000000)) ?? 0) * 0xF139);
		Main.fn32(E1.E1A, (v295 * v295), v295);
		switch ((false ? H.at([v295], v295, 0) : 122)) {
			case 0: {
				var v296:Array<Float> = ([0.5] : Array<Float>);
			};
			case 1 | 5: {
				var v297 = v295;
			};
			case c298 if (c298 > 10): {
				var v299:Bool = a70;
			};
			case _: {
				var v300 = (E1.E1A).match(E1A);
			};
		}
		final lf301:() -> Bool = function():Bool {
			H.tick();
			H.out("o302 " + Std.string(C9.f10));
			for (i303 in 0...H.lim(v295)) {
				H.tick();
				++v295;
				v295 -= 1839553918;
				var v304:Int = i303;
			}
			Main.fn39(63, 7.0);
			return Main.fn37();
		};
		return ((0x55D2 - v295) <= v295);
	}
	public static function ext74(a72:String, a73:C20):Int {
		H.tick();
		var v305:Int = (0x80000000 % H.nz(99));
		(((false ? new C7(false) : new C9(E0.E0A, v305)) : C7)).m4((v305 & 11), ((switch (E1.E1A) {
			case E1A: 0.1;
			case _: 70;
		}) : Float));
		var v306:Array<Array<Int>> = ([] : Array<Array<Int>>);
		H.out("o307 " + Std.string(231));
		if ((E0.E0A).match(E0A)) {
			H.out("o308 " + Std.string(0x80000000));
		}
		v305 &= (v305 * Math.ceil(v305));
		return 279;
	}
}
