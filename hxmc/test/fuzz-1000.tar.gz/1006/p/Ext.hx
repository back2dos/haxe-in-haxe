package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext32(a30:String, a31:String):Int {
		H.tick();
		var v135 = (269 + (("a\rb").charCodeAt(184) ?? -1));
		var v136:Int = v135;
		++v135;
		var v137:Float = v135;
		if (true) {
			if (([v135]).contains(30)) {
				H.out("o138 " + a31);
				var v139 = v135;
			}
		} else {
			switch ((E6.E6C(v136, a30)).match(E6D)) {
				case true: {
					var v140 = true;
					Main.fn13();
				};
				case false: {
					var v141:E0 = E0.E0A;
					var v142 = a31;
				};
			}
		}
		return v136;
	}
}
