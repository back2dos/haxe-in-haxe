package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E5 {
	E5A;
}

abstract A11(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A11, b:A11):A11
		return new A11(a.get() + b.get());

	@:op(A * B) public static function mul(a:A11, b:A11):A11
		return new A11(a.get() * b.get());

	@:op(-A) public static function neg(a:A11):A11
		return new A11(-a.get());
}
