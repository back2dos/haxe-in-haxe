package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

enum E6 {
	E6A;
	E6B(a8:String);
	E6C(a9:Int, a10:String);
	E6D;
}

enum abstract K12(Int) to Int {
	var K12A = 1;
	var K12B = 4;
	var K12C = 7;
	var K12D = 10;
}
