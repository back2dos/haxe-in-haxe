import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Int);
	E0C(a2:String, a3:Float);
	E0D(a4:Int);
}

class Main {
	public static function fn13():E6 {
		H.tick();
		H.out("o33 " + Std.string((cast (H.at([132, 15], 150, 0)) : Int)));
		switch (E5.E5A) {
			case E5A: {
				if (true) return E6.E6A;
			};
		}
		if ((("日本語").indexOf("ab") < Math.floor(100.75))) {
			H.out("o34 " + (["-7"]).join(" "));
		} else {
			final lf35:() -> Void = function():Void {
				H.tick();
				H.out("o36 " + Std.string(E6.E6C(148, "ünï")));
			};
			var v37 = Type.enumIndex(E5.E5A);
		}
		{
			var v38:Array<String> = ["\t", ""];
			if (false) {
				var v39:Array<A11> = ([new A11(290), new A11(119)] : Array<A11>);
				H.out("o40 " + Std.string(v38));
			}
		}
		var v41 = (7 < 79);
		final v42:() -> Void = function():Void {
			H.tick();
			var v43:Array<Int> = [223425021, 92, 0x266C];
			final v44:E5 = E5.E5A;
		};
		switch (v41) {
			case true: {
				final v45 = "Haxe";
				H.out("o46 " + Std.string(([77]).contains(8)));
			};
			case false: {
				var v47:String = "日本語";
				var v48:Null<Int> = 280;
			};
		}
		var v49:Null<Int> = ((false ? null : 63) : Null<Int>);
		return E6.E6A;
	}
	public static inline function fn14(a15:Array<E0>, a16:Float, a17:Array<Int>):Int {
		H.tick();
		H.out("o50 " + Std.string(({ var v51 = ("42").charAt(-1); 97; })));
		H.out("o52 " + Std.string((false && (new Map<String, String>()).exists("k2"))));
		a17.unshift((cast ((("42").charCodeAt(125) ?? -1)) : Int));
		H.out("o53 " + Std.string((K12.K12A : Int)));
		function lf54(n55:Int):Int {
			H.tick();
			return n55 <= 0 ? ("-7").length : (lf54(n55 - 1) + 219);
		}
		H.out("lf54 " + lf54(3));
		H.out("o56 " + Std.string(E5.E5A));
		fn13();
		H.out("o57 " + Std.string((a17).length));
		return 86;
	}
	public static function fn18():Int {
		H.tick();
		fn13();
		var v58:Array<A11> = (([] : Array<A11>)).filter(v59 -> true);
		switch (H.id((([] : Array<Int>)).map((v60:Int) -> v60))) {
			case []: {
				var v61:Array<K12> = ([] : Array<K12>);
				var v62:Array<Bool> = [false, false];
			};
			case [c63]: {
				switch (((new Map<Int, Int>()).get(4) ?? 0)) {
					case 0: {
						H.out("o64 " + Std.string(284));
						H.out("o65 " + Std.string(true));
					};
					case 3 | 6: {
						var v66 = 254;
					};
					case c67 if (c67 > 10): {
						var v68:String = "\"q\"";
						H.out("o69 " + Std.string((K12.K12C : Int)));
					};
					case _: {
						("-7").ext32("q");
						var v70:E6 = E6.E6A;
					};
				}
				var v71 = 58;
			};
			case [_, c72]: {
				var v73:Float = 0.5;
			};
			case _: {
				fn13();
			};
		}
		switch (("0" >= Std.string(E0B(0x6644)))) {
			case true: {
				H.out("o74 " + Std.string((("0").charCodeAt(170) ?? -1)));
				switch (E6.E6A) {
					case E6A: {
						H.out("o75 " + Std.string(1422273124));
						var v76:E5 = E5.E5A;
					};
					case E6B(c77): {
						var v78:Array<Int> = ([] : Array<Int>);
						var v79:E6 = E6.E6A;
					};
					case E6C(c80, c81) if (c80 > 4): {
						H.out("o82 " + Std.string(false));
					};
					case E6D: {
						final v83 = 182;
						var v84:Array<Int> = ([] : Array<Int>);
					};
					case _: {
						var v85:K12 = K12.K12C;
						final v86:() -> String = () -> "abc";
					};
				}
			};
			case false: {
				var v87:Int = (-66625450);
			};
		}
		H.out("o88 " + Std.string(Ext.ext32("0", "zz")));
		H.out("o89 " + (StringTools.lpad("hello world", "*", 3) + ""));
		var v90:Map<Int, Bool> = ([-3 => true, 4 => true] : Map<Int, Bool>);
		return (~((String.fromCharCode(65 + (((-11)) & 15))).charCodeAt((Std.parseInt("\u{1F600}") ?? 0)) ?? -1));
	}
	public static function fn19(a20:Int = 3):Bool {
		H.tick();
		fn18();
		a20 = H.id(a20);
		a20++;
		a20--;
		var v91:Int = a20;
		var v92:Map<Int, Map<String, Float>> = (((([-3 => v91, 4 => a20] : Map<Int, Int>)).exists(4) ? new Map<Int, Map<String, Float>>() : new Map<Int, Map<String, Float>>()) : Map<Int, Map<String, Float>>);
		Ext.ext32(StringTools.hex(((new A11(v91)).get()) & 0xFFFF, 4), (("zz").lastIndexOf("\t") + "A-B-C"));
		var v93:Int = a20;
		return ((1.25 / Math.sin(5e-324)) <= ((false ? Math.pow(v91, 2) : v91) : Float));
	}
	public static function fn21():Float {
		H.tick();
		var v94:Map<String, String> = (["k0" => "a", "k1" => Std.string(E0.E0A), "k2" => "hello world"] : Map<String, String>);
		switch (E0.E0A) {
			case E0A: {
				var v95 = ((108 : A11)).get();
				H.out("o96 " + Std.string((K12.K12D : Int)));
			};
			case E0B(_): {
				H.out("o97 " + Std.string(([] : Array<String>)));
				H.out("o98 " + Std.string(Lambda.count([116, 0x7FFFFFFF], v99 -> (E0C("a\rb", v99)).match(E0B(_)))));
			};
			case E0D(_): {
				var v100:Array<Float> = ([(-2.5), 3.0] : Array<Float>);
			};
			case _: {
				var v101 = H.at([(-581593977), 123, 51], 144, 0);
			};
		}
		fn19(281);
		if (((E0.E0A).match(E0C(_, _)) ? false : ([60]).contains(106))) return Main.fn14(([E0.E0B(1521395882)] : Array<E0>), 1e21, [(-157578212), 0x1C61, 205]);
		return Main.fn18();
	}
	public static function fn22():Void {
		H.tick();
		H.out("o102 " + Std.string(((switch (K12.K12A) {
			case K12.K12A: 3.0;
			case K12.K12B: 123456.789;
			case K12.K12C: 1e3;
			case K12.K12D: 1e100;
		}) : Float)));
		var v103:Array<Int> = (cast ([2081027456]) : Array<Int>);
		final v104:(Int, Float) -> Bool = (p105:Int, p106:Float) -> false;
	}
	public static function fn23(a24:E6, a25:Array<Int>):Float {
		H.tick();
		if (({ var v107 = Math.round(1.25); (E6.E6A).match(E6A); })) {
			final v108 = (a25).contains(284);
			a25.pop();
			H.out("o109 " + Std.string(((175 : A11)).get()));
		} else {
			final v110:String = "A-B-C";
		}
		if (a25.length > 0) a25[H.ix(Lambda.fold([275, 83], (v111:Int, v112:Int) -> 262, 0), a25.length)] = 0x80000000;
		final v113 = true;
		final v114:(Float) -> Int = ((switch (H.id([1482576679, 97, 0xFFFFFFFF])) {
			case []: (p115:Float) -> 0xE93B;
			case [c116]: (p117:Float) -> 0x9CD9;
			case [_, c118]: (p119:Float) -> c118;
			case _: function(p120:Float):Int {
				H.tick();
				a25.unshift((-167749036));
				return 0xFFFFFFFF;
			};
		}) : (Float) -> Int);
		fn14((([E0.E0B(73), E0.E0C("日本語", 1.7976931348623157e308), E0.E0D(273)] : Array<E0>)).slice(5, 1), (100.75 - Type.enumIndex(E6.E6A)), [24]);
		return ((switch ((Lambda.fold([797124567], (v121:Int, v122:Int) -> Std.int(v121), 0) - Type.enumIndex(E0B(256)))) {
			case 0: 7.0;
			case 2 | 4: (0.5 * 123456.789);
			case c123 if (c123 > 10): Ext.ext32(("  pad  ").toLowerCase(), StringTools.replace("\"q\"", " ", "\n"));
			case _: ((false ? 0.1 : 0.5) : Float);
		}) : Float);
	}
	public static function fn26(a27:Float, a28:Bool, ?a29:Null<Int>):Void {
		H.tick();
		final v124:Map<String, String> = new Map<String, String>();
		final v125 = a28;
		if (((("\\").charCodeAt(221) ?? -1) >= ("x,y,z").lastIndexOf("x,y,z"))) {
			var v126 = Reflect.compare(147, 183);
		} else {
			var v127:E6 = E6.E6A;
		}
		H.out("o128 " + "日本語");
		Ext.ext32(StringTools.hex(((-1523430084)) & 0xFFFF, 4), ("" + Math.isNaN(a27)));
		final v129:(Int, Int) -> Int = function(p130:Int, p131:Int):Int {
			H.tick();
			var v132 = p131;
			("  pad  ").ext32("\"q\"");
			H.out("o133 " + Std.string(v132));
			return v132;
		};
		H.out("o134 " + Std.string(a27));
	}
	public static function section0():Void {
		H.tick();
		switch (E0.E0A) {
			case E0A: {
				var v143:A11 = new A11((-2));
				Main.fn22();
			};
			case E0B(c144) if (c144 > 3): {
				var v145:String = ("\n").substr((c144 & 7), 6);
				final v146:Map<Int, String> = ([-3 => v145] : Map<Int, String>);
			};
			case E0C(c147, c148): {
				var v149 = c147;
			};
			case E0D(_): {
				var v150:E0 = E0.E0D(42);
				var v151:A11 = new A11(278);
			};
			case _: {
				if (([(-325301443)]).contains(296276252)) {
					var v152:E5 = E5.E5A;
					H.out("o153 " + Std.string(101));
					final v154 = 0xBCB4;
				}
				var v155:A11 = new A11(25);
			};
		}
		var v156 = 199;
		var v157:E5 = E5.E5A;
		if ((switch (K12.K12D) {
			case K12.K12A: StringTools.startsWith("ünï", "\"q\"");
			case K12.K12B: true;
			case K12.K12C: false;
			case K12.K12D: false;
			case _: true;
		})) {
			H.out("o158 " + Std.string(v156));
			final v159:Array<Int> = [103];
		} else {
			fn13();
			H.out("o160 " + Std.string(v156));
		}
		var v161:Map<Int, (Float) -> String> = ([-3 => function(p162:Float):String {
			H.tick();
			var v163:Int = v156;
			H.out("o164 " + "a");
			var v165:Array<(Float) -> String> = ([(p166:Float) -> "-7", function(p167:Float):String {
				H.tick();
				H.out("o168 " + Std.string(v163));
				return "abc";
			}] : Array<(Float) -> String>);
			return "\\";
		}] : Map<Int, (Float) -> String>);
		final v169:Int = (~v156);
	}
	public static function section1():Void {
		H.tick();
		var v170 = (("a\rb").toLowerCase()).lastIndexOf(Std.string((-20)));
		H.out("o171 " + Std.string(Main.fn14(([] : Array<E0>), 1e-7, ([] : Array<Int>))));
		H.out("o172 " + Std.string((K12.K12B : Int)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
