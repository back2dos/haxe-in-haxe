package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

typedef S0 = {x1:Bool, x2:String};

typedef S3 = {x4:Float, x5:String, x6:String};

abstract A7(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A7, b:A7):A7
		return new A7(a.get() + b.get());

	@:op(A * B) public static function mul(a:A7, b:A7):A7
		return new A7(a.get() * b.get());

	@:op(-A) public static function neg(a:A7):A7
		return new A7(-a.get());
}
