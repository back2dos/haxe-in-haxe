package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext38(a37:Array<Int>):Float {
		H.tick();
		for (x110 in ([] : Array<Float>)) {
			H.tick();
			final v111 = 241;
			var v112:Int = ("Haxe").lastIndexOf("é");
		}
		final v113:A7 = new A7(252);
		Main.fn23(({ var v114 = 1.25; 77; }), String.fromCharCode(65 + ((239) & 15)), Math.isNaN(Math.sin(1e21)), (("  pad  ").indexOf("é") ^ Std.int(100.75)));
		H.out("o115 " + Std.string((cast ((([-3 => 103, 4 => 261, 11 => (-19)] : Map<Int, Int>)).exists(4)) : Bool)));
		for (x116 in a37) {
			H.tick();
			var v117:Map<String, String> = (["k0" => "zz", "k1" => "0"] : Map<String, String>);
			H.out("o118 " + Std.string(x116));
		}
		var v119:Float = Math.pow(1e3, 2);
		try {
			if (false) {
				H.out("o120 " + Std.string(false));
				final v121 = 191;
			} else {
				var v122:A7 = v113;
				var v123:Array<String> = ([] : Array<String>);
			}
			if (false) return 300;
			if (false) throw 60;
		} catch (ex124:String) {
			H.out("caught String " + ex124);
			final v125 = 5;
		} catch (ex126:Int) {
			H.out("caught Int " + ex126);
			for (i127 in 0...1) {
				H.tick();
				var v128:K8 = K8.K8B;
				var v129:Null<Int> = i127;
			}
			var v130 = 201;
		} catch (ex131:Err) {
			H.out("caught Err " + ex131.errCode);
			var v132 = ("abc").length;
			final v133 = "\n";
		} catch (ex134:Dynamic) {
			H.out("caught " + H.exn(ex134));
			H.out("o135 " + Std.string(143));
			for (i136 in 0...H.lim(199)) {
				H.tick();
				final v137:Float = i136;
				H.out("o138 " + Std.string(true));
			}
		}
		return v119;
	}
	public static function ext40(a39:String):Array<Int> {
		H.tick();
		var v139:Int = 48;
		H.out("o140 " + Std.string(v139));
		final v141:String = a39;
		if (false) {
			for (k142 => v143 in new Map<String, Int>()) {
				H.tick();
				v139 <<= (v143 & 7);
			}
			for (k144 => v145 in new Map<String, Int>()) {
				H.tick();
				if (false) break;
			}
			if (true) {
				v139--;
				Main.fn23(v139, v141, false, v139);
				H.out("o146 " + Std.string((new A7(v139) : Int)));
			} else {
				H.out("o147 " + Std.string(({x1: false, x2: a39} : S0)));
				var v148 = 230;
			}
		} else {
			Main.fn15((a39).replace("a", "b"), (v139 : A7));
		}
		v139 &= 202;
		var v149 = Main.fn15("\u{1F600}", (v139 : A7));
		if (StringTools.endsWith((a39).substr((4 & 7), -2), Std.string(true))) {
			for (k151 => x150 in [16, v149, 0x7FFFFFFF]) {
				H.tick();
				final v152:() -> Int = () -> v139;
				v149 = (-10);
			}
			try {
				var v153:Map<String, Int> = new Map<String, Int>();
				Main.fn15(v141, new A7(v139), v149, 158);
				var v154:Int = v139;
				if (true) throw a39;
			} catch (ex155:Err) {
				H.out("caught Err " + ex155.errCode);
				var v156 = v139;
				v149 = 310020627;
			} catch (ex157:haxe.Exception) {
				H.out("caught " + H.exn(ex157));
				Main.fn19(true, v149, v139);
				Ext.ext38(([] : Array<Int>));
			}
		} else {
			Main.fn9(((v141).charCodeAt(0xF206) ?? -1));
		}
		return [(((171 : A7)).twice % H.nz((("\x41\x42").split(" ")).length))];
	}
	public static function ext43(a41:Array<Int>, a42:Array<Int>):String {
		H.tick();
		final v158:Bool = true;
		if ((true && v158)) {
			var v159:Int = (K8.K8A : Int);
			Main.fn11(({x4: v159, x5: "a", x6: "ab"} : S3), (a42).contains(v159), 260);
		}
		if (("abc" > ("0").substring(1, -2))) {
			Ext.ext40(("\u{1F600}").substr((127 & 7), (328788778 & 7)));
		}
		Main.fn9(Main.fn15(("a").substr((0x80000000 & 7), (0x77F7 & 7)), new A7(574904902)));
		var v160:Float = (("\"q\"").length / 7.0);
		return '<${Std.string(v158)}';
	}
}
