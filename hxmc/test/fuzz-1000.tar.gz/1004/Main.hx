import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum abstract K8(Int) to Int {
	var K8A = 1;
	var K8B = 4;
	var K8C = 7;
	var K8D = 10;
}

class Main {
	public static function fn9(a10:Int):Int {
		H.tick();
		H.out("o44 " + Std.string(a10));
		if (true) {
			var w45 = 0;
do {
				w45++;
				H.tick();
				var v46:Map<String, Int> = new Map<String, Int>();
			} while (w45 < 3 && false);
		}
		H.out("o47 " + Std.string(123456.789));
		for (x48 in [false, false, StringTools.endsWith("A-B-C", "ab")]) {
			H.tick();
			H.out("o49 " + Std.string(false));
		}
		return (new A7((Std.parseInt("42") ?? 0)) : Int);
	}
	public static inline function fn11(a12:S3, a13:Bool, ?a14:Null<Int>):Float {
		H.tick();
		final v50:Float = Math.abs(1.25);
		fn9((Std.parseInt(Std.string(221)) ?? 0));
		for (i51 in 0...2) {
			H.tick();
			final v52:(Bool, Bool) -> Float = (p53:Bool, p54:Bool) -> v50;
			H.out("o55 " + Std.string(a13));
			var v56:Bool = ([i51, i51]).contains(i51);
		}
		var v57 = (K8.K8A : Int);
		final v58:Bool = true;
		H.out("o59 " + Std.string(v50));
		var v60:Array<Int> = ([294, 74]).filter(v61 -> false);
		if ((Std.string(7.0) != "zz")) {
			var v62:Array<S3> = ([a12, a12, ({x6: "hello world", x4: 0.1, x5: "\\"} : S3)] : Array<S3>);
			var v63:K8 = K8.K8A;
			Main.fn9(v57);
		} else {
			var v64:Int = Reflect.compare("Haxe", "\u{1F600}");
			H.out("o65 " + Std.string(174));
		}
		return v50;
	}
	public static function fn15(a16:String, a17:A7, ...r18:Int):Int {
		H.tick();
		for (k66 => v67 in new Map<String, Int>()) {
			H.tick();
			Main.fn9((r18.toArray()).indexOf(v67));
		}
		fn11(({x6: a16, x4: 1e3, x5: a16} : S3), !true);
		H.out("o68 " + Std.string(({x1: false, x2: a16} : S0)));
		var w69 = 0;
while (w69 < 1 && false) {
			w69++;
			H.tick();
			H.out("o70 " + Std.string((a16).indexOf(a16)));
			var v71:Int = H.at(r18.toArray(), 115, 0);
			H.out("o72 " + a16);
		}
		H.out("o73 " + Std.string((K8.K8D : Int)));
		H.out("o74 " + Std.string(((K8.K8C : Int) - 87)));
		fn9(Reflect.compare(StringTools.replace(a16, " ", a16), StringTools.hex(((-1373054404)) & 0xFFFF, 4)));
		var v75 = (a16).indexOf("q");
		return (false ? (v75 % H.nz(((new Map<String, Int>()).get("k1") ?? 0))) : fn9(Math.round(v75)));
	}
	public static function fn19(a20:Bool, a21:Int, a22:Int = 4):Null<Int> {
		H.tick();
		for (x76 in ([false]).copy()) {
			H.tick();
			H.out("o77 " + Std.string(("ab").lastIndexOf("a")));
		}
		var v78:Float = (0.5 * 3.0);
		var v79:S3 = ({x4: a22, x5: "0", x6: "42"} : S3);
		final v80:(Bool) -> Bool = (p81:Bool) -> true;
		fn15("ünï", (new A7(a22) * new A7(0x2EF7)), 0x7FFFFFFF);
		Main.fn9(({ var v82 = 0xFFFFFFFF; (new A7(1271733751)).twice; }));
		return (105 ^ a21);
	}
	public static function fn23(a24:Float, a25:String, a26:Bool, ...r27:Int):Void {
		H.tick();
		for (x83 in ((false ? [a26, a26] : [a26, a26]) : Array<Bool>)) {
			H.tick();
			{
				H.out("o84 " + a25);
				var v85:Float = a24;
			}
		}
		H.out("o86 " + Std.string((K8.K8A : Int)));
		var v87:Map<String, Float> = ({ var v88 = a25; new Map<String, Float>(); });
		H.out("o89 " + Std.string(((K8.K8C : Int) != Reflect.compare(a25, a25))));
	}
	public static function fn28(a29:Int, ?a30:Null<Int>):Int {
		H.tick();
		H.out("o90 " + Std.string(({x1: true, x2: "hello world"} : S0)));
		H.out("o91 " + Std.string(Ext.ext38([0x51EA, 1507803654, a29])));
		final v92:K8 = K8.K8D;
		a29 = (-1447526242);
		H.out("o93 " + "\t");
		H.out("o94 " + Std.string(([v92, v92, v92] : Array<K8>)));
		if (StringTools.contains("  pad  ", "A-B-C")) {
			final v95:A7 = new A7(a29);
		}
		var v96:Array<Int> = ([12]).slice(3, (a29 & 7));
		return a29;
	}
	public static function fn31(a32:String, a33:Float, a34:Int):Float {
		H.tick();
		var v97 = Main.fn9(a34);
		v97 = (new A7(v97)).twice;
		if (true) {
			if ((new Map<String, Float>()).exists(a32)) {
				var v98:Map<Int, Int> = ([-3 => v97, 4 => 15] : Map<Int, Int>);
				H.out("o99 " + Std.string((-1392875967)));
				H.out("o100 " + a32);
			}
			H.out("o101 " + Std.string(v97));
			for (i102 in 0...H.lim(v97)) {
				H.tick();
				fn9(v97);
				a34 = 145;
				final v103:String = a32;
			}
		} else {
			var v104:K8 = K8.K8C;
			H.out("o105 " + Std.string((a32).indexOf(a32)));
		}
		v97 |= Main.fn28(Reflect.compare(v97, v97), v97);
		H.out("o106 " + Std.string(149));
		return 0.5;
	}
	public static function fn35(a36:Int):Void {
		H.tick();
		var v107:Array<Int> = ([] : Array<Int>);
		var v108:Null<Int> = 286;
		H.out("o109 " + (([] : Array<String>)).join(","));
		a36 = H.id(a36);
	}
	public static function section0():Void {
		H.tick();
		final v161 = (((new Map<String, Int>()).get("k0") ?? 0) * H.at([239, 215, 0x80000000], 297, 0));
		for (x162 in ([] : Array<String>)) {
			H.tick();
			var v163:Map<Int, Array<Int>> = new Map<Int, Array<Int>>();
			final v164:Map<String, Int> = new Map<String, Int>();
			var v165:Map<String, Bool> = new Map<String, Bool>();
		}
		for (i166 in 0...H.lim(Main.fn15("A-B-C", new A7(v161), 146))) {
			H.tick();
			var v167:Map<Int, Int> = ([-3 => 229, 4 => i166, 11 => v161] : Map<Int, Int>);
		}
		var v168:Array<Int> = ((true ? [v161] : [v161, v161, 153]) : Array<Int>);
		H.out("o169 " + Std.string((((v168).contains(v161) ? ({x5: "\x41\x42", x6: "A-B-C", x4: 0.1} : S3) : ({x4: 0.5, x5: "\"q\"", x6: "é"} : S3)) : S3)));
	}
	public static function section1():Void {
		H.tick();
		if ((false && false)) {
			var v170:Array<Float> = ([1.25, (-2.5), 0.1] : Array<Float>);
			var v171:Float = 3.0;
		}
		for (i172 in 2...H.lim(((["日本語", "\u{1F600}", "ab"]).join(" ")).length)) {
			H.tick();
			var v173 = 65535;
		}
		for (x174 in (([1e-7, 3.0] : Array<Float>)).map((v175:Float) -> false)) {
			H.tick();
			if (false) {
				var v176:Array<() -> String> = ([function():String {
					H.tick();
					H.out("o177 " + "A-B-C");
					Ext.ext38([152, 0xB431]);
					return "é";
				}, function():String {
					H.tick();
					H.out("o178 " + Std.string(x174));
					var v179 = (-15);
					var v180:Int = v179;
					return "ab";
				}] : Array<() -> String>);
				H.out("o181 " + "\"q\"");
				final v182 = 2031434251;
			}
			H.out("o183 " + Std.string(["q"]));
		}
		var v184:Map<String, Int> = ({ var v185 = Reflect.compare("  pad  ", "\u{1F600}"); (["k0" => v185, "k1" => 265] : Map<String, Int>); });
		var v186 = (([] : Array<Int>)).indexOf(279);
		for (x187 in (["hello world"]).filter(v188 -> (new Map<String, Int>()).exists(v188))) {
			H.tick();
			fn23((-2.5), x187, StringTools.endsWith(x187, x187), 195);
			var w189 = 0;
while (w189 < 5 && true) {
				w189++;
				H.tick();
				final v190:String = x187;
			}
			H.out("o191 " + Std.string(H.at([v186], v186, 0)));
		}
		var v192:Int = v186;
		if (("\x41\x42" > ([true]).join(" "))) {
			final v193 = "0";
			final v194:A7 = new A7(v192);
			final v195:Int = v186;
		} else {
			try {
				if ((new Map<String, S0>()).exists("k0")) throw String.fromCharCode(65 + ((v186) & 15));
				var v196:S0 = ({x2: "hello world", x1: false} : S0);
			} catch (ex197:String) {
				H.out("caught String " + ex197);
				var v198 = "-7";
				var v199:Float = v192;
			} catch (ex200:Int) {
				H.out("caught Int " + ex200);
				H.out("o201 " + Std.string(ex200));
			} catch (ex202:Err) {
				H.out("caught Err " + ex202.errCode);
				v192 = H.id(v192);
			} catch (ex203:Dynamic) {
				H.out("caught " + H.exn(ex203));
				final v204:Map<Int, Int> = new Map<Int, Int>();
				var v205:Array<Float> = ([v192, v186, (-2.5)] : Array<Float>);
			}
		}
	}
	public static function section2():Void {
		H.tick();
		var v206:A7 = new A7((Std.parseInt(Std.string(274)) ?? 0));
		var w207 = 0;
while (w207 < 4 && (StringTools.contains("42", "\t") || true)) {
			w207++;
			H.tick();
			H.out("o208 " + Std.string(Reflect.compare(1339793379, 0x7222)));
			fn23(1e3, ("hello world").toUpperCase(), Math.isNaN(1.25), ((12 : A7) : Int), ("\n").indexOf("-7"));
		}
		if (StringTools.endsWith("é", "ab")) {
			var v209:Array<String> = ["a\rb", "zz"];
			for (x210 in ([3.0] : Array<Float>)) {
				H.tick();
				var v211 = true;
				var v212:Int = 14;
				var v213:Map<Int, Int> = new Map<Int, Int>();
			}
		}
		var v214:Map<String, Int> = new Map<String, Int>();
	}
	public static function section3():Void {
		H.tick();
		try {
			if (Math.isNaN(43)) throw "boom";
			H.out("o215 " + Std.string([128]));
			for (x216 in ("0").split("-")) {
				H.tick();
				var v217:Float = 1.25;
				var v218:Float = v217;
			}
			{
				H.out("o219 " + Std.string(163));
				H.out("o220 " + Std.string(7.0));
				var v221 = 0xFFEF;
			}
		} catch (ex222:Err) {
			H.out("caught Err " + ex222.errCode);
			H.out("o223 " + Std.string(Reflect.compare("ünï", "a\rb")));
		} catch (ex224:haxe.Exception) {
			H.out("caught " + H.exn(ex224));
			H.out("o225 " + Std.string(Math.round(2.5e-3)));
		}
		for (x226 in ([] : Array<String>)) {
			H.tick();
			var v227:Array<Bool> = [true];
		}
		var v228:Int = ((152 : A7)).get();
		var v229 = (Std.parseInt("0") ?? 0);
		var v230:A7 = ((false ? new A7(v228) : new A7(v229)) : A7);
		if ((([v228, 47]).contains(0xDE10) && true)) {
			H.out("o231 " + Std.string((["x,y,z"]).indexOf("\x41\x42")));
			var v232:String = ("\t").substring(1, (v229 & 7));
		}
		try {
			final v233:Map<String, Int> = new Map<String, Int>();
			var v234 = 288;
			if (!false) throw ("\u{1F600}").charAt(5);
		} catch (ex235:String) {
			H.out("caught String " + ex235);
			v229 |= 156;
			H.out("o236 " + ("\n").toLowerCase());
		} catch (ex237:Int) {
			H.out("caught Int " + ex237);
			var v238:K8 = K8.K8B;
			H.out("o239 " + Std.string(([] : Array<Int>)));
		} catch (ex240:Err) {
			H.out("caught Err " + ex240.errCode);
			var w241 = 0;
do {
				w241++;
				H.tick();
				var v242:Map<String, Float> = new Map<String, Float>();
				var v243 = false;
			} while (w241 < 2 && false);
		} catch (ex244:Dynamic) {
			H.out("caught " + H.exn(ex244));
			var v245:Array<Float> = ([v228, v229] : Array<Float>);
			if (true) {
				v229 = (-2147483647);
			} else {
				H.out("o246 " + "\"q\"");
				H.out("o247 " + Std.string(({x4: 7.0, x5: "ab", x6: "a\rb"} : S3)));
			}
		}
		var w248 = 0;
do {
			w248++;
			H.tick();
			if (Math.isNaN(v229)) {
				Main.fn35(v228);
				var v249:Array<Int> = [v228, v229];
			}
			v229 <<= (v228 & 7);
		} while (w248 < 1 && (true ? false : true));
		H.out("o250 " + "a");
	}
	public static function section4():Void {
		H.tick();
		var v251:Array<Float> = ([0.5] : Array<Float>);
		try {
			H.out("o252 " + Std.string((-1662095133)));
			if ((123456.789 < 2.5e-3)) throw new Err((K8.K8C : Int));
		} catch (ex253:String) {
			H.out("caught String " + ex253);
			for (k255 => x254 in [(-1491340171), (-2147483647)]) {
				H.tick();
				v251.pop();
			}
		} catch (ex256:Int) {
			H.out("caught Int " + ex256);
			for (i257 in 0...1) {
				H.tick();
				var v258 = true;
				var v259:String = "a";
				H.out("o260 " + "abc");
			}
			if (false) {
				final v261:Int = (-2147483647);
				var v262 = ex256;
			} else {
				var v263 = true;
			}
		} catch (ex264:Err) {
			H.out("caught Err " + ex264.errCode);
			var v265:Map<String, Int> = new Map<String, Int>();
			var w266 = 0;
while (w266 < 1 && true) {
				w266++;
				H.tick();
				var v267 = "\x41\x42";
				H.out("o268 " + Std.string(125));
				H.out("o269 " + Std.string(({x4: 1e3, x5: v267, x6: v267} : S3)));
			}
		} catch (ex270:Dynamic) {
			H.out("caught " + H.exn(ex270));
			H.out("o271 " + Std.string(true));
		}
		H.out("o272 " + Std.string((new A7(([53]).indexOf(206)) : Int)));
		Ext.ext40(Ext.ext43(([] : Array<Int>), [0x7FFFFFFF]));
		final v273:(Int) -> Int = (p274:Int) -> ([p274, p274, p274]).indexOf(p274);
		var w275 = 0;
while (w275 < 1 && true) {
			w275++;
			H.tick();
			try {
				if (Math.isNaN(1e3)) throw new Err(262);
				var v276:Bool = false;
			} catch (ex277:Err) {
				H.out("caught Err " + ex277.errCode);
				H.out("o278 " + "\"q\"");
				H.out("o279 " + Std.string([124, 0x6E0B]));
			} catch (ex280:haxe.Exception) {
				H.out("caught " + H.exn(ex280));
				Main.fn11(({x4: 123456.789, x6: "\t", x5: "  pad  "} : S3), true);
			}
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
