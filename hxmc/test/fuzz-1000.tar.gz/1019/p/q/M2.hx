package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

interface I5 {
	function m6():E0;
}

class C19 extends C7 implements I5 {
	public static var f20:Int = 187;
	public function new(a21:Array<Bool>, a22:Bool) {
		super(((([-3 => 104, 4 => 246, 11 => 0xFFFFFFFF] : Map<Int, Int>)).get(4) ?? 0));
	}
	override public function m6():E0 {
		H.tick();
		C19.f20 ^= 207;
		var v100:Array<Int> = [for (i101 in 0...4) ([i101]).indexOf(i101)];
		H.out("o102 " + Std.string(E1.E1C(1.25)));
		H.out("o103 " + Std.string(3.0));
		return ((StringTools.startsWith("  pad  ", "\"q\"") ? E0.E0B : E0.E0A) : E0);
	}
	public function m23():String {
		H.tick();
		H.out("o104 " + ("q").substr(-2, -1));
		var v105:C19 = new C19([true, false, false], false);
		H.out("o106 " + Std.string((("\\").split(",")).indexOf(C7.f8)));
		H.out("o107 " + Std.string(Reflect.compare((([] : Array<Float>)).length, ((new Map<String, Int>()).get("k0") ?? 0))));
		if (false) {
			var v108:Array<String> = ([] : Array<String>);
		}
		return ("a").substr(2, (19 & 7));
	}
	public static function m24(a25:Int, a26:Int):Int {
		H.tick();
		try {
			if ((true ? false : (E0.E0A).match(E0B))) throw "boom";
			C19.f20 = a26;
			var v109:Array<Int> = ([] : Array<Int>);
		} catch (ex110:String) {
			H.out("caught String " + ex110);
			H.out("o111 " + Std.string(a25));
		} catch (ex112:Int) {
			H.out("caught Int " + ex112);
			var v113 = (Std.parseInt(Std.string(a25)) ?? 0);
			var v114:String = C7.f8;
		} catch (ex115:Err) {
			H.out("caught Err " + ex115.errCode);
			H.out("o116 " + Std.string(new C19([false, true, false], false)));
		} catch (ex117:Dynamic) {
			H.out("caught " + H.exn(ex117));
			(new C33(false, C7.f9)).m39();
		}
		{
			var v118 = a25;
			var v119 = Type.enumIndex(E0.E0B);
			try {
				if (Math.isNaN(0.1)) throw "boom";
				H.out("o120 " + Std.string(v119));
				var v121:Array<Int> = [v118, v119];
				var v122 = false;
			} catch (ex123:String) {
				H.out("caught String " + ex123);
				var v124:Float = v119;
			} catch (ex125:Int) {
				H.out("caught Int " + ex125);
				(new C19([true], true)).m6();
			} catch (ex126:Err) {
				H.out("caught Err " + ex126.errCode);
				H.out("o127 " + "\x41\x42");
				var v128:Float = a26;
			} catch (ex129:Dynamic) {
				H.out("caught " + H.exn(ex129));
				a26 = 52;
			}
		}
		final v130:Array<String> = [for (i131 in [(-4), a26, 129]) if (false) C7.f8];
		if (Main.fn64(a25, "-7")) {
			C19.f20--;
			C7.f9 = E0.E0A;
			try {
				Main.fn64(a26, "42");
				if (Std.isOfType(new C19([true, true], true), I5)) throw "boom";
			} catch (ex132:Err) {
				H.out("caught Err " + ex132.errCode);
				H.out("o133 " + Std.string(a26));
			} catch (ex134:haxe.Exception) {
				H.out("caught " + H.exn(ex134));
				Main.fn52(a26, a25, (["k0" => a26, "k1" => a26, "k2" => a26] : Map<String, Int>));
			}
		}
		try {
			if ((true ? Std.isOfType(new C33(false, E0.E0B), C33) : (E0.E0A).match(E0B))) throw new Err(((("42").charCodeAt(a25) ?? -1) - ("Haxe").indexOf("abc")));
			H.out("o135 " + Std.string(E0.E0A));
			H.out("o136 " + Std.string((([] : Array<Int>)).contains(132)));
			Main.fn60(("").split(","), C7.f8, new C19([false, false], true));
		} catch (ex137:String) {
			H.out("caught String " + ex137);
			H.out("o138 " + Std.string(Math.floor(0.1)));
			C19.f20 *= a26;
		} catch (ex139:Int) {
			H.out("caught Int " + ex139);
			if (false) {
				Main.fn49(a25, a25);
				H.out("o140 " + Std.string(true));
				H.out("o141 " + Std.string(ex139));
			}
		} catch (ex142:Err) {
			H.out("caught Err " + ex142.errCode);
			var v143:Bool = StringTools.startsWith("zz", "q");
			var v144:Array<Bool> = [v143];
		} catch (ex145:Dynamic) {
			H.out("caught " + H.exn(ex145));
			var v146 = (Std.parseInt("a\rb") ?? 0);
		}
		var v147:E0 = E0.E0B;
		(new C33(Std.isOfType(null, C7), v147)).m6();
		H.out("o148 " + Std.string((new C19(([] : Array<Bool>), false)).m14(([] : Array<Int>), C19.f20)));
		return a26;
	}
}

class C33 implements I5 {
	public function new(a34:Bool, a35:E0) {}
	public function m6():E0 {
		H.tick();
		H.out("o176 " + Std.string(E0.E0A));
		H.out("o177 " + Std.string((0x5015 ^ 47)));
		H.out("o178 " + Std.string((new C19(([] : Array<Bool>), false)).m14([113, 191, 64], ("zz").length)));
		H.out("o179 " + ({ var v180 = C19.f20; "ünï"; }));
		try {
			if ((("\n").indexOf("日本語") == 174)) throw C7.f8;
			H.out("o181 " + StringTools.hex((191) & 0xFFFF, 4));
			H.out("o182 " + Std.string(new C19([false, false], true)));
		} catch (ex183:Err) {
			H.out("caught Err " + ex183.errCode);
			Main.fn64(52, ("a").substr((87 & 7), 3));
		} catch (ex184:haxe.Exception) {
			H.out("caught " + H.exn(ex184));
			var v185:Array<Int> = [241, 64];
			v185 = H.capa([0x7F3E, 207, 65535]);
		}
		return E0.E0B;
	}
	public function m36():Void {
		H.tick();
		this.m40(Std.string((-12)), C19.m24(0xD608, C19.f20));
		var v186:Bool = false;
		C19.f20 -= 140;
		var v187 = "";
		{
			C7.m11(C7.f8, "ünï");
			var v188:E1 = E1.E1A;
			C19.f20 = (([] : Array<Bool>)).length;
		}
	}
	public function m37(a38:String):Int {
		H.tick();
		var v189:Array<I5> = ([new C33(false, E0.E0B), new C19([true], true)] : Array<I5>);
		var v190:Int = (a38).lastIndexOf("\x41\x42");
		var v191:Int = Math.ceil(123456.789);
		var v192:Bool = true;
		C19.f20 = (([v190, v190]).indexOf(v190) % H.nz((([] : Array<Float>)).length));
		v190 = v191;
		(new C19([v192, v192], (new Map<Int, Int>()).exists(-3))).m23();
		return Main.fn60([a38, StringTools.lpad(a38, "*", 4), a38], (new C19([v192, v192], v192)).m23(), new C19([v192], v192));
	}
	public function m39():Void {
		H.tick();
		(new C19(([] : Array<Bool>), false)).m14([H.at([0x49C0], (-10), 0)], 294);
		final v193:Array<Int> = ([78, 0xB2C5, (-4)]).slice(((Std.parseInt("é") ?? 0) & 7), -2);
		C19.f20++;
		if (false) {
			if ((v193).contains(158)) {
				H.out("o194 " + Std.string(v193));
			} else {
				C19.f20 = 278;
			}
			if ((E1.E1D).match(E1D)) {
				var v195 = 402669285;
			} else {
				var v196 = 35;
			}
			var v197:Float = 100.75;
		}
	}
	public function m40(a41:String, a42:Int):Void {
		H.tick();
		try {
			var v198:Bool = true;
			var v199:I5 = new C19([v198, v198, v198], v198);
			C7.m17();
			if ((true && v198)) throw 49;
		} catch (ex200:Err) {
			H.out("caught Err " + ex200.errCode);
			var v201:I5 = new C19([false], true);
		} catch (ex202:haxe.Exception) {
			H.out("caught " + H.exn(ex202));
			H.out("o203 " + Std.string(Reflect.compare("zz", a41)));
			var v204 = a42;
		}
		if ((StringTools.contains(a41, "-7") || StringTools.endsWith("a\rb", a41))) {
			var v205 = C19.f20;
			var v206 = (E0.E0B).match(E0B);
		} else {
			H.out("o207 " + Std.string(E0.E0A));
		}
		(new C19([false, false], ([253]).contains(a42))).m14(((([a42, a42]).contains(26) ? [159] : [a42]) : Array<Int>), C19.f20);
		(new C19([true], (E0.E0B).match(E0A))).m14(([] : Array<Int>), (78 ^ (Std.parseInt(Std.string(a42)) ?? 0)));
		this.m39();
		H.out("o208 " + Std.string((C19.f20 ^ ((new Map<String, Int>()).get("k0") ?? 0))));
	}
}

class C43 {
	public final f44:String;
	public var f45:Int;
	public final f46:Float;
	public function new() {
		this.f44 = ([96, (-894762758)]).join(",");
		this.f45 = ((([-3 => 0x1884, 4 => 156] : Map<Int, Int>)).get(-3) ?? 0);
		this.f46 = 1e3;
	}
	public function m47(a48:Int):Int {
		H.tick();
		var v209:Array<Int> = [a48, 295];
		final v210:Int = 298;
		final v211:Int = a48;
		Main.fn64((Reflect.compare("a\rb", "\t") - 22), "é");
		var v212:Int = (new C33(false, E0.E0B)).m37(Std.string(a48));
		return 194;
	}
}
