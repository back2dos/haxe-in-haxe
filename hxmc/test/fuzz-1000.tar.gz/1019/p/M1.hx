package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

enum E0 {
	E0A;
	E0B;
}

enum E1 {
	E1A;
	E1B(a2:Float, a3:String);
	E1C(a4:Float);
	E1D;
}
