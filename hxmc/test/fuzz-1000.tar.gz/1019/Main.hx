import H;
import p.M1;
import p.q.M2;

abstract class C7 implements I5 {
	public static var f8:String = "\x41\x42";
	public static var f9:E0 = E0.E0A;
	public function new(a10:Int) {}
	public function m6():E0 {
		H.tick();
		var v78:Float = Main.fn49(C19.f20, Reflect.compare((-157181090), 234));
		if ((C19.f20 <= C19.f20)) {
			var v79:Map<Int, Int> = new Map<Int, Int>();
		}
		final v80 = !false;
		final v81 = String.fromCharCode(65 + ((59) & 15));
		H.out("o82 " + Std.string(v78));
		var v83:Array<Int> = [for (i84 in 0...2) H.at([i84], i84, 0)];
		H.out("o85 " + Std.string(50));
		var v86:String = v81;
		if (v80) {
			if (v80) {
				Main.fn52(v78, 134, (["k0" => 133, "k1" => (-2147483647)] : Map<String, Int>), 222, 208);
				C19.f20 = 216;
			}
			C19.f20++;
		}
		return ({ var v87 = (((v81).charCodeAt(0x60B3) ?? -1) % H.nz(Math.round(v78))); E0.E0A; });
	}
	public static function m11(a12:String, a13:String):Bool {
		H.tick();
		var v88 = Main.fn64(277, "ab");
		(new C19([v88], Std.isOfType(new C43(), C43))).m6();
		C19.f20 = ((a13).lastIndexOf(a12) * (-2112455287));
		Main.fn60(((StringTools.endsWith("a", a12) ? [a13, a13, a13] : ("\x41\x42").split(",")) : Array<String>), a13, new C19(([] : Array<Bool>), ([29, 132, 9]).contains(98)));
		Main.fn57((202 == 159), (a12).toUpperCase());
		var v89:Float = (cast (Math.sin(3.0)) : Float);
		var v90 = "é";
		C7.m17((-13), (true ? C19.f20 : (-3)));
		C19.f20 = ((Std.parseInt(Std.string(258)) ?? 0) ^ ((v90).charCodeAt(209) ?? -1));
		return C7.m17(C19.f20);
	}
	public function m14(a15:Array<Int>, a16:Int):Int {
		H.tick();
		var v91:I5 = new C19([false], true);
		H.out("o92 " + Std.string(C19.f20));
		C19.f20 <<= ((a16 + a16) & 7);
		H.out("o93 " + Std.string(2.5e-3));
		if (((E0.E0B).match(E0A) && false)) {
			var v94 = StringTools.replace("\\", " ", "\"q\"");
			if (false) {
				H.out("o95 " + Std.string(a16));
			} else {
				a16 = H.id(a16);
			}
		} else {
			H.out("o96 " + "é");
		}
		return C19.f20;
	}
	public static function m17(...r18:Int):Bool {
		H.tick();
		(new C19([false, false], (Std.downcast((null : C27), C27) != null))).m14(r18.toArray(), ((((["k0" => 0x7FFFFFFF, "k1" => 0xFFFFFFFF, "k2" => 113] : Map<String, Int>)).get("k2") ?? 0) - ("\"q\"").indexOf("ab")));
		C19.f20 &= 65535;
		var v97 = ((r18.toArray()).join(" ")).charAt(6);
		var v98 = StringTools.trim(v97);
		final v99:Float = 1e-7;
		return (false && false);
	}
}

abstract class C27 extends C7 implements I5 {
	public var f28:Map<Int, Int>;
	public function new() {
		super(C19.f20);
		this.f28 = ([-3 => 183] : Map<Int, Int>);
	}
	override public function m6():E0 {
		H.tick();
		C19.f20 |= Reflect.compare(Type.enumIndex(E0.E0A), Type.enumIndex(E0.E0A));
		try {
			var v149:Int = (-12);
			H.out("o150 " + Std.string(StringTools.startsWith("日本語", "ünï")));
			if (true) throw "boom";
		} catch (ex151:String) {
			H.out("caught String " + ex151);
			H.out("o152 " + Std.string(158));
		} catch (ex153:Int) {
			H.out("caught Int " + ex153);
			if ((E0.E0B).match(E0A)) {
				var v154:Int = ex153;
				var v155 = "Haxe";
				H.out("o156 " + v155);
			} else {
				H.out("o157 " + Std.string(ex153));
				H.out("o158 " + Std.string([ex153, 39, (-1564991060)]));
			}
			try {
				if ((new Map<Int, Int>()).exists(18)) throw "boom";
				C7.m17(140, ex153);
			} catch (ex159:String) {
				H.out("caught String " + ex159);
				var v160 = true;
			} catch (ex161:Int) {
				H.out("caught Int " + ex161);
				H.out("o162 " + Std.string(false));
				Main.fn49(216, 150);
			} catch (ex163:Err) {
				H.out("caught Err " + ex163.errCode);
				var v164:Map<String, Map<String, Bool>> = (["k0" => (["k0" => false] : Map<String, Bool>), "k1" => (["k0" => true, "k1" => true] : Map<String, Bool>), "k2" => new Map<String, Bool>()] : Map<String, Map<String, Bool>>);
				var v165 = false;
			} catch (ex166:Dynamic) {
				H.out("caught " + H.exn(ex166));
				var v167 = "\u{1F600}";
			}
		} catch (ex168:Err) {
			H.out("caught Err " + ex168.errCode);
			{
				C7.f8 += "abc";
			}
		} catch (ex169:Dynamic) {
			H.out("caught " + H.exn(ex169));
			var v170 = (("").charCodeAt(162) ?? -1);
			var v171:Int = Reflect.compare("42", "Haxe");
		}
		final v172:Int = C19.f20;
		final v173:Int = C19.f20;
		var v174:C19 = new C19(([] : Array<Bool>), true);
		var v175:Int = ((Std.downcast((v174 : C7), C19) != null) ? v173 : v173);
		v175 &= 58;
		if (true) {
			C19.f20 = (Std.parseInt("日本語") ?? 0);
		}
		return E0.E0A;
	}
	abstract public function m29():Void;
	abstract public function m30(a31:Float, a32:Int):Int;
}

class Main {
	public static function fn49(a50:Int, a51:Int):Int {
		H.tick();
		H.out("o213 " + Std.string(((["ünï"]).join("")).indexOf("hello world")));
		H.out("o214 " + Std.string(C19.f20));
		H.out("o215 " + Std.string(new C33(([44, a51, a50]).contains(a51), E0.E0B)));
		if (C7.m17()) {
			a51 -= a50;
		} else {
			if (((["k0" => true, "k1" => true, "k2" => false] : Map<String, Bool>)).exists("k0")) {
				var v216:C19 = new C19([true], true);
			}
			var v217:Array<Array<String>> = ([([] : Array<String>), ["x,y,z", "0", "日本語"], ["", "\t"]] : Array<Array<String>>);
		}
		return 250;
	}
	public static function fn52(a53:Float, a54:Int, a55:Map<String, Int>, ...r56:Int):String {
		H.tick();
		var v218:Float = a53;
		H.out("o219 " + Std.string(E0.E0B));
		var v220 = (new C19([true], true)).m14(r56.toArray(), ([a54, a54, 37]).indexOf(a54));
		final v221:I5 = new C19(([] : Array<Bool>), Std.isOfType(null, I5));
		return 'x${Std.string(1744600859)}<${Std.string(0x4B8C)}';
	}
	public static function fn57(a58:Bool, a59:String):Int {
		H.tick();
		C19.f20 ^= (if (a58) 0x80000000 else (a59).length);
		if (true) {
			var v222:Float = 73;
			var v223 = false;
		}
		{
			H.out("o224 " + Std.string(C19.f20));
			H.out("o225 " + a59);
			if (a58) {
				var v226 = (-7);
				H.out("o227 " + a59);
				var v228:Float = 0.1;
			} else {
				var v229 = a58;
				(new C33(v229, C7.f9)).m40("x,y,z", 192);
			}
		}
		var v230:Map<Int, Int> = ([-3 => 210, 4 => ([211, 19]).length, 11 => 61] : Map<Int, Int>);
		if (true) {
			var v231:Float = C19.f20;
			var v232 = 0x6166;
			H.out("o233 " + Std.string(([] : Array<E1>)));
		}
		H.out("o234 " + Std.string(([a59]).indexOf("\u{1F600}")));
		C7.f8 = H.cap((new C19(([] : Array<Bool>), a58)).m23());
		(({ var v235 = Std.isOfType(new C19([a58, a58], false), I5); new C19([v235], a58); })).m23();
		var v236:Bool = (0xE1DE <= C19.f20);
		return ((-1298406831) << (0xF3EE & 31));
	}
	public static function fn60(a61:Array<String>, a62:String, a63:C7):Int {
		H.tick();
		var v237:Float = Math.max(1e-7, Std.parseFloat("-0.25"));
		fn57(true, (a62).toLowerCase());
		++C19.f20;
		C19.f20 = ((-865679136) << (Math.ceil(v237) & 31));
		if (true) {
			var v238:I5 = a63;
		} else {
			C19.f20 += (("\u{1F600}").charCodeAt(112) ?? -1);
		}
		return ((252 ^ (-1520008752)) - (~((a62).charCodeAt(23) ?? -1)));
	}
	public static function fn64(a65:Int, a66:String):Bool {
		H.tick();
		H.out("o239 " + Std.string(E0.E0A));
		C19.f20 = 153;
		C19.f20 = a65;
		return ({ var v240 = (StringTools.hex((a65) & 0xFFFF, 4)).indexOf(C7.f8); false; });
	}
	public static function fn67():Int {
		H.tick();
		var v241:Int = 250;
		C7.m11((StringTools.startsWith("zz", "\"q\"") ? "42" : "abc"), "");
		H.out("o242 " + Std.string(127));
		if (!false) {
			if (true) return v241;
			H.out("o243 " + Std.string(E0.E0B));
		} else {
			H.out("o244 " + Std.string(E0.E0B));
			v241--;
		}
		var v245:Array<Int> = [(Std.parseInt("  pad  ") ?? 0), v241];
		var v246:C7 = new C19(([] : Array<Bool>), (([-3 => E1.E1D, 4 => E1.E1C(v241)] : Map<Int, E1>)).exists(v241));
		return (-C19.f20);
	}
	public static function fn68(a69:Int, a70:Float, a71:Int, ...r72:Int):Bool {
		H.tick();
		{
			(new C19([true], false)).m6();
			var v247:Map<String, Int> = (["k0" => a71] : Map<String, Int>);
			final v248 = Std.string(a71);
		}
		a69 <<= ((r72.toArray()).indexOf(a71) & 7);
		H.out("o249 " + Std.string(a69));
		var v250:Map<Int, Float> = ([-3 => a69, 4 => a71, 11 => 100.75] : Map<Int, Float>);
		(new C33(true, E0.E0A)).m40((StringTools.trim("abc") + (E0.E0A).match(E0A)), a71);
		return C7.m17(a71, (Std.parseInt(Std.string((("x,y,z").charCodeAt(a71) ?? -1))) ?? 0));
	}
	public static function fn73(a74:E1, a75:Float):Bool {
		H.tick();
		var v251 = Math.round(a75);
		var v252:Int = (232 << ((("ünï").charCodeAt(v251) ?? -1) & 31));
		var v253:Array<Int> = [v252, C19.f20];
		C7.f9 = E0.E0B;
		return ([for (i254 in 0...1) v251]).contains(Main.fn57((v253).contains(v252), ([false]).join("")));
	}
	public static function fn76():Bool {
		H.tick();
		H.out("o255 " + Std.string(E1.E1D));
		var v256:Array<String> = ([] : Array<String>);
		var v257:C43 = ({ var v258 = C7.f8; new C43(); });
		var v259 = Main.fn52(282, ("\u{1F600}").length, new Map<String, Int>());
		return false;
	}
	public static function fn77():Void {
		H.tick();
		H.out("o260 " + Std.string((new Map<Int, Bool>()).exists(18)));
		H.out("o261 " + Std.string(C19.f20));
		var v262:Bool = Main.fn73(E1.E1D, Math.pow(0.5, 2));
		if (StringTools.contains(C7.f8, ([v262, v262]).join(""))) {
			H.out("o263 " + Std.string(285));
			var v264 = (([] : Array<Int>)).contains(217);
		}
		var v265:Array<Float> = ([1e-7] : Array<Float>);
		(new C33(v262, C7.f9)).m40('-${("0").toLowerCase()}x${Std.string(C19.f20)}x${Std.string(true)}', 266);
		{
			(new C33(v262, E0.E0A)).m37(Std.string(E1.E1C(0.1)));
			var v266:Map<Int, String> = new Map<Int, String>();
			var v267:Float = Math.PI;
		}
	}
	public static function section0():Void {
		H.tick();
		(new C33(false, E0.E0B)).m39();
		H.out("o268 " + Std.string(((("hello world").toLowerCase()).charCodeAt(49) ?? -1)));
		C19.f20 &= (("é").charCodeAt(Math.round((-2.5))) ?? -1);
		++C19.f20;
		var v269:Array<Int> = [for (i270 in 0...0) 141];
		var v271:Array<String> = [C7.f8, (v269).join(" ")];
	}
	public static function section1():Void {
		H.tick();
		H.out("o272 " + Std.string(0xFFFFFFFF));
		H.out("o273 " + Std.string((Std.parseInt(StringTools.replace("a\rb", "a", "  pad  ")) ?? 0)));
		H.out("o274 " + Std.string((109 != 79)));
		fn49(fn67(), (C7.f8).lastIndexOf("0"));
		final v275:Float = ((false ? 1e-7 : 1.25) : Float);
		H.out("o276 " + Std.string(([240]).indexOf((("zz").charCodeAt(213) ?? -1))));
		(new C43()).m47(103);
	}
	public static function section2():Void {
		H.tick();
		C19.f20 = (236 >>> (("ab").indexOf("0") & 31));
		H.out("o277 " + Std.string(({ var v278 = StringTools.startsWith("x,y,z", "\x41\x42"); (-2020144527); })));
		C19.f20 = ({ var v279 = StringTools.lpad("ab", "*", 1); C19.f20; });
		H.out("o280 " + '${"A-B-C"}');
	}
	public static function section3():Void {
		H.tick();
		H.out("o281 " + Std.string((false && true)));
		H.out("o282 " + Std.string((79 / 206)));
		final v283 = ((-2147483647) * 0xFFFFFFFF);
	}
	public static function section4():Void {
		H.tick();
		{ var dyn284:Dynamic = (51 >> (C19.f20 & 31)); H.out("dyn " + Std.string(dyn284 + 1)); }
		var v285:Array<Int> = [138, Std.int(1e3), Reflect.compare((-2147483647), 232)];
		H.out("o286 " + Std.string(new C43()));
		try {
			H.out("o287 " + "hello world");
			var v288 = Math.floor(2.5e-3);
			if (((v285).contains(0xDF8C) || StringTools.endsWith("x,y,z", "42"))) throw (new C19(([] : Array<Bool>), false)).m23();
		} catch (ex289:Dynamic) {
			H.out("caught " + H.exn(ex289));
			if (true) {
				C19.f20 -= 44;
			}
			var v290:Map<Int, String> = ([-3 => "ab", 4 => "q", 11 => "x,y,z"] : Map<Int, String>);
		}
		H.out("o291 " + Std.string(C19.f20));
		var v292:Array<Bool> = (cast (([] : Array<Bool>)) : Array<Bool>);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
