import H;
import p.M1;
using p.Ext;

enum E0 {
	E0A;
	E0B;
	E0C(a1:Float);
}

typedef S2 = {x3:Int, x4:Int, x5:Int};

abstract A6(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A6, b:A6):A6
		return new A6(a.get() + b.get());

	@:op(A * B) public static function mul(a:A6, b:A6):A6
		return new A6(a.get() * b.get());

	@:op(-A) public static function neg(a:A6):A6
		return new A6(-a.get());
}

class Main {
	public static inline function fn7(a8:Array<Float>, a9:E0):Bool {
		H.tick();
		{ var dyn22:Dynamic = ({x5: 65535, x4: (-1832988839), x3: (-16)} : S2); H.out("dyn " + Std.string(dyn22.x3) + " " + Std.string(Reflect.field(dyn22, "x3"))); }
		for (i23 in 0...3) {
			H.tick();
			for (i24 in 1...5) {
				H.tick();
				var v25:Int = i24;
				var v26 = true;
			}
			H.out("o27 " + Std.string(a9));
			final v28:() -> Void = function():Void {
				H.tick();
				var v29:E0 = a9;
			};
		}
		final v30 = ({ var v31 = 13883984; Type.enumIndex(E0A); });
		switch (false) {
			case true: {
				for (x32 in ([v30, v30, 7.0] : Array<Float>)) {
					H.tick();
					var v33 = false;
					H.out("o34 " + Std.string(v30));
					H.out("o35 " + Std.string(v30));
				}
				H.out("o36 " + Std.string(v30));
			};
			case false: {
				switch (0x80000000) {
					case 0: {
						var v37 = v30;
						H.out("o38 " + Std.string(a9));
					};
					case 1 | 6: {
						var v39:Array<Int> = ([] : Array<Int>);
					};
					case _: {
						var v40:Float = 0.1;
						a8.insert(0, v30);
					};
				}
			};
		}
		return ({ var v41 = ((new Map<Int, S2>()).exists(v30) || (E0C(v30)).match(E0A)); v41; });
	}
	public static inline function fn10(a11:Int, a12:Int, a13:Float):Bool {
		H.tick();
		a11 = a12;
		a12 |= ((-2026140032) >>> (a12 & 31));
		a12 = H.id(a12);
		for (x42 in (([a13, 1e-7] : Array<Float>)).slice((a12 & 7), 5)) {
			H.tick();
			var v43:Float = 1e-7;
		}
		var v44 = (switch (E0C(a13)) {
			case E0A: a12;
			case E0B: (({x4: a12, x3: a12, x5: 0x3A49} : S2)).x5;
			case E0C(c45): ((a12 : A6)).twice;
		});
		return ((((["k0" => v44, "k1" => v44, "k2" => 107] : Map<String, Int>)).exists("k1") && true) || (([true, false]).indexOf(true) == (-11)));
	}
	public static function fn14(a15:Bool, a16:String = "d"):Float {
		H.tick();
		final v46:S2 = ({x5: 0x2E8A, x3: (Std.parseInt(Std.string(60)) ?? 0), x4: H.at(([] : Array<Int>), 0x7FFFFFFF, 0)} : S2);
		for (x47 in [([(-2147483647), 183, 1389316584]).join(""), "-7"]) {
			H.tick();
			H.out("o48 " + Std.string((([-3 => (90 : A6), 4 => (74 : A6)] : Map<Int, A6>)).exists(-3)));
			H.out("o49 " + Std.string(Lambda.fold([1551745063], (v50:Int, v51:Int) -> Math.ceil(v51), 0)));
		}
		try {
			if ((Std.string(a15)).ext21((([2.5e-3, 1e3, 123456.789] : Array<Float>)).length)) throw (false ? "ab" : a16);
			Main.fn7(([5e-324] : Array<Float>), E0B);
		} catch (ex52:String) {
			H.out("caught String " + ex52);
			for (x53 in ([] : Array<Float>)) {
				H.tick();
				if (a15) break;
			}
			final v54:Map<String, Bool> = (["k0" => a15, "k1" => a15, "k2" => a15] : Map<String, Bool>);
		} catch (ex55:Int) {
			H.out("caught Int " + ex55);
			fn7(([ex55, ex55, ex55] : Array<Float>), E0C(ex55));
		} catch (ex56:Err) {
			H.out("caught Err " + ex56.errCode);
			var v57:S2 = ({x3: 527287298, x4: 57, x5: 0x7FFFFFFF} : S2);
			var v58:Float = 4;
		} catch (ex59:Dynamic) {
			H.out("caught " + H.exn(ex59));
			var v60:Map<String, Int> = (["k0" => 188] : Map<String, Int>);
			var v61:Int = 150;
		}
		Ext.ext21(({ var v62 = (Std.parseInt(a16) ?? 0); "A-B-C"; }), 2115131302);
		final v63:Int = (v46).x5;
		for (i64 in 1...3) {
			H.tick();
			var v65:Array<Bool> = [a15, a15];
			var v66:E0 = E0.E0C(v63);
			var v67:Map<String, Int> = new Map<String, Int>();
		}
		for (x68 in ([] : Array<Int>)) {
			H.tick();
			var v69 = ((([-3 => 147] : Map<Int, Int>)).get(18) ?? 0);
			Main.fn7(([] : Array<Float>), E0C(x68));
			var v70:E0 = E0.E0C(x68);
		}
		return Math.sin((cast (v63) : Float));
	}
	public static function fn17(a18:Bool):String {
		H.tick();
		final v71:Array<E0> = ([E0A, E0A] : Array<E0>);
		final v72:Bool = fn10((Std.parseInt(Std.string(124)) ?? 0), Lambda.fold([157], (v73:Int, v74:Int) -> 0xFFFFFFFF, 0), 99);
		var v75 = true;
		switch (E0.E0C(186)) {
			case E0A: {
				var v76 = ([v72, false, v75]).length;
			};
			case E0B: {
				var v77:Map<String, Int> = (["k0" => 188] : Map<String, Int>);
				Main.fn7(([0.5, 2.5e-3] : Array<Float>), E0B);
			};
			case E0C(c78): {
				if ((E0.E0B).match(E0B)) {
					var v79:Array<Float> = ([] : Array<Float>);
					H.out("o80 " + Std.string(false));
				} else {
					H.out("o81 " + Std.string(([c78, c78, c78] : Array<Float>)));
					final v82:() -> Int = () -> 215;
				}
			};
		}
		final v83:A6 = (new A6(78) * new A6(105043678));
		var v84:Float = (170 / 228);
		Ext.ext21(("q" + Math.isNaN(v84)), (switch (Type.enumIndex(E0.E0C(v84))) {
			case 0: 190;
			case 2 | 6: H.at(([] : Array<Int>), 0x9511, 0);
			case c85 if (c85 > 10): (({x3: c85, x4: 158, x5: c85} : S2)).x3;
			case _: 0x3119;
		}));
		final v86 = 293;
		return "42";
	}
	public static function section0():Void {
		H.tick();
		function lf105(n106:Int):Int {
			H.tick();
			return n106 <= 0 ? (Std.parseInt("42") ?? 0) : (lf105(n106 - 1) + 87);
		}
		H.out("lf105 " + lf105(0));
		H.out("o107 " + Std.string(false));
		final v108:S2 = ({x4: 12, x3: 141, x5: Type.enumIndex(E0A)} : S2);
		var v109:Array<Int> = [Lambda.fold([0xFFFFFFFF, 135605807], (v110:Int, v111:Int) -> 0x3AD5, 0), 135];
		switch (((11 : A6) : Int)) {
			case 0: {
				if ((([] : Array<Int>)).contains(60)) {
					fn14(true);
				}
			};
			case 1 | 5: {
				var w112 = 0;
while (w112 < 1 && (E0B).match(E0A)) {
					w112++;
					H.tick();
					var v113:Int = 114;
					var v114 = 202;
				}
				var v115:Int = ((new Map<String, Int>()).get("k0") ?? 0);
			};
			case _: {
				var v116:Int = Math.round(1.7976931348623157e308);
				final v117:E0 = E0A;
			};
		}
		var v118:Map<String, Map<String, Int>> = new Map<String, Map<String, Int>>();
	}
	public static function section1():Void {
		H.tick();
		H.out("o119 " + Std.string(E0C(20)));
		var v120:Float = 1e-7;
		fn17(true);
		var v121:Float = v120;
		H.out("o122 " + Std.string(((({x3: 0x7FFFFFFF, x4: 81, x5: 35} : S2)).x4 <= 215)));
		var v123:Int = H.at(([] : Array<Int>), 106, 0);
		final lf124:(Int) -> Int = function(p125:Int):Int {
			H.tick();
			if ((E0C(v121)).match(E0B)) {
				H.out("o126 " + Std.string(p125));
				Ext.ext21("-7", p125);
				var v127:Int = p125;
			}
			{
				H.out("o128 " + Std.string(v123));
			}
			H.out("o129 " + Std.string(E0.E0A));
			return (false ? p125 : ((([-3 => v123] : Map<Int, Int>)).get((-2147483647)) ?? 0));
		};
		Main.fn7((([v120] : Array<Float>)).filter(v130 -> (E0.E0A).match(E0A)), E0C(Math.pow(v121, 2)));
	}
	public static function section2():Void {
		H.tick();
		var v131:Map<String, Int> = (["k0" => Reflect.compare(0xB639, 268), "k1" => 126] : Map<String, Int>);
		H.out("o132 " + Std.string((new A6(236) : Int)));
		for (k133 => v134 in new Map<String, Int>()) {
			H.tick();
			switch (H.id([v134, v134])) {
				case []: {
					var v135:Array<Float> = ([v134, (-2.5)] : Array<Float>);
					var v136:Map<Int, Int> = new Map<Int, Int>();
				};
				case [c137]: {
					var v138 = c137;
					var v139:Bool = true;
				};
				case [_, c140]: {
					var v141 = c140;
					var v142:E0 = E0A;
				};
				case _: {
					H.out("o143 " + Std.string(v134));
					H.out("o144 " + Std.string(v134));
				};
			}
			var v145:Bool = false;
			var v146:Array<Bool> = ([] : Array<Bool>);
		}
		var v147:E0 = E0.E0B;
		H.out("o148 " + Std.string([128, 3, ((new Map<Int, Int>()).get(11) ?? 0)]));
		H.out("o149 " + Std.string((new A6(0xF1B) : Int)));
	}
	public static function section3():Void {
		H.tick();
		H.out("o150 " + '$$');
		var v151 = (Math.round(123456.789) ^ (({x3: 66, x4: 105, x5: 231} : S2)).x3);
		v151 = 0x2F33;
		++v151;
		var v152:E0 = E0.E0B;
	}
	public static function section4():Void {
		H.tick();
		final v153:Array<Int> = [256, (([] : Array<String>)).indexOf("zz"), (-5)];
		H.out("o154 " + Std.string((([1e21] : Array<Float>)).length));
		H.out("o155 " + Std.string(((([-3 => 18, 4 => 83] : Map<Int, Int>)).exists(89) ? 124 : Math.round(1.25))));
		switch (88) {
			case 0: {
				final lf156:(Int, Int) -> Float = function(p157:Int, p158:Int):Float {
					H.tick();
					H.out("o159 " + Std.string(E0.E0A));
					H.out("o160 " + Std.string(v153));
					var v161:Array<Map<Int, Float>> = ([([-3 => p157, 4 => p158, 11 => p158] : Map<Int, Float>), new Map<Int, Float>(), ([-3 => p157, 4 => p157, 11 => p158] : Map<Int, Float>)] : Array<Map<Int, Float>>);
					return p158;
				};
				var v162:Int = (([7.0] : Array<Float>)).length;
			};
			case 3 | 5: {
				H.out("o163 " + Std.string(([0.1] : Array<Float>)));
				if ((v153).contains(43)) {
					H.out("o164 " + Std.string(null));
				} else {
					H.out("o165 " + Std.string(1e3));
				}
			};
			case c166 if (c166 > 10): {
				final v167:(Float, String) -> Bool = function(p168:Float, p169:String):Bool {
					H.tick();
					Main.fn7(([] : Array<Float>), E0C(c166));
					return false;
				};
			};
			case _: {
				H.out("o170 " + Std.string(2136874230));
				if (false) {
					fn7(([0.1, 0.1] : Array<Float>), E0C(1e3));
				} else {
					final v171:Array<Bool> = ([] : Array<Bool>);
				}
			};
		}
		final v172:Int = 53;
		var v173:Int = H.at(v153, Std.int(v172), 0);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
