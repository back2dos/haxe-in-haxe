package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext21(a19:String, a20:Int):Bool {
		H.tick();
		if ((1750961279 < Reflect.compare(a20, a20))) {
			H.out("o87 " + Std.string(Math.floor(1e-7)));
			var v88:Int = 0xFFFFFFFF;
			var v89:Float = a20;
		} else {
			try {
				if (false) throw new Err(a20);
				final v90:Array<Int> = [a20, 11, 130];
				Main.fn10(172, a20, a20);
				var v91:Array<Float> = ([0.5] : Array<Float>);
			} catch (ex92:Dynamic) {
				H.out("caught " + H.exn(ex92));
				Main.fn10(a20, a20, 3.0);
			}
		}
		if ((0.5 > a20)) {
			var v93:A6 = new A6(a20);
		}
		if ((a20 > a20)) return ({ var v94 = true; ([a20, a20]).contains(155); });
		H.out("o95 " + Std.string(66));
		switch (a20) {
			case 0: {
				H.out("o96 " + Std.string(a20));
				var v97:Map<String, Int> = new Map<String, Int>();
			};
			case 2 | 5: {
				var v98 = a20;
			};
			case c99 if (c99 > 10): {
				var v100:Array<Int> = ([] : Array<Int>);
			};
			case _: {
				final v101:Map<Int, Int> = new Map<Int, Int>();
				{
					a20 = 162;
					var v102 = a20;
					H.out("o103 " + Std.string(E0.E0B));
				}
			};
		}
		H.out("o104 " + Std.string([a20, 0xB80D, a20]));
		return ((Math.PI <= a20) && (Math.ceil(a20) <= (new A6(a20) : Int)));
	}
}
