package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext25(a23:String, a24:Int):Int {
		H.tick();
		final v167:Map<Int, Int> = new Map<Int, Int>();
		var v168 = (a24 << (0x11D3 & 31));
		var v169 = a24;
		if (!false) {
			if ((E1.E1A).match(E1A)) {
				v168 |= 65;
				final v170:(Bool, Int) -> String = (p171:Bool, p172:Int) -> a23;
				H.out("o173 " + Std.string(true));
			} else {
				var v174:E0 = E0.E0A;
				Main.fn10((-1198350190), v168);
			}
		} else {
			v168 <<= ((K2.K2A : Int) & 7);
			try {
				v169 |= v169;
				if (false) throw "boom";
			} catch (ex175:String) {
				H.out("caught String " + ex175);
				var v176:Bool = true;
				var v177:Int = 255;
			} catch (ex178:Int) {
				H.out("caught Int " + ex178);
				H.out("o179 " + Std.string(v168));
				H.out("o180 " + Std.string(true));
			} catch (ex181:Err) {
				H.out("caught Err " + ex181.errCode);
				var v182:Float = v169;
				final v183 = a24;
			} catch (ex184:Dynamic) {
				H.out("caught " + H.exn(ex184));
				a24 &= a24;
				v168 = H.id(v168);
			}
		}
		return (-601337959);
	}
}
