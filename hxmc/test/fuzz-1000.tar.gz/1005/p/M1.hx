package p;

import Main;
import H;
import p.M1;
using p.Ext;

class M1 {}

enum E0 {
	E0A;
	E0B;
}

enum E1 {
	E1A;
}
