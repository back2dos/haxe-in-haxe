import H;
import p.M1;
using p.Ext;

enum abstract K2(Int) to Int {
	var K2A = 1;
	var K2B = 4;
}

class Main {
	public static function fn3():Void {
		H.tick();
		var v26:Bool = true;
		final v27:Map<String, Int> = new Map<String, Int>();
		try {
			if (v26) throw new Err(195);
			switch (Reflect.compare(179, 247)) {
				case 0: {
					H.out("o28 " + Std.string(3.0));
					H.out("o29 " + Std.string(E1.E1A));
				};
				case 2 | 4: {
					H.out("o30 " + Std.string((-7)));
				};
				case c31 if (c31 > 10): {
					H.out("o32 " + Std.string(c31));
					var v33:E0 = E0.E0B;
				};
				case _: {
					var v34:E0 = E0.E0A;
					var v35 = 105;
				};
			}
			for (i36 in 0...3) {
				H.tick();
				H.out("o37 " + Std.string(i36));
			}
		} catch (ex38:Dynamic) {
			H.out("caught " + H.exn(ex38));
			H.out("o39 " + Std.string(Math.ceil(0.5)));
		}
		final v40 = (3 & 139);
		for (i41 in 0...H.lim((((["k0" => 1, "k1" => 240] : Map<String, Int>)).get("k1") ?? 0))) {
			H.tick();
			{
				var v42:Int = v40;
			}
			var w43 = 0;
do {
				w43++;
				H.tick();
				final v44:() -> Int = () -> i41;
				H.out("o45 " + Std.string(1e-7));
			} while (w43 < 4 && v26);
		}
		for (i46 in 0...3) {
			H.tick();
			try {
				if (true) throw 14;
				var v47:Bool = v26;
			} catch (ex48:Err) {
				H.out("caught Err " + ex48.errCode);
				var v49:Bool = v26;
			} catch (ex50:haxe.Exception) {
				H.out("caught " + H.exn(ex50));
				H.out("o51 " + Std.string(E0.E0B));
				var v52:Int = v40;
			}
		}
	}
	public static function fn4(a5:Bool, a6:Int = -2):Bool {
		H.tick();
		for (i53 in 0...4) {
			H.tick();
			for (i54 in 0...H.lim(a6)) {
				H.tick();
				final v55:Map<Int, Float> = ([-3 => 1e-7, 4 => 123456.789] : Map<Int, Float>);
				final v56:Int = a6;
				final v57 = 201;
			}
		}
		var v58:E1 = E1.E1A;
		H.out("o59 " + Std.string(a5));
		Main.fn3();
		return Math.isNaN((Std.parseInt("") ?? 0));
	}
	public static function fn7(a8:Int):Float {
		H.tick();
		H.out("o60 " + Std.string((K2.K2A : Int)));
		a8 = Math.floor(3.0);
		var v61:Map<String, Float> = new Map<String, Float>();
		var v62:Map<String, () -> Bool> = new Map<String, () -> Bool>();
		var v63:E0 = E0.E0A;
		H.out("o64 " + Std.string((if (false) a8 else a8)));
		final v65:Float = ((switch (Math.floor(a8)) {
			case 0: a8;
			case 2 | 4: a8;
			case c66 if (c66 > 10): (-2.5);
			case _: a8;
		}) : Float);
		return ((((new Map<Int, Int>()).get(11) ?? 0) >> (91 & 31)) / v65);
	}
	public static function fn9():String {
		H.tick();
		if (fn4((E0.E0A).match(E0A), Type.enumIndex(E1.E1A))) {
			H.out("o67 " + Std.string(100.75));
		} else {
			switch (K2.K2B) {
				case K2.K2A: {
					var v68:Int = 40;
				};
				case K2.K2B: {
					Main.fn4(true);
					var v69:Int = 175;
				};
			}
			try {
				if (false) throw "a";
				H.out("o70 " + Std.string((-19)));
				final v71:E1 = E1.E1A;
				fn4(false, 125);
			} catch (ex72:String) {
				H.out("caught String " + ex72);
				var v73:K2 = K2.K2A;
				fn4(false, 0x4BA4);
			} catch (ex74:Int) {
				H.out("caught Int " + ex74);
				var v75:K2 = K2.K2B;
			} catch (ex76:Err) {
				H.out("caught Err " + ex76.errCode);
				var v77:E0 = E0.E0B;
				H.out("o78 " + Std.string((K2.K2A : Int)));
			} catch (ex79:Dynamic) {
				H.out("caught " + H.exn(ex79));
				var v80:K2 = K2.K2B;
				var v81 = 180;
			}
		}
		H.out("o82 " + Std.string(212));
		fn3();
		return ((false || false) + ("\t" + "a"));
	}
	public static function fn10(a11:Int, a12:Int = 6):Float {
		H.tick();
		fn3();
		H.out("o83 " + Std.string((a12 << (80 & 31))));
		if (Main.fn4(Math.isNaN(a11), 65535)) {
			var v84:Int = (Std.parseInt("zz") ?? 0);
		} else {
			H.out("o85 " + Std.string(null));
			var v86:Map<String, Int> = (["k0" => a11, "k1" => 20] : Map<String, Int>);
		}
		H.out("o87 " + Std.string((E0.E0B).match(E0B)));
		switch ((a11 | Std.int(a12))) {
			case 0: {
				var v88:Map<String, Int> = (["k0" => 271] : Map<String, Int>);
			};
			case 3 | 5: {
				for (i89 in 0...H.lim((Std.parseInt(Std.string(0x74F8)) ?? 0))) {
					H.tick();
					fn3();
					a11 = 185;
				}
				Main.fn9();
			};
			case c90 if (c90 > 10): {
				try {
					if ((([-3 => false, 4 => false, 11 => true] : Map<Int, Bool>)).exists(11)) throw new Err(a12);
					final v91:E0 = E0.E0A;
				} catch (ex92:Err) {
					H.out("caught Err " + ex92.errCode);
					var v93:Int = 0xEA27;
					var v94 = a12;
				} catch (ex95:haxe.Exception) {
					H.out("caught " + H.exn(ex95));
					a11 ^= 239;
					fn7(a12);
				}
			};
			case _: {
				var w96 = 0;
while (w96 < 2 && true) {
					w96++;
					H.tick();
					var v97:E0 = E0.E0B;
					fn3();
					H.out("o98 " + Std.string(a11));
				}
				Main.fn4((E1.E1A).match(E1A), (K2.K2A : Int));
			};
		}
		H.out("o99 " + Std.string((switch (true) {
			case true: 0xD6CF;
			case false: a11;
		})));
		Main.fn9();
		var v100:Int = (-2055816441);
		{ var dyn101:Dynamic = 173; H.out("dyn " + Std.string(dyn101 + 1)); }
		return ((switch ((false ? Reflect.compare(a11, a11) : a12)) {
			case 0: 0.1;
			case 3 | 5: (a11 * 132);
			case c102 if (c102 > 10): a11;
			case _: 100.75;
		}) : Float);
	}
	public static function fn13(...r14:Int):Int {
		H.tick();
		final v103:Int = (Lambda.count(r14.toArray(), v104 -> (E0.E0B).match(E0B)) ^ (((["k0" => 29, "k1" => 250] : Map<String, Int>)).get("ab") ?? 0));
		for (i105 in 0...H.lim((Std.string(false)).ext25(0xB2C0))) {
			H.tick();
			final v106:Int = Math.round(v103);
			H.out("o107 " + Std.string(129));
		}
		Main.fn7(Ext.ext25(Std.string(E1.E1A), Math.floor(v103)));
		H.out("o108 " + Std.string((v103 == v103)));
		for (i109 in 1...4) {
			H.tick();
			var v110:Float = v103;
		}
		return (({ var v111 = (K2.K2A : Int); false; }) ? 162 : ((E1.E1A).match(E1A) ? 0x80000000 : v103));
	}
	public static function fn15(a16:Float):Int {
		H.tick();
		var v112:Map<String, E1> = new Map<String, E1>();
		try {
			var v113 = ((new Map<Int, Int>()).get(0x80000000) ?? 0);
			var v114:Float = v113;
			if ((switch (E0.E0B) {
				case E0A: (new Map<String, Bool>()).exists("-7");
				case E0B: true;
			})) throw new Err((switch (K2.K2A) {
				case K2.K2A: Std.int(v114);
				case K2.K2B: 0xD8EE;
			}));
		} catch (ex115:Err) {
			H.out("caught Err " + ex115.errCode);
			var v116:Int = 83;
		} catch (ex117:haxe.Exception) {
			H.out("caught " + H.exn(ex117));
			var v118:Float = a16;
			final v119:Map<Int, Bool> = ([-3 => true] : Map<Int, Bool>);
		}
		H.out("o120 " + Std.string((true || false)));
		final v121:(Int, Float) -> Bool = ((false ? (p122:Int, p123:Float) -> true : (p124:Int, p125:Float) -> true) : (Int, Float) -> Bool);
		return (94 - (if (false) 86 else Lambda.fold([0x5382, 225, 216], (v126:Int, v127:Int) -> 256, 0)));
	}
	public static function fn17(a18:Bool):E1 {
		H.tick();
		var v128 = 118;
		(Std.string(v128)).ext25((65535 * 0xBABC));
		var v129 = (true && false);
		return E1.E1A;
	}
	public static function fn19():Bool {
		H.tick();
		var v130:Float = (Math.PI / 0.1);
		switch (E1.E1A) {
			case E1A: {
				var v131 = 172;
				var v132 = (Std.parseInt(Std.string(v131)) ?? 0);
			};
		}
		var v133:Bool = (190 != 171);
		var v134:Float = (v130 - 1602771872);
		var v135 = (((([-3 => 0x9D94] : Map<Int, Int>)).get(266) ?? 0) ^ 84);
		try {
			if (v133) throw new Err((true ? Reflect.compare(v135, 0x1C36) : v135));
			var v136:Int = ((new Map<Int, Int>()).get(-3) ?? 0);
		} catch (ex137:Err) {
			H.out("caught Err " + ex137.errCode);
			var v138:E0 = E0.E0A;
			final v139:Int = v135;
		} catch (ex140:haxe.Exception) {
			H.out("caught " + H.exn(ex140));
			var v141:Int = (K2.K2A : Int);
			v141 = (((["k0" => v135] : Map<String, Int>)).get("hello world") ?? 0);
		}
		H.out("o142 " + Std.string((v135 < v135)));
		if (false) {
			H.out("o143 " + Std.string(218));
			H.out("o144 " + Std.string(v133));
			H.out("o145 " + Std.string(v135));
		} else {
			var v146:K2 = K2.K2A;
			var w147 = 0;
while (w147 < 1 && (E0.E0B).match(E0B)) {
				w147++;
				H.tick();
				("\"q\"").ext25(v135);
				H.out("o148 " + Std.string(v135));
				H.out("o149 " + Std.string(v135));
			}
		}
		return (Math.isNaN(v135) ? Math.isNaN(1e-7) : (v133 && (new Map<String, Null<Int>>()).exists("\n")));
	}
	public static function fn20(a21:Int, ?a22:Null<Int>):Float {
		H.tick();
		for (i150 in 0...H.lim((a21 - (-18)))) {
			H.tick();
			final v151:Map<Int, Bool> = new Map<Int, Bool>();
		}
		for (i152 in 0...1) {
			H.tick();
			for (i153 in 0...H.lim(a21)) {
				H.tick();
				fn17(false);
			}
			if (((["k0" => a21, "k1" => a21, "k2" => i152] : Map<String, Float>)).exists("q")) break;
		}
		var v154 = ((Std.parseInt("") ?? 0) ^ a21);
		for (i155 in 2...3) {
			H.tick();
			H.out("o156 " + Std.string(1e-7));
			try {
				final v157:Float = v154;
				if ((E0.E0A).match(E0A)) throw "boom";
			} catch (ex158:Err) {
				H.out("caught Err " + ex158.errCode);
				H.out("o159 " + Std.string(v154));
			} catch (ex160:haxe.Exception) {
				H.out("caught " + H.exn(ex160));
				H.out("o161 " + Std.string(v154));
				H.out("o162 " + Std.string(E0.E0B));
			}
			switch (E1.E1A) {
				case E1A: {
					H.out("o163 " + Std.string(a21));
				};
				case _: {
					var v164:Float = v154;
				};
			}
		}
		var v165 = 116;
		var v166:Bool = false;
		return 0.1;
	}
	public static function section0():Void {
		H.tick();
		var v185:Int = 69;
		var v186:Map<String, Bool> = (["k0" => true] : Map<String, Bool>);
		for (i187 in 0...1) {
			H.tick();
			var v188 = i187;
			var v189:Map<Int, Bool> = new Map<Int, Bool>();
			var v190:E1 = E1.E1A;
		}
		var v191 = ((-1895708843) ^ 65535);
		H.out("o192 " + Std.string((((E1.E1A).match(E1A) ? E0.E0A : E0.E0A) : E0)));
		switch (E1.E1A) {
			case E1A: {
				var v193:Null<Int> = null;
			};
			case _: {
				final v194 = true;
				if (v194) {
					H.out("o195 " + Std.string(224));
				}
			};
		}
		H.out("o196 " + Std.string(E0.E0B));
		v185--;
	}
	public static function section1():Void {
		H.tick();
		var v197:Float = fn15(Math.sin(0.5));
		{ var dyn198:Dynamic = (false ? 262 : 127); H.out("dyn " + Std.string(dyn198 + 1)); }
		if ((false && false)) {
			H.out("o199 " + Std.string(0.1));
			final v200:Map<Int, Map<Int, Bool>> = new Map<Int, Map<Int, Bool>>();
			for (i201 in 0...H.lim(0xD599)) {
				H.tick();
				var v202 = true;
				if (true) continue;
				H.out("o203 " + Std.string(E0.E0B));
			}
		}
		if ((244 >= Lambda.count([258, 955402009, 192], v204 -> true))) {
			v197 = H.id(v197);
			H.out("o205 " + Std.string(275));
		} else {
			Main.fn20(191);
		}
		if ((Reflect.compare(0xB91B, 139) < 237)) {
			switch (Math.round(v197)) {
				case 0: {
					var v206 = 0x7FFFFFFF;
					H.out("o207 " + Std.string(v206));
				};
				case 1 | 6: {
					H.out("o208 " + Std.string((K2.K2B : Int)));
					final v209:() -> Int = function():Int {
						H.tick();
						fn3();
						var v210:Int = 11;
						return 45;
					};
				};
				case c211 if (c211 > 10): {
					H.out("o212 " + Std.string((-2)));
				};
				case _: {
					H.out("o213 " + Std.string(E0.E0B));
					H.out("o214 " + "");
				};
			}
			try {
				H.out("o215 " + "q");
				H.out("o216 " + Std.string(v197));
				H.out("o217 " + Std.string((K2.K2A : Int)));
				if (((["k0" => 279] : Map<String, Int>)).exists("k1")) throw 30;
			} catch (ex218:String) {
				H.out("caught String " + ex218);
				H.out("o219 " + ex218);
				H.out("o220 " + Std.string(0xA66D));
			} catch (ex221:Int) {
				H.out("caught Int " + ex221);
				final v222:Int = ex221;
				final v223:Null<Int> = v222;
			} catch (ex224:Err) {
				H.out("caught Err " + ex224.errCode);
				final v225:E1 = E1.E1A;
			} catch (ex226:Dynamic) {
				H.out("caught " + H.exn(ex226));
				H.out("o227 " + Std.string(E0.E0A));
				H.out("o228 " + Std.string(false));
			}
		} else {
			H.out("o229 " + Std.string(1510875639));
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
