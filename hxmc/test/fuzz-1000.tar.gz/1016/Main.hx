import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a3:String, a4:Bool);
	E0C(a5:Float);
	E0D(a6:Int);
}

enum abstract K14(Int) to Int {
	var K14A = 1;
	var K14B = 4;
}

class Main {
	public static function fn15(a16:String, a17:Int = -1):Void {
		H.tick();
		H.out("o35 " + ("ab" + Std.string(E7.E7B(true, false))));
		if ((false && false)) {
			a17 = H.id(a17);
		} else {
			final v36:E13 = E13.E13A;
			H.out("o37 " + Std.string(234));
		}
		a17 = (new Box(2147470372)).value;
		var v38:Map<String, String> = new Map<String, String>();
		if (StringTools.endsWith("\n", "x,y,z")) {
			H.out("o39 " + "-7");
			var v40 = true;
			final v41:K14 = K14.K14A;
		}
		var v42 = 229689106;
	}
	public static function fn18():Bool {
		H.tick();
		if ((true && StringTools.contains("abc", "a"))) {
			final lf43:(Float, Float) -> Void = function(p44:Float, p45:Float):Void {
				H.tick();
				var v46:Box<Int> = new Box((-2147483647));
				var v47:Map<Int, Int> = ([-3 => (-1559860062), 4 => 79, 11 => 202] : Map<Int, Int>);
				var v48 = false;
			};
			switch (K14.K14B) {
				case K14.K14A: {
					H.out("o49 " + Std.string(217));
				};
				case K14.K14B: {
					final v50:String = "\u{1F600}";
				};
			}
			var v51:Int = (("\t").charCodeAt(177) ?? -1);
		} else {
			final v52 = ("42").indexOf("x,y,z");
		}
		H.out("o53 " + Std.string((291 << (205 & 31))));
		Main.fn15(Std.string(false));
		if ((StringTools.startsWith("a\rb", "q") || true)) {
			H.out("o54 " + Std.string((K14.K14B : Int)));
			var v55:Map<String, Bool> = (["k0" => true, "k1" => true] : Map<String, Bool>);
		} else {
			var v56:Bool = false;
			H.out("o57 " + Std.string(E7.E7C("\x41\x42")));
		}
		switch (E7.E7B(false, (new Map<Int, K14>()).exists(11))) {
			case E7A: {
				H.out("o58 " + Std.string((Std.parseInt(Std.string(65535)) ?? 0)));
			};
			case E7B(c59, c60): {
				var v61 = StringTools.endsWith("zz", "日本語");
				try {
					if (false) throw 59;
					fn15("abc");
				} catch (ex62:Dynamic) {
					H.out("caught " + H.exn(ex62));
					H.out("o63 " + Std.string(123456.789));
					H.out("o64 " + "Haxe");
				}
			};
			case E7D(c65, c66): {
				{ var dyn67:Dynamic = (-275988395); H.out("dyn " + Std.string(dyn67 + 1)); }
			};
			case _: {
				var v68:Bool = Math.isNaN(1e3);
			};
		}
		switch (42) {
			case 0: {
				var v69:E7 = E7.E7B(false, false);
				var v70 = Math.round(2.5e-3);
			};
			case 1 | 4: {
				switch (("日本語").lastIndexOf("")) {
					case 0: {
						var v71:E0 = E0.E0D(274);
						var v72 = 209;
					};
					case 2 | 4: {
						var v73 = true;
					};
					case _: {
						final v74:Int = 121;
						var v75 = 139;
					};
				}
			};
			case _: {
				switch ((-2147483647)) {
					case 0: {
						var v76 = 239;
						H.out("o77 " + Std.string(250));
					};
					case 2 | 4: {
						H.out("o78 " + Std.string(276));
						H.out("o79 " + "a");
					};
					case c80 if (c80 > 10): {
						var v81:String = "\n";
					};
					case _: {
						fn15("abc");
						var v82:Int = 88;
					};
				}
			};
		}
		H.out("o83 " + Std.string(((Std.parseInt("Haxe") ?? 0) ^ (Std.parseInt(Std.string(46)) ?? 0))));
		H.out("o84 " + Std.string((Math.sin(1e3) / 23)));
		H.out("o85 " + Std.string(0x59C3));
		return H.apply(((-2.5) * Std.parseFloat("3")), (v86:Float) -> (true ? Math.isNaN(v86) : StringTools.endsWith("", "ab")));
	}
	public static function fn19(a20:String = "d"):Int {
		H.tick();
		try {
			if (false) {
				var v87:E13 = E13.E13A;
				var v88 = 258;
			}
			final v89:Map<Int, String> = new Map<Int, String>();
			final v90:Int = (Std.parseInt(Std.string(0xFFFFFFFF)) ?? 0);
			if ((v90 < (K14.K14A : Int))) throw Std.string(true);
		} catch (ex91:Err) {
			H.out("caught Err " + ex91.errCode);
			var v92:K14 = K14.K14A;
			H.out("o93 " + Std.string((a20).lastIndexOf("42")));
		} catch (ex94:haxe.Exception) {
			H.out("caught " + H.exn(ex94));
			{
				H.out("o95 " + Std.string(E13.E13A));
			}
		}
		var w96 = 0;
do {
			w96++;
			H.tick();
			var v97:Map<String, E13> = new Map<String, E13>();
			final v98:Int = (("\n").charCodeAt(244) ?? -1);
			var v99 = a20;
		} while (w96 < 3 && fn18());
		for (k100 => v101 in (["k0" => 38, "k1" => Reflect.compare("  pad  ", a20), "k2" => Type.enumIndex(E7.E7C(a20))] : Map<String, Int>)) {
			H.tick();
			var v102 = Type.enumIndex(E0.E0C(v101));
		}
		final v103:String = (a20 + Math.floor(1e-7));
		fn15(((a20).charAt(((-1916000699) & 7))).substr((((new Map<Int, Int>()).get(228) ?? 0) & 7), (Type.enumIndex(E7.E7C("")) & 7)), Ext.ext34(([] : Array<Int>), (Std.parseInt(a20) ?? 0)));
		var v104:Int = (Math.ceil(1e3) - 0xD155);
		var v105:E7 = E7.E7A;
		H.out("o106 " + Std.string((((switch (E13.E13A) {
			case E13A: K14.K14B;
		}) : K14) : Int)));
		v104 |= v104;
		return (-2147483647);
	}
	public static function fn21(a22:Int, a23:Int):Int {
		H.tick();
		if (!StringTools.contains("\t", "")) {
			(([] : Array<Int>)).ext34(95);
			var v107:Int = (Std.parseInt("x,y,z") ?? 0);
		}
		if (({ var v108 = Math.floor(a23); true; })) {
			if ((E7.E7C("zz")).match(E7C(_))) return ("\n").length;
			function lf109(n110:Int):Int {
				H.tick();
				return n110 <= 0 ? ("ünï").indexOf("zz") : (lf109(n110 - 1) + a23);
			}
			H.out("lf109 " + lf109(2));
			(Type.enumIndex(E7.E7A)).ext31(a23);
		}
		for (i111 in 0...4) {
			H.tick();
			Ext.ext34(([] : Array<Int>), a22);
			var v112:E0 = E0A;
			for (i113 in 2...3) {
				H.tick();
				H.out("o114 " + Std.string(a23));
			}
		}
		for (k115 => v116 in ((switch (K14.K14B) {
			case K14.K14A: new Map<String, Int>();
			case K14.K14B: (["k0" => a22, "k1" => a22] : Map<String, Int>);
		}) : Map<String, Int>)) {
			H.tick();
			H.out("o117 " + Std.string(7.0));
			var w118 = 0;
while (w118 < 1 && false) {
				w118++;
				H.tick();
				var v119:Float = a23;
				var v120:Int = (-1771825707);
				final v121:Box<String> = new Box("\x41\x42");
			}
		}
		for (i122 in 1...5) {
			H.tick();
			var v123:Map<String, Int> = new Map<String, Int>();
		}
		var w124 = 0;
while (w124 < 4 && ("42" >= ("hello world").substring(2, 0))) {
			w124++;
			H.tick();
			H.out("o125 " + Std.string((K14.K14B : Int)));
			var v126:E13 = E13.E13A;
		}
		H.out("o127 " + Std.string((false ? 136 : a22)));
		return (Std.parseInt(Std.string((StringTools.startsWith("é", "\n") ? (a22 = 5) : 257))) ?? 0);
	}
	public static function fn24(a25:Int):Int {
		H.tick();
		var v128 = "zz";
		var w129 = 0;
do {
			w129++;
			H.tick();
			var v130:E7 = E7.E7A;
			H.out("o131 " + (v128).substr(3, 1));
		} while (w129 < 2 && (100.75 == a25));
		if ((a25 >= Std.parseFloat(v128))) return Main.fn21(a25, a25);
		var v132:Map<Int, Int> = ((switch (a25) {
			case 0: new Map<Int, Int>();
			case 2 | 6: new Map<Int, Int>();
			case _: ([-3 => a25] : Map<Int, Int>);
		}) : Map<Int, Int>);
		H.out("o133 " + Std.string(a25));
		return a25;
	}
	public static function section0():Void {
		H.tick();
		try {
			if (false) throw new Err((false ? Math.round(3.0) : 0x2104));
			var v159:E0 = E0D(0xCF94);
			if (false) {
				final v160 = true;
				H.out("o161 " + Std.string(E7.E7B(v160, v160)));
				var v162 = "a\rb";
			}
			H.out("o163 " + Std.string((("\n").charCodeAt(719610685) ?? -1)));
		} catch (ex164:String) {
			H.out("caught String " + ex164);
			Main.fn21((ex164).lastIndexOf("\x41\x42"), (ex164).indexOf(ex164));
		} catch (ex165:Int) {
			H.out("caught Int " + ex165);
			final lf166:(Bool) -> Int = (p167:Bool) -> (((["k0" => ex165, "k1" => 170, "k2" => 1078730251] : Map<String, Int>)).get("Haxe") ?? 0);
			if (false) {
				var v168 = 142;
			} else {
				var v169:String = "Haxe";
				var v170:Box<Int> = new Box(77);
			}
		} catch (ex171:Err) {
			H.out("caught Err " + ex171.errCode);
			var v172 = 130;
			switch ("\x41\x42") {
				case "a" | "b": {
					H.out("o173 " + "日本語");
					var v174 = false;
				};
				case "Haxe": {
					Main.fn19();
					var v175:E13 = E13.E13A;
				};
				case "": {
					var v176:E0 = E0A;
					v172 = H.id(v172);
				};
				case _: {
					H.out("o177 " + "\\");
				};
			}
		} catch (ex178:Dynamic) {
			H.out("caught " + H.exn(ex178));
			fn21(((new Map<Int, Int>()).get(18) ?? 0), ("\n").indexOf("hello world"));
		}
		fn24((Std.string(1.7976931348623157e308)).length);
		if ((switch (E7.E7B(true, false)) {
			case E7A: Math.isNaN(0.1);
			case E7B(c179, c180): true;
			case E7C(_): (([-3 => 1e-7] : Map<Int, Float>)).exists(-3);
			case E7D(_, c181): false;
			case _: false;
		})) {
			H.out("o182 " + Std.string(Math.isNaN(2.5e-3)));
		}
		H.out("o183 " + Std.string((switch (E0A) {
			case E0A: 45;
			case E0B(c184, _): (("abc").charCodeAt(44) ?? -1);
			case E0C(c185): 65535;
			case E0D(0 | 3): (Std.parseInt(Std.string(169)) ?? 0);
			case _: 252;
		})));
	}
	public static function section1():Void {
		H.tick();
		function lf186(n187:Int):Int {
			H.tick();
			return n187 <= 0 ? 1723045782 : (lf186(n187 - 1) + ({ var v188 = n187; (Std.parseInt("\\") ?? 0); }));
		}
		H.out("lf186 " + lf186(0));
		final v189:String = ({ var sb190 = new StringBuf(); sb190.add(Std.string((K14.K14B : Int))); sb190.toString(); });
		var v191 = (Std.string(0.5) == String.fromCharCode(65 + (((-2147483647)) & 15)));
		fn19();
		if ((([-3 => 0xF9B9] : Map<Int, Int>)).exists(288)) {
			if (((["k0" => v189, "k1" => v189] : Map<String, String>)).exists("k3")) {
				var v192:Float = 1e100;
				H.out("o193 " + Std.string((-255541795)));
			} else {
				var v194:Float = 7.0;
				var v195 = 0xFFFFFFFF;
			}
			try {
				if (Math.isNaN(123456.789)) throw "boom";
				fn24((-1706829604));
			} catch (ex196:String) {
				H.out("caught String " + ex196);
				H.out("o197 " + Std.string((-17)));
			} catch (ex198:Int) {
				H.out("caught Int " + ex198);
				var v199:String = "-7";
				H.out("o200 " + Std.string(ex198));
			} catch (ex201:Err) {
				H.out("caught Err " + ex201.errCode);
				Main.fn19("zz");
			} catch (ex202:Dynamic) {
				H.out("caught " + H.exn(ex202));
				var v203 = 119;
			}
		} else {
			H.out("o204 " + Std.string(0.1));
			([210, 180]).ext28(E0.E0A);
		}
	}
	public static function section2():Void {
		H.tick();
		fn18();
		var v205 = ("\\" != ("\u{1F600}").replace("a", "b"));
		final v206:K14 = K14.K14B;
		if (((((["k0" => 161, "k1" => 10] : Map<String, Int>)).get("k0") ?? 0) >= (Std.parseInt(Std.string(277)) ?? 0))) {
			for (i207 in 2...H.lim(Type.enumIndex(E13.E13A))) {
				H.tick();
				H.out("o208 " + Std.string((v206 : Int)));
			}
			try {
				if (v205) throw 3;
				H.out("o209 " + Std.string(E7.E7B(v205, v205)));
				Ext.ext34([259], (-3));
			} catch (ex210:String) {
				H.out("caught String " + ex210);
				var v211:Bool = false;
				H.out("o212 " + Std.string(1e-7));
			} catch (ex213:Int) {
				H.out("caught Int " + ex213);
				H.out("o214 " + "  pad  ");
				final v215:Int = 3;
			} catch (ex216:Err) {
				H.out("caught Err " + ex216.errCode);
				var v217 = v205;
				var v218:Map<String, String> = (["k0" => "q"] : Map<String, String>);
			} catch (ex219:Dynamic) {
				H.out("caught " + H.exn(ex219));
				fn15("\n", 150);
			}
			H.out("o220 " + "-7");
		}
	}
	public static function section3():Void {
		H.tick();
		var v221:Map<String, Int> = ({ var v222 = "a"; (["k0" => 110] : Map<String, Int>); });
		if ((true && true)) {
			for (i223 in 0...2) {
				H.tick();
				(i223).ext31(i223);
				var v224:E7 = E7.E7C("A-B-C");
				H.out("o225 " + Std.string(E7.E7A));
			}
			try {
				var v226:Map<Int, Int> = new Map<Int, Int>();
				if (StringTools.endsWith("\x41\x42", "-7")) throw 7;
			} catch (ex227:Err) {
				H.out("caught Err " + ex227.errCode);
				H.out("o228 " + Std.string(1.7976931348623157e308));
				var v229 = 195;
			} catch (ex230:haxe.Exception) {
				H.out("caught " + H.exn(ex230));
				var v231:Int = 208;
			}
		}
		var v232:Int = ({ var v233 = 0xAAAF; Reflect.compare("\u{1F600}", "\\"); });
		final lf234:(Bool, String) -> Void = function(p235:Bool, p236:String):Void {
			H.tick();
			var v237:E7 = E7.E7A;
			var w238 = 0;
while (w238 < 5 && (E13.E13A).match(E13A)) {
				w238++;
				H.tick();
				var v239:Map<Int, Int> = ([-3 => v232, 4 => v232, 11 => v232] : Map<Int, Int>);
				H.out("o240 " + p236);
			}
		};
		final v241:Bool = (Math.round(v232) == 0x389A);
		fn24((v232 >>> (v232 & 31)));
	}
	public static function section4():Void {
		H.tick();
		H.out("o242 " + Std.string(fn19(Std.string(E13.E13A))));
		var v243:Map<String, Int> = new Map<String, Int>();
		if (Main.fn18()) {
			switch (E0B("abc", true)) {
				case E0A: {
					var v244:Bool = false;
					var v245:K14 = K14.K14A;
				};
				case E0B(c246, _): {
					var v247:Bool = true;
					var v248:Bool = v247;
				};
				case E0D(c249): {
					var v250:Bool = true;
				};
				case _: {
					var v251:Int = 80;
				};
			}
			fn18();
			final v252:E7 = E7.E7A;
		} else {
			var v253:Float = 5e-324;
		}
		switch ((("42").charCodeAt(52) ?? -1)) {
			case 0: {
				switch (("hello world").indexOf("ünï")) {
					case 0: {
						H.out("o254 " + Std.string((K14.K14B : Int)));
					};
					case 1 | 5: {
						(([] : Array<Int>)).ext28(E0A);
					};
					case _: {
						fn24(268);
					};
				}
			};
			case 2 | 5: {
				if (true) {
					var v255:Float = 1.7976931348623157e308;
					v243.remove("k3");
					var v256:Int = (-11);
				}
			};
			case c257 if (c257 > 10): {
				final v258:E7 = E7.E7B(false, false);
			};
			case _: {
				var v259 = (-2147483647);
				v259 = Reflect.compare("0", "\x41\x42");
			};
		}
		if ((E7.E7C("  pad  ")).match(E7D(_, _))) {
			final v260:String = "";
		} else {
			Ext.ext34([0x7FFFFFFF, 297, 227], (-1));
		}
		H.out("o261 " + H.id("  pad  "));
		var v262:Box<Int> = new Box<Int>((Std.parseInt(Std.string(237)) ?? 0));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
