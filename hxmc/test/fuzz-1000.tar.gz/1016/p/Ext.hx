package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext28(a26:Array<Int>, a27:E0):String {
		H.tick();
		try {
			if ((Math.floor(0.30000000000000004) <= 149)) throw "boom";
			H.out("o134 " + ("42").substr(6, (266 & 7)));
			if ((E13.E13A).match(E13A)) {
				final v135:Float = 1.25;
				var v136:Map<Int, Int> = new Map<Int, Int>();
			} else {
				var v137:K14 = K14.K14B;
			}
		} catch (ex138:Dynamic) {
			H.out("caught " + H.exn(ex138));
			H.out("o139 " + Std.string((-1596488626)));
		}
		var v140 = ({ var v141 = 0xDAF0; StringTools.endsWith("ab", "42"); });
		var v142:String = (new Box<String>("zz")).value;
		var v143:Float = Math.abs(1e3);
		var v144:String = v142;
		if (Main.fn18()) {
			Main.fn18();
			switch (E13.E13A) {
				case E13A: {
					var v145:Int = 1;
					var v146:Map<String, Float> = new Map<String, Float>();
				};
			}
			Main.fn18();
		}
		return v142;
	}
	public static function ext31(a29:Int, a30:Float):Bool {
		H.tick();
		Main.fn15("q", (true ? (a29--) : (a29 += 3)));
		var v147:K14 = K14.K14B;
		final lf148:() -> String = function():String {
			H.tick();
			var v149:Map<String, Float> = new Map<String, Float>();
			var v150 = "42";
			return ((E0.E0C(a29)).match(E0A) + "a");
		};
		a29 = H.id(a29);
		a29 = Std.int(a29);
		return Main.fn18();
	}
	public static function ext34(a32:Array<Int>, a33:Int):Int {
		H.tick();
		H.out("o151 " + Std.string(new Box((E7.E7C("hello world")).match(E7A))));
		a33 |= (a33 & 266);
		final v152:K14 = K14.K14A;
		if (Main.fn18()) {
			Ext.ext31(a33, a33);
			switch ("q") {
				case "a" | "b": {
					Ext.ext31(25, a33);
				};
				case "Haxe": {
					var v153:Int = 0x80000000;
				};
				case "": {
					a33 -= 194;
					var v154:Float = a33;
				};
				case _: {
					var v155:Int = a33;
					Main.fn18();
				};
			}
		}
		var v156:Float = a33;
		H.out("o157 " + Std.string(((switch (E0.E0B("ünï", false)) {
			case E0A: 0.1;
			case E0C(c158): a33;
			case E0D(1 | 4): a33;
			case _: 2.5e-3;
		}) : Float)));
		return a33;
	}
}
