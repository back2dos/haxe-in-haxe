package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

enum E7 {
	E7A;
	E7B(a8:Bool, a9:Bool);
	E7C(a10:String);
	E7D(a11:E7, a12:Float);
}

enum E13 {
	E13A;
}
