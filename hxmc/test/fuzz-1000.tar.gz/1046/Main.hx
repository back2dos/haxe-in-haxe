import H;
import p.M1;
using p.Ext;

class Main {
	public static inline function fn13(a14:Int):E1 {
		H.tick();
		a14 = 280;
		{
			var v46:Array<Int> = [a14, a14, a14];
			var v47:S5 = ({x8: a14, x6: a14, x7: true} : S5);
			var v48:S9 = ({x10: 0.1} : S9);
		}
		var v49:Array<E1> = ([E1.E1B(a14), E1.E1A, E1.E1A] : Array<E1>);
		var v50:Array<Array<Bool>> = ([[true, false], [false, true]] : Array<Array<Bool>>);
		function lf51(n52:Int):Int {
			H.tick();
			return n52 <= 0 ? a14 : (lf51(n52 - 1) + a14);
		}
		H.out("lf51 " + lf51(5));
		final v53:Bool = (((a14 : A11) : Int) != Math.floor(a14));
		return ((([a14, a14]).contains(Reflect.compare(a14, a14)) ? E1.E1B(0x7FFFFFFF) : E1.E1A) : E1);
	}
	public static function fn15(a16:Int, a17:E0):Int {
		H.tick();
		fn13(190);
		var v54:S5 = ({x8: (Std.parseInt(Std.string(a16)) ?? 0), x7: false, x6: a16} : S5);
		final v55:E1 = E1.E1B(a16);
		H.out("o56 " + Std.string(Std.parseFloat(Std.string(a16))));
		final v57:Bool = (a16 == a16);
		final v58 = a16;
		var v59:E1 = v55;
		final v60:Null<Int> = 0x1B6;
		return a16;
	}
	public static function fn18(...r19:Int):Void {
		H.tick();
		final v61 = ([237, 0x8CA0, 211]).length;
		{
			H.out("o62 " + Std.string((K12.K12A : Int)));
		}
		var v63 = true;
		r19.toArray().sort((x, y) -> x - y);
		fn13((~Type.enumIndex(E1.E1B(v61))));
		if (true) {
			function lf64(n65:Int):Int {
				H.tick();
				return n65 <= 0 ? v61 : (lf64(n65 - 1) + (Std.parseInt("42") ?? 0));
			}
			H.out("lf64 " + lf64(5));
			var v66 = v61;
			final v67:Int = v66;
		}
		var v68:E1 = Main.fn13(v61);
		Main.fn13(117);
		final v69 = v61;
	}
	public static function fn20():Array<Float> {
		H.tick();
		final v70:Array<K12> = ([] : Array<K12>);
		if (((K12.K12C : Int) == 17)) {
			H.out("o71 " + Std.string(0x80000000));
			final v72 = (({x6: 129, x7: false, x8: 51} : S5)).x8;
		} else {
			var v73:E1 = E1.E1A;
		}
		if ((false || false)) {
			H.out("o74 " + Std.string(Math.ceil(0.5)));
		} else {
			var v75:E1 = E1.E1B(65535);
		}
		var v76:Array<Int> = ([126, (-19), 156]).slice(((-443471752) & 7), (Reflect.compare(137, (-9)) & 7));
		v76.push((~(({x7: false, x8: (-16), x6: 64} : S5)).x6));
		v76.sort((x, y) -> x - y);
		function lf77(n78:Int):Int {
			H.tick();
			return n78 <= 0 ? Type.enumIndex(E0.E0D) : (lf77(n78 - 1) + n78);
		}
		H.out("lf77 " + lf77(5));
		if (true) {
			if (true) {
				var v79:Null<Int> = 273;
			} else {
				var v80:Int = 231;
				fn13(v80);
			}
			H.out("o81 " + Std.string(true));
		}
		H.out("o82 " + Std.string(([for (i83 in 0...1) ({x6: 264, x7: true, x8: i83} : S5)] : Array<S5>)));
		return (((true ? Math.isNaN((-2.5)) : true) ? ([for (i84 in 0...3) i84] : Array<Float>) : ([2.5e-3] : Array<Float>)) : Array<Float>);
	}
	public static function fn21():Void {
		H.tick();
		var v85:Array<Int> = ([0xFFFFFFFF, 173, 63]).copy();
		final v86:E0 = E0.E0B;
		H.out("o87 " + Std.string(({x10: 88} : S9)));
		var v88:S5 = ({x8: 210, x7: (E1.E1A).match(E1B(_)), x6: Std.int((-2.5))} : S5);
		var v89:Array<E1> = ([] : Array<E1>);
		final v90:E0 = v86;
		final v91 = ("42").ext45(([true]).length);
	}
	public static function fn22(a23:E1, a24:Int, a25:Int):Int {
		H.tick();
		if ((255 != 188)) {
			final v92 = 18;
			final v93:Bool = true;
		}
		var v94:Int = (~(([a24, a25] : Array<Float>)).length);
		var v95:Bool = true;
		Main.fn21();
		H.out("o96 " + Std.string((new A11(([true, v95, v95]).length) : Int)));
		var v97:Int = (Std.parseInt("\\") ?? 0);
		v97 = (136 | Std.int(v94));
		var v98:Int = (-1980297118);
		final v99 = a24;
		return (Std.parseInt(Std.string(Main.fn15(a24, E0.E0B))) ?? 0);
	}
	public static function fn26(?a27:Null<Int>):Int {
		H.tick();
		final v100 = (({x6: 134, x7: true, x8: 335081034} : S5)).x8;
		var v101:Array<Int> = ((Math.isNaN(v100) ? [v100, 35, v100] : [v100, v100]) : Array<Int>);
		{ var dyn102:Dynamic = ({x8: v100, x7: ([v100, v100, 153]).contains(65535), x6: (K12.K12B : Int)} : S5); H.out("dyn " + Std.string(dyn102.x6) + " " + Std.string(Reflect.field(dyn102, "x6"))); }
		H.out("o103 " + Std.string(([] : Array<Int>)));
		return v100;
	}
	public static function fn28(a29:Bool, a30:Int):Array<E1> {
		H.tick();
		var v104:Bool = !false;
		var v105 = a30;
		final lf106:(Int, Float) -> Void = function(p107:Int, p108:Float):Void {
			H.tick();
			var v109:E1 = E1.E1B(a30);
			H.out("o110 " + Std.string(a30));
			{ var dyn111:Dynamic = ({x6: a30, x7: false, x8: (-595688956)} : S5); H.out("dyn " + Std.string(dyn111.x6) + " " + Std.string(Reflect.field(dyn111, "x6"))); }
		};
		H.out("o112 " + Std.string(Ext.ext45("日本語", 127)));
		return ([E1.E1B(195)] : Array<E1>);
	}
	public static function fn31(a32:A11):Int {
		H.tick();
		H.out("o113 " + Std.string((Std.parseInt(Std.string(244)) ?? 0)));
		var v114:A11 = a32;
		if ((64 > ([96, 0x80000000]).length)) {
			var v115:Array<Float> = ([1e-7] : Array<Float>);
			{
				Main.fn18(155);
			}
			var v116:E1 = E1.E1A;
		}
		return (K12.K12C : Int);
	}
	public static function fn33(a34:Null<Int>):Int {
		H.tick();
		H.out("o117 " + Std.string((if (false) (K12.K12C : Int) else Type.enumIndex(E1.E1B(0xB4C9)))));
		var v118:Float = Std.parseFloat("-0.25");
		final v119:Float = Math.min(2.5e-3, v118);
		return ((135 >> ((-3) & 31)) + Main.fn22(E1.E1B(205), 106, (new A11(208) : Int)));
	}
	public static function fn35(a36:Int, a37:E1, a38:Float):Float {
		H.tick();
		var v120 = Ext.ext40((-1432479977));
		final lf121:(Int) -> Int = function(p122:Int):Int {
			H.tick();
			a36 = H.id(a36);
			return a36;
		};
		var v123:Null<Int> = null;
		a36 <<= ((a36 | (-2147483647)) & 7);
		return Math.min(a38, (0.1 / a36));
	}
	public static function section0():Void {
		H.tick();
		var v147 = (Reflect.compare(13, 50) ^ 0x81DA);
		var v148 = H.at([v147, v147, 0x9E1], 2034987530, 0);
		{
			H.out("o149 " + Std.string(Math.pow(v148, 2)));
		}
		v147 = (Std.parseInt(([false]).join(" ")) ?? 0);
		var v150 = Main.fn31(new A11(v147));
	}
	public static function section1():Void {
		H.tick();
		function lf151(n152:Int):Int {
			H.tick();
			return n152 <= 0 ? Reflect.compare((K12.K12B : Int), (new A11(n152)).twice) : (lf151(n152 - 1) + n152);
		}
		H.out("lf151 " + lf151(2));
		var v153 = ((Std.parseInt(Std.string(291)) ?? 0) | 178);
		var v154:Array<S5> = ([({x6: (-2147483647), x7: true, x8: v153} : S5), ({x6: 12, x7: false, x8: v153} : S5), ({x6: 111, x7: true, x8: v153} : S5)] : Array<S5>);
		var v155:Array<Int> = [(Std.parseInt(Std.string(0x7FFFFFFF)) ?? 0), 173, (([] : Array<Int>)).indexOf(v153)];
	}
	public static function section2():Void {
		H.tick();
		if (({ var v156 = (-9); true; })) {
			if (false) {
				final v157:Null<Int> = null;
			} else {
				("42").ext45(95);
				H.out("o158 " + Std.string(true));
			}
		} else {
			fn33(null);
		}
		H.out("o159 " + Std.string(Main.fn13(0x165C)));
		if (((([] : Array<Int>)).contains(0x7595) && ([254, 180]).contains(177))) {
			H.out("o160 " + Std.string((E0.E0B).match(E0D)));
		}
		Main.fn35((if (([20, 298, 0xE49A]).contains(0x4F8E)) (K12.K12B : Int) else (({x8: 89, x6: 0x80000000, x7: false} : S5)).x6), E1.E1A, Math.max(123456.789, 1e3));
		final v161 = (([231, 20, 1258612889]).indexOf(180) * 190);
		H.out("o162 " + Std.string(123456.789));
		if (true) {
			("42").ext42();
			{
				Main.fn26(v161);
				var v163 = v161;
			}
			var v164 = (Std.parseInt(Std.string(v161)) ?? 0);
		}
		(Std.string(E1.E1A)).ext42();
	}
	public static function section3():Void {
		H.tick();
		H.out("o165 " + Std.string((-251)));
		var v166:E1 = fn13(214);
		var v167:Float = 2.5e-3;
		var v168 = Math.floor(Std.parseFloat("-0.25"));
		{
			{
				H.out("o169 " + Std.string(0xC0F2));
			}
		}
		var v170:S9 = ({x10: v168} : S9);
		if ((([124, v168]).contains(85) || true)) {
			fn31(new A11(0xFFFFFFFF));
			var v171:Array<S5> = ([] : Array<S5>);
			final v172:Float = v168;
		}
	}
	public static function section4():Void {
		H.tick();
		var v173 = (Std.int(100.75)).ext40();
		H.out("o174 " + Std.string(E0.E0A));
		final v175:S5 = ({x6: 1602795782, x7: v173, x8: Std.int(123456.789)} : S5);
		H.out("o176 " + Std.string((0x42D7 >>> (2048671924 & 31))));
		var v177:K12 = K12.K12A;
		H.out("o178 " + Std.string(Math.round(0.5)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
