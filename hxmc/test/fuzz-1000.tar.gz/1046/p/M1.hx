package p;

import Main;
import H;
import p.M1;
using p.Ext;

class M1 {}

enum E0 {
	E0A;
	E0B;
	E0C;
	E0D;
}

enum E1 {
	E1A;
	E1B(a4:Int);
}

typedef S5 = {x6:Int, x7:Bool, x8:Int};

typedef S9 = {x10:Float};

abstract A11(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A11, b:A11):A11
		return new A11(a.get() + b.get());

	@:op(A * B) public static function mul(a:A11, b:A11):A11
		return new A11(a.get() * b.get());

	@:op(-A) public static function neg(a:A11):A11
		return new A11(-a.get());
}

enum abstract K12(Int) to Int {
	var K12A = 1;
	var K12B = 4;
	var K12C = 7;
}
