package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext40(a39:Int):Bool {
		H.tick();
		if (true) {
			final lf124:(Int) -> Void = function(p125:Int):Void {
				H.tick();
				var v126:Int = 94;
				final v127:Array<Bool> = ([] : Array<Bool>);
			};
			var v128:S9 = ({x10: a39} : S9);
		}
		var v129:Bool = (Type.enumIndex(E1.E1B(70)) == (new A11(a39) : Int));
		var v130:Int = ({ var v131 = "\"q\""; (([] : Array<Int>)).length; });
		v129 = ((new A11(a39)).twice < (Std.parseInt("\\") ?? 0));
		Main.fn18();
		var v132 = ((E1.E1A).match(E1A) && true);
		if (v129) return (2.5e-3 >= 0x5215);
		if ((false ? (E1.E1B(a39)).match(E1A) : true)) {
			H.out("o133 " + Std.string(195));
			var v134:Float = (-2.5);
			var v135:Int = Math.floor(123456.789);
		} else {
			a39 = 257;
		}
		var v136:E0 = ((v129 ? E0.E0B : E0.E0A) : E0);
		return v132;
	}
	public static function ext42(a41:String):Array<Float> {
		H.tick();
		var v137:Int = (Type.enumIndex(E1.E1B(157)) << ((Std.parseInt(Std.string((-2147483647))) ?? 0) & 31));
		if (Ext.ext40(133)) return ([Std.parseFloat(a41), Std.parseFloat("3"), v137] : Array<Float>);
		H.out("o138 " + Std.string((([] : Array<Null<Int>>)).concat(([null, v137] : Array<Null<Int>>))));
		var v139:Array<Int> = (([] : Array<Int>)).slice(4, -1);
		return ([3.0, (1e3 * 100.75), ((true ? v137 : 1e-7) : Float)] : Array<Float>);
	}
	public static function ext45(a43:String, a44:Int):Int {
		H.tick();
		var v140 = Main.fn15(a44, E0.E0A);
		Ext.ext42(([a44, 182, v140]).join("|"));
		var v141:Int = ({ var v142 = (E0.E0B).match(E0B); (K12.K12C : Int); });
		Ext.ext42(a43);
		v141 = a44;
		var v143:A11 = (a44 : A11);
		v141 *= a44;
		var v144:Int = (new A11(v141) : Int);
		{
			final v145:K12 = K12.K12B;
			H.out("o146 " + Std.string((v143 : Int)));
		}
		return ((if (true) (([] : Array<Int>)).indexOf((-1)) else v141) << ((Reflect.compare(36, 1263006662) % H.nz(18)) & 31));
	}
}
