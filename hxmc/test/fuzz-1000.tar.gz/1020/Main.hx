import H;
import p.M1;
using p.Ext;
using StringTools;

enum E3 {
	E3A;
	E3B;
	E3C;
	E3D(a4:String);
}

typedef S5 = {x6:String};

abstract A10(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A10, b:A10):A10
		return new A10(a.get() + b.get());

	@:op(A * B) public static function mul(a:A10, b:A10):A10
		return new A10(a.get() * b.get());

	@:op(-A) public static function neg(a:A10):A10
		return new A10(-a.get());
}

enum abstract K11(Int) to Int {
	var K11A = 1;
	var K11B = 4;
	var K11C = 7;
}

class C21 extends C12 {
	public function new(a22:Float, a23:Int) {
		super();
	}
	public function m24(a25:String = "d"):String {
		H.tick();
		var v114 = (switch (61) {
			case 0: "  pad  ";
			case 3 | 4: "\x41\x42";
			case c115 if (c115 > 10): (a25).charAt((c115 & 7));
			case _: C12.f13;
		});
		if ((a25 != Std.string(100.75))) return a25;
		switch (a25) {
			case "a" | "b": {
				for (i116 in 0...H.lim(0xFFFFFFFF)) {
					H.tick();
					C45.f46 += i116;
				}
				if (true) {
					var v117:S5 = ({x6: "42"} : S5);
					var v118 = a25;
				}
			};
			case "Haxe": {
				{
					H.out("o119 " + Std.string(E0.E0A));
					var v120 = true;
				}
			};
			case _: {
				try {
					if ((Std.downcast((new C12() : C12), C21) != null)) throw "boom";
					H.out("o121 " + Std.string(4));
					H.out("o122 " + v114);
				} catch (ex123:Dynamic) {
					H.out("caught " + H.exn(ex123));
					final v124:Map<String, C12> = new Map<String, C12>();
					final v125:Bool = false;
				}
			};
		}
		switch (v114) {
			case "a" | "b": {
				final v126:C21 = new C21(1e-7, 0xC4CA);
			};
			case "Haxe": {
				for (i127 in 0...2) {
					H.tick();
					Main.fn60(false, i127, false);
				}
				H.out("o128 " + Std.string(true));
			};
			case "": {
				this.f14 = (({x8: "Haxe", x9: 99} : S7)).x9;
				for (i129 in 0...0) {
					H.tick();
					H.out("o130 " + Std.string(i129));
					var v131:C12 = new C12();
					final v132:Int = i129;
				}
			};
			case _: {
				if (false) {
					H.out("o133 " + Std.string(new C21(0.1, 208)));
					var v134:S5 = ({x6: v114} : S5);
				} else {
					H.out("o135 " + Std.string(18));
					var v136:S5 = ({x6: v114} : S5);
				}
			};
		}
		if (Std.isOfType(new C12(), C12)) {
			++this.f14;
			Main.fn55((Std.parseInt(a25) ?? 0));
			if (false) {
				var v137:Map<String, String> = (["k0" => a25, "k1" => a25, "k2" => v114] : Map<String, String>);
			} else {
				Main.fn60(false, 123456.789, true);
				final v138:Map<Int, Int> = ([-3 => 224, 4 => 297] : Map<Int, Int>);
			}
		}
		try {
			if (((a25).substr(0, ((-2) & 7)) == "42")) throw new Err((-1580918305));
			H.out("o139 " + Std.string(new Box<Int>((-1850371862))));
		} catch (ex140:Dynamic) {
			H.out("caught " + H.exn(ex140));
			this.f14 = (v114).length;
		}
		return "abc";
	}
	public function m26(a27:E3):Int {
		H.tick();
		var v141:E0 = E0.E0A;
		H.out("o142 " + Std.string((((StringTools.endsWith("zz", "\\") ? new A10(146) : new A10((-7))) : A10) : Int)));
		m19(({ var sb143 = new StringBuf(); sb143.add(("\\").toLowerCase()); sb143.addChar(73); sb143.toString(); }));
		var v144:K11 = K11.K11A;
		Main.fn55(Main.fn57((new A10(6)).twice));
		C12.f13 += "\\";
		final v145:Map<String, Int> = new Map<String, Int>();
		return 0x4F8C;
	}
	public function m28(a29:Int):String {
		H.tick();
		if ((false && false)) return "0";
		var v146 = a29;
		var w147 = 0;
while (w147 < 4 && (((new Map<Int, Int>()).get(4) ?? 0) < v146)) {
			w147++;
			H.tick();
			var v148 = v146;
		}
		H.out("o149 " + Std.string(((switch (E0.E0A) {
			case E0A: 3.0;
		}) : Float)));
		return (new C21(123456.789, (v146 -= 1))).m15();
	}
}

class Main {
	public static function fn50(a51:E3, a52:String, a53:Int, ...r54:Int):Int {
		H.tick();
		if (((["k0" => E0.E0A] : Map<String, E0>)).exists("k0")) {
			H.out("o174 " + Std.string(364316025));
			var v175 = (-2147483647);
			v175 = (-13);
		} else {
			var w176 = 0;
while (w176 < 2 && false) {
				w176++;
				H.tick();
				var v177:C45 = new C45(248, a53);
				H.out("o178 " + a52);
			}
			if (true) return a53;
		}
		(((true ? new C12() : new C21(1e3, 72)) : C12)).m19(H.apply(("  pad  ").toLowerCase(), (v179:String) -> v179));
		H.out("o180 " + Std.string(1e-7));
		C45.f46 <<= (a53 & 7);
		H.out("o181 " + Std.string(((new A10(a53)).twice % H.nz(a53))));
		try {
			try {
				var v182:Int = 56;
				var v183:Int = 64;
				(new C21(a53, a53)).m28(a53);
				if (false) throw 58;
			} catch (ex184:Dynamic) {
				H.out("caught " + H.exn(ex184));
				H.out("o185 " + Std.string(new Box(false)));
				(new C12()).m15();
			}
			for (i186 in 0...2) {
				H.tick();
				(new C12()).m19("q");
				var v187:String = a52;
				(new C30("q")).m33(a52);
			}
			if (false) throw new Err((Std.string(1.25)).indexOf(a52));
		} catch (ex188:Err) {
			H.out("caught Err " + ex188.errCode);
			final v189:E2 = E2.E2A;
			var w190 = 0;
while (w190 < 1 && false) {
				w190++;
				H.tick();
				(new C21(a53, a53)).m15();
				var v191:Null<Int> = 0xC173;
			}
		} catch (ex192:haxe.Exception) {
			H.out("caught " + H.exn(ex192));
			final v193:Float = a53;
			switch ((new A10(a53)).twice) {
				case 0: {
					final v194 = 4;
				};
				case 3 | 5: {
					var v195:Float = 123456.789;
				};
				case _: {
					final v196 = a53;
				};
			}
		}
		return Math.ceil(H.id(a53));
	}
	public static function fn55(?a56:Null<Int>):String {
		H.tick();
		H.out("o197 " + Std.string(7.0));
		try {
			if (StringTools.endsWith(C12.f13, C12.f13)) throw 4;
			try {
				if (true) throw "boom";
				var v198:S7 = ({x8: "", x9: 54} : S7);
			} catch (ex199:Err) {
				H.out("caught Err " + ex199.errCode);
				var v200:Map<String, Float> = new Map<String, Float>();
			} catch (ex201:haxe.Exception) {
				H.out("caught " + H.exn(ex201));
				(new C12()).m15();
				C45.f46 = (-2147483647);
			}
			var w202 = 0;
while (w202 < 2 && true) {
				w202++;
				H.tick();
				var v203:Int = 0x92D6;
			}
		} catch (ex204:Dynamic) {
			H.out("caught " + H.exn(ex204));
			H.out("o205 " + C12.f13);
			for (i206 in 0...0) {
				H.tick();
				var v207:Int = i206;
				final v208:Map<Int, Int> = ([-3 => 137] : Map<Int, Int>);
			}
		}
		H.out("o209 " + Std.string(new C21(C45.f46, (new A10(50)).twice)));
		var w210 = 0;
while (w210 < 5 && H.apply(Std.string(E0.E0A), (v211:String) -> (Std.downcast((new C21(1.25, 41) : C21), C21) != null))) {
			w210++;
			H.tick();
			var w212 = 0;
while (w212 < 4 && StringTools.startsWith("-7", "\x41\x42")) {
				w212++;
				H.tick();
				a56 = H.id(a56);
			}
		}
		C45.f46 += fn50(E3.E3B, Std.string(169), Reflect.compare("\n", "ünï"), 22, 220);
		var v213:Map<Int, String> = ([-3 => C12.f13, 4 => "x,y,z", 11 => StringTools.hex((1250172028) & 0xFFFF, 4)] : Map<Int, String>);
		(new C30(("x,y,z").charAt(6))).m33(("ünï").substr(6, -2));
		{
			C45.f46 = (new A10(10)).twice;
			switch (E0.E0A) {
				case E0A: {
					C45.f46 &= (-432065615);
					C45.f46--;
				};
				case _: {
					var v214:Bool = false;
				};
			}
			var v215:String = StringTools.trim("abc");
		}
		for (i216 in 0...H.lim(8)) {
			H.tick();
			if (true) {
				var v217:Float = i216;
			}
			(new C21(i216, 0xB869)).m28((K11.K11C : Int));
			var v218:C12 = new C21(i216, i216);
		}
		return (new C21((-2.5), 1127030353)).m28(37);
	}
	public static function fn57(a58:Int, a59:Float = 1.5):Int {
		H.tick();
		H.out("o219 " + Std.string((((a58 -= 1) : A10) : Int)));
		var w220 = 0;
while (w220 < 1 && (Std.string(a58) <= "\\")) {
			w220++;
			H.tick();
			var v221:S5 = ({x6: "ünï"} : S5);
			var v222:C40 = new C40(a58, a58);
		}
		var v223:S7 = ({x9: (Std.parseInt("hello world") ?? 0), x8: "a"} : S7);
		switch (K11.K11C) {
			case K11.K11A: {
				(new C12()).m19(C12.f13);
				var v224:Bool = true;
			};
			case K11.K11B: {
				var v225 = (new Map<Int, Null<Int>>()).exists(4);
				fn55();
			};
			case K11.K11C: {
				final v226:Int = (a58 = 5);
			};
			case _: {
				Main.fn50(E3D("\t"), String.fromCharCode(65 + ((a58) & 15)), Reflect.compare("a\rb", "日本語"));
			};
		}
		{
			H.out("o227 " + Std.string(E0.E0A));
			H.out("o228 " + Std.string(E3B));
			if ((([-3 => a58, 4 => a58] : Map<Int, Int>)).exists(11)) {
				var v229:C30 = new C30("Haxe");
				a59 = a58;
			} else {
				a58--;
			}
		}
		return ((-7) >>> ((Std.parseInt(Std.string(a58)) ?? 0) & 31));
	}
	public static function fn60(a61:Bool, a62:Float, a63:Bool):Bool {
		H.tick();
		final v230:Map<Int, Int> = ([-3 => Math.floor(a62), 4 => Type.enumIndex(E0.E0A)] : Map<Int, Int>);
		if (a61) return (a63 ? a61 : true);
		switch ((StringTools.contains("\x41\x42", "\\") && a61)) {
			case true: {
				H.out("o231 " + Std.string((K11.K11B : Int)));
			};
			case false: {
				H.out("o232 " + Std.string(276));
			};
		}
		H.out("o233 " + Std.string(123456.789));
		for (i234 in 0...0) {
			H.tick();
			if (StringTools.startsWith("-7", "\u{1F600}")) {
				(new C12()).m19("\x41\x42");
				var v235:E0 = E0.E0A;
				Main.fn55(i234);
			}
			C45.f46 = i234;
		}
		return a63;
	}
	public static function fn64(...r65:Int):Int {
		H.tick();
		var v236:C30 = new C30(Std.string(1e-7));
		C45.f46 -= 268;
		H.out("o237 " + Std.string(((Std.parseInt(Std.string(48)) ?? 0) >>> (("\x41\x42").length & 31))));
		Main.fn55(Math.round(7.0));
		C45.f46 += 1401901953;
		H.out("o238 " + Std.string(242));
		final v239:Int = 574951261;
		C45.f46 &= ((([-3 => 0x68CF, 4 => v239, 11 => v239] : Map<Int, Int>)).get(4) ?? 0);
		return v239;
	}
	public static function fn66(a67:Int, a68:Float = 1.5):Bool {
		H.tick();
		final v240:C40 = new C40((({x8: "  pad  ", x9: a67} : S7)).x9, C45.f46);
		H.out("o241 " + Std.string((168 & (-1668113894))));
		C45.f46 = ((E0.E0A).match(E0A) ? Reflect.compare(0xFFFFFFFF, a67) : 74);
		try {
			if (((Std.parseInt(Std.string(0x45F1)) ?? 0) < a67)) throw 35;
			if (true) {
				++a67;
				H.out("o242 " + Std.string(a67));
			}
			switch (84) {
				case 0: {
					var v243:Map<String, Int> = new Map<String, Int>();
					(new C30("é")).m33("\"q\"");
				};
				case 3 | 4: {
					final v244:Map<String, Bool> = new Map<String, Bool>();
				};
				case _: {
					var v245:Float = a68;
				};
			}
			var w246 = 0;
do {
				w246++;
				H.tick();
				C45.f46 = 73;
				a67 = H.id(a67);
			} while (w246 < 3 && false);
		} catch (ex247:String) {
			H.out("caught String " + ex247);
			for (i248 in 2...5) {
				H.tick();
				var v249:Float = a67;
				H.out("o250 " + Std.string(120));
				var v251:E2 = E2.E2B;
			}
			var v252:Box<C21> = new Box<C21>(new C21(a67, a67));
		} catch (ex253:Int) {
			H.out("caught Int " + ex253);
			var w254 = 0;
while (w254 < 2 && StringTools.contains("q", "\\")) {
				w254++;
				H.tick();
				H.out("o255 " + Std.string(ex253));
				H.out("o256 " + Std.string(E2.E2A));
				var v257:E0 = E0.E0A;
			}
		} catch (ex258:Err) {
			H.out("caught Err " + ex258.errCode);
			var v259 = "\u{1F600}";
		} catch (ex260:Dynamic) {
			H.out("caught " + H.exn(ex260));
			H.out("o261 " + Std.string(({x8: "\t", x9: a67} : S7)));
			if (false) {
				C12.m16(new A10(a67), ({x8: "ünï", x9: a67} : S7));
			}
		}
		H.out("o262 " + Std.string((-2.5)));
		return (fn50(E3.E3A, StringTools.lpad("\n", "*", 6), Math.floor(1.7976931348623157e308), Type.enumIndex(E0.E0A)) != 67);
	}
	public static function fn69(a70:String):Int {
		H.tick();
		if ((E0.E0A).match(E0A)) {
			var v263:E3 = E3.E3C;
			H.out("o264 " + Std.string(new Box(1389953171)));
		}
		C45.f46 = 253;
		final v265:Int = (new C21(1.7976931348623157e308, 226)).m26(E3A);
		var v266 = a70;
		H.out("o267 " + Std.string(v265));
		H.out("o268 " + Std.string((switch (({x8: a70, x9: v265} : S7)) {
			case {x8: c269}: true;
		})));
		{
			C45.f46 -= 162;
		}
		if (("\t" > C12.f13)) return v265;
		return (new C21(v265, (((-2000783439) : A10) : Int))).m26(E3.E3C);
	}
	public static function fn71(a72:Int):String {
		H.tick();
		final v270:Int = C45.f46;
		var v271:S5 = ((switch (("ab").substr(6, -1)) {
			case "a" | "b": ({x6: "-7"} : S5);
			case "Haxe": ({x6: "-7"} : S5);
			case _: ({x6: "hello world"} : S5);
		}) : S5);
		var v272 = 75;
		fn50(E3A, "A-B-C", (a72 << ((((["k0" => a72, "k1" => a72, "k2" => 230] : Map<String, Int>)).get("k3") ?? 0) & 31)), (new Box(35)).get());
		return ((new C21(1e100, v270)).m24(StringTools.lpad("\u{1F600}", "*", 3))).charAt(-1);
	}
	public static function section0():Void {
		H.tick();
		H.out("o296 " + Std.string(((Std.parseInt("é") ?? 0) >>> (0xE1DE & 31))));
		C12.f13 = H.cap((StringTools.contains("\t", "abc") ? "-7" : C12.f13));
		H.out("o297 " + Std.string(70));
		H.out("o298 " + Std.string(C45.f46));
		final v299:Map<String, Float> = (["k0" => C45.f46] : Map<String, Float>);
		if (((E2.E2A).match(E2B) && true)) {
			for (i300 in 0...0) {
				H.tick();
				var v301:Int = 186;
			}
			fn66(Math.ceil(1e21), Std.parseFloat("1.5"));
		} else {
			C12.f13 = H.cap(Std.string(E0.E0A));
		}
		H.out("o302 " + Std.string(fn69(StringTools.hex((120) & 0xFFFF, 4))));
		var v303:String = (new C21(1e3, 0x2B1C)).m15();
	}
	public static function section1():Void {
		H.tick();
		H.out("o304 " + (switch (E2.E2A) {
			case E2A: "\"q\"";
			case E2B: ("q").charAt(3);
			case _: Std.string(1e21);
		}));
		H.out("o305 " + Std.string((new C21(1.25, 183)).m26(E3.E3A)));
		if (false) {
			try {
				if (false) throw "boom";
				H.out("o306 " + Std.string(new C45(129, (-2147483647))));
				var v307:Int = 235;
			} catch (ex308:Dynamic) {
				H.out("caught " + H.exn(ex308));
				H.out("o309 " + Std.string(false));
				H.out("o310 " + "é");
			}
			if (false) {
				final v311:Map<String, Int> = new Map<String, Int>();
				C45.f46 = 0x38DA;
				final v312:E2 = E2.E2A;
			} else {
				var v313:String = "a";
			}
		} else {
			C45.f46 = 168;
		}
		H.out("o314 " + Std.string((Std.parseInt(Std.string(("  pad  ").length)) ?? 0)));
		H.out("o315 " + ("hello world").ext75(Std.isOfType(new C30("日本語"), C30)));
	}
	public static function section2():Void {
		H.tick();
		var v316:Null<Int> = H.apply(true, (v317:Bool) -> null);
		for (k318 => v319 in (["k0" => (("  pad  ").charCodeAt(65535) ?? -1), "k1" => C45.f46, "k2" => C45.f46] : Map<String, Int>)) {
			H.tick();
			H.out("o320 " + "Haxe");
			H.out("o321 " + Std.string(new C45(v319, v319)));
		}
		H.out("o322 " + Std.string(C45.f46));
		var v323 = (Math.isNaN(0.1) ? true : StringTools.contains("zz", "hello world"));
		if ((Std.downcast((new C12() : C12), C21) != null)) {
			if (v323) {
				var v324 = "q";
				(new C12()).m19(v324);
			} else {
				var v325:Int = 281;
				final v326:Int = v325;
			}
			var w327 = 0;
do {
				w327++;
				H.tick();
				H.out("o328 " + Std.string(11));
			} while (w327 < 1 && (E0.E0A).match(E0A));
			if (v323) {
				fn71(47);
				C45.f46 *= 277;
				var v329:Int = 165;
			} else {
				H.out("o330 " + Std.string(new C45(284, 0x7C1C)));
				C45.f46 &= 139;
			}
		}
		switch ((C12.f13).length) {
			case 0: {
				H.out("o331 " + Std.string(new Box<C40>(new C45(154, 0x8AC4))));
			};
			case 1 | 6: {
				C45.f46--;
			};
			case _: {
				(new C21(7.0, 1885615657)).m28(0x6FF6);
			};
		}
		switch (E2.E2A) {
			case E2A: {
				var v332:A10 = new A10(0xEA6B);
			};
			case E2B: {
				{
					H.out("o333 " + Std.string(44));
					C45.f46 = 8;
					H.out("o334 " + Std.string(1534611674));
				}
			};
			case _: {
				switch ((({x8: "ünï", x9: 231} : S7)).x9) {
					case 0: {
						var v335:C12 = new C12();
						C12.m16(new A10(116), ({x8: "日本語", x9: 92} : S7));
					};
					case 2 | 4: {
						H.out("o336 " + Std.string(new C40(0xFFFFFFFF, 0.1)));
					};
					case _: {
						C45.f46 = (-690549017);
						var v337:Int = 0xF299;
					};
				}
				final v338:Bool = (new Map<String, Int>()).exists("日本語");
			};
		}
		var v339 = (switch (E2.E2B) {
			case E2A: 75;
			case E2B: C45.f46;
			case _: 257;
		});
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
