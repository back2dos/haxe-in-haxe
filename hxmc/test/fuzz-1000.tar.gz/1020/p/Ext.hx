package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext75(a73:String, a74:Bool):String {
		H.tick();
		H.out("o273 " + ' = ${Std.string(C45.f46)} = ${Std.string(a74)}');
		H.out("o274 " + Std.string(({x8: (a73).toLowerCase(), x9: Std.int(123456.789)} : S7)));
		H.out("o275 " + Std.string(H.apply((new A10((-5)) : Int), (v276:Int) -> E0.E0A)));
		if (!a74) {
			for (i277 in 2...6) {
				H.tick();
				H.out("o278 " + Std.string((K11.K11B : Int)));
				(new C21(i277, 0x4E89)).m19(a73);
			}
			var v279:Bool = a74;
		} else {
			if (StringTools.endsWith("-7", a73)) {
				final v280 = "abc";
			}
			for (i281 in 1...4) {
				H.tick();
				(new C21(2.5e-3, i281)).m28(i281);
				H.out("o282 " + Std.string(new C30(a73)));
				var v283:Float = i281;
			}
		}
		for (i284 in 0...0) {
			H.tick();
			C45.f46 = ("A-B-C").indexOf(a73);
		}
		return a73;
	}
	public static function ext78(a76:Int, a77:E3):Float {
		H.tick();
		a76 = (Std.parseInt(C12.f13) ?? 0);
		H.out("o285 " + Std.string(a76));
		final v286:Int = (-93125343);
		var w287 = 0;
do {
			w287++;
			H.tick();
			var v288:S7 = ({x9: a76, x8: "x,y,z"} : S7);
			for (i289 in 0...2) {
				H.tick();
				var v290:C21 = new C21(7.0, a76);
			}
		} while (w287 < 3 && ((E0.E0A).match(E0A) || false));
		if ((new Map<Int, Bool>()).exists(18)) {
			{
				H.out("o291 " + Std.string(E0.E0A));
			}
		}
		C45.f46 = ("42").lastIndexOf(C12.f13);
		var v292:K11 = ((false ? K11.K11C : K11.K11B) : K11);
		return a76;
	}
	public static function ext80(a79:Int):Int {
		H.tick();
		C45.f46 = (a79 >> ((new A10(a79) : Int) & 31));
		var w293 = 0;
while (w293 < 3 && (C12.f13 != StringTools.hex((a79) & 0xFFFF, 4))) {
			w293++;
			H.tick();
			var v294 = true;
		}
		var v295 = C12.f13;
		return C45.f46;
	}
}
