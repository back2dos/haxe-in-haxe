package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
}

enum E2 {
	E2A;
	E2B;
}

typedef S7 = {x8:String, x9:Int};

class C12 {
	public static var f13:String = "ab";
	public var f14:Int;
	public function new() {
		this.f14 = Math.ceil(7.0);
	}
	public function m15():String {
		H.tick();
		H.out("o81 " + Std.string(C45.f46));
		C45.f46 *= 196;
		H.out("o82 " + Std.string(46));
		var v83:Box<Int> = new Box(0x7FFFFFFF);
		try {
			switch (E3.E3B) {
				case E3A: {
					this.f14 |= (-1866356438);
					var v84:Map<Int, Int> = ([-3 => 294, 4 => 205] : Map<Int, Int>);
				};
				case E3C: {
					var v85 = "ab";
					var v86:A10 = (281 : A10);
				};
				case _: {
					var v87:S5 = ({x6: "ab"} : S5);
					v87 = H.id(v87);
				};
			}
			if ((switch (("  pad  ").substring(0, ((-1205656722) & 7))) {
				case "a" | "b": true;
				case "Haxe": true;
				case "": (E2.E2A).match(E2A);
				case _: StringTools.endsWith("Haxe", "-7");
			})) throw "boom";
		} catch (ex88:String) {
			H.out("caught String " + ex88);
			var v89:Int = 65535;
			var v90 = Math.floor(1.25);
		} catch (ex91:Int) {
			H.out("caught Int " + ex91);
			C45.f46 = 221;
		} catch (ex92:Err) {
			H.out("caught Err " + ex92.errCode);
			H.out("o93 " + Std.string((K11.K11C : Int)));
			var v94:Float = Math.pow(0.5, 2);
		} catch (ex95:Dynamic) {
			H.out("caught " + H.exn(ex95));
			try {
				if ((E2.E2B).match(E2A)) throw new Err((("  pad  ").charCodeAt(42) ?? -1));
				this.f14 += 141;
				final v96:K11 = K11.K11B;
			} catch (ex97:Dynamic) {
				H.out("caught " + H.exn(ex97));
				this.f14 = 28;
			}
			this.f14 <<= (C45.f46 & 7);
		}
		H.out("o98 " + Std.string(new C12()));
		H.out("o99 " + Std.string(3.0));
		return C12.f13;
	}
	public static function m16(a17:A10, a18:S7):Void {
		H.tick();
		H.out("o100 " + Std.string(2.5e-3));
		Ext.ext78(Type.enumIndex(E2.E2B), (new Box<E3>(E3.E3C)).get());
		final v101:C40 = new C40(190, 7.0);
		C45.f46 = Main.fn50(E3.E3B, ("-7").toLowerCase(), 247);
		if ((Std.parseFloat("12.5") <= 1e-7)) {
			H.out("o102 " + Std.string((a18).x9));
			H.out("o103 " + Std.string(Math.isNaN(123456.789)));
		} else {
			Main.fn50(E3.E3C, "a", 261, Type.enumIndex(E3.E3C));
			var v104:E2 = E2B;
		}
		var v105:A10 = a17;
		C45.f46 = (92 | 130);
		if (true) {
			var v106:E0 = E0.E0A;
			C45.f46 = (-80367500);
		} else {
			var w107 = 0;
while (w107 < 2 && true) {
				w107++;
				H.tick();
				C12.f13 = H.cap("\\");
			}
			switch (Math.floor(1e3)) {
				case 0: {
					Main.fn50(E3.E3B, "a", 161);
				};
				case 1 | 4: {
					var v108:C40 = new C40(111, 5e-324);
					var v109:Map<String, Float> = (["k0" => 0.1, "k1" => (-2.5)] : Map<String, Float>);
				};
				case _: {
					C45.f46 = 213;
					H.out("o110 " + Std.string(0x22CD));
				};
			}
		}
		var v111:E0 = E0A;
	}
	public function m19(a20:String):Void {
		H.tick();
		var v112:String = (switch (a20) {
			case "a" | "b": (a20).substring((111 & 7), 3);
			case "Haxe": StringTools.lpad("a\rb", "*", 4);
			case _: (a20).substring(((-2) & 7), 6);
		});
		this.m15();
		H.out("o113 " + Std.string(((201 : A10) : Int)));
	}
}

class C30 {
	public var f31:Float;
	public function new(a32:String) {
		this.f31 = 1.25;
	}
	public function m33(a34:String):Void {
		H.tick();
		var v150:Bool = (new Box(false)).value;
		if (((("\\").charCodeAt(50) ?? -1) > Type.enumIndex(E3.E3C))) {
			(new C21(0.1, 160)).m28(Math.ceil(3.0));
		} else {
			if (StringTools.startsWith(a34, a34)) {
				var v151 = 1649223202;
				C45.f46 -= v151;
				v151 = H.id(v151);
			}
			var w152 = 0;
do {
				w152++;
				H.tick();
				H.out("o153 " + Std.string(24));
				var v154 = 245;
				C45.f46 = (-8);
			} while (w152 < 1 && Math.isNaN(1.25));
		}
		for (i155 in 0...1) {
			H.tick();
			try {
				if (false) throw new Err((new A10(i155)).twice);
				C45.f46 <<= (0xC2AF & 7);
			} catch (ex156:Dynamic) {
				H.out("caught " + H.exn(ex156));
				var v157:String = a34;
				var v158:Null<Int> = i155;
			}
			if (v150) {
				var v159:Int = (-5);
				H.out("o160 " + a34);
				C45.f46 ^= v159;
			} else {
				H.out("o161 " + Std.string(v150));
				(new C21(1e3, (-6))).m15();
			}
		}
		H.out("o162 " + Std.string(({x6: C12.f13} : S5)));
		switch (K11.K11C) {
			case K11.K11A: {
				var v163:Int = (Std.parseInt(Std.string(238)) ?? 0);
			};
			case K11.K11B: {
				(new C12()).m15();
			};
			case K11.K11C: {
				var v164:String = "abc";
				(new C21(7.0, 133)).m19(Std.string(E3.E3B));
			};
		}
		var v165:E2 = E2B;
		var v166:Bool = (a34 >= a34);
		C45.f46 = ((a34).indexOf(a34) | 244);
		{
			var v167:Bool = Math.isNaN(1.25);
		}
	}
	public function m35(a36:Int, a37:Int):Bool {
		H.tick();
		var v168 = "hello world";
		switch ((859164026 + Reflect.compare(193, (-19)))) {
			case 0: {
				Ext.ext78((a36++), E3.E3A);
			};
			case 3 | 5: {
				a36 |= a37;
			};
			case _: {
				final v169:E2 = E2.E2B;
			};
		}
		if ((C45.f46 == 38)) {
			Main.fn57(Type.enumIndex(E2A), 100.75);
		}
		var v170:E0 = E0A;
		H.out("o171 " + Std.string(a36));
		return Main.fn60(StringTools.contains("ünï", (v168).substr((a37 & 7), (a36 & 7))), (a37).ext78(E3.E3B), Main.fn60(false, a36, true));
	}
	public static function m38(?a39:Null<Bool>):Float {
		H.tick();
		C45.f46 <<= (34 & 7);
		switch (E0.E0A) {
			case E0A: {
				(new C12()).m15();
			};
		}
		{
			Ext.ext80(0xFFFFFFFF);
			var v172:C30 = new C30("-7");
			C45.f46 = Math.floor(100.75);
		}
		H.out("o173 " + Std.string(new C12()));
		return (("\\").charCodeAt(7) ?? -1);
	}
}

class C40 {
	public var f41:String;
	var _f42:Float;

	public var f42(get, set):Float;

	function get_f42():Float
		return _f42;

	function set_f42(v:Float):Float
		return _f42 = v;
	public function new(a43:Int, a44:Float) {
		this.f41 = C12.f13;
		this._f42 = a44;
	}
}

class C45 extends C40 {
	public static var f46:Int = 137;
	public var f47:Int;
	public function new(a48:Int, a49:Int) {
		super(a48, 2.5e-3);
		this.f47 = (Std.parseInt("ab") ?? 0);
	}
}
