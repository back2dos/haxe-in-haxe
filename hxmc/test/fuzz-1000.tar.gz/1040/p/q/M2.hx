package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

enum E0 {
	E0A;
	E0B(a1:Bool);
}

typedef S6 = {x7:Float};
