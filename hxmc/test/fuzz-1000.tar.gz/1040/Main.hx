import H;
import p.M1;
import p.q.M2;

typedef S2 = {x3:Int, x4:Float, x5:Bool};

enum abstract K8(Int) to Int {
	var K8A = 1;
	var K8B = 4;
}

class Main {
	public static function fn9(a10:Int, a11:Int):Array<Int> {
		H.tick();
		H.out("o31 " + Std.string(([K8.K8B, K8.K8B] : Array<K8>)));
		H.out("o32 " + Std.string((switch (E0.E0A) {
			case E0A: (++a10);
			case _: Type.enumIndex(E0.E0B(false));
		})));
		var w33 = 0;
while (w33 < 4 && (a11 < a11)) {
			w33++;
			H.tick();
			if (false) return ([] : Array<Int>);
			if (true) {
				var v34:Null<Int> = a11;
				H.out("o35 " + Std.string(a11));
			}
			for (i36 in 2...H.lim((a10 += 3))) {
				H.tick();
				H.out("o37 " + Std.string(i36));
			}
		}
		if ((1e-7 > 1e3)) {
			var v38 = 277;
		} else {
			var w39 = 0;
while (w39 < 4 && false) {
				w39++;
				H.tick();
				var v40:E0 = E0.E0A;
				final v41:Bool = true;
				var v42:Int = a10;
			}
			if (false) {
				var v43:Map<String, Array<Int>> = new Map<String, Array<Int>>();
				H.out("o44 " + "  pad  ");
				var v45:E0 = E0.E0A;
			} else {
				H.out("o46 " + Std.string(([E0.E0A, E0.E0B(false)] : Array<E0>)));
				var v47:S2 = ({x3: a10, x4: a10, x5: true} : S2);
			}
		}
		switch (K8.K8B) {
			case K8.K8A: {
				H.out("o48 " + Std.string(a11));
			};
			case K8.K8B: {
				a10 = H.id(a10);
				switch ((([a10, a11] : Array<Float>)).length) {
					case 0: {
						a11 = H.id(a11);
						H.out("o49 " + Std.string(1e-7));
					};
					case 3 | 5: {
						final v50:(Float, Int) -> Int = function(p51:Float, p52:Int):Int {
							H.tick();
							var v53 = 66;
							return a10;
						};
						var v54:Array<Float> = ([] : Array<Float>);
					};
					case _: {
						H.out("o55 " + Std.string(({x4: a10, x5: true, x3: a10} : S2)));
					};
				}
			};
			case _: {
				a10 = (a11 -= 1);
			};
		}
		return [(a11 >> (293 & 31))];
	}
	public static function fn12():Void {
		H.tick();
		var v56:Map<String, Int> = new Map<String, Int>();
		if ((0.5 >= 230)) {
			for (i57 in 0...H.lim((([] : Array<Int>)).indexOf(26))) {
				H.tick();
				var v58:Float = i57;
				H.out("o59 " + Std.string(E0.E0B(true)));
				var v60:Int = i57;
			}
			for (i61 in 0...H.lim(Math.floor(1e3))) {
				H.tick();
				var v62:Int = 72;
			}
		}
		H.out("o63 " + Std.string(([E0.E0B(true), E0.E0A, E0.E0B(false)] : Array<E0>)));
		for (k65 => x64 in [([227]).length, Math.floor(0.1), (K8.K8B : Int)]) {
			H.tick();
			fn9(218, (([] : Array<Int>)).indexOf(x64));
			for (i66 in 0...3) {
				H.tick();
				var v67:Array<Int> = [k65, k65, 139];
				var v68:Int = x64;
				var v69:Bool = true;
			}
			var v70:Array<Int> = [x64, x64];
		}
		H.out("o71 " + Std.string(({x3: ([true, true, true]).indexOf(false), x4: (-2147483647), x5: (new Map<Int, Int>()).exists(18)} : S2)));
	}
	public static function fn13(...r14:Int):Bool {
		H.tick();
		var v72:Array<K8> = ([for (i73 in ["\\", "q"]) if (true) K8.K8B] : Array<K8>);
		for (i74 in 0...4) {
			H.tick();
			H.out("o75 " + Std.string(1e21));
			var v76:E0 = E0.E0B(false);
			final v77:S2 = ({x3: 230, x4: 1.7976931348623157e308, x5: true} : S2);
		}
		var v78:Bool = !true;
		var w79 = 0;
do {
			w79++;
			H.tick();
			H.out("o80 " + Std.string(1.25));
		} while (w79 < 3 && ((["k0" => K8.K8A, "k1" => K8.K8B] : Map<String, K8>)).exists("é"));
		var v81:Map<Int, Int> = ([-3 => Math.round(0.30000000000000004)] : Map<Int, Int>);
		var w82 = 0;
while (w82 < 4 && (false || v78)) {
			w82++;
			H.tick();
			H.out("o83 " + "x,y,z");
			H.out("o84 " + Std.string(148));
		}
		fn9(Math.ceil(0.5), (-24));
		H.out("o85 " + Std.string((K8.K8A : Int)));
		return v78;
	}
	public static function fn15(a16:Int, a17:Int):Bool {
		H.tick();
		if (false) {
			var v86:Int = a17;
			final v87:Array<Float> = ([100.75, v86] : Array<Float>);
		}
		var v88:Array<Int> = [for (i89 in ([1.25, a17] : Array<Float>)) if (false) a17];
		H.out("o90 " + Std.string((-a16)));
		for (i91 in 2...H.lim((Std.parseInt(Std.string((({x3: a16, x4: a17, x5: false} : S2)).x3)) ?? 0))) {
			H.tick();
			H.out("o92 " + Std.string(701073355));
		}
		var v93:E0 = E0.E0A;
		{ var dyn94:Dynamic = ({x7: 1e-7} : S6); H.out("dyn " + Std.string(dyn94.x7) + " " + Std.string(Reflect.field(dyn94, "x7"))); }
		return (false && false);
	}
	public static function fn18(a19:Array<Null<Int>>, a20:Bool, ?a21:Null<Float>):Int {
		H.tick();
		var v95:Array<Bool> = ((a20 ? [false, false, true] : ([] : Array<Bool>)) : Array<Bool>);
		if (a20) return 122;
		H.out("o96 " + Std.string(292));
		H.out("o97 " + Std.string(([] : Array<Int>)));
		H.out("o98 " + Std.string(((Std.parseInt(Std.string(810911002)) ?? 0) | 55)));
		if (true) {
			H.out("o99 " + Std.string(180));
			if (Math.isNaN(3.0)) {
				var v100:Bool = a20;
				var v101:Int = 22;
			} else {
				var v102:Array<K8> = ([K8.K8A, K8.K8A, K8.K8A] : Array<K8>);
			}
		} else {
			final v103:Map<Int, (Bool, Int) -> Int> = ([-3 => (p104:Bool, p105:Int) -> p105, 4 => (p106:Bool, p107:Int) -> p107] : Map<Int, (Bool, Int) -> Int>);
			if (false) {
				final v108:(Float, Bool) -> Int = function(p109:Float, p110:Bool):Int {
					H.tick();
					H.out("o111 " + Std.string(69));
					fn13(54, 264);
					var v112:Int = (-7);
					return v112;
				};
				final v113:Float = 123456.789;
				H.out("o114 " + "ünï");
			} else {
				var v115:Int = 60;
				fn15(v115, v115);
			}
		}
		{
			var v116:Int = 0xFFFFFFFF;
		}
		return (((-2120344224) + Math.floor(1e3)) ^ (((new Map<String, Int>()).get("k3") ?? 0) >> (Reflect.compare(283, 146) & 31)));
	}
	public static function fn22(a23:Int, ?a24:Null<Int>):() -> String {
		H.tick();
		for (x117 in ((false ? [true, false, true] : ([] : Array<Bool>)) : Array<Bool>)) {
			H.tick();
			var v118:Array<Int> = [a23];
			for (k119 => v120 in (["k0" => a23, "k1" => a23] : Map<String, Int>)) {
				H.tick();
				if (x117) continue;
				var v121:Float = v120;
				a23 -= v120;
			}
			++a23;
		}
		if (({ var v122 = 267; false; })) {
			try {
				var v123 = 210;
				if ((([] : Array<Int>)).contains(a23)) throw 14;
			} catch (ex124:Err) {
				H.out("caught Err " + ex124.errCode);
				var v125 = 133;
			} catch (ex126:haxe.Exception) {
				H.out("caught " + H.exn(ex126));
				final v127:Int = a23;
				H.out("o128 " + Std.string(16));
			}
			var v129 = (--a23);
			H.out("o130 " + Std.string(Type.enumIndex(E0.E0B(false))));
		}
		var v131:Int = 717533507;
		return function():String {
			H.tick();
			var v132:Int = (Std.parseInt("\\") ?? 0);
			fn9(((([-3 => 904079939] : Map<Int, Int>)).get(a23) ?? 0), v131);
			return (Std.string(v131) + "zz");
		};
	}
	public static function fn25(a26:Int = 3):Int {
		H.tick();
		for (x133 in (((([-3 => 112] : Map<Int, Int>)).exists(a26) ? [false, false] : [false, false]) : Array<Bool>)) {
			H.tick();
			H.out("o134 " + Std.string((K8.K8B : Int)));
			var w135 = 0;
while (w135 < 5 && true) {
				w135++;
				H.tick();
				H.out("o136 " + Std.string(E0.E0A));
				H.out("o137 " + Std.string(a26));
			}
			var v138:Array<Bool> = [false, true, false];
		}
		var v139:Bool = (new Map<String, Int>()).exists("k2");
		{ var dyn140:Dynamic = ({x3: a26, x4: 0.1, x5: Math.isNaN(a26)} : S2); H.out("dyn " + Std.string(dyn140.x3) + " " + Std.string(Reflect.field(dyn140, "x3"))); }
		H.out("o141 " + Std.string(a26));
		try {
			if ((switch (E0.E0B(v139)) {
				case E0A: v139;
				case E0B(c142): (([-3 => true] : Map<Int, Bool>)).exists(a26);
				case _: v139;
			})) throw 91;
			H.out("o143 " + Std.string(E0.E0A));
			for (i144 in 0...1) {
				H.tick();
				H.out("o145 " + Std.string(([i144, 7.0] : Array<Float>)));
			}
			final v146:Array<Int> = ([] : Array<Int>);
		} catch (ex147:String) {
			H.out("caught String " + ex147);
			if (false) {
				a26--;
				var v148:Bool = v139;
			}
			fn15(a26, (K8.K8A : Int));
		} catch (ex149:Int) {
			H.out("caught Int " + ex149);
			Main.fn9(Reflect.compare(ex149, ex149), 27);
			var v150:Float = 2.5e-3;
		} catch (ex151:Err) {
			H.out("caught Err " + ex151.errCode);
			a26 *= 0xF4D1;
			H.out("o152 " + Std.string((Std.parseInt("42") ?? 0)));
		} catch (ex153:Dynamic) {
			H.out("caught " + H.exn(ex153));
			Main.fn9(a26, 0xFFFFFFFF);
		}
		if ((false ? v139 : v139)) {
			if (v139) {
				H.out("o154 " + Std.string(E0.E0A));
			}
		} else {
			if (false) {
				a26 ^= a26;
				H.out("o155 " + Std.string(255));
			} else {
				final v156:(Int) -> Int = (p157:Int) -> p157;
				H.out("o158 " + Std.string(a26));
			}
		}
		final v159 = (6 >>> ((a26 += 3) & 31));
		fn18(([for (i160 in [72, a26, 199]) if (false) i160] : Array<Null<Int>>), fn13(Type.enumIndex(E0.E0B(false)), v159));
		return v159;
	}
	public static function fn27(a28:Float, a29:Float, a30:Bool):E0 {
		H.tick();
		try {
			if (Math.isNaN(2.5e-3)) throw "日本語";
			var v161:Array<Int> = [300, 141, 72];
			var v162 = 0x80000000;
			fn18(([v162, v162, v162] : Array<Null<Int>>), false, a29);
		} catch (ex163:Err) {
			H.out("caught Err " + ex163.errCode);
			H.out("o164 " + Std.string(202));
			var v165:Map<Int, Bool> = ([-3 => a30, 4 => false, 11 => a30] : Map<Int, Bool>);
		} catch (ex166:haxe.Exception) {
			H.out("caught " + H.exn(ex166));
			H.out("o167 " + Std.string((Std.parseInt(Std.string(267)) ?? 0)));
			switch (0x7FFFFFFF) {
				case 0: {
					H.out("o168 " + Std.string((-1)));
					H.out("o169 " + Std.string((-2147483647)));
				};
				case 3 | 5: {
					var v170:Float = 3.0;
					H.out("o171 " + Std.string(E0.E0B(true)));
				};
				case _: {
					H.out("o172 " + Std.string(299));
				};
			}
		}
		H.out("o173 " + Std.string(1763009195));
		var v174 = ({ var v175 = (Std.parseInt("\n") ?? 0); v175; });
		H.out("o176 " + Std.string((((["k0" => v174, "k1" => 35] : Map<String, Int>)).get("\\") ?? 0)));
		v174 = (false ? (Std.parseInt(Std.string(v174)) ?? 0) : (-2147483647));
		fn22((([v174]).contains(v174) ? v174 : 297), Main.fn25(v174));
		if (a30) {
			H.out("o177 " + Std.string(false));
			var v178:E0 = E0.E0A;
			var v179:Array<Float> = ([] : Array<Float>);
		} else {
			H.out("o180 " + Std.string(E0.E0A));
		}
		var v181 = v174;
		return ({ var v182 = (v181 <= H.at([87, 167, 204], v181, 0)); E0.E0B(false); });
	}
	public static function section0():Void {
		H.tick();
		try {
			{
				H.out("o183 " + Std.string((-14)));
				var v184 = 0x5635;
			}
			final v185:Int = 0x65DA;
			if (({ var v186 = ([v185, 1837853098, v185]).contains(131); Math.isNaN(v185); })) throw "ünï";
		} catch (ex187:String) {
			H.out("caught String " + ex187);
			H.out("o188 " + Std.string(({x7: 0.1} : S6)));
			var w189 = 0;
while (w189 < 4 && true) {
				w189++;
				H.tick();
				var v190:Array<Int> = [255, 163, 279];
				fn9(188, 0xF7CA);
			}
		} catch (ex191:Int) {
			H.out("caught Int " + ex191);
			for (i192 in 0...4) {
				H.tick();
				var v193:Map<Int, Bool> = ([-3 => false] : Map<Int, Bool>);
				fn13();
				H.out("o194 " + Std.string(E0.E0B(false)));
			}
		} catch (ex195:Err) {
			H.out("caught Err " + ex195.errCode);
			var v196 = ([true, false]).indexOf(false);
			var v197 = v196;
		} catch (ex198:Dynamic) {
			H.out("caught " + H.exn(ex198));
			final v199:Array<Bool> = [false];
			var v200:Bool = true;
		}
		H.out("o201 " + Std.string((([] : Array<Int>)).length));
		var v202:Array<Int> = ([0x80000000, 145, 29]).slice(0, 2);
		H.out("o203 " + Std.string(E0.E0A));
	}
	public static function section1():Void {
		H.tick();
		H.out("o204 " + Std.string(Math.abs(0.5)));
		var v205:Map<String, Array<Int>> = (["k0" => [28, 1159789675], "k1" => ([] : Array<Int>), "k2" => [36, 196, 286]] : Map<String, Array<Int>>);
		Main.fn27((7.0 * Std.parseFloat("1.5")), 273, (([76, 0xE2E6, 1543447189]).indexOf(161) != (([7.0, 1.25, 2.5e-3] : Array<Float>)).length));
		if ((switch (K8.K8B) {
			case K8.K8A: true;
			case K8.K8B: false;
		})) {
			H.out("o206 " + Std.string(({x7: 0.30000000000000004} : S6)));
			final v207:Null<Int> = (-37478449);
			var v208:Int = Math.ceil(2.5e-3);
		}
		H.out("o209 " + Std.string(([124, 218]).contains((Std.parseInt(Std.string(93)) ?? 0))));
		H.out("o210 " + Std.string(fn18(([] : Array<Null<Int>>), false, 1e-7)));
		switch (E0.E0B(true)) {
			case E0A: {
				for (i211 in 0...H.lim(65)) {
					H.tick();
					Main.fn13(i211);
					var v212 = 263;
				}
				try {
					if (false) throw new Err((([0.30000000000000004, (-2.5)] : Array<Float>)).length);
					H.out("o213 " + Std.string((K8.K8A : Int)));
					H.out("o214 " + Std.string(100.75));
				} catch (ex215:String) {
					H.out("caught String " + ex215);
					var v216 = 0xFFFFFFFF;
				} catch (ex217:Int) {
					H.out("caught Int " + ex217);
					var v218:Int = ex217;
				} catch (ex219:Err) {
					H.out("caught Err " + ex219.errCode);
					final v220:() -> Int = function():Int {
						H.tick();
						H.out("o221 " + Std.string(true));
						final v222 = false;
						fn9(0x81D7, (-2147483647));
						return 41;
					};
				} catch (ex223:Dynamic) {
					H.out("caught " + H.exn(ex223));
					var v224:S6 = ({x7: 1.25} : S6);
				}
			};
			case _: {
				if (([0x7FFFFFFF, 64]).contains((-10))) {
					H.out("o225 " + Std.string(100.75));
				}
			};
		}
		final v226:E0 = E0.E0B((([-3 => 22, 4 => 0x3D86] : Map<Int, Int>)).exists(1379532886));
		var v227:Array<Int> = [for (i228 in 0...4) Math.ceil(i228)];
	}
	public static function section2():Void {
		H.tick();
		H.out("o229 " + Std.string(((-102501294) << (H.at([163], 17, 0) & 31))));
		H.out("o230 " + Std.string((K8.K8B : Int)));
		var v231:Int = (0x7FFFFFFF + Math.round(1.25));
		for (k233 => x232 in ([v231, 121, v231]).copy()) {
			H.tick();
			var v234:Float = 100.75;
			for (x235 in ([] : Array<Int>)) {
				H.tick();
				var v236:E0 = E0.E0B(true);
				v231 &= k233;
				var v237:Map<String, Int> = (["k0" => x235] : Map<String, Int>);
			}
		}
		var v238:Map<String, Map<Int, Bool>> = (cast ((["k0" => new Map<Int, Bool>(), "k1" => ([-3 => true] : Map<Int, Bool>)] : Map<String, Map<Int, Bool>>)) : Map<String, Map<Int, Bool>>);
		var v239:K8 = K8.K8B;
	}
	public static function section3():Void {
		H.tick();
		var v240 = Main.fn18(([154, 78] : Array<Null<Int>>), false, 3.0);
		var v241:Bool = false;
		var w242 = 0;
while (w242 < 4 && ((({x3: 116, x5: v241, x4: 100.75} : S2)).x3 <= 12)) {
			w242++;
			H.tick();
			var v243:Map<String, Int> = new Map<String, Int>();
		}
		Main.fn15((cast (94) : Int), Main.fn18(([v240, 0x7FFFFFFF] : Array<Null<Int>>), v241));
		Main.fn22(46, 216);
		var w244 = 0;
while (w244 < 3 && true) {
			w244++;
			H.tick();
			v240 *= v240;
			final v245:(Float, Int) -> Float = function(p246:Float, p247:Int):Float {
				H.tick();
				H.out("o248 " + Std.string(131));
				var v249:E0 = E0.E0B(v241);
				return p247;
			};
		}
		var v250 = v240;
	}
	public static function section4():Void {
		H.tick();
		switch (E0.E0B(true)) {
			case E0A: {
				var v251:E0 = E0.E0B(false);
				try {
					if (([255, 297, 65535]).contains((-1391205734))) throw "Haxe";
					H.out("o252 " + Std.string((-1580443887)));
				} catch (ex253:Err) {
					H.out("caught Err " + ex253.errCode);
					H.out("o254 " + "");
				} catch (ex255:haxe.Exception) {
					H.out("caught " + H.exn(ex255));
					final v256:E0 = v251;
					final v257 = false;
				}
			};
			case E0B(_): {
				final v258:Array<(Int, Float) -> Float> = ([] : Array<(Int, Float) -> Float>);
			};
		}
		{ var dyn259:Dynamic = (cast (({x7: 1e3} : S6)) : S6); H.out("dyn " + Std.string(dyn259.x7) + " " + Std.string(Reflect.field(dyn259, "x7"))); }
		fn27(((switch (Math.floor(1e3)) {
			case 0: 0.1;
			case 1 | 5: 100.75;
			case _: 3.0;
		}) : Float), (-2147483647), (0x80000000 >= 111));
		var w260 = 0;
while (w260 < 5 && (1e-7 != 1e-7)) {
			w260++;
			H.tick();
			var v261:Array<(Float) -> Void> = ([function(p262:Float):Void {
				H.tick();
				var v263 = false;
				v263 = H.id(v263);
				final v264:Bool = v263;
			}, function(p265:Float):Void {
				H.tick();
				fn9((-2147483647), (-1831875543));
			}, function(p266:Float):Void {
				H.tick();
				var v267:Map<Int, Int> = ([-3 => 217765501, 4 => 43, 11 => 196] : Map<Int, Int>);
			}] : Array<(Float) -> Void>);
			H.out("o268 " + "  pad  ");
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
