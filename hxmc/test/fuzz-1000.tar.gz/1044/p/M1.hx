package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E3 {
	E3A;
}

typedef S4 = {x5:Int};

typedef S6 = {x7:Int};

enum abstract K9(Int) to Int {
	var K9A = 1;
	var K9B = 4;
	var K9C = 7;
	var K9D = 10;
}

interface I10 {
	function m11(a12:String):Int;
	function m13(a14:Int, a15:String):Bool;
}

class C45 implements I10 {
	public var f46:String;
	public function new(a47:Int, a48:Int) {
		this.f46 = ("\\").toLowerCase();
	}
	public function m11(a12:String):Int {
		H.tick();
		if (true) {
			H.out("o192 " + Std.string(Lambda.count(([] : Array<Int>), v193 -> StringTools.contains("日本語", "0"))));
			(([] : Array<Int>)).ext90();
		} else {
			switch (H.id([0x74EC, 28])) {
				case []: {
					var v194:Array<String> = [a12];
					final v195:Array<Bool> = [true];
				};
				case [c196]: {
					H.out("o197 " + Std.string(c196));
				};
				case [_, c198]: {
					H.out("o199 " + Std.string([a12, a12]));
					var v200 = a12;
				};
				case _: {
					H.out("o201 " + a12);
					var v202:K9 = K9.K9D;
				};
			}
			H.out("o203 " + Std.string((Std.downcast((new C29((-2.5), [300]) : C29), C29) != null)));
		}
		C57.m60(Lambda.fold([295, 16], (v204:Int, v205:Int) -> 0x68E1, 0));
		var v206:Float = ((switch (E3.E3A) {
			case E3A: (-2.5);
		}) : Float);
		if (false) return Main.fn62((Std.parseInt("  pad  ") ?? 0), (E0.E0A).match(E0A), [96]);
		for (i207 in 1...H.lim(({ var v208 = a12; 28; }))) {
			H.tick();
			try {
				if (false) throw new Err(i207);
				this.f46 += "日本語";
			} catch (ex209:Dynamic) {
				H.out("caught " + H.exn(ex209));
				var v210:Int = i207;
				var v211 = 169;
			}
			var v212:Array<Int> = [i207];
			H.out("o213 " + Std.string(new C29(i207, v212)));
		}
		if (({ var v214 = 109; ([v214, v214, v214]).contains(v214); })) {
			var w215 = 0;
do {
				w215++;
				H.tick();
				Ext.ext93([133], 0xFFFFFFFF);
				H.out("o216 " + Std.string(E0.E0B(false, 190)));
			} while (w215 < 4 && true);
			if (Math.isNaN(1e3)) {
				([267]).ext93(300);
				var v217:Array<C16> = ([new C16("\t"), new C16(a12), new C16(a12)] : Array<C16>);
				([0x7FFFFFFF, 65535, (-1891466748)]).ext93(152);
			} else {
				H.out("o218 " + Std.string(E3A));
				Main.fn73();
			}
		} else {
			var v219 = 218;
			H.out("o220 " + Std.string(Std.int(v219)));
		}
		for (i221 in 0...H.lim((Std.string(7)).length)) {
			H.tick();
			final lf222:(Int) -> String = (p223:Int) -> a12;
			var v224:Int = (new A8(i221)).twice;
			var v225:Bool = true;
		}
		return Main.fn62(Main.fn62(Reflect.compare(a12, a12), false, [(-324147508), 0xEF2B]), true, [for (i226 in 0...1) Reflect.compare(i226, i226)]);
	}
	public function m13(a14:Int, a15:String):Bool {
		H.tick();
		var v227:A8 = (-new A8(a14));
		for (x228 in [a14]) {
			H.tick();
			{
				var v229:Float = a14;
			}
			var v230:Array<Int> = ([] : Array<Int>);
		}
		a14 = (a14 >> ((a15).indexOf(a15) & 31));
		H.out("o231 " + Std.string(new C57(a15)));
		var v232:String = "42";
		return StringTools.endsWith(StringTools.replace(String.fromCharCode(65 + ((a14) & 15)), "b", (v232).toUpperCase()), StringTools.hex((a14) & 0xFFFF, 4));
	}
	public static function m49(a50:String = "d"):Float {
		H.tick();
		final v233:Array<Int> = (new C16(a50)).m23();
		H.out("o234 " + Std.string(([(-455657229)]).length));
		if (false) {
			final v235:Bool = StringTools.startsWith(a50, "ünï");
			if ((E3A).match(E3A)) return (-2.5);
			final lf236:(Int) -> Void = function(p237:Int):Void {
				H.tick();
				C57.m60(47);
			};
		}
		H.out("o238 " + Std.string(([false, false]).map((v239:Bool) -> (E3.E3A : E3))));
		var v240:S6 = (((v233).contains(142) ? ({x7: 0xBDFD} : S6) : ({x7: 127} : S6)) : S6);
		function lf241(n242:Int):Int {
			H.tick();
			return n242 <= 0 ? n242 : (lf241(n242 - 1) + n242);
		}
		H.out("lf241 " + lf241(0));
		var v243:Array<K9> = H.id(([K9.K9B] : Array<K9>));
		var v244 = (12 * (-2147483647));
		var v245:Int = (v244 += 3);
		return 0.5;
	}
}

class C51 implements I10 {
	public var f52:E0;
	public function new(a53:Int) {
		this.f52 = E0.E0A;
	}
	public function m11(a12:String):Int {
		H.tick();
		H.out("o246 " + Std.string(((new C16(a12)).m20(0x1062, (a12).lastIndexOf(a12)) : Int)));
		if ((switch (false) {
			case true: false;
			case false: (E3.E3A).match(E3A);
		})) {
			var v247:Int = (([] : Array<Bool>)).indexOf(true);
			H.out("o248 " + Std.string(v247));
		}
		H.out("o249 " + Std.string((23 & (Std.parseInt(a12) ?? 0))));
		var v250:Int = C51.m54(78, StringTools.contains(a12, "-7"));
		if (((E0.E0A).match(E0B(_, _)) || false)) {
			Main.fn62(Math.floor(1e3), ([v250]).contains(v250), [1834188109, 258, v250]);
			H.out("o251 " + Std.string(52));
		} else {
			{
				H.out("o252 " + Std.string(([({x7: v250} : S6), ({x7: v250} : S6)] : Array<S6>)));
				Ext.ext90([65535, v250, 69]);
			}
			H.out("o253 " + Std.string(new C57(a12)));
		}
		H.out("o254 " + Std.string(([v250, v250]).filter(v255 -> false)));
		final lf256:() -> Int = function():Int {
			H.tick();
			H.out("o257 " + Std.string(({x5: v250} : S4)));
			var v258:Float = v250;
			C57.m60(v250);
			return ((-5) >>> ((new A8(v250) : Int) & 31));
		};
		for (x259 in (cast ([0xA6D5, v250, v250]) : Array<Int>)) {
			H.tick();
			v250--;
		}
		return v250;
	}
	public function m13(a14:Int, a15:String):Bool {
		H.tick();
		try {
			(([] : Array<Int>)).ext93(a14);
			final lf260:(String) -> String = function(p261:String):String {
				H.tick();
				var v262:String = a15;
				return C29.f30;
			};
			a14 *= 158;
			if ((true || true)) throw "boom";
		} catch (ex263:String) {
			H.out("caught String " + ex263);
			try {
				if (false) throw 53;
				var v264 = 705251510;
			} catch (ex265:Err) {
				H.out("caught Err " + ex265.errCode);
				final v266:(Float) -> Int = (p267:Float) -> a14;
			} catch (ex268:haxe.Exception) {
				H.out("caught " + H.exn(ex268));
				H.out("o269 " + Std.string(a14));
				C57.m60(90);
			}
		} catch (ex270:Int) {
			H.out("caught Int " + ex270);
			var v271:Int = 65535;
			for (x272 in [0xD4D6, v271]) {
				H.tick();
				var v273 = a14;
			}
		} catch (ex274:Err) {
			H.out("caught Err " + ex274.errCode);
			var v275 = 55;
			H.out("o276 " + Std.string((a14--)));
		} catch (ex277:Dynamic) {
			H.out("caught " + H.exn(ex277));
			switch (((a15).charCodeAt(a14) ?? -1)) {
				case 0: {
					var v278:Float = a14;
					var v279:S6 = ({x7: a14} : S6);
				};
				case 1 | 4: {
					H.out("o280 " + Std.string(59));
				};
				case c281 if (c281 > 10): {
					a14 = H.id(a14);
				};
				case _: {
					var v282 = a14;
				};
			}
		}
		Main.fn70((new Box(a14)).get(), [false, true]);
		H.out("o283 " + Std.string((((switch (Lambda.fold([a14, a14], (v284:Int, v285:Int) -> (["\t", a15, a15]).indexOf("x,y,z"), 0)) {
			case 0: K9.K9D;
			case 2 | 6: K9.K9C;
			case _: K9.K9C;
		}) : K9) : Int)));
		var v286:Int = a14;
		for (x287 in [for (i288 in 0...3) Std.int(a14)]) {
			H.tick();
			Ext.ext93([v286], Math.floor(a14));
			H.out("o289 " + Std.string(([x287]).contains(a14)));
			final v290:Int = Type.enumIndex(E0.E0A);
		}
		if ((true || ([v286, a14]).contains(a14))) {
			if (Std.isOfType(new C45(v286, a14), C45)) {
				Main.fn73();
				H.out("o291 " + Std.string(({x5: a14} : S4)));
			} else {
				v286 = H.id(v286);
				var v292:Int = a14;
			}
			C51.m54(0x7FFFFFFF, StringTools.startsWith(a15, a15));
			var v293:Int = (("\t").charCodeAt(231) ?? -1);
		}
		switch ("abc") {
			case "a" | "b": {
				v286 = ([a14]).length;
			};
			case "Haxe": {
				try {
					if (true) throw 54;
					var v294:Bool = false;
				} catch (ex295:Err) {
					H.out("caught Err " + ex295.errCode);
					var v296:Array<Float> = ([v286, a14, v286] : Array<Float>);
					(new C16(a15)).m20(163, v286);
				} catch (ex297:haxe.Exception) {
					H.out("caught " + H.exn(ex297));
					var v298 = a15;
					H.out("o299 " + Std.string(new C45(v286, a14)));
				}
				final v300 = true;
			};
			case "": {
				switch (({x5: 103} : S4)) {
					case {x5: 1 | 2}: {
						v286 = H.id(v286);
						H.out("o302 " + Std.string(new Box<String>(a15)));
					};
					case {x5: c301}: {
						H.out("o303 " + "  pad  ");
						H.out("o304 " + Std.string(c301));
					};
				}
				H.out("o305 " + Std.string([a15, a15, a15]));
			};
			case _: {
				for (i306 in 0...2) {
					H.tick();
					var v307:String = a15;
					Main.fn62(v286, true, [0x599E, (-12)]);
				}
			};
		}
		H.out("o308 " + Std.string(E0.E0B(([a14]).contains(a14), a14)));
		for (x309 in [87]) {
			H.tick();
			var v310:C51 = new C51(x309);
		}
		return (E3.E3A).match(E3A);
	}
	public static function m54(a55:Int, a56:Bool):Int {
		H.tick();
		a55 = H.id(a55);
		H.out("o311 " + Std.string(((C29.f30).charCodeAt(0x873D) ?? -1)));
		final v312:Array<String> = (cast (["", "x,y,z", "\"q\""]) : Array<String>);
		return (a55 = 5);
	}
}
