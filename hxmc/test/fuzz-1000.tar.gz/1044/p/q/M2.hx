package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

abstract A8(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A8, b:A8):A8
		return new A8(a.get() + b.get());

	@:op(A * B) public static function mul(a:A8, b:A8):A8
		return new A8(a.get() * b.get());

	@:op(-A) public static function neg(a:A8):A8
		return new A8(-a.get());
}

class C29 implements I10 {
	public static var f30:String = "\u{1F600}";
	public var f31:Bool;
	public function new(a32:Float, a33:Array<Int>) {
		this.f31 = StringTools.startsWith("a\rb", "\"q\"");
	}
	public function m11(a12:String):Int {
		H.tick();
		{
			if (true) return Std.int(1.25);
		}
		for (i121 in 0...1) {
			H.tick();
			Ext.ext90([989080763]);
			var v122:Int = 131;
		}
		var v123:Array<Bool> = (([] : Array<Bool>)).concat([true, false, true]);
		H.out("o124 " + Std.string((this.f31 ? 131 : 0xC3E0)));
		if (Ext.ext93([(-2147483647), 245], (a12).indexOf("zz"))) {
			var v125:C57 = new C57(a12);
			var v126:String = C29.f30;
			var v127:I10 = new C29(0.5, [3, 83]);
		} else {
			var v128 = 0x1623;
		}
		([1582785250, 6, Type.enumIndex(E3.E3A)]).ext90();
		H.out("o129 " + Std.string(new Box(31)));
		var v130:I10 = new C29(5e-324, [1611893566, 0x168A]);
		var v131 = 184;
		return (v131 << (v131 & 31));
	}
	public function m13(a14:Int, a15:String):Bool {
		H.tick();
		H.out("o132 " + Std.string(({ var v133 = (E0.E0B(true, 183)).match(E0A); v133; })));
		H.out("o134 " + Std.string((switch (H.id([a14, a14, a14])) {
			case []: true;
			case [c135]: true;
			case [_, c136]: false;
			case _: (E0.E0B(false, a14)).match(E0B(_, _));
		})));
		for (x137 in ({ var v138 = Std.string(3.0); ([] : Array<String>); })) {
			H.tick();
			for (x139 in ([] : Array<Bool>)) {
				H.tick();
				if (true) continue;
				Main.fn66(a14, new Box<String>(x137), a14);
				H.out("o140 " + "é");
			}
			if ((Std.downcast((new C16(a15) : C16), C16) != null)) return this.f31;
		}
		var v141:Float = 3.0;
		H.out("o142 " + Std.string(E0.E0A));
		return false;
	}
	public function m34(?a35:Null<Bool>):Int {
		H.tick();
		(new C51(0xA656)).m11("\\");
		if ((Std.isOfType(new C29(1e100, [138, (-20), 127]), I10) || false)) {
			final v143:S4 = ({x5: 30} : S4);
			for (x144 in ("  pad  ").split("a")) {
				H.tick();
				var v145:E3 = E3.E3A;
			}
		}
		var v146:Float = (Type.enumIndex(E0.E0A) * Math.sin(1.25));
		final v147:Array<String> = ((true ? ["é"] : ([] : Array<String>)) : Array<String>);
		var v148:I10 = new C51(223);
		switch (E0.E0A) {
			case E0A: {
				Main.fn73();
				H.out("o149 " + Std.string(Type.enumIndex(E0.E0B(false, 134))));
			};
			case E0B(c150, c151): {
				final v152:Array<Float> = ([c151] : Array<Float>);
			};
		}
		var w153 = 0;
while (w153 < 1 && ((-3) != ("").indexOf("Haxe"))) {
			w153++;
			H.tick();
			H.out("o154 " + Std.string(new C57("\"q\"")));
			H.out("o155 " + Std.string(H.at([22, 0x7CEB, 212], 247, 0)));
			for (x156 in [(-19), 39]) {
				H.tick();
				var v157 = "42";
				final v158:Float = v146;
			}
		}
		var v159:Bool = (new C45((-2147483647), 8)).m13(95, ("hello world").substr((165 & 7), ((-6) & 7)));
		H.out("o160 " + C29.f30);
		return ((Std.string(1e3)).charCodeAt((StringTools.hex((53) & 0xFFFF, 4)).indexOf(Std.string(v146))) ?? -1);
	}
	public static function m36(a37:Bool):Bool {
		H.tick();
		var v161:Int = ((new A8((-3))).get() % H.nz(Reflect.compare(287, 0x83C8)));
		var v162:Box<Box<Bool>> = new Box<Box<Bool>>(new Box(a37));
		H.out("o163 " + Std.string(v161));
		var v164:E3 = E3.E3A;
		var v165:Array<Int> = [for (i166 in [0x261A, 293]) if (true) i166];
		C29.f30 = H.cap((C29.f30).substring(((K9.K9D : Int) & 7), 2));
		return (new C45(v161, 214)).m13(v161, (("").toUpperCase() + "a\rb"));
	}
	public function m38(a39:Bool, a40:Array<Float>):Float {
		H.tick();
		var v167:Array<C45> = ([new C45(101, 135), new C45((-378205438), 290)] : Array<C45>);
		var v168:I10 = new C51((Std.parseInt("\u{1F600}") ?? 0));
		final v169:String = (switch (({x5: 76} : S4)) {
			case {x5: 1 | 2}: "  pad  ";
			case {x5: c170}: C29.f30;
		});
		for (x171 in ([a39]).filter(v172 -> true)) {
			H.tick();
			var v173:Array<Bool> = [a39, false];
			final v174 = ([a39]).join("");
		}
		var w175 = 0;
do {
			w175++;
			H.tick();
			final v176 = false;
		} while (w175 < 4 && a39);
		return 3.0;
	}
	public function m41(a42:Int, a43:Int, ...r44:Int):Float {
		H.tick();
		for (i177 in 0...4) {
			H.tick();
			H.out("o178 " + Std.string(3.0));
			a43 += H.at([266], a43, 0);
			for (i179 in 0...H.lim((a42 = 5))) {
				H.tick();
				var v180 = "hello world";
				var v181:E3 = E3.E3A;
			}
		}
		var v182:Array<String> = (([] : Array<String>)).filter(v183 -> false);
		for (x184 in [(E3.E3A).match(E3A), (E3.E3A).match(E3A)]) {
			H.tick();
			H.out("o185 " + Std.string(198));
			H.out("o186 " + Std.string((new A8(65535) : Int)));
			var v187:K9 = K9.K9D;
		}
		for (i188 in 0...H.lim((~("日本語").indexOf("Haxe")))) {
			H.tick();
			if (false) {
				H.out("o189 " + Std.string(a43));
				var v190:Array<Float> = ([] : Array<Float>);
			}
			var v191 = Type.enumIndex(E0.E0A);
		}
		return (new C45((Std.parseInt(Std.string(a42)) ?? 0), 287)).m11(([true, false]).join(","));
	}
}

class C57 {
	public var cb58:(Int) -> Int;
	public function new(a59:String) {
		this.cb58 = function(p313:Int):Int {
			H.tick();
			H.out("o314 " + Std.string([true]));
			return p313;
		};
	}
	public static function m60(a61:Int):Void {
		H.tick();
		(((true ? new C16("é") : new C16("zz")) : C16)).m20((Std.parseInt(Std.string((K9.K9B : Int))) ?? 0), Type.enumIndex(E3.E3A));
		var v315:Float = C51.m54(a61, StringTools.startsWith("  pad  ", "zz"));
		H.out("o316 " + Std.string(((a61--) & a61)));
		final v317:C29 = new C29(123456.789, ([] : Array<Int>));
		if ((StringTools.contains("zz", "hello world") || false)) {
			C51.m54(a61, false);
			var v318:Int = 0x5F6D;
			var v319 = (Std.parseInt(Std.string(v318)) ?? 0);
		} else {
			var v320:Float = 79;
		}
		for (x321 in ([] : Array<Int>)) {
			H.tick();
			a61 <<= (Math.floor(a61) & 7);
			C51.m54(x321, false);
		}
		if (StringTools.startsWith(Std.string(v315), ("a").charAt(4))) {
			var v322 = a61;
			var v323:E0 = E0.E0A;
		}
		for (i324 in 0...3) {
			H.tick();
			var v325:Float = 1e3;
			H.out("o326 " + Std.string(123456.789));
			final v327:Int = (a61++);
		}
		var v328:Int = a61;
	}
}
