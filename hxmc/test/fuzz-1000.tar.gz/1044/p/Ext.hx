package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext90(a89:Array<Int>):Int {
		H.tick();
		var v498:String = (([] : Array<Int>)).join("");
		var v499:A8 = (new A8(208) + new A8(0x479A));
		var v500:Array<String> = (["0", "ünï", v498]).concat(("abc").split(" "));
		for (i501 in 0...1) {
			H.tick();
			H.out("o502 " + Std.string(new C51(i501)));
		}
		H.out("o503 " + Std.string(new C29(1e-7, a89)));
		if (true) {
			var v504 = H.at(a89, 43, 0);
			final v505:Int = (Std.parseInt(Std.string(248)) ?? 0);
			var v506:Float = v504;
		}
		if (((-2.5) == 7.0)) {
			var v507 = (K9.K9C : Int);
		}
		H.out("o508 " + (false ? C29.f30 : ([true]).join("")));
		return (({x5: 65535} : S4)).x5;
	}
	public static function ext93(a91:Array<Int>, a92:Int):Bool {
		H.tick();
		var v509:C45 = ((switch ("Haxe") {
			case "a" | "b": new C45(a92, 973818646);
			case "Haxe": new C45(65535, a92);
			case "": new C45(a92, a92);
			case _: new C45(a92, 52);
		}) : C45);
		a92 = (new A8(a92)).get();
		C29.f30 = H.cap(Std.string(1e21));
		for (k511 => x510 in ((false ? a91 : [a92, 17]) : Array<Int>)) {
			H.tick();
			a92 -= k511;
		}
		var w512 = 0;
do {
			w512++;
			H.tick();
			Main.fn66((-1310730765), new Box<String>("\u{1F600}"), a92);
			var v513:Float = a92;
			var w514 = 0;
do {
				w514++;
				H.tick();
				var v515:Box<Int> = new Box((-19));
				a92 &= a92;
			} while (w514 < 3 && false);
		} while (w512 < 2 && (0.1 != a92));
		a92 = Lambda.fold([a92], (v516:Int, v517:Int) -> (new A8(257)).get(), 0);
		return (((new A8(a92)).get() < (new A8(a92)).get()) ? (a92 != a92) : (a92 != Math.floor(2.5e-3)));
	}
}
