import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Bool, a2:Int);
}

class C16 {
	var _f17:Bool;

	public var f17(get, set):Bool;

	function get_f17():Bool
		return _f17;

	function set_f17(v:Bool):Bool
		return _f17 = v;
	public var f18:E3;
	public function new(a19:String) {
		this._f17 = Std.isOfType(null, I10);
		this.f18 = E3.E3A;
	}
	public function m20(a21:Int, a22:Int):A8 {
		H.tick();
		this.f18 = ((false ? E3.E3A : E3.E3A) : E3);
		{
			try {
				if (Std.isOfType(new C57("Haxe"), C57)) throw Std.string(E3.E3A);
				final v94:C57 = new C57("\u{1F600}");
			} catch (ex95:Dynamic) {
				H.out("caught " + H.exn(ex95));
				var v96 = "42";
				var v97:S6 = ({x7: a22} : S6);
			}
			final v98:I10 = new C45(298, a21);
			H.out("o99 " + Std.string(1977215185));
		}
		H.out("o100 " + Std.string(a22));
		switch (("zz" > StringTools.lpad("x,y,z", "*", -1))) {
			case true: {
				final v101 = StringTools.endsWith("42", "\n");
				var v102:Box<(String) -> String> = new Box<(String) -> String>(function(p103:String):String {
					H.tick();
					var v104:Array<Int> = [a21, a22, 292];
					var v105:Int = a22;
					return p103;
				});
			};
			case false: {
				if (true) return new A8(296);
				for (i106 in 0...4) {
					H.tick();
					var v107:Float = i106;
					if (false) continue;
				}
			};
		}
		var v108:Array<Bool> = (([] : Array<String>)).map((v109:String) -> false);
		return (a22 : A8);
	}
	public function m23():Array<Int> {
		H.tick();
		final v110:Array<String> = (["\\"]).filter(v111 -> true);
		H.out("o112 " + Main.fn66((({x7: 127} : S6)).x7, new Box(""), ("42").length));
		function lf113(n114:Int):Int {
			H.tick();
			return n114 <= 0 ? (n114 - ([n114, 203, n114]).length) : (lf113(n114 - 1) + n114);
		}
		H.out("lf113 " + lf113(5));
		(new C45((Std.parseInt("0") ?? 0), 68)).m13(0xA2A3, StringTools.trim(StringTools.trim("A-B-C")));
		return [((Std.parseInt(Std.string(0x80000000)) ?? 0) - (({x5: 1331582355} : S4)).x5), (new C29(2.5e-3, [36])).m11(Std.string(123456.789)), (StringTools.trim("é")).indexOf("ünï")];
	}
	public function m24(a25:Int = 4):Int {
		H.tick();
		final v115:E3 = ((switch (K9.K9C) {
			case K9.K9A: E3.E3A;
			case K9.K9B: E3.E3A;
			case K9.K9C: E3.E3A;
			case K9.K9D: this.f18;
		}) : E3);
		if (this.f17) {
			(new C29(a25, [a25, a25])).m13(Lambda.count([a25], v116 -> Std.isOfType(new C29(v116, ([] : Array<Int>)), C29)), "\t");
		}
		(new C29(0.1, [a25])).m13(((("ünï").charCodeAt(a25) ?? -1) * a25), "-7");
		H.out("o117 " + Std.string((false ? a25 : 222)));
		return a25;
	}
	public function m26(a27:Int, a28:Bool):Void {
		H.tick();
		H.out("o118 " + Std.string((K9.K9D : Int)));
		var v119:Float = 0.5;
		var v120:Int = a27;
	}
}

class Main {
	public static function fn62(a63:Int, a64:Bool, a65:Array<Int>):Int {
		H.tick();
		function lf329(n330:Int):Int {
			H.tick();
			return n330 <= 0 ? n330 : (lf329(n330 - 1) + C51.m54(a63, StringTools.startsWith("\"q\"", "\"q\"")));
		}
		H.out("lf329 " + lf329(0));
		var v331 = C51.m54(a63, a64);
		v331--;
		return (C29.f30).length;
	}
	public static inline function fn66(a67:Int, a68:Box<String>, a69:Int):String {
		H.tick();
		H.out("o332 " + Std.string(E3.E3A));
		a69 = (cast (a67) : Int);
		final v333:(Float) -> Bool = function(p334:Float):Bool {
			H.tick();
			var v335 = false;
			var v336:C51 = new C51(a69);
			return v335;
		};
		C57.m60((("\\").indexOf("hello world") | a67));
		H.out("o337 " + Std.string(a67));
		H.out("o338 " + Std.string((cast (({x5: a67} : S4)) : S4)));
		if (false) {
			a69++;
		} else {
			var v339:Int = (Std.parseInt("42") ?? 0);
			switch (0x135C) {
				case 0: {
					H.out("o340 " + Std.string((-12)));
					var v341:A8 = new A8(a69);
				};
				case 1 | 5: {
					H.out("o342 " + Std.string(((a69 : A8) : Int)));
					var v343:Int = a69;
				};
				case _: {
					(new C16("\"q\"")).m20(0x1D5, v339);
				};
			}
		}
		for (k345 => x344 in (new Box<Array<String>>(["\\", "ünï", "q"])).value) {
			H.tick();
			var v346:S6 = ({x7: 226} : S6);
			var v347:Array<String> = [x344, x344];
		}
		return StringTools.replace("  pad  ", "b", C29.f30);
	}
	public static inline function fn70(a71:Int, a72:Array<Bool>):String {
		H.tick();
		H.out("o348 " + Std.string(E0B(false, (K9.K9D : Int))));
		H.out("o349 " + Std.string(("a\rb").split(",")));
		for (i350 in 2...H.lim((K9.K9B : Int))) {
			H.tick();
			final v351:Array<Int> = ([] : Array<Int>);
		}
		for (x352 in ([a71] : Array<Float>)) {
			H.tick();
			if (([a71, a71, a71]).contains(a71)) {
				var v353:Bool = false;
				(new C16("ab")).m20(a71, a71);
				a71 &= a71;
			} else {
				var v354:Array<Int> = [a71];
				H.out("o355 " + Std.string(true));
			}
			a71 = (Std.parseInt(Std.string(0x80000000)) ?? 0);
			H.out("o356 " + Std.string(0.30000000000000004));
		}
		H.out("o357 " + Std.string(Type.enumIndex(E3.E3A)));
		try {
			H.out("o358 " + Std.string((a71 += 3)));
			if (true) throw 76;
		} catch (ex359:Err) {
			H.out("caught Err " + ex359.errCode);
			H.out("o360 " + Std.string(Math.floor(1e3)));
		} catch (ex361:haxe.Exception) {
			H.out("caught " + H.exn(ex361));
			final v362:String = C29.f30;
		}
		(new C16(C29.f30)).m20(Lambda.fold([a71, a71, a71], (v363:Int, v364:Int) -> 273, 0), 162);
		{
			final lf365:(String) -> Int = (p366:String) -> (({x7: 212} : S6)).x7;
			H.out("o367 " + "ünï");
		}
		return ([for (i368 in [a71, a71]) if (true) a71]).join("|");
	}
	public static function fn73():Int {
		H.tick();
		H.out("o369 " + Std.string(true));
		var v370 = (Std.string(1.7976931348623157e308) < "-7");
		C29.f30 += "\"q\"";
		return Std.int((K9.K9B : Int));
	}
	public static function fn74(?a75:Null<Int>):String {
		H.tick();
		var v371:A8 = new A8(Reflect.compare(238, 298));
		H.out("o372 " + Std.string(H.at(([] : Array<Int>), (v371).twice, 0)));
		var v373:Box<Array<S6>> = new Box<Array<S6>>(([] : Array<S6>));
		var v374:Float = Math.abs(Std.parseFloat("3"));
		var v375:Array<Array<String>> = (([["\x41\x42", "0"], ["日本語", "é", "\x41\x42"]] : Array<Array<String>>)).concat(([["x,y,z", "\u{1F600}", "a"], ["ab"], ["A-B-C", "a"]] : Array<Array<String>>));
		if (Ext.ext93([295], 37468031)) {
			try {
				if (StringTools.startsWith("\u{1F600}", "A-B-C")) throw "boom";
				final v376:Box<S6> = new Box<S6>(({x7: 191} : S6));
				var v377 = true;
			} catch (ex378:String) {
				H.out("caught String " + ex378);
				final v379:(String, Float) -> Float = (p380:String, p381:Float) -> p381;
			} catch (ex382:Int) {
				H.out("caught Int " + ex382);
				H.out("o383 " + Std.string(ex382));
				var v384 = "ab";
			} catch (ex385:Err) {
				H.out("caught Err " + ex385.errCode);
				var v386 = "42";
				final v387:(Int, String) -> String = (p388:Int, p389:String) -> v386;
			} catch (ex390:Dynamic) {
				H.out("caught " + H.exn(ex390));
				var v391:Float = 1e3;
			}
		} else {
			try {
				final v392 = true;
				if (([553192050, 234]).contains(139)) throw Std.string(true);
			} catch (ex393:Dynamic) {
				H.out("caught " + H.exn(ex393));
				H.out("o394 " + "\\");
				H.out("o395 " + Std.string(0x1626));
			}
		}
		var v396:Array<Int> = (([] : Array<Int>)).filter(v397 -> false);
		var v398 = (StringTools.lpad("x,y,z", "*", 3)).substr(-1, (Type.enumIndex(E0B(true, 261)) & 7));
		H.out("o399 " + Std.string((E3.E3A).match(E3A)));
		return (Std.string(false) + (v398).replace("a", "b"));
	}
	public static function fn76(...r77:Int):String {
		H.tick();
		for (i400 in 0...H.lim(H.id(122))) {
			H.tick();
			switch (E3.E3A) {
				case E3A: {
					final v401:Box<Box<String>> = new Box<Box<String>>(new Box("\x41\x42"));
				};
			}
			if (true) {
				var v402:Box<Bool> = new Box<Bool>(false);
			}
			Main.fn66((new A8(i400)).get(), new Box("é"), i400);
		}
		final lf403:(Int) -> Float = (p404:Int) -> p404;
		for (i405 in 2...H.lim((new C45(229, 267)).m11(("0").replace("a", "b")))) {
			H.tick();
			var w406 = 0;
do {
				w406++;
				H.tick();
				H.out("o407 " + Std.string(["a\rb"]));
				var v408 = false;
			} while (w406 < 1 && (Std.downcast((new C29(i405, ([] : Array<Int>)) : C29), C29) != null));
		}
		final lf409:(Float) -> Int = function(p410:Float):Int {
			H.tick();
			H.out("o411 " + Std.string((-1798646)));
			return 223;
		};
		final v412:E3 = E3.E3A;
		H.out("o413 " + ((E3.E3A).match(E3A) ? "abc" : Std.string((-2.5))));
		return Main.fn74(((({x5: 0x7F6B} : S4)).x5 >>> ((("x,y,z").charCodeAt(189) ?? -1) & 31)));
	}
	public static function fn78(a79:Array<String>, a80:Int, a81:String):C57 {
		H.tick();
		switch (Main.fn73()) {
			case 0: {
				switch (K9.K9D) {
					case K9.K9A: {
						H.out("o414 " + Std.string((K9.K9B : Int)));
					};
					case K9.K9B: {
						final v415:Box<Box<Int>> = new Box<Box<Int>>(new Box(a80));
						var v416 = true;
					};
					case K9.K9C: {
						H.out("o417 " + Std.string(a80));
						C45.m49("42");
					};
					case K9.K9D: {
						final v418:Bool = true;
					};
				}
				switch ((-2147483647)) {
					case 0: {
						H.out("o419 " + Std.string(((a80 : A8) : Int)));
						(new C51(a80)).m13(a80, "42");
					};
					case 1 | 5: {
						H.out("o420 " + Std.string(([] : Array<E0>)));
					};
					case c421 if (c421 > 10): {
						var v422:Float = c421;
						final v423 = c421;
					};
					case _: {
						H.out("o424 " + Std.string(false));
					};
				}
			};
			case 3 | 6: {
				(new C51(219)).m11("  pad  ");
			};
			case _: {
				H.out("o425 " + Std.string(242));
			};
		}
		var v426:Float = a80;
		if (({ var v427 = ([2044755254, a80]).length; false; })) {
			H.out("o428 " + a81);
			H.out("o429 " + Std.string(([new C29(v426, [134, 174, 195]), new C29(a80, [270, a80, 176]), new C29((-2.5), [a80, 0x3DB4, a80])] : Array<C29>)));
			var v430:String = "42";
		} else {
			for (x431 in [false, false, true]) {
				H.tick();
				(new C51(a80)).m13(a80, a81);
				C29.m36(x431);
			}
		}
		function lf432(n433:Int):Int {
			H.tick();
			return n433 <= 0 ? fn73() : (lf432(n433 - 1) + (([a80, 83]).contains(93) ? (Std.parseInt("A-B-C") ?? 0) : (a79).indexOf(a81)));
		}
		H.out("lf432 " + lf432(0));
		final v434:C45 = (cast (new C45(a80, a80)) : C45);
		switch (E0A) {
			case E0A: {
				var v435:String = "ab";
				H.out("o436 " + Std.string(new C45(86, a80)));
			};
			case E0B(c437, c438): {
				v426 = H.id(v426);
			};
		}
		H.out("o439 " + Std.string(C29.m36(true)));
		return new C57((StringTools.replace("hello world", "a", a81)).substr(2, (("ab").lastIndexOf(a81) & 7)));
	}
	public static function fn82(a83:Array<String>, a84:Bool, a85:String):Int {
		H.tick();
		var v440:C57 = new C57(Std.string(20));
		var v441:Array<Int> = ((true ? [216, 259] : [120]) : Array<Int>);
		for (i442 in 0...2) {
			H.tick();
			final lf443:() -> Void = function():Void {
				H.tick();
				Main.fn66(i442, new Box("A-B-C"), 188);
				H.out("o444 " + "ünï");
			};
		}
		final v445:E0 = ({ var v446 = (a85).length; E0.E0B(false, v446); });
		if (a84) {
			H.out("o447 " + Std.string(([] : Array<Int>)));
		} else {
			for (x448 in v441) {
				H.tick();
				var v449:Array<Int> = v441;
				if (false) continue;
			}
			a85 += "q";
		}
		var v450:String = String.fromCharCode(65 + ((1129562427) & 15));
		if (false) {
			var v451 = StringTools.trim("é");
		}
		(new C16((v441).join("|"))).m26((Math.floor(1e3) >> (Math.ceil(1e-7) & 31)), (cast (Math.isNaN((-2.5))) : Bool));
		var v452:String = (("\t").toUpperCase()).replace("a", "b");
		return (new C51((-18))).m11((true ? v450 : v450));
	}
	public static function fn86(...r87:Int):Bool {
		H.tick();
		var v453:E0 = E0B(true, 0x4859);
		for (x454 in (["a\rb"]).filter(v455 -> false)) {
			H.tick();
			Main.fn74(0x7FFFFFFF);
		}
		H.out("o456 " + Std.string(E0A));
		if (((K9.K9B : Int) < 42)) {
			H.out("o457 " + Std.string((Std.parseInt(Std.string(211)) ?? 0)));
			var v458:Box<Bool> = new Box(false);
		}
		final v459 = (switch (("\t").toLowerCase()) {
			case "a" | "b": true;
			case "Haxe": false;
			case "": true;
			case _: true;
		});
		for (i460 in 0...H.lim(195)) {
			H.tick();
			for (x461 in ([1e21, i460, i460] : Array<Float>)) {
				H.tick();
				H.out("o462 " + Std.string(new C45(i460, (-6))));
				H.out("o463 " + Std.string(v453));
			}
			H.out("o464 " + Std.string(new C45(i460, i460)));
			var w465 = 0;
while (w465 < 5 && v459) {
				w465++;
				H.tick();
				var v466 = v459;
			}
		}
		(new C29(1.25, [144, 52])).m38(false, ([for (i467 in 0...0) 258] : Array<Float>));
		var v468:Float = (new Box<Float>(123456.789)).value;
		H.out("o469 " + Std.string(new C45(13, (Std.parseInt("ab") ?? 0))));
		return v459;
	}
	public static function fn88():Int {
		H.tick();
		switch (E3.E3A) {
			case E3A: {
				for (i470 in 2...5) {
					H.tick();
					if (false) continue;
					H.out("o471 " + Std.string(i470));
					var v472:String = "\t";
				}
			};
			case _: {
				if (true) {
					var v473:Int = 256;
				}
				(new C16("ünï")).m24();
			};
		}
		switch (H.id((new C16("q")).m23())) {
			case []: {
				(new C29(1e-7, ([] : Array<Int>))).m34(true);
				if (StringTools.startsWith("  pad  ", "\t")) {
					var v474:Box<K9> = new Box<K9>(K9.K9B);
					H.out("o475 " + "日本語");
				} else {
					var v476:I10 = new C45(0xA504, 98);
				}
			};
			case [c477]: {
				try {
					var v478:K9 = K9.K9D;
					if (false) throw "a\rb";
				} catch (ex479:String) {
					H.out("caught String " + ex479);
					var v480 = ex479;
					final v481:(Int) -> Int = (p482:Int) -> c477;
				} catch (ex483:Int) {
					H.out("caught Int " + ex483);
					var v484:Array<Int> = ([] : Array<Int>);
					H.out("o485 " + Std.string(false));
				} catch (ex486:Err) {
					H.out("caught Err " + ex486.errCode);
					fn62(c477, false, ([] : Array<Int>));
				} catch (ex487:Dynamic) {
					H.out("caught " + H.exn(ex487));
					var v488:Int = c477;
					v488 += c477;
				}
			};
			case [_, c489]: {
				var v490:Float = c489;
				H.out("o491 " + Std.string(true));
			};
			case _: {
				var v492:String = "ab";
			};
		}
		C29.m36((true ? true : Math.isNaN(2.5e-3)));
		if ((65 == 0xE258)) {
			if (true) return ((141 : A8) : Int);
			var v493 = (K9.K9C : Int);
			var v494:Int = v493;
		}
		H.out("o495 " + Std.string(((E0B(false, 96)).match(E0A) ? ("\t").indexOf("0") : (([1.25] : Array<Float>)).length)));
		var v496:Bool = (new C29(100.75, [(-10), 247, 254])).m13(89, "-7");
		H.out("o497 " + StringTools.trim(""));
		return (new C45((Std.parseInt(Std.string(0xFFFFFFFF)) ?? 0), (K9.K9B : Int))).m11(StringTools.replace(StringTools.trim("é"), " ", Std.string(v496)));
	}
	public static function section0():Void {
		H.tick();
		Main.fn66((new C51(115)).m11("\n"), new Box<String>(C29.f30), (new Box(5)).value);
		var v518:String = "";
		var v519:S4 = ({x5: 1028358815} : S4);
		for (i520 in 0...H.lim((switch (E0B(false, 175)) {
			case E0A: (("\\").charCodeAt(250) ?? -1);
			case E0B(_, c521): (v518).indexOf(v518);
		}))) {
			H.tick();
			for (i522 in 0...2) {
				H.tick();
				final v523:Array<String> = ["x,y,z"];
				var v524:Int = i520;
				var v525 = "ünï";
			}
			var v526:Bool = (Std.downcast((new C16("é") : C16), C16) != null);
		}
		for (i527 in 0...H.lim((117 ^ (Std.parseInt(Std.string(294)) ?? 0)))) {
			H.tick();
			var v528:Array<Int> = ([] : Array<Int>);
			fn82([v518, v518, v518], false, StringTools.replace("abc", ",", v518));
		}
		var v529:Array<Int> = (new C16(v518)).m23();
		var v530 = (v529).contains((v519).x5);
		var v531:Float = (((288 : A8) : Int) / (-2.5));
	}
	public static function section1():Void {
		H.tick();
		var v532:A8 = (-new A8(146));
		switch ((199 - H.at(([] : Array<Int>), 0x3069, 0))) {
			case 0: {
				var v533:Int = Math.round(1.7976931348623157e308);
			};
			case 1 | 6: {
				final v534:Int = 65535;
			};
			case c535 if (c535 > 10): {
				var v536:Float = c535;
			};
			case _: {
				var v537 = Type.enumIndex(E0.E0A);
				H.out("o538 " + Std.string(E0.E0B(false, v537)));
			};
		}
		var v539:Int = C51.m54((["é"]).length, Math.isNaN(1e3));
		H.out("o540 " + Std.string((K9.K9B : Int)));
		if ((("Haxe").length >= 0xA018)) {
			if (false) {
				var v541:E0 = E0B(true, v539);
			}
			if (true) {
				H.out("o542 " + Std.string(new Box<E3>(E3.E3A)));
			}
			var v543:Bool = true;
		} else {
			if (StringTools.contains("ünï", "\t")) {
				v539 = 0x32DC;
			} else {
				C57.m60(278);
				C51.m54(v539, true);
			}
		}
		function lf544(n545:Int):Int {
			H.tick();
			return n545 <= 0 ? (switch (270) {
			case 0: n545;
			case 3 | 4: n545;
			case _: H.at(([] : Array<Int>), v539, 0);
		}) : (lf544(n545 - 1) + (({x5: n545} : S4)).x5);
		}
		H.out("lf544 " + lf544(5));
		if ((false ? Std.isOfType(new C29((-2.5), ([] : Array<Int>)), I10) : ([1, v539, v539]).contains(v539))) {
			final v546:(String) -> Int = (p547:String) -> 158;
			H.out("o548 " + C29.f30);
		} else {
			var w549 = 0;
do {
				w549++;
				H.tick();
				H.out("o550 " + Std.string((v532 : Int)));
				final v551:Box<Bool> = new Box(true);
				var v552:A8 = v532;
			} while (w549 < 3 && StringTools.contains("日本語", "q"));
			if (StringTools.contains("ünï", "0")) {
				var v553:Array<Bool> = ([] : Array<Bool>);
				v539 = H.id(v539);
				(new C51((-802285612))).m13(v539, "-7");
			} else {
				final v554 = true;
			}
		}
		v539 = H.id(v539);
	}
	public static function section2():Void {
		H.tick();
		for (i555 in 0...H.lim((true ? 0x56E3 : 81))) {
			H.tick();
			{
				C57.m60(i555);
			}
			var v556:Array<Int> = [i555, i555, i555];
			final v557:Box<String> = new Box("hello world");
		}
		final lf558:(String) -> String = (p559:String) -> (switch (E0A) {
			case E0A: (p559).toLowerCase();
			case E0B(_, _): p559;
		});
		C29.f30 = H.cap((([false, false]).join(" ") + "-7"));
		try {
			if ((true && ([123]).contains(15))) throw (switch (0x80000000) {
				case 0: C29.f30;
				case 2 | 4: Std.string(1e-7);
				case c560 if (c560 > 10): ("ünï").substr(4, -1);
				case _: ("abc").toUpperCase();
			});
			var v561 = C29.f30;
		} catch (ex562:String) {
			H.out("caught String " + ex562);
			H.out("o563 " + Std.string(new C51((-2147483647))));
		} catch (ex564:Int) {
			H.out("caught Int " + ex564);
			var v565:S4 = ({x5: ex564} : S4);
			H.out("o566 " + Std.string(ex564));
		} catch (ex567:Err) {
			H.out("caught Err " + ex567.errCode);
			for (i568 in 0...0) {
				H.tick();
				var v569:I10 = new C51(i568);
				Main.fn86();
				final v570:Bool = true;
			}
			var v571:Array<Float> = ([123456.789, 0.1, 1e3] : Array<Float>);
		} catch (ex572:Dynamic) {
			H.out("caught " + H.exn(ex572));
			var v573:E0 = E0A;
			(new C29(2.5e-3, ([] : Array<Int>))).m41(62, (({x5: (-15)} : S4)).x5);
		}
		var v574:E0 = ((true ? E0.E0B(false, 7) : E0.E0B(false, 258)) : E0);
		function lf575(n576:Int):Int {
			H.tick();
			return n576 <= 0 ? 277 : (lf575(n576 - 1) + ((E3.E3A).match(E3A) ? Reflect.compare(n576, n576) : (new A8(n576)).get()));
		}
		H.out("lf575 " + lf575(2));
		var v577:Int = (K9.K9D : Int);
	}
	public static function section3():Void {
		H.tick();
		try {
			if ((true ? (Std.downcast((new C51(270) : I10), C51) != null) : ([0xE739, 120, 173]).contains(48))) throw (StringTools.lpad("abc", "*", (152 & 7)) + true);
			for (i578 in 0...H.lim(Reflect.compare("é", "-7"))) {
				H.tick();
				var v579:String = "日本語";
			}
			H.out("o580 " + Std.string(([201]).contains(0x7876)));
			for (i581 in 0...2) {
				H.tick();
				var v582:Array<Float> = ([0.1, i581, i581] : Array<Float>);
			}
		} catch (ex583:Dynamic) {
			H.out("caught " + H.exn(ex583));
			var w584 = 0;
while (w584 < 2 && true) {
				w584++;
				H.tick();
				final v585:Array<Int> = [4];
			}
		}
		(new C51(1893049764)).m11(StringTools.hex(((new A8(24)).get()) & 0xFFFF, 4));
		final v586:A8 = (Type.enumIndex(E0B(false, 247)) : A8);
		var v587:Int = H.at([199], Math.round(123456.789), 0);
	}
	public static function section4():Void {
		H.tick();
		for (x588 in [C29.f30, Std.string(123456.789), C29.f30]) {
			H.tick();
			var v589 = Math.isNaN(1e-7);
		}
		(new C45(Std.int(123456.789), H.at([67, 5], 122, 0))).m13(148, "ab");
		switch (H.id((((E3.E3A).match(E3A) ? [18, 1218864489, 2130479127] : ([] : Array<Int>)) : Array<Int>))) {
			case []: {
				H.out("o590 " + Std.string(0.1));
				switch (E0.E0A) {
					case E0A: {
						var v591:Float = 1e-7;
					};
					case _: {
						var v592:Array<Box<Int>> = ([new Box(0x7FFFFFFF), new Box<Int>(271), new Box(0x7FFFFFFF)] : Array<Box<Int>>);
					};
				}
			};
			case [c593]: {
				H.out("o594 " + Std.string(([E0.E0A, E0B(true, c593), E0.E0A] : Array<E0>)));
				H.out("o595 " + Std.string(new Box(c593)));
			};
			case [_, c596]: {
				H.out("o597 " + Std.string(("0").length));
			};
			case _: {
				for (x598 in ([] : Array<Bool>)) {
					H.tick();
					var v599:Array<Int> = [65535, 40437098, 139];
				}
			};
		}
		try {
			if (!(([] : Array<Int>)).contains(174)) throw 61;
			final v600:Array<Float> = ([1e100, 0.1] : Array<Float>);
			H.out("o601 " + Std.string(E0.E0B(false, 233)));
			for (i602 in 0...2) {
				H.tick();
				H.out("o603 " + Std.string(new C51(i602)));
			}
		} catch (ex604:String) {
			H.out("caught String " + ex604);
			if (false) {
				H.out("o605 " + Std.string(([] : Array<S4>)));
				H.out("o606 " + ex604);
			} else {
				H.out("o607 " + Std.string(true));
				var v608:String = ex604;
			}
			if (true) {
				var v609:E3 = E3.E3A;
				final v610:String = ex604;
			} else {
				var v611:A8 = new A8((-16));
				var v612:Array<K9> = ([K9.K9A] : Array<K9>);
			}
		} catch (ex613:Int) {
			H.out("caught Int " + ex613);
			if (false) {
				H.out("o614 " + "Haxe");
			} else {
				var v615 = ex613;
				final v616:E0 = E0.E0B(false, v615);
			}
		} catch (ex617:Err) {
			H.out("caught Err " + ex617.errCode);
			switch (E3.E3A) {
				case E3A: {
					Main.fn76();
				};
				case _: {
					var v618 = 0xD68E;
					(new C45(v618, v618)).m11("  pad  ");
				};
			}
		} catch (ex619:Dynamic) {
			H.out("caught " + H.exn(ex619));
			H.out("o620 " + Std.string(new C45(229, 0x63E3)));
			var v621:C29 = new C29(123456.789, ([] : Array<Int>));
		}
		H.out("o622 " + Std.string((((false ? new A8(227) : new A8(47)) : A8) : Int)));
		for (i623 in 1...3) {
			H.tick();
			var v624:C51 = new C51(i623);
		}
		for (i625 in 0...H.lim(((("\t").charCodeAt(255) ?? -1) - (Std.parseInt(Std.string((-265125972))) ?? 0)))) {
			H.tick();
			H.out("o626 " + Std.string(i625));
			(new C16("hello world")).m20(i625, 0x7FFFFFFF);
			var v627:Array<Int> = ([] : Array<Int>);
		}
		var v628:Bool = (37 < (-2.5));
		final lf629:() -> Int = Main.fn73;
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
