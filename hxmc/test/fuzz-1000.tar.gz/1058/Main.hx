import H;
import p.M1;
import p.q.M2;
using p.Ext;

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

enum abstract K6(Int) to Int {
	var K6A = 1;
	var K6B = 4;
	var K6C = 7;
}

class Main {
	public static function fn42():Int {
		H.tick();
		(new C19(false)).m14((new C25()).m23((([] : Array<Int>)).contains(267)));
		if ((65535 <= C33.f34)) {
			final v147:C33 = new C33(146);
		} else {
			C7.m16((([2.5e-3, 1e3] : Array<Float>)).length, 0x80000000);
			{
				C33.f34 = 34;
				(new C33(121)).m39();
				C33.f34 = 125;
			}
		}
		(((true ? new C25() : new C19(false)) : C19)).m22();
		C7.m16((-1776277947), 45);
		var v148:Map<String, A5> = new Map<String, A5>();
		return Math.round(1e3);
	}
	public static function fn43():Int {
		H.tick();
		var v149:Int = (K6.K6B : Int);
		if ((Reflect.compare(100, v149) > v149)) return v149;
		switch (((new Map<String, Int>()).get("k1") ?? 0)) {
			case 0: {
				v149++;
				var v150:Int = H.at([v149, 294], v149, 0);
			};
			case 3 | 6: {
				var v151:Bool = true;
			};
			case _: {
				H.out("o152 " + Std.string(C25.f26));
				H.out("o153 " + Std.string(83));
			};
		}
		final v154:C29 = new C29(([v149, v149, v149]).indexOf(v149));
		return 178;
	}
	public static function fn44(a45:S1, a46:Int, a47:Int):E0 {
		H.tick();
		C33.f34 += (Math.ceil(a46) + a47);
		H.out("o155 " + Std.string(false));
		if (true) {
			var v156:Float = C33.f34;
		}
		H.out("o157 " + Std.string(203));
		var v158:Map<Int, Int> = new Map<Int, Int>();
		C33.f34 = (new A5(283) : Int);
		switch (E0.E0A) {
			case E0A: {
				var v159:Array<K6> = ([K6.K6B] : Array<K6>);
			};
		}
		C33.f34 = 148;
		return E0.E0A;
	}
	public static function fn48():A5 {
		H.tick();
		var v160 = (Std.downcast((new C7(([2.5e-3, 1e100, 0.1] : Array<Float>)) : C7), C7) != null);
		C7.m16((C25.f26 + Math.floor(0.1)), 81);
		var v161:Map<String, Int> = (["k0" => 65535, "k1" => 256, "k2" => 0x80000000] : Map<String, Int>);
		C33.f34 -= ((Std.parseInt(Std.string(0x80000000)) ?? 0) * (K6.K6A : Int));
		H.out("o162 " + Std.string(({x3: Math.round(7.0), x2: ([false, v160]).indexOf(v160), x4: "a"} : S1)));
		(new C19(v160)).m23((Math.isNaN(0.5) || v160));
		return ((new C25()).m23(false) : A5);
	}
	public static function fn49(a50:Bool, a51:Bool, a52:Int):Bool {
		H.tick();
		switch (K6.K6A) {
			case K6.K6A: {
				switch (K6.K6A) {
					case K6.K6A: {
						var v163:Array<Int> = [a52, 145];
						C25.f26 = a52;
					};
					case K6.K6B: {
						final v164:Null<Int> = a52;
						fn48();
					};
					case K6.K6C: {
						C25.f26 += a52;
					};
				}
			};
			case K6.K6B: {
				H.out("o165 " + Std.string(([] : Array<Int>)));
				final v166:C7 = new C25();
			};
			case K6.K6C: {
				{
					var v167:Bool = true;
					var v168:Int = a52;
				}
			};
		}
		var v169:A5 = (((([-3 => a52] : Map<Int, Int>)).get(-3) ?? 0) : A5);
		(new C25()).m22();
		return a50;
	}
	public static function fn53(a54:C25, a55:Int, a56:Int):Int {
		H.tick();
		if (([a56, 134, a56]).contains((K6.K6B : Int))) {
			switch (false) {
				case true: {
					H.out("o170 " + Std.string(a56));
				};
				case false: {
					(new C33(a56)).m39();
				};
			}
		} else {
			C25.f26 = (K6.K6A : Int);
		}
		var v171:E0 = E0.E0A;
		a56 = (-H.at([124, 1094040891, 0x91DE], a56, 0));
		C25.f26--;
		H.out("o172 " + Std.string([a56]));
		return Main.fn42();
	}
	public static function fn57(a58:E0, a59:C7, a60:Bool):E0 {
		H.tick();
		var v173:E0 = a58;
		var v174 = (-(new A5(64)).get());
		switch (K6.K6A) {
			case K6.K6A: {
				H.out("o175 " + Std.string(E0.E0A));
			};
			case K6.K6B: {
				function lf176(n177:Int):Int {
					H.tick();
					return n177 <= 0 ? n177 : (lf176(n177 - 1) + 31);
				}
				H.out("lf176 " + lf176(1));
				if (a60) return E0.E0A;
			};
			case K6.K6C: {
				H.out("o178 " + Std.string(new C33(v174)));
				(new C7(([] : Array<Float>))).m14(12271128);
			};
		}
		C7.m16(182, 114);
		++v174;
		if ((Reflect.compare(v174, v174) >= 23)) {
			{ var dyn179:Dynamic = ({x2: v174, x4: "  pad  ", x3: 154} : S1); H.out("dyn " + Std.string(dyn179.x2) + " " + Std.string(Reflect.field(dyn179, "x2"))); }
			function lf180(n181:Int):Int {
				H.tick();
				return n181 <= 0 ? (-197932764) : (lf180(n181 - 1) + (Std.parseInt(Std.string(v174)) ?? 0));
			}
			H.out("lf180 " + lf180(0));
			function lf182(n183:Int):Int {
				H.tick();
				return n183 <= 0 ? Reflect.compare(v174, 0x9903) : (lf182(n183 - 1) + (K6.K6B : Int));
			}
			H.out("lf182 " + lf182(4));
		} else {
			var v184:Array<C33> = ([new C33(0x7FFFFFFF)] : Array<C33>);
			var v185:K6 = K6.K6A;
		}
		var v186:Array<Int> = ([] : Array<Int>);
		var v187:Int = 82;
		return E0.E0A;
	}
	public static function fn61(a62:Int):E0 {
		H.tick();
		fn53(new C25(), (a62 - a62), Math.round(a62));
		var v188 = (switch (E0.E0A) {
			case E0A: true;
		});
		H.out("o189 " + Std.string((true ? Reflect.compare(a62, a62) : 274)));
		a62 -= C7.m16((a62 = 5), a62);
		C33.f34 *= a62;
		switch ((22 - a62)) {
			case 0: {
				{
					C33.f34 = 158;
					C25.f26 = a62;
					final v190 = v188;
				}
			};
			case 3 | 5: {
				final lf191:(Float) -> Int = function(p192:Float):Int {
					H.tick();
					var v193:C33 = new C33(a62);
					return (new A5(126)).twice;
				};
				if (false) return E0.E0A;
			};
			case _: {
				final v194:E0 = E0.E0A;
			};
		}
		C33.f34 = (v188 ? Std.int(1.25) : (++a62));
		return ({ var v195 = v188; (cast (E0.E0A) : E0); });
	}
	public static function section0():Void {
		H.tick();
		switch ((new C33(292)).m40(Std.isOfType(new C33(169), C29))) {
			case 0: {
				Main.fn49(true, Std.isOfType(new C25(), C25), 40);
				var v211:Array<Bool> = [false, true, false];
			};
			case 1 | 4: {
				if (false) {
					H.out("o212 " + Std.string(95));
				} else {
					H.out("o213 " + Std.string(new C25()));
				}
			};
			case _: {
				final v214:Array<Float> = ([] : Array<Float>);
			};
		}
		final v215:Array<Int> = [for (i216 in [(-16)]) if (true) 0xFD25];
		if (Main.fn49(true, false, (-87746577))) {
			final v217:Map<String, Float> = new Map<String, Float>();
			C25.f26 = (v215).length;
		}
		switch ((Math.ceil(2.5e-3) <= 237)) {
			case true: {
				var v218:Array<Int> = ([] : Array<Int>);
			};
			case false: {
				++C33.f34;
			};
		}
	}
	public static function section1():Void {
		H.tick();
		final v219:Array<Bool> = [false, true];
		H.out("o220 " + Std.string(new C25()));
		var v221:Array<Float> = ([Std.parseFloat("1.5"), 7.0, 51] : Array<Float>);
		H.out("o222 " + Std.string(true));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
