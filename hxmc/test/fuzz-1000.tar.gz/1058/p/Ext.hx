package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class Ext {
	public static function ext64(a63:Int):Int {
		H.tick();
		function lf196(n197:Int):Int {
			H.tick();
			return n197 <= 0 ? a63 : (lf196(n197 - 1) + Main.fn53(new C25(), n197, n197));
		}
		H.out("lf196 " + lf196(5));
		(new C25()).m23(Main.fn49(false, (([] : Array<Int>)).contains(a63), a63));
		var v198:Array<String> = [for (i199 in [a63]) if (false) "\t"];
		return C25.f26;
	}
	public static function ext66(a65:String):Int {
		H.tick();
		switch (E0.E0A) {
			case E0A: {
				H.out("o200 " + Std.string(([140, 277]).contains(174)));
				H.out("o201 " + Std.string(49));
			};
		}
		var v202 = C33.f34;
		final v203:K6 = K6.K6C;
		H.out("o204 " + Std.string((cast (Math.isNaN(v202)) : Bool)));
		var v205:Array<Int> = [Reflect.compare(42, 137), (([] : Array<Bool>)).length];
		final v206 = Main.fn49(false, false, C25.f26);
		var v207:Map<String, Int> = (["k0" => v202] : Map<String, Int>);
		if (([v202, v202]).contains(68)) {
			H.out("o208 " + Std.string(({x2: v202, x3: v202, x4: a65} : S1)));
			H.out("o209 " + Std.string((new A5(v202) : Int)));
		}
		H.out("o210 " + Std.string(new C7(([v202] : Array<Float>))));
		return 138;
	}
}
