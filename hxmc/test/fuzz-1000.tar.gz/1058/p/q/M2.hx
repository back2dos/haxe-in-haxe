package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;

class M2 {}

typedef S1 = {x2:Int, x3:Int, x4:String};

class C7 {
	public var f8:Int;
	var _f9:Float;

	public var f9(get, set):Float;

	function get_f9():Float
		return _f9;

	function set_f9(v:Float):Float
		return _f9 = v;
	public var f10:Int;
	public function new(a11:Array<Float>) {
		this.f8 = Math.round(0.5);
		this._f9 = 0.5;
		this.f10 = (Std.parseInt(Std.string((-20))) ?? 0);
	}
	public static function m12(a13:Array<Int>):Void {
		H.tick();
		if (Main.fn49(((["k0" => E0.E0A] : Map<String, E0>)).exists("k0"), true, 135)) {
			H.out("o67 " + Std.string(C25.f26));
			function lf68(n69:Int):Int {
				H.tick();
				return n69 <= 0 ? n69 : (lf68(n69 - 1) + (-9));
			}
			H.out("lf68 " + lf68(3));
			switch (E0.E0A) {
				case E0A: {
					var v70 = 175;
				};
			}
		}
		var v71:Map<Int, String> = new Map<Int, String>();
		if (a13.length > 0) a13[H.ix(181, a13.length)] = Reflect.compare(H.at(a13, (-1637925078), 0), C33.f34);
		C33.f34 = ((["-7", "ab", "Haxe"]).indexOf("") + C33.f34);
	}
	public function m14(a15:Int):Array<Float> {
		H.tick();
		final v72 = (new A5(a15)).twice;
		if ((1e3 <= 1.25)) {
			var v73:Bool = false;
			H.out("o74 " + Std.string(false));
		} else {
			var v75 = v72;
			var v76:S1 = ({x4: "ab", x3: 203, x2: 254} : S1);
		}
		function lf77(n78:Int):Int {
			H.tick();
			return n78 <= 0 ? (v72 + (--a15)) : (lf77(n78 - 1) + (-18));
		}
		H.out("lf77 " + lf77(4));
		H.out("o79 " + Std.string(C33.f34));
		return ([] : Array<Float>);
	}
	public static function m16(a17:Int, a18:Int):Int {
		H.tick();
		var v80:Int = a17;
		if ((a17 >= 25)) {
			H.out("o81 " + Std.string((({x3: v80, x4: "\\", x2: a18} : S1)).x3));
			(new C19(true)).m14(v80);
		}
		var v82:Float = 1.25;
		(new C19(true)).m14(((({x4: "\"q\"", x3: v80, x2: v80} : S1)).x3 * 0x80000000));
		return (new A5((({x2: 174, x3: 180, x4: "\\"} : S1)).x3)).get();
	}
}

class C19 extends C7 {
	public var f20:E0;
	public function new(a21:Bool) {
		super(([(-2.5), 0.1] : Array<Float>));
		this.f20 = E0.E0A;
	}
	public function m22():Int {
		H.tick();
		C25.f26 -= C7.m16(263, this.f8);
		switch (E0.E0A) {
			case E0A: {
				C7.m16((-183197331), 55);
			};
			case _: {
				switch (Reflect.compare(41, 280)) {
					case 0: {
						var v83:Array<Bool> = [true, true];
						C25.f26 -= 194;
					};
					case 3 | 6: {
						(new C7(([7.0] : Array<Float>))).m14(0x7FFFFFFF);
					};
					case _: {
						var v84:C29 = new C33(2);
					};
				}
				this.f10--;
			};
		}
		var v85:S1 = ({x2: this.f10, x3: (Std.parseInt(Std.string(0xCE36)) ?? 0), x4: "a"} : S1);
		H.out("o86 " + Std.string(this.f8));
		switch (K6.K6B) {
			case K6.K6A: {
				if (false) {
					H.out("o87 " + Std.string(130));
					this.f10 = 91;
					var v88:E0 = E0.E0A;
				}
			};
			case K6.K6B: {
				H.out("o89 " + Std.string(false));
				H.out("o90 " + Std.string([(-1), 230, 177]));
			};
			case K6.K6C: {
				C25.f26 = Math.floor(123456.789);
			};
		}
		return C7.m16(7, C7.m16((v85).x3, 110));
	}
	public function m23(a24:Bool):Int {
		H.tick();
		if (([21, (-16)]).contains((([] : Array<Bool>)).indexOf(a24))) return ((([-3 => 76] : Map<Int, Int>)).get(-3) ?? 0);
		C7.m16((Std.parseInt(Std.string(0x8398)) ?? 0), ((new A5(1450039477)).twice % H.nz((Std.parseInt("-7") ?? 0))));
		var v91:Int = (-H.at([221, 74, 124], 206, 0));
		final v92 = v91;
		return this.m22();
	}
}

class C29 {
	public function new(a30:Int) {}
	public function m31():E0 {
		H.tick();
		final v95:Bool = (true ? ([137]).contains(271) : (([-3 => 0x27DF] : Map<Int, Int>)).exists(11));
		if ((((([-3 => 0x7FFFFFFF, 4 => 179, 11 => 355129249] : Map<Int, Int>)).get(-3) ?? 0) >= C25.f26)) {
			switch (Reflect.compare(45, 205)) {
				case 0: {
					H.out("o96 " + Std.string([49, 0x80000000, 159]));
				};
				case 3 | 4: {
					var v97:S1 = ({x2: 163, x3: 0x8624, x4: "A-B-C"} : S1);
				};
				case _: {
					H.out("o98 " + Std.string(({x4: "42", x2: 241, x3: 294} : S1)));
				};
			}
			H.out("o99 " + Std.string(Math.ceil(2.5e-3)));
			var v100:E0 = E0.E0A;
		} else {
			final v101:Float = 282;
			switch (E0.E0A) {
				case E0A: {
					final v102:Array<Float> = ([123456.789, v101] : Array<Float>);
				};
			}
		}
		switch (E0.E0A) {
			case E0A: {
				if (false) {
					var v103 = 297;
					v103 += v103;
				}
				H.out("o104 " + Std.string((new A5(0x80000000) : Int)));
			};
		}
		function lf105(n106:Int):Int {
			H.tick();
			return n106 <= 0 ? C25.f26 : (lf105(n106 - 1) + C7.m16(Math.floor(n106), n106));
		}
		H.out("lf105 " + lf105(3));
		H.out("o107 " + Std.string((false ? false : true)));
		final v108 = !v95;
		return Main.fn44(({x2: (new A5(269)).twice, x3: C25.f26, x4: Std.string(E0.E0A)} : S1), 6, C7.m16((K6.K6B : Int), 33));
	}
	public function m32():Int {
		H.tick();
		var v109 = Main.fn43();
		var v110 = v109;
		var v111:Array<String> = [for (i112 in 0...0) (([] : Array<Bool>)).join("")];
		Main.fn43();
		var v113:Bool = (v110 == 56);
		function lf114(n115:Int):Int {
			H.tick();
			return n115 <= 0 ? C25.f26 : (lf114(n115 - 1) + (v109 + n115));
		}
		H.out("lf114 " + lf114(4));
		var v116:A5 = Main.fn48();
		return C25.f26;
	}
}
