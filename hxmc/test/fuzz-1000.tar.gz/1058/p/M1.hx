package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;

class M1 {}

enum E0 {
	E0A;
}

class C25 extends C19 {
	public static var f26:Int = 59;
	public var f27:Int;
	public final f28:Int;
	public function new() {
		super(([112231873]).contains((-13)));
		this.f27 = 225;
		this.f28 = (Std.parseInt(Std.string(0x796F)) ?? 0);
	}
	override public function m23(a24:Bool):Int {
		H.tick();
		var v93:Map<Int, String> = new Map<Int, String>();
		C7.m16(this.f10, m22());
		var v94:A5 = ((([10]).contains(1986332060) ? (188 : A5) : new A5(44)) : A5);
		this.m22();
		return 42;
	}
}

class C33 extends C29 {
	public static var f34:Int = (-12);
	public function new(a35:Int) {
		super((Std.parseInt(Std.string(250)) ?? 0));
	}
	public function m36(a37:Array<S1>, a38:Bool):Float {
		H.tick();
		m40(((Std.parseInt("a") ?? 0) == (({x2: 222, x3: (-2147483647), x4: "x,y,z"} : S1)).x2));
		C33.f34 = C25.f26;
		if ((cast (Std.isOfType(new C19(a38), C19)) : Bool)) {
			(new C33(196)).m39();
		} else {
			switch (Math.isNaN((-2.5))) {
				case true: {
					H.out("o117 " + Std.string(a38));
				};
				case false: {
					var v118:Array<Int> = ([] : Array<Int>);
				};
			}
		}
		H.out("o119 " + Std.string((({x2: 300, x4: "q", x3: 83} : S1)).x2));
		H.out("o120 " + Std.string((K6.K6C : Int)));
		(new C25()).m23(a38);
		final lf121:(Int, Bool) -> Void = function(p122:Int, p123:Bool):Void {
			H.tick();
			H.out("o124 " + Std.string(new C25()));
		};
		H.out("o125 " + Std.string((({x3: 222, x4: "q", x2: 157} : S1)).x3));
		H.out("o126 " + Std.string(new C33(Reflect.compare(299, 102))));
		return (((107 < 238) ? (222 - C33.f34) : Ext.ext64(0x80000000)) : Float);
	}
	public function m39():S1 {
		H.tick();
		if ((cast (false) : Bool)) {
			var v127:Array<Int> = [89];
			var v128:Array<Bool> = ([] : Array<Bool>);
		} else {
			{ var dyn129:Dynamic = ({x2: 114, x3: 270, x4: "0"} : S1); H.out("dyn " + Std.string(dyn129.x2) + " " + Std.string(Reflect.field(dyn129, "x2"))); }
			H.out("o130 " + Std.string(new C33(88)));
		}
		var v131 = (new C19(true)).m23(false);
		{
			var v132:C25 = new C25();
			var v133:Null<Int> = v131;
		}
		var v134:Float = 1.25;
		(new C25()).m22();
		H.out("o135 " + Std.string(v131));
		final v136:E0 = E0.E0A;
		return ({x3: (v131 + H.at([v131, 184], 271, 0)), x4: (["abc"]).join(""), x2: (switch ((({x2: 0x1E95, x3: 0x8797, x4: "abc"} : S1)).x3) {
			case 0: 30;
			case 1 | 6: (v131--);
			case _: v131;
		})} : S1);
	}
	public function m40(a41:Bool):Int {
		H.tick();
		H.out("o137 " + Std.string(C7.m16(283, (({x4: "  pad  ", x2: 96, x3: 0x7FFFFFFF} : S1)).x2)));
		C25.f26 -= 54;
		final lf138:(Bool, Int) -> Int = function(p139:Bool, p140:Int):Int {
			H.tick();
			var v141:Map<Int, Bool> = new Map<Int, Bool>();
			H.out("o142 " + Std.string((new A5(p140) : Int)));
			var v143:C19 = new C19(a41);
			return C33.f34;
		};
		C25.f26 = ((Std.parseInt(Std.string((-13))) ?? 0) + 0xE1D3);
		if ((([-3 => 135, 4 => 293] : Map<Int, Int>)).exists((new A5((-670247763)) : Int))) {
			final v144:E0 = E0A;
			C25.f26 = Type.enumIndex(E0A);
		} else {
			H.out("o145 " + Std.string(1.25));
			this.m39();
		}
		(new C25()).m14((-223));
		var v146:C25 = new C25();
		C25.f26 -= (Math.isNaN(1e-7) ? C33.f34 : 262);
		C25.f26 = Reflect.compare(88, C33.f34);
		return (([0x80000000]).contains(0x9CB1) ? (Type.enumIndex(E0A) * ((new Map<Int, Int>()).get(4) ?? 0)) : 182);
	}
}
