import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class Main {
	public static function fn1(a2:Bool, a3:Float):Int {
		H.tick();
		final lf26:(Float, String) -> Int = function(p27:Float, p28:String):Int {
			H.tick();
			for (x29 in ["日本語", "a\rb"]) {
				H.tick();
				H.out("o30 " + Std.string(249));
				final v31:String = p28;
			}
			if ((E0.E0A).match(E0A)) {
				H.out("o32 " + Std.string(true));
			}
			return (Std.parseInt(Std.string(((([-3 => 0xE592, 4 => 0x4F70] : Map<Int, Int>)).get(299) ?? 0))) ?? 0);
		};
		for (i33 in 0...1) {
			H.tick();
			a3 = 0.5;
			switch (Math.floor(a3)) {
				case 0: {
					var v34:Array<String> = ["日本語"];
					var v35:String = "a";
				};
				case 2 | 6: {
					var v36:Int = (-9);
					final v37:(String) -> String = (p38:String) -> p38;
				};
				case _: {
					H.out("o39 " + Std.string(i33));
					final v40:Float = i33;
				};
			}
			H.out("o41 " + Std.string((([-3 => a2] : Map<Int, Bool>)).exists(18)));
		}
		var v42:Bool = (65535 != Type.enumIndex(E0.E0C));
		var v43:Int = ("\t").length;
		v43 = H.id(v43);
		var v44 = Std.int(v43);
		if (v42) {
			final v45:(Int, String) -> Void = function(p46:Int, p47:String):Void {
				H.tick();
				H.out("o48 " + Std.string(([E0.E0B, E0.E0A] : Array<E0>)));
				var v49:Bool = a2;
			};
			if (v42) {
				H.out("o50 " + Std.string(v43));
				v44--;
			} else {
				final v51:Box<E0> = new Box<E0>(E0.E0C);
				var v52 = 712347224;
			}
			switch ((v43--)) {
				case 0: {
					var v53:Int = v43;
				};
				case 2 | 6: {
					final v54:() -> String = function():String {
						H.tick();
						H.out("o55 " + Std.string(245));
						a2 = v42;
						var v56 = v43;
						return "ab";
					};
				};
				case c57 if (c57 > 10): {
					var v58 = (-17);
					H.out("o59 " + Std.string(11));
				};
				case _: {
					v43 *= v43;
					H.out("o60 " + Std.string(v43));
				};
			}
		} else {
			for (i61 in 0...4) {
				H.tick();
				var v62:Int = v43;
			}
		}
		return 0x10AA;
	}
	public static function fn4():E0 {
		H.tick();
		Main.fn1((false || false), (cast (1.25) : Float));
		var v63:Array<Int> = ([] : Array<Int>);
		var v64:String = H.id("ünï");
		var v65:Array<Float> = ([196, Math.PI, 0.30000000000000004] : Array<Float>);
		var w66 = 0;
while (w66 < 1 && false) {
			w66++;
			H.tick();
			var w67 = 0;
do {
				w67++;
				H.tick();
				H.out("o68 " + Std.string(3.0));
				var v69:String = "hello world";
				H.out("o70 " + Std.string(E0.E0B));
			} while (w67 < 4 && (v63).contains(18));
		}
		var w71 = 0;
while (w71 < 3 && false) {
			w71++;
			H.tick();
			final v72:(Int) -> Void = function(p73:Int):Void {
				H.tick();
				final v74 = p73;
				var v75:Float = 123456.789;
				var v76:Array<String> = [v64];
			};
		}
		H.out("o77 " + Std.string((25 % H.nz(143))));
		return (((new Map<Int, E0>()).exists(11) ? (new Box<E0>(E0.E0B)).get() : E0.E0C) : E0);
	}
	public static function fn5(a6:Int, a7:Box<Float>):Int {
		H.tick();
		var v78:Int = H.apply(Std.string(E0.E0B), (v79:String) -> Lambda.count([a6, a6, 0xDFB], v80 -> false));
		var v81:Array<Float> = ((switch (E0.E0D) {
			case E0A: ([] : Array<Float>);
			case E0B: ([a6, a6, v78] : Array<Float>);
			case _: ([a6, v78, a6] : Array<Float>);
		}) : Array<Float>);
		var v82 = ({ var v83 = StringTools.replace("\n", ",", "-7"); v83; });
		{
			Ext.ext25(Std.string(v78));
			H.out("o84 " + Std.string((Std.parseInt("ab") ?? 0)));
			for (i85 in 0...1) {
				H.tick();
				Ext.ext25(v82);
				H.out("o86 " + Std.string(89));
				var v87 = v78;
			}
		}
		for (i88 in 0...0) {
			H.tick();
			(([a6]).length).ext23(0xE8A0);
			Ext.ext20(v82, ("\\").indexOf(v82));
		}
		Ext.ext20(H.id("A-B-C"), 230);
		final lf89:() -> Int = function():Int {
			H.tick();
			Main.fn4();
			v78 <<= (((v82).charCodeAt(a6) ?? -1) & 7);
			return (a6 << (((new Map<Int, Int>()).get(11) ?? 0) & 31));
		};
		return fn1(({ var v90 = 1.25; StringTools.endsWith(v82, v82); }), (a6 - v78));
	}
	public static function fn8():String {
		H.tick();
		function lf91(n92:Int):Int {
			H.tick();
			return n92 <= 0 ? fn1((([] : Array<Int>)).contains(n92), 7.0) : (lf91(n92 - 1) + (Type.enumIndex(E0.E0D) << (Lambda.fold(([] : Array<Int>), (v93:Int, v94:Int) -> (("0").charCodeAt(159) ?? -1), 0) & 31)));
		}
		H.out("lf91 " + lf91(0));
		H.out("o95 " + Std.string(E0.E0A));
		if (((E0.E0D).match(E0B) && StringTools.endsWith("\u{1F600}", "\x41\x42"))) {
			var v96 = 0x74EE;
			final v97:Array<String> = ["\\", "\x41\x42", "q"];
		} else {
			H.out("o98 " + Std.string(false));
		}
		for (i99 in 0...H.lim(("\"q\"").length)) {
			H.tick();
			(("42").lastIndexOf("a")).ext23(299);
			switch ((("ünï").split(",")).join("|")) {
				case "a" | "b": {
					var v100:Int = i99;
					v100 *= 291;
				};
				case "Haxe": {
					final v101:Int = i99;
					H.out("o102 " + "é");
				};
				case "": {
					var v103:String = "ünï";
				};
				case _: {
					H.out("o104 " + "\n");
					H.out("o105 " + Std.string(1572542469));
				};
			}
			if (true) {
				var v106:String = "é";
				H.out("o107 " + Std.string(85));
				var v108 = i99;
			} else {
				H.out("o109 " + Std.string(new Box(i99)));
			}
		}
		switch ("\\") {
			case "a" | "b": {
				var v110 = 0x9B28;
				H.out("o111 " + Std.string(v110));
			};
			case "Haxe": {
				var v112:Bool = (E0.E0C).match(E0D);
				for (k113 => v114 in (["k0" => 257, "k1" => 69] : Map<String, Int>)) {
					H.tick();
					H.out("o115 " + Std.string(v114));
				}
			};
			case "": {
				var v116 = 107;
				var v117 = true;
			};
			case _: {
				H.out("o118 " + Std.string(E0.E0B));
				H.out("o119 " + Std.string(("\"q\"").lastIndexOf("x,y,z")));
			};
		}
		var v120:Int = Math.ceil(0.30000000000000004);
		H.out("o121 " + Std.string(Main.fn1(true, 1e21)));
		fn4();
		return (StringTools.replace("ab", " ", "\"q\"") + ((("\"q\"").charCodeAt((-1258995581)) ?? -1) * 195));
	}
	public static function fn9(a10:Bool, a11:Array<Int>, a12:Bool):Bool {
		H.tick();
		H.out("o122 " + Std.string(([E0.E0B, E0.E0C] : Array<E0>)));
		(fn8()).ext25();
		var v123:Map<String, String> = new Map<String, String>();
		H.out("o124 " + Main.fn8());
		return a12;
	}
	public static function fn13(a14:Int):Int {
		H.tick();
		var v125:Map<Int, String> = ([-3 => StringTools.trim("\t")] : Map<Int, String>);
		H.out("o126 " + Std.string(H.apply(((([-3 => 5, 4 => (-1)] : Map<Int, Int>)).get(4) ?? 0), (v127:Int) -> v127)));
		a14 = (cast (a14) : Int);
		var v128:String = (([true]).join(" ")).toUpperCase();
		{
			a14 &= ((new Map<String, Int>()).get("q") ?? 0);
		}
		Ext.ext25(fn8());
		final v129 = (StringTools.trim(v128) + (["hello world", v128]).indexOf("\t"));
		for (x130 in ((v128).replace("a", "b")).split("a")) {
			H.tick();
			var v131 = (a14 += 3);
			var v132:Int = (([] : Array<Int>)).indexOf(v131);
			H.out("o133 " + Std.string(((new Map<String, Int>()).get("k3") ?? 0)));
		}
		fn4();
		return (((a14++) * Math.floor(3.0)) % H.nz((a14 | Std.int(1e3))));
	}
	public static function fn15(a16:Int, a17:E0):Int {
		H.tick();
		var v134:Array<Float> = (([a16, a16] : Array<Float>)).filter(v135 -> (new Map<Int, Int>()).exists(a16));
		var v136 = (Std.parseInt("A-B-C") ?? 0);
		a16++;
		var v137:String = Std.string(Reflect.compare(229, v136));
		final lf138:(String) -> Void = function(p139:String):Void {
			H.tick();
			for (x140 in [a16]) {
				H.tick();
				H.out("o141 " + Std.string([2126362775, 117]));
				a16 = H.id(a16);
			}
			var v142:Float = 2.5e-3;
		};
		v134.remove((("42").charCodeAt(0x54EE) ?? -1));
		Main.fn1((291 <= ((v137).charCodeAt(80) ?? -1)), (new Box<Float>(v136)).value);
		for (x143 in [(v137).lastIndexOf("\\")]) {
			H.tick();
			if (false) {
				a16 |= v136;
				v137 = H.cap("A-B-C");
				final v144:Float = x143;
			} else {
				H.out("o145 " + Std.string(true));
				H.out("o146 " + Std.string(v136));
			}
		}
		H.out("o147 " + Std.string(([v136]).copy()));
		return (switch ((284 != v136)) {
			case true: (("zz").charCodeAt(v136) ?? -1);
			case false: a16;
		});
	}
	public static function section0():Void {
		H.tick();
		H.out("o174 " + Std.string(Main.fn1(([0x7C98, 168]).contains((-2147483647)), Std.parseFloat("12.5"))));
		var v175:Box<Int> = new Box(Reflect.compare("-7", "A-B-C"));
		(H.id(String.fromCharCode(65 + ((156) & 15)))).ext25();
		var v176:Array<(String, Int) -> Int> = ([for (i177 in [277, 244]) if ((E0.E0B).match(E0C)) (p178:String, p179:Int) -> p179] : Array<(String, Int) -> Int>);
		var v180:Array<Bool> = [false, true];
		switch ((false || StringTools.contains("\"q\"", "\\"))) {
			case true: {
				var v181 = ("ünï").toLowerCase();
				for (x182 in [v181, v181, v181]) {
					H.tick();
					H.out("o183 " + Std.string(81));
					final v184:Map<String, String> = (["k0" => "\x41\x42"] : Map<String, String>);
					var v185:Float = 1e3;
				}
			};
			case false: {
				var v186:String = "a";
			};
		}
		var v187 = ((("\x41\x42").charCodeAt(44) ?? -1) + "ab");
	}
	public static function section1():Void {
		H.tick();
		switch (76) {
			case 0: {
				var v188 = ("\u{1F600}").substr((9 & 7), 1);
				var v189 = (([-3 => true, 4 => false] : Map<Int, Bool>)).exists(-3);
			};
			case 2 | 5: {
				var v190:Box<Int> = new Box(123);
				for (i191 in 0...H.lim(146)) {
					H.tick();
					var v192:Map<Int, Bool> = new Map<Int, Bool>();
				}
			};
			case _: {
				var v193:Array<(Int, String) -> String> = ([(p194:Int, p195:String) -> ""] : Array<(Int, String) -> String>);
				switch (E0.E0A) {
					case E0A: {
						H.out("o196 " + Std.string(0.1));
					};
					case E0B: {
						Ext.ext20("ab", 34);
					};
					case E0D: {
						final v197 = true;
					};
					case _: {
						H.out("o198 " + Std.string(0x7FFFFFFF));
					};
				}
			};
		}
		for (i199 in 0...H.lim(fn5(137, new Box<Float>(0.1)))) {
			H.tick();
			var v200:Float = 1.25;
			switch (E0.E0B) {
				case E0A: {
					var v201:Map<Int, Int> = ([-3 => i199, 4 => i199] : Map<Int, Int>);
					H.out("o202 " + Std.string(i199));
				};
				case E0B: {
					("-7").ext20(i199);
					final v203:Map<String, Int> = (["k0" => 144] : Map<String, Int>);
				};
				case E0C: {
					var v204:String = "zz";
					fn5(i199, new Box<Float>(i199));
				};
				case _: {
					Main.fn1(true, v200);
					var v205:Box<Array<Bool>> = new Box<Array<Bool>>(([] : Array<Bool>));
				};
			}
			var v206 = ("abc").toLowerCase();
		}
		for (i207 in 0...2) {
			H.tick();
			Ext.ext23(i207, i207);
		}
		H.out("o208 " + Std.string((50 ^ (([123456.789] : Array<Float>)).length)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
