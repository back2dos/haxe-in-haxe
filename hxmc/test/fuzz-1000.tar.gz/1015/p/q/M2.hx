package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

enum E0 {
	E0A;
	E0B;
	E0C;
	E0D;
}
