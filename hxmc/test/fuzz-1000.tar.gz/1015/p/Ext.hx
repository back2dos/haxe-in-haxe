package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext20(a18:String, a19:Int):Float {
		H.tick();
		var v148:Float = a19;
		var v149:Float = Reflect.compare(a18, "42");
		var v150:String = (a18).replace("a", "b");
		var v151:Array<Float> = ([for (i152 in [false, false]) if (false) v148] : Array<Float>);
		var v153:Int = Main.fn1(true, v148);
		Main.fn1((([a19]).contains(0x53FB) || Math.isNaN(v153)), 3.0);
		return (Math.min(2.5e-3, 195) - 5e-324);
	}
	public static function ext23(a21:Int, a22:Int):E0 {
		H.tick();
		var w154 = 0;
while (w154 < 2 && (Std.string(E0.E0B) > "0")) {
			w154++;
			H.tick();
			for (i155 in 0...H.lim(a21)) {
				H.tick();
				Main.fn4();
			}
		}
		for (x156 in [for (i157 in 0...3) 245]) {
			H.tick();
			var v158:Map<Int, Bool> = new Map<Int, Bool>();
		}
		var v159:String = Std.string(7.0);
		a21 ^= (new Box(a21)).get();
		Main.fn4();
		function lf160(n161:Int):Int {
			H.tick();
			return n161 <= 0 ? (switch (n161) {
			case 0: (v159).indexOf(v159);
			case 2 | 6: a22;
			case _: ((v159).charCodeAt(n161) ?? -1);
		}) : (lf160(n161 - 1) + ((new Map<Int, Int>()).get(("日本語").lastIndexOf(v159)) ?? 0));
		}
		H.out("lf160 " + lf160(1));
		var w162 = 0;
while (w162 < 5 && (0xA264 >= a22)) {
			w162++;
			H.tick();
			var v163:Int = 103;
			v163 <<= (110 & 7);
			v163 <<= (a21 & 7);
		}
		var v164:Array<String> = (([] : Array<String>)).filter(v165 -> true);
		return E0.E0B;
	}
	public static function ext25(a24:String):Float {
		H.tick();
		var v166 = (0x80000000 >>> (("\n").lastIndexOf(a24) & 31));
		H.out("o167 " + Std.string(E0.E0B));
		var v168:String = a24;
		var v169:Int = 0x4513;
		var v170 = (((new Map<Int, Int>()).get(v166) ?? 0) != v166);
		H.out("o171 " + Std.string(new Box(v169)));
		H.out("o172 " + "  pad  ");
		var v173 = v169;
		return (v169 + Ext.ext20(v168, (v168).length));
	}
}
