package p;

import Main;
import H;
using StringTools;

class Ext {
	public static function ext57(a55:Array<Int>, a56:Int):String {
		H.tick();
		{
			var v398:Int = (("ab").charCodeAt((-18)) ?? -1);
			(new C27()).m35((-692978246));
			var v399:A8 = (a56 : A8);
		}
		var v400:Bool = (true && Math.isNaN(a56));
		H.out("o401 " + Std.string(new C27()));
		if ((v400 || false)) {
			H.out("o402 " + Std.string(v400));
		} else {
			var v403:Int = Type.enumIndex(E0.E0A);
		}
		return 'x${Std.string(a56)}<${Std.string(a56)}';
	}
	public static function ext59(a58:String):Bool {
		H.tick();
		var v404 = 91;
		final v405:(Int, Bool) -> String = (p406:Int, p407:Bool) -> "\\";
		v404 *= v404;
		v404 += 1996148400;
		var v408:Array<Map<String, Int>> = ((true ? ([(["k0" => v404, "k1" => v404, "k2" => v404] : Map<String, Int>), new Map<String, Int>(), (["k0" => v404, "k1" => v404, "k2" => v404] : Map<String, Int>)] : Array<Map<String, Int>>) : ([(["k0" => 65535] : Map<String, Int>)] : Array<Map<String, Int>>)) : Array<Map<String, Int>>);
		v404 = (v404 + v404);
		if ((v404 < v404)) {
			(new C27()).m35(((a58).charCodeAt(v404) ?? -1));
			v404 -= v404;
		}
		var v409:Array<Array<Float>> = (([] : Array<Array<Float>>)).concat(([([v404, v404] : Array<Float>), ([] : Array<Float>), ([v404, v404, 0.1] : Array<Float>)] : Array<Array<Float>>));
		if (StringTools.contains(a58, Std.string(v404))) {
			if (false) {
				final v410 = "q";
			}
			H.out("o411 " + Std.string(E0.E0B(true)));
		} else {
			function lf412(n413:Int):Int {
				H.tick();
				return n413 <= 0 ? 0xA387 : (lf412(n413 - 1) + (new A8(117)).get());
			}
			H.out("lf412 " + lf412(5));
		}
		return (100.75 >= 2.5e-3);
	}
	public static function ext61(a60:String):E0 {
		H.tick();
		H.out("o414 " + (([(-1478971817), 161]).join("|")).replace("a", "b"));
		switch (K9.K9B) {
			case K9.K9A: {
				H.out("o415 " + Std.string((-297590733)));
				H.out("o416 " + Std.string((K9.K9B : Int)));
			};
			case K9.K9B: {
				H.out("o417 " + Std.string(193));
				var v418:Float = Math.sin(1e100);
			};
		}
		var v419:Int = (StringTools.lpad(a60, "*", -2)).length;
		if (StringTools.contains(a60, (a60).toUpperCase())) {
			(new C27()).m12();
		}
		return ({ var v420 = (Type.enumIndex(E0.E0A) + ("x,y,z").lastIndexOf("\n")); E0.E0B(false); });
	}
}
