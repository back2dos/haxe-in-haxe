import H;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Bool);
}

typedef S2 = {x3:String};

typedef S4 = {x5:String, x6:Int, x7:Int};

abstract A8(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A8, b:A8):A8
		return new A8(a.get() + b.get());

	@:op(A * B) public static function mul(a:A8, b:A8):A8
		return new A8(a.get() * b.get());

	@:op(-A) public static function neg(a:A8):A8
		return new A8(-a.get());
}

enum abstract K9(Int) to Int {
	var K9A = 1;
	var K9B = 4;
}

interface I10 {
	function m11():Float;
	function m12():S4;
}

abstract class C13 implements I10 {
	public var f14:Int;
	public function new() {
		this.f14 = (("A-B-C").charCodeAt(56) ?? -1);
	}
	abstract public function m11():Float;
	public function m12():S4 {
		H.tick();
		switch (E0.E0A) {
			case E0A: {
				switch (false) {
					case true: {
						final v62:Array<String> = ([] : Array<String>);
						var v63:E0 = E0.E0B(false);
					};
					case false: {
						final v64 = 99;
					};
				}
				var v65:Int = (({x5: "a\rb", x6: 285, x7: 0x8672} : S4)).x6;
			};
			case E0B(c66): {
				if (Math.isNaN(2.5e-3)) {
					var v67:Array<Float> = ([] : Array<Float>);
					var v68:Map<Int, (Float, Int) -> Void> = new Map<Int, (Float, Int) -> Void>();
				} else {
					var v69 = 77;
					H.out("o70 " + Std.string(([] : Array<Int>)));
				}
			};
			case _: {
				{
					var v71:Map<String, Bool> = new Map<String, Bool>();
				}
				if (true) return ({x6: 0xE42F, x5: "abc", x7: 134} : S4);
			};
		}
		var v72:Map<String, String> = new Map<String, String>();
		++this.f14;
		H.out("o73 " + 'x${Std.string(Std.isOfType(new C20(1e3, 12), C20))}');
		this.f14 = (false ? this.f14 : 58);
		return ((switch (K9.K9A) {
			case K9.K9A: ({x5: "\\", x6: 294, x7: H.at([280, 231], 284, 0)} : S4);
			case K9.K9B: ({x5: "a", x6: 124, x7: 289} : S4);
		}) : S4);
	}
	public function m15(a16:Int):Int {
		H.tick();
		function lf74(n75:Int):Int {
			H.tick();
			return n75 <= 0 ? 55 : (lf74(n75 - 1) + 23);
		}
		H.out("lf74 " + lf74(2));
		var v76:A8 = ((switch ((Std.parseInt(Std.string(a16)) ?? 0)) {
			case 0: new A8(a16);
			case 1 | 5: new A8(a16);
			case _: new A8(a16);
		}) : A8);
		H.out("o77 " + Std.string((K9.K9B : Int)));
		H.out("o78 " + Std.string((false ? true : true)));
		return a16;
	}
	abstract public function m17(a18:Bool, a19:Int):Void;
}

class C20 extends C13 implements I10 {
	public function new(a21:Float, a22:Int) {
		super();
	}
	public function m11():Float {
		H.tick();
		{
			var v79:Int = ([false, true]).indexOf(true);
			var v80:Map<String, Int> = new Map<String, Int>();
		}
		(new C27()).m35((289 * ((272 : A8)).get()));
		(new C27()).m34();
		final v81:Int = (-97);
		var v82 = true;
		H.out("o83 " + Std.string(v81));
		return ((v82 ? 7.0 : v81) : Float);
	}
	public function m17(a18:Bool, a19:Int):Void {
		H.tick();
		var v84:String = "Haxe";
		function lf85(n86:Int):Int {
			H.tick();
			return n86 <= 0 ? (((["k0" => 169, "k1" => 59] : Map<String, Int>)).get((([] : Array<Int>)).join("|")) ?? 0) : (lf85(n86 - 1) + this.f14);
		}
		H.out("lf85 " + lf85(4));
		this.f14 = ([a18]).length;
		var v87:Map<String, Int> = (["k0" => (Std.parseInt(Std.string(a19)) ?? 0), "k1" => (-140941324)] : Map<String, Int>);
		this.f14 -= (212 - a19);
		a18 = true;
		try {
			if ((((["k0" => v84, "k1" => v84] : Map<String, String>)).exists(v84) ? StringTools.startsWith("  pad  ", v84) : Std.isOfType(new C27(), C27))) throw "boom";
			H.out("o88 " + Std.string(a19));
		} catch (ex89:Dynamic) {
			H.out("caught " + H.exn(ex89));
			v87.remove(v84);
		}
		(new C27()).m12();
		final v90:S4 = (((new Map<String, String>()).exists("k1") ? ({x5: "hello world", x6: 75, x7: a19} : S4) : ({x5: v84, x6: a19, x7: a19} : S4)) : S4);
	}
	override public function m12():S4 {
		H.tick();
		this.f14 = H.id(this.f14);
		var v91 = (switch (E0.E0A) {
			case E0A: ((245 : A8)).twice;
			case E0B(c92): 0xFEBE;
			case _: (K9.K9B : Int);
		});
		if ((([v91, v91]).contains(v91) || ([v91, v91, 238]).contains((-2029040427)))) {
			var v93:Float = 155;
		} else {
			var v94 = 0x80F0;
			v94 *= (v91--);
		}
		return ((switch (E0.E0B(true)) {
			case E0A: ({x5: ("").replace("a", "b"), x6: (("日本語").charCodeAt(v91) ?? -1), x7: v91} : S4);
			case E0B(c95): ((false ? ({x7: v91, x6: v91, x5: "é"} : S4) : ({x7: 1864936263, x6: v91, x5: "x,y,z"} : S4)) : S4);
		}) : S4);
	}
}

abstract class C23 implements I10 {
	public function new() {}
	public function m11():Float {
		H.tick();
		var v96:Array<Float> = ([226]).map((v97:Int) -> ((-2.5) : Float));
		H.out("o98 " + StringTools.lpad(("hello world").replace("a", "b"), "*", -1));
		H.out("o99 " + Std.string(0x80000000));
		var v100 = (if ((([] : Array<Int>)).contains((-11))) 270 else Lambda.count([44, 173, 175], v101 -> StringTools.endsWith("\n", "\u{1F600}")));
		var v102:Map<String, Bool> = ((Std.isOfType(null, C37) ? new Map<String, Bool>() : new Map<String, Bool>()) : Map<String, Bool>);
		return ((("-7").charCodeAt(v100) ?? -1) - 236);
	}
	public function m12():S4 {
		H.tick();
		var v103:Map<String, Float> = (["k0" => 1e-7, "k1" => (-2.5)] : Map<String, Float>);
		var v104:Int = (Math.ceil(2.5e-3) * (Std.parseInt(Std.string(0x80000000)) ?? 0));
		var v105:Float = ((--v104) - v104);
		var v106:String = ([v104]).join("");
		final v107:E0 = E0A;
		switch (v104) {
			case 0: {
				var v108 = v104;
			};
			case 1 | 5: {
				{
					final v109:S2 = ({x3: v106} : S2);
					final v110:(String) -> String = function(p111:String):String {
						H.tick();
						v104 -= v104;
						H.out("o112 " + p111);
						H.out("o113 " + Std.string(v105));
						return p111;
					};
				}
			};
			case _: {
				var v114:String = (v106).toLowerCase();
			};
		}
		switch (230) {
			case 0: {
				var v115 = v106;
			};
			case 2 | 5: {
				H.out("o116 " + Std.string(v104));
			};
			case _: {
				var v117 = (v106).replace("a", "b");
			};
		}
		return ({x5: v106, x6: (switch (E0.E0B(false)) {
			case E0A: Lambda.fold([v104, v104, v104], (v118:Int, v119:Int) -> ((v106).charCodeAt(v118) ?? -1), 0);
			case E0B(c120): 262;
		}), x7: (((["k0" => v104] : Map<String, Int>)).exists(v106) ? v104 : (v106).lastIndexOf(v106))} : S4);
	}
	public function m24(a25:S4, a26:String):String {
		H.tick();
		H.out("o121 " + Std.string((true ? (a25).x7 : 0xFFFFFFFF)));
		H.out("o122 " + a26);
		(new C20(Math.PI, 294)).m12();
		if (!true) {
			H.out("o123 " + Std.string(123456.789));
			final lf124:() -> Int = function():Int {
				H.tick();
				var v125:Bool = false;
				H.out("o126 " + "hello world");
				final v127:Array<String> = (a26).split(" ");
				return 161;
			};
		} else {
			var v128:Map<Int, Bool> = new Map<Int, Bool>();
		}
		final v129:Array<Int> = ([] : Array<Int>);
		return "42";
	}
}

class C27 implements I10 {
	public var f28:Float;
	public var f29:E0;
	public final f30:Float;
	public var cb31:(Int) -> Int;
	public function new() {
		this.f28 = 0.5;
		this.f29 = E0.E0A;
		this.f30 = (-2.5);
		this.cb31 = function(p130:Int):Int {
			H.tick();
			final v131:C27 = null;
			var v132:Map<String, Int> = (["k0" => p130, "k1" => p130, "k2" => p130] : Map<String, Int>);
			return p130;
		};
	}
	public function m11():Float {
		H.tick();
		H.out("o133 " + Std.string((((Std.parseInt("ab") ?? 0) : A8) : Int)));
		if ((Type.enumIndex(E0B(true)) != Math.floor((-2.5)))) {
			{
				H.out("o134 " + Std.string(true));
			}
			var v135 = "x,y,z";
		} else {
			var v136:Map<String, String> = new Map<String, String>();
			final lf137:() -> Int = function():Int {
				H.tick();
				(new C20(7.0, 84)).m12();
				return Type.enumIndex(E0A);
			};
		}
		var v138:String = (([] : Array<Int>)).ext57(("Haxe").indexOf("a"));
		var v139 = (switch (Type.enumIndex(E0A)) {
			case 0: ([65535]).contains(222);
			case 1 | 6: (([-3 => (-12), 4 => 70] : Map<Int, Int>)).exists(-3);
			case _: false;
		});
		if (v139) {
			H.out("o140 " + Std.string(E0A));
			final v141:(Float, Float) -> Void = function(p142:Float, p143:Float):Void {
				H.tick();
				var v144:Float = p142;
				var v145:Float = p142;
				final v146:() -> String = function():String {
					H.tick();
					(v138).ext59();
					return "A-B-C";
				};
			};
			final v147 = v139;
		}
		if ((false ? (([] : Array<Int>)).contains(69) : v139)) {
			final v148 = v139;
			H.out("o149 " + Std.string(StringTools.startsWith(v138, "\t")));
			var v150:Array<Int> = [221, 286, (-8)];
		} else {
			if (true) {
				v138 = H.cap(v138 + v138);
			}
			try {
				if (v139) throw "boom";
				H.out("o151 " + v138);
			} catch (ex152:Err) {
				H.out("caught Err " + ex152.errCode);
				H.out("o153 " + v138);
				H.out("o154 " + v138);
			} catch (ex155:haxe.Exception) {
				H.out("caught " + H.exn(ex155));
				H.out("o156 " + Std.string(0x8394));
			}
		}
		final v157:C20 = ({ var v158 = (([] : Array<Int>)).contains(0x80000000); new C20(1.25, 172); });
		switch (E0.E0A) {
			case E0A: {
				H.out("o159 " + Std.string((K9.K9B : Int)));
				var v160:Float = 232;
			};
			case E0B(c161): {
				Ext.ext61(v138);
			};
		}
		final v162:K9 = K9.K9A;
		return 123456.789;
	}
	public function m12():S4 {
		H.tick();
		switch ((50 * Std.int(0.30000000000000004))) {
			case 0: {
				var v163:Int = (new A8(76) : Int);
				var v164 = false;
			};
			case 2 | 6: {
				final v165:Int = H.at([9, 65535, 282], 138, 0);
			};
			case _: {
				try {
					if ((new Map<Int, String>()).exists(163)) throw 80;
					var v166:Array<A8> = ([new A8(51)] : Array<A8>);
				} catch (ex167:Dynamic) {
					H.out("caught " + H.exn(ex167));
					var v168:String = "zz";
				}
				var v169:Array<Bool> = [true, true];
			};
		}
		switch (E0A) {
			case E0A: {
				var v170:Float = 0.1;
			};
			case _: {
				final v171:E0 = E0B(true);
			};
		}
		if ((this.f30 != 100.75)) {
			{
				var v172:Map<String, Int> = (["k0" => 206] : Map<String, Int>);
				var v173:Bool = false;
			}
			var v174:String = Std.string((-8));
		}
		var v175:Int = ({ var v176 = (({x5: "42", x6: 271, x7: (-2147483647)} : S4)).x7; Math.ceil(v176); });
		if ((v175 > (({x6: v175, x5: "Haxe", x7: v175} : S4)).x7)) {
			if (((["k0" => v175, "k1" => v175, "k2" => (-7)] : Map<String, Int>)).exists("k3")) return ({x5: "\\", x6: (-6), x7: v175} : S4);
		} else {
			H.out("o177 " + Std.string(132));
			var v178 = v175;
		}
		var v179:Map<String, String> = ({ var v180 = Lambda.count(([] : Array<Int>), v181 -> (([] : Array<Int>)).contains(v175)); new Map<String, String>(); });
		var v182 = (([v175, 225]).contains(0xFCDB) ? v175 : (v175 += 3));
		return ({x5: (String.fromCharCode(65 + ((v182) & 15)) + v175), x6: 109, x7: v182} : S4);
	}
	public function m32(a33:String):A8 {
		H.tick();
		H.out("o183 " + Std.string(((({x5: "q", x6: 251, x7: 1740097741} : S4)).x7 * 170)));
		final lf184:() -> Void = function():Void {
			H.tick();
			switch (false) {
				case true: {
					var v185:E0 = E0.E0B(true);
					var v186:Int = 260;
				};
				case false: {
					final v187:Int = 48;
					var v188 = a33;
				};
			}
			H.out("o189 " + Std.string(([0x80000000, 171, 0x7FFFFFFF]).contains(229)));
			var v190:C20 = new C20(2.5e-3, 65535);
		};
		if (false) {
			var v191:E0 = E0.E0B(false);
			(new C20(1e100, 101)).m17(([14, 310921271]).contains(296), (-18));
			var v192:Array<Array<S2>> = ([([({x3: "A-B-C"} : S2), ({x3: "\"q\""} : S2), ({x3: "\\"} : S2)] : Array<S2>)] : Array<Array<S2>>);
		} else {
			H.out("o193 " + Std.string((a33).lastIndexOf(a33)));
		}
		return ((-new A8(0x6784)) + (((([-3 => a33, 4 => a33] : Map<Int, String>)).exists(0x80000000) ? new A8(964511881) : new A8(272)) : A8));
	}
	public function m34():Bool {
		H.tick();
		var v194:Int = H.at([100, 119, 26], 67, 0);
		v194 = (-(Std.parseInt("0") ?? 0));
		H.out("o195 " + Std.string(v194));
		return (false && (true && false));
	}
	public function m35(a36:Int):String {
		H.tick();
		H.out("o196 " + Std.string(0x80000000));
		var v197:S4 = ({x7: (({x5: "zz", x6: a36, x7: 27} : S4)).x6, x5: StringTools.replace("\u{1F600}", "b", "\x41\x42"), x6: (Std.parseInt("é") ?? 0)} : S4);
		var v198:Map<Int, String> = ([-3 => StringTools.trim("\n")] : Map<Int, String>);
		var v199:E0 = E0A;
		a36--;
		var v200:Int = a36;
		var v201:Array<Bool> = [for (i202 in 0...0) false];
		return '<${Std.string((true && false))} = ${Std.string(({ var v203 = (new A8(2066099431)).twice; false; }))}';
	}
}

abstract class C37 implements I10 {
	public final f38:E0;
	public function new(a39:Int) {
		this.f38 = E0.E0A;
	}
	public function m11():Float {
		H.tick();
		H.out("o204 " + Std.string(E0.E0A));
		if ((((["k0" => 0x9B39, "k1" => 78, "k2" => 259] : Map<String, Int>)).exists("k3") && true)) {
			var v205:Map<String, String> = (["k0" => "hello world", "k1" => "日本語", "k2" => "q"] : Map<String, String>);
			var v206 = Math.floor(3.0);
		} else {
			H.out("o207 " + Std.string((Std.parseInt(Std.string(2119717559)) ?? 0)));
		}
		(new C20(5e-324, Reflect.compare(300, 278))).m12();
		H.out("o208 " + Std.string((({x7: 181, x6: 213, x5: "A-B-C"} : S4)).x7));
		var v209 = !false;
		return 123456.789;
	}
	public function m12():S4 {
		H.tick();
		final v210 = Math.round(1e21);
		final lf211:(Int, String) -> Void = function(p212:Int, p213:String):Void {
			H.tick();
			{
				var v214:Float = 7.0;
				var v215:Array<Array<I10>> = ([] : Array<Array<I10>>);
				H.out("o216 " + Std.string(({x7: p212, x6: 110, x5: "\"q\""} : S4)));
			}
			final v217:(String, Bool) -> Float = (p218:String, p219:Bool) -> p212;
			H.out("o220 " + Std.string((p213).lastIndexOf(p213)));
		};
		var v221:Float = 134;
		var v222:A8 = (-new A8(v210));
		if ((false && true)) {
			var v223:E0 = E0A;
		} else {
			var v224 = "ünï";
		}
		if (true) return ({x7: 93, x5: StringTools.trim("\n"), x6: 214} : S4);
		H.out("o225 " + "hello world");
		return ({x5: ("\"q\"" + (([] : Array<Int>)).contains(v210)), x6: v210, x7: 165} : S4);
	}
	public function m40():Array<String> {
		H.tick();
		(new C20(Std.parseFloat("1.5"), 1)).m17((Std.parseFloat("-7") > Std.parseFloat("3")), (Reflect.compare(45, 32) - ((([-3 => 46, 4 => (-18)] : Map<Int, Int>)).get(-3) ?? 0)));
		(new C20(1e3, ((new Map<String, Int>()).get("\\") ?? 0))).m12();
		H.out("o226 " + Std.string(E0B(false)));
		switch (E0B(Math.isNaN(0.30000000000000004))) {
			case E0A: {
				if (([79570912, 80]).contains((-15))) {
					var v227:String = "";
					var v228:Array<Int> = ([] : Array<Int>);
					var v229 = (-2026747230);
				} else {
					(new C27()).m12();
				}
				(new C27()).m35(H.at(([] : Array<Int>), 129, 0));
			};
			case E0B(c230): {
				if (Std.isOfType(null, I10)) {
					final v231 = "a\rb";
					var v232:Int = 0x7FFFFFFF;
				}
				H.out("o233 " + Std.string(E0A));
			};
		}
		var v234:Bool = (([263]).join("") > "日本語");
		return ([] : Array<String>);
	}
}

class Main {
	public static inline function fn41(a42:Int):String {
		H.tick();
		H.out("o235 " + Std.string(([(-12), 1993213982, 0x44D3]).contains(Lambda.fold([a42, a42], (v236:Int, v237:Int) -> Lambda.fold(([] : Array<Int>), (v238:Int, v239:Int) -> Std.int(a42), 0), 0))));
		try {
			var v240:Map<String, String> = (["k0" => "zz", "k1" => "q"] : Map<String, String>);
			(new C27()).m12();
			function lf241(n242:Int):Int {
				H.tick();
				return n242 <= 0 ? Type.enumIndex(E0A) : (lf241(n242 - 1) + ("ünï").lastIndexOf("q"));
			}
			H.out("lf241 " + lf241(4));
			if ((([a42, 767485426, a42]).length < (("a\rb").charCodeAt(298) ?? -1))) throw "boom";
		} catch (ex243:String) {
			H.out("caught String " + ex243);
			var v244:Float = a42;
		} catch (ex245:Int) {
			H.out("caught Int " + ex245);
			if (true) {
				var v246:Array<Float> = ([a42, a42, ex245] : Array<Float>);
				var v247:Array<Int> = [141, 69, ex245];
				var v248:Float = (-2.5);
			} else {
				final v249:(Int, String) -> Bool = (p250:Int, p251:String) -> true;
				var v252:Float = ex245;
			}
		} catch (ex253:Err) {
			H.out("caught Err " + ex253.errCode);
			H.out("o254 " + ("q").substr((a42 & 7), 3));
			switch (([a42, 196, a42]).contains(a42)) {
				case true: {
					H.out("o255 " + Std.string(true));
				};
				case false: {
					var v256:Map<Int, String> = new Map<Int, String>();
				};
			}
		} catch (ex257:Dynamic) {
			H.out("caught " + H.exn(ex257));
			a42 = H.id(a42);
		}
		switch ((switch (257) {
			case 0: ((new Map<String, Int>()).get("k1") ?? 0);
			case 3 | 6: a42;
			case _: Std.int(a42);
		})) {
			case 0: {
				H.out("o258 " + Std.string(Math.round(100.75)));
				var v259:Int = 32;
			};
			case 3 | 4: {
				if (true) {
					final v260:Array<Null<Int>> = ([] : Array<Null<Int>>);
				}
				H.out("o261 " + Std.string(122));
			};
			case _: {
				H.out("o262 " + Std.string((-241932166)));
			};
		}
		var v263:C20 = new C20(Math.sin(a42), 178);
		H.out("o264 " + (Std.string(a42) + (a42--)));
		return ("0" + (("\u{1F600}").replace("a", "b") + ("0").toLowerCase()));
	}
	public static function fn43():Void {
		H.tick();
		var v265:Array<A8> = ([] : Array<A8>);
		var v266:Int = (Std.string(E0A)).indexOf("Haxe");
		var v267:Map<String, String> = new Map<String, String>();
		H.out("o268 " + Std.string(new C20(1.25, (Std.parseInt(Std.string(v266)) ?? 0))));
		var v269:Array<Float> = ((Std.isOfType(new C20(v266, 0xFFFFFFFF), I10) ? ([v266] : Array<Float>) : ([v266, v266, v266] : Array<Float>)) : Array<Float>);
		try {
			try {
				var v270:Map<Int, Int> = ([-3 => v266, 4 => v266] : Map<Int, Int>);
				final v271 = "é";
				v266 = 65535;
				if (([v266, v266]).contains(0x7FFFFFFF)) throw "boom";
			} catch (ex272:String) {
				H.out("caught String " + ex272);
				final v273 = v266;
			} catch (ex274:Int) {
				H.out("caught Int " + ex274);
				v266 = ex274;
			} catch (ex275:Err) {
				H.out("caught Err " + ex275.errCode);
				v266 = H.id(v266);
			} catch (ex276:Dynamic) {
				H.out("caught " + H.exn(ex276));
				v266 = H.id(v266);
				var v277:I10 = new C20(v266, v266);
			}
			if ((new Map<String, Int>()).exists(("日本語").substr(2, 3))) throw 57;
		} catch (ex278:String) {
			H.out("caught String " + ex278);
			H.out("o279 " + Std.string(Reflect.compare(v266, v266)));
		} catch (ex280:Int) {
			H.out("caught Int " + ex280);
			var v281:I10 = new C27();
		} catch (ex282:Err) {
			H.out("caught Err " + ex282.errCode);
			var v283:E0 = E0.E0B(false);
			v266 -= v266;
		} catch (ex284:Dynamic) {
			H.out("caught " + H.exn(ex284));
			H.out("o285 " + Std.string((K9.K9A : Int)));
			var v286:Float = 1.7976931348623157e308;
		}
		H.out("o287 " + Std.string(new C20(123456.789, (new A8(v266) : Int))));
		if (false) {
			v266--;
			H.out("o288 " + Std.string(([v266]).contains(v266)));
		} else {
			if (([219]).contains(42609273)) {
				final v289:(String) -> Float = (p290:String) -> 0.1;
				var v291 = v266;
				(new C20(0.1, v266)).m17(false, v291);
			} else {
				H.out("o292 " + "é");
			}
		}
	}
	public static function fn44(a45:String):Float {
		H.tick();
		var v293:Map<String, (Int, String) -> Bool> = new Map<String, (Int, String) -> Bool>();
		var v294:C27 = new C27();
		var v295:Bool = ((new A8(256)).get() < (new A8(3) : Int));
		if ((a45 < a45)) {
			final v296:Array<Int> = ([] : Array<Int>);
		}
		var v297:Float = (7.0 + H.at([111, 0x3541], 239, 0));
		switch (E0.E0B(v295)) {
			case E0A: {
				var v298:String = StringTools.replace(a45, ",", "\\");
				function lf299(n300:Int):Int {
					H.tick();
					return n300 <= 0 ? n300 : (lf299(n300 - 1) + n300);
				}
				H.out("lf299 " + lf299(1));
			};
			case E0B(c301): {
				var v302:Float = Math.PI;
			};
		}
		final v303:Int = (-163705929);
		var v304:Array<String> = (([] : Array<String>)).concat(([] : Array<String>));
		return (v297 / 1e3);
	}
	public static function fn46():Int {
		H.tick();
		try {
			if ((([60, 183]).indexOf(0x60E3) != 168)) throw 87;
			H.out("o305 " + Std.string(E0A));
			final v306:Array<String> = ["-7", "\t", "ünï"];
			H.out("o307 " + Std.string(Std.int(0.1)));
		} catch (ex308:Dynamic) {
			H.out("caught " + H.exn(ex308));
			var v309:E0 = E0A;
		}
		final lf310:(Bool) -> Int = (p311:Bool) -> 0xEBD0;
		H.out("o312 " + Std.string(((-2147483647) - 1.7976931348623157e308)));
		final v313:Int = 270;
		switch (E0A) {
			case E0A: {
				switch (176) {
					case 0: {
						H.out("o314 " + Std.string(v313));
						var v315:Array<String> = ("q").split(" ");
					};
					case 2 | 4: {
						H.out("o316 " + Std.string((K9.K9A : Int)));
						final v317:String = "42";
					};
					case _: {
						var v318:E0 = E0.E0A;
					};
				}
				var v319 = ("0").substr(3, 3);
			};
			case E0B(c320): {
				var v321 = ([155]).indexOf(v313);
				var v322 = ("\x41\x42").charAt(((-1784374445) & 7));
			};
		}
		H.out("o323 " + Std.string(Ext.ext59("é")));
		return v313;
	}
	public static function fn47(a48:Int):Bool {
		H.tick();
		if ((0.1 <= 123456.789)) {
			a48 = ((new Map<String, Int>()).get("\x41\x42") ?? 0);
			var v324:Array<Bool> = [true];
		}
		var v325:Bool = (StringTools.startsWith("", "-7") || false);
		H.out("o326 " + Std.string(Math.pow(Math.sin(a48), 2)));
		try {
			if (v325) throw Ext.ext57([a48, a48, a48], (({x7: a48, x5: "\x41\x42", x6: a48} : S4)).x6);
			var v327:String = "x,y,z";
			final v328 = (K9.K9B : Int);
			if (true) {
				H.out("o329 " + Std.string([189, 298]));
				final v330:(Int, Int) -> String = function(p331:Int, p332:Int):String {
					H.tick();
					var v333:S4 = ({x5: v327, x6: 247, x7: 101} : S4);
					return v327;
				};
			}
		} catch (ex334:String) {
			H.out("caught String " + ex334);
			var v335:C27 = new C27();
			final v336 = Math.isNaN(0.1);
		} catch (ex337:Int) {
			H.out("caught Int " + ex337);
			a48 -= ex337;
		} catch (ex338:Err) {
			H.out("caught Err " + ex338.errCode);
			var v339:Map<String, String> = (["k0" => "abc"] : Map<String, String>);
		} catch (ex340:Dynamic) {
			H.out("caught " + H.exn(ex340));
			var v341 = (({x5: "42", x6: (-1676447340), x7: a48} : S4)).x7;
			switch (E0.E0A) {
				case E0A: {
					final v342:Array<Float> = ([a48, 7.0] : Array<Float>);
				};
				case _: {
					(new C20(a48, v341)).m11();
					H.out("o343 " + Std.string(v341));
				};
			}
		}
		return true;
	}
	public static function fn49():Int {
		H.tick();
		final v344:(Float, Int) -> Bool = (p345:Float, p346:Int) -> false;
		var v347:Map<Int, Int> = new Map<Int, Int>();
		(new C20(Std.parseFloat("3"), (((["k0" => (-1676260440), "k1" => 65535, "k2" => 0x62E0] : Map<String, Int>)).get("k1") ?? 0))).m17((Std.isOfType(new C20((-2.5), 93), C20) ? true : Std.isOfType(null, C37)), Reflect.compare("\t", Std.string(0.1)));
		try {
			if ((new C27()).m34()) throw "boom";
			final v348:Array<S2> = ([({x3: "\u{1F600}"} : S2)] : Array<S2>);
		} catch (ex349:Dynamic) {
			H.out("caught " + H.exn(ex349));
			try {
				var v350:Map<String, Int> = new Map<String, Int>();
				if (((["k0" => null, "k1" => 0x5B6D] : Map<String, Null<Int>>)).exists("k2")) throw new Err((("-7").charCodeAt(65) ?? -1));
			} catch (ex351:String) {
				H.out("caught String " + ex351);
				var v352:Float = 1e-7;
			} catch (ex353:Int) {
				H.out("caught Int " + ex353);
				final v354:Bool = true;
			} catch (ex355:Err) {
				H.out("caught Err " + ex355.errCode);
				var v356 = false;
			} catch (ex357:Dynamic) {
				H.out("caught " + H.exn(ex357));
				Main.fn43();
				var v358 = 146;
			}
			var v359:K9 = K9.K9A;
		}
		if (false) {
			final v360 = false;
			H.out("o361 " + Std.string(293));
		} else {
			if (true) {
				var v362 = 129;
				(new C20(1e21, v362)).m17(true, 155);
			}
		}
		fn43();
		(new C20(0.5, ("  pad  ").lastIndexOf("\u{1F600}"))).m12();
		return (("\\").charCodeAt(55) ?? -1);
	}
	public static function fn50(a51:E0, a52:Int):Int {
		H.tick();
		var v363:Array<String> = ({ var v364 = 250; ("a").split(" "); });
		a52 = H.id(a52);
		var v365:Bool = (Std.isOfType(null, C23) || ([a52, a52]).contains(a52));
		a52 += (switch (E0.E0B(v365)) {
			case E0A: 108;
			case E0B(c366): 35;
		});
		H.out("o367 " + Std.string((Type.enumIndex(E0B(v365)) % H.nz((({x6: a52, x7: a52, x5: "42"} : S4)).x6))));
		return (switch (Std.string(E0B(false))) {
			case "a" | "b": fn46();
			case "Haxe": (v365 ? a52 : 0x1368);
			case _: (true ? (Std.parseInt(Std.string(a52)) ?? 0) : a52);
		});
	}
	public static function fn53(a54:Float):Array<Int> {
		H.tick();
		try {
			if ((0.5 >= 2.5e-3)) throw 89;
			H.out("o368 " + Std.string(0.1));
			switch ((Std.parseInt("0") ?? 0)) {
				case 0: {
					(new C27()).m35(249);
				};
				case 3 | 6: {
					var v369 = 125;
					v369 = H.id(v369);
				};
				case _: {
					var v370:Array<Int> = [0x54F7];
					var v371 = 20;
				};
			}
			var v372:I10 = new C27();
		} catch (ex373:String) {
			H.out("caught String " + ex373);
			H.out("o374 " + Std.string((ex373).indexOf(ex373)));
			fn46();
		} catch (ex375:Int) {
			H.out("caught Int " + ex375);
			var v376 = ex375;
			var v377 = Std.string(3.0);
		} catch (ex378:Err) {
			H.out("caught Err " + ex378.errCode);
			var v379:I10 = new C27();
		} catch (ex380:Dynamic) {
			H.out("caught " + H.exn(ex380));
			var v381 = Std.string(E0B(false));
		}
		try {
			Main.fn44(([false, false]).join("|"));
			Main.fn41(752949448);
			if (({ var v382 = 1.7976931348623157e308; false; })) throw "boom";
		} catch (ex383:Err) {
			H.out("caught Err " + ex383.errCode);
			H.out("o384 " + Std.string(E0.E0A));
			H.out("o385 " + Std.string(([new A8((-2147483647)), new A8(25), new A8(187)] : Array<A8>)));
		} catch (ex386:haxe.Exception) {
			H.out("caught " + H.exn(ex386));
			var v387 = true;
			var v388:Float = a54;
		}
		if (false) {
			var v389:Bool = false;
		}
		try {
			if ((switch (Reflect.compare("\u{1F600}", "a\rb")) {
				case 0: true;
				case 1 | 5: false;
				case _: Math.isNaN(a54);
			})) throw "boom";
			var v390 = Math.isNaN(a54);
			var v391:Int = 7;
			(new C27()).m32(StringTools.replace("\u{1F600}", ",", ""));
		} catch (ex392:Err) {
			H.out("caught Err " + ex392.errCode);
			H.out("o393 " + Std.string(Math.sin(1e-7)));
			H.out("o394 " + Std.string((-4)));
		} catch (ex395:haxe.Exception) {
			H.out("caught " + H.exn(ex395));
			(new C20(a54, 1880891330)).m12();
			H.out("o396 " + Std.string(225));
		}
		return [for (i397 in [Math.ceil(2.5e-3)]) if (([i397]).contains(([1974515919, i397, i397]).indexOf(193))) (true ? (K9.K9B : Int) : 125)];
	}
	public static function section0():Void {
		H.tick();
		var v421:Array<A8> = (([new A8((-646454560)), new A8((-1701957876))] : Array<A8>)).slice(-2, 6);
		H.out("o422 " + Std.string(E0.E0A));
		fn44((true + ""));
		switch (K9.K9B) {
			case K9.K9A: {
				var v423:Array<Int> = [88, 231, 259];
			};
			case K9.K9B: {
				var v424 = ("Haxe").charAt(3);
			};
			case _: {
				var v425:Int = 117;
				final v426:Array<Int> = [v425, v425];
			};
		}
		final v427:Int = (K9.K9A : Int);
		(new C20(3.0, v427)).m17(Math.isNaN(170), (-16));
		H.out("o428 " + Std.string(0.30000000000000004));
		H.out("o429 " + Std.string(E0A));
	}
	public static function section1():Void {
		H.tick();
		function lf430(n431:Int):Int {
			H.tick();
			return n431 <= 0 ? n431 : (lf430(n431 - 1) + (n431 - Type.enumIndex(E0.E0B(true))));
		}
		H.out("lf430 " + lf430(5));
		var v432:Array<String> = ["abc"];
		var v433:Map<String, C13> = (["k0" => new C20(123456.789, 214)] : Map<String, C13>);
		switch (E0B((Std.downcast((null : C23), C23) != null))) {
			case E0A: {
				var v434 = Math.floor(0.5);
			};
			case E0B(c435): {
				var v436:Bool = true;
				H.out("o437 " + Std.string(E0.E0A));
			};
		}
		var v438:S2 = ({x3: ("").substring(4, 3)} : S2);
	}
	public static function section2():Void {
		H.tick();
		H.out("o439 " + Std.string(({x7: Std.int(1e21), x6: (K9.K9B : Int), x5: "Haxe"} : S4)));
		final v440:() -> Int = () -> 0xC934;
		var v441:Int = 166;
		var v442:E0 = Ext.ext61(("ab").substr(((-319608091) & 7), (v441 & 7)));
		function lf443(n444:Int):Int {
			H.tick();
			return n444 <= 0 ? 0x80000000 : (lf443(n444 - 1) + Std.int(Std.parseFloat("3")));
		}
		H.out("lf443 " + lf443(4));
		v441 *= (((["ab", "\n", "\x41\x42"]).join(",")).charCodeAt(v441) ?? -1);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
