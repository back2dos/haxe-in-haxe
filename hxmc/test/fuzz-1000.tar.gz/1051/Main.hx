import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
}

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

enum abstract K6(Int) to Int {
	var K6A = 1;
	var K6B = 4;
	var K6C = 7;
}

class Main {
	public static inline function fn7(a8:Int, a9:String, a10:Float):Float {
		H.tick();
		var v29:Bool = (true ? true : true);
		a8 -= a8;
		a8++;
		H.out("o30 " + Std.string((-2147483647)));
		if (v29) {
			var v31:Float = a10;
			a8 |= 107;
			var v32:E0 = E0.E0A;
		}
		return H.apply(((a8 -= 1) - 0x7FFFFFFF), (v33:Int) -> v33);
	}
	public static inline function fn11():Void {
		H.tick();
		var v34:String = "A-B-C";
		Main.fn7((-368641254), "\t", (123456.789 / 187));
		var v35:Map<String, String> = ((switch (K6.K6B) {
			case K6.K6A: (["k0" => v34, "k1" => "\u{1F600}", "k2" => v34] : Map<String, String>);
			case K6.K6B: new Map<String, String>();
			case K6.K6C: new Map<String, String>();
		}) : Map<String, String>);
		if ((StringTools.startsWith("Haxe", v34) && Math.isNaN(100.75))) {
			switch (E0.E0A) {
				case E0A: {
					H.out("o36 " + v34);
				};
			}
			for (i37 in 0...2) {
				H.tick();
				var v38 = i37;
			}
			H.out("o39 " + Std.string(Lambda.count(([] : Array<Int>), v40 -> false)));
		} else {
			{
				Main.fn7(0x80000000, "\u{1F600}", 0.1);
				var v41:Map<Int, E0> = ([-3 => E0A, 4 => E0.E0A, 11 => E0A] : Map<Int, E0>);
			}
			var v42:E0 = E0A;
		}
	}
	public static function fn12():Float {
		H.tick();
		var v43 = ("ab").toLowerCase();
		fn7((0xFFFFFFFF & Type.enumIndex(E0.E0A)), (Std.string(false) + (((-1263090900) : A5) : Int)), Math.fceil(0.1));
		H.out("o44 " + Std.string((Std.parseInt(v43) ?? 0)));
		var v45:Int = 197;
		Main.fn7((Std.string(E0.E0A)).lastIndexOf("zz"), "ünï", ((false ? v45 : v45) : Float));
		for (i46 in 0...H.lim(v45)) {
			H.tick();
			H.out("o47 " + Std.string(Math.ceil(1e-7)));
			final v48:Float = i46;
		}
		var v49:K6 = K6.K6B;
		return fn7((cast (Lambda.count([288, v45], v50 -> StringTools.startsWith(v43, v43))) : Int), H.id("\t"), fn7(Reflect.compare(v43, v43), "", 0.5));
	}
	public static function fn13(a14:E0):Bool {
		H.tick();
		H.out("o51 " + Std.string((Std.parseInt(Std.string(((81 : A5)).get())) ?? 0)));
		if ((switch (139) {
			case 0: false;
			case 1 | 4: true;
			case _: false;
		})) {
			var v52 = true;
		}
		H.out("o53 " + Std.string((cast ((("q").charCodeAt(174) ?? -1)) : Int)));
		H.out("o54 " + ("\n" + 175));
		Main.fn12();
		var v55:Float = ((new A5(49)).get() - 131);
		var v56:Int = 195;
		return !(true ? false : Math.isNaN(0.5));
	}
	public static function fn15(a16:E0, a17:String, a18:Bool):Void {
		H.tick();
		var v57:E0 = E0.E0A;
		H.out("o58 " + Std.string(Math.ceil(1e100)));
		if (a18) {
			H.out("o59 " + String.fromCharCode(65 + ((142) & 15)));
			var w60 = 0;
do {
				w60++;
				H.tick();
				H.out("o61 " + Std.string(new Box(119)));
				var v62:Map<Int, Int> = ([-3 => 0x192E] : Map<Int, Int>);
				H.out("o63 " + Std.string(a18));
			} while (w60 < 2 && true);
			var v64:S3 = ({x4: a18} : S3);
		}
		H.out("o65 " + a17);
	}
	public static function fn19(?a20:Null<String>):Int {
		H.tick();
		var v66 = Std.string(true);
		var v67:Int = (v66).lastIndexOf(Std.string(1.7976931348623157e308));
		switch (((true ? K6.K6A : K6.K6B) : K6)) {
			case K6.K6A: {
				var v68:String = v66;
				switch (K6.K6A) {
					case K6.K6A: {
						var v69:K6 = K6.K6B;
						H.out("o70 " + Std.string(false));
					};
					case K6.K6B: {
						H.out("o71 " + Std.string(0xB687));
					};
					case K6.K6C: {
						final v72:Bool = true;
						var v73:S3 = ({x4: v72} : S3);
					};
				}
			};
			case K6.K6B: {
				switch (K6.K6B) {
					case K6.K6A: {
						v67 = 0xAE22;
						var v74 = v67;
					};
					case K6.K6B: {
						Main.fn13(E0A);
						H.out("o75 " + Std.string(v67));
					};
					case K6.K6C: {
						var v76:Bool = false;
					};
				}
			};
			case K6.K6C: {
				for (i77 in 0...2) {
					H.tick();
					v67 += i77;
				}
				fn12();
			};
			case _: {
				final v78:E0 = E0A;
			};
		}
		return 0x7FFFFFFF;
	}
	public static function fn21(a22:Int, a23:Float):(Int) -> Int {
		H.tick();
		H.out("o79 " + Std.string(({ var v80 = (-1471629260); (-3); })));
		for (i81 in 1...1) {
			H.tick();
			var w82 = 0;
while (w82 < 3 && true) {
				w82++;
				H.tick();
				H.out("o83 " + Std.string(161));
			}
			var v84:Int = i81;
		}
		if (false) {
			var v85:S3 = ({x4: false} : S3);
			a22 = (K6.K6A : Int);
		}
		H.out("o86 " + Std.string(E0A));
		H.out("o87 " + Std.string(({x4: true} : S3)));
		final v88:() -> Float = () -> 1.25;
		return (p89:Int) -> a22;
	}
	public static function section0():Void {
		H.tick();
		(({ var v103 = ("-7").lastIndexOf("42"); [99]; })).ext25();
		var v104:E0 = E0.E0A;
		var v105 = 90;
		Main.fn7(Main.fn19("hello world"), Std.string(Math.floor(v105)), (v105 + v105));
		H.out("o106 " + Std.string(Main.fn19(String.fromCharCode(65 + ((220) & 15)))));
	}
	public static function section1():Void {
		H.tick();
		if ((74 <= 300)) {
			{
				final v107:Bool = true;
			}
			H.out("o108 " + Std.string(E0.E0A));
		}
		final v109:Bool = (StringTools.contains("x,y,z", "q") && true);
		var v110 = ("zz").replace("a", "b");
		var v111:Null<Int> = null;
		v110 = H.cap(v110 + v110);
		for (i112 in 0...2) {
			H.tick();
			switch ((-1886536968)) {
				case 0: {
					var v113:Box<() -> Int> = new Box<() -> Int>(function():Int {
						H.tick();
						final v114:Bool = v109;
						var v115 = i112;
						var v116 = v115;
						return i112;
					});
					var v117:String = "x,y,z";
				};
				case 2 | 6: {
					fn7(i112, v110, i112);
					var v118:Box<Bool> = new Box(v109);
				};
				case _: {
					Main.fn15(E0.E0A, v110, false);
					v110 = H.cap(v110 + v110);
				};
			}
			switch ((v110).replace("a", "b")) {
				case "a" | "b": {
					var v119:Int = 1438631947;
				};
				case "Haxe": {
					var v120:Float = (-2.5);
					H.out("o121 " + Std.string(i112));
				};
				case _: {
					final v122 = i112;
					H.out("o123 " + Std.string(v122));
				};
			}
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
