package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext25(a24:Array<Int>):String {
		H.tick();
		switch (StringTools.lpad("ünï", "*", (0xD30C & 7))) {
			case "a" | "b": {
				var v90:S3 = ({x4: false} : S3);
			};
			case "Haxe": {
				Main.fn12();
			};
			case _: {
				var v91:Map<String, String> = new Map<String, String>();
			};
		}
		if ((([-3 => 105, 4 => 65535, 11 => 248] : Map<Int, Int>)).exists(151)) return 'x${Std.string((E0.E0A).match(E0A))}';
		var v92:Float = ((false ? 1.7976931348623157e308 : (-2.5)) : Float);
		var v93:Int = (if ((E0.E0A).match(E0A)) 100 else (Std.parseInt(Std.string(644301706)) ?? 0));
		v93 <<= (v93 & 7);
		return ("hello world").toLowerCase();
	}
	public static function ext28(a26:String, a27:Float):Float {
		H.tick();
		var v94 = 0xB3B4;
		var v95 = 228;
		var w96 = 0;
do {
			w96++;
			H.tick();
			H.out("o97 " + Std.string(v94));
		} while (w96 < 3 && true);
		if (true) {
			for (i98 in 0...H.lim(Reflect.compare(a26, "hello world"))) {
				H.tick();
				var v99 = i98;
				H.out("o100 " + Std.string(v99));
				final v101:Float = v99;
			}
			Main.fn13(E0.E0A);
		}
		H.out("o102 " + Std.string(248));
		return 100.75;
	}
}
