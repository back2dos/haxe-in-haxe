import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class Main {
	public static function fn5():Float {
		H.tick();
		H.out("o27 " + Std.string(Type.enumIndex(E3.E3B)));
		if ((StringTools.startsWith("abc", "\x41\x42") ? (new Map<Int, Bool>()).exists(-3) : false)) {
			switch (E3.E3A) {
				case E3A: {
					H.out("o28 " + "42");
				};
				case E3B: {
					var v29:E0 = E0.E0B;
				};
			}
			H.out("o30 " + Std.string(([270, 0xFFFFFFFF, 1312096057]).length));
			H.out("o31 " + Std.string((Std.parseInt("0") ?? 0)));
		} else {
			var v32:String = Std.string(100.75);
			if (true) {
				var v33 = 0x57EB;
			} else {
				final v34 = true;
				v32 += "0";
			}
		}
		var v35 = ((Std.parseInt(Std.string(9)) ?? 0) + "-7");
		var v36:Array<A4> = ([new A4(0xFFFFFFFF), new A4(0x967A)] : Array<A4>);
		if ((123456.789 != 7.0)) {
			var v37:Int = 0x31F3;
			H.out("o38 " + Std.string(v37));
		}
		return 0.1;
	}
	public static function fn6(?a7:Null<Int>):Null<Int> {
		H.tick();
		var v39:A4 = ((switch (259) {
			case 0: new A4(210);
			case 1 | 5: new A4(0xC47F);
			case c40 if (c40 > 10): new A4(0xEF95);
			case _: new A4(175);
		}) : A4);
		var v41:Int = ((new Map<String, Int>()).get("k3") ?? 0);
		var v42:Array<String> = ["日本語"];
		return v41;
	}
	public static function fn8():Bool {
		H.tick();
		var v43:Array<Bool> = [(E3.E3A).match(E3A), true, false];
		Ext.ext23((new A4(118)).get(), (Std.string(175) <= ("abc").substr(-1, 6)));
		H.out("o44 " + Std.string(((String.fromCharCode(65 + (((-17)) & 15))).charCodeAt((Std.parseInt("zz") ?? 0)) ?? -1)));
		(99).ext26(Type.enumIndex(E3.E3B));
		var v45:Array<Int> = Ext.ext23(Math.ceil(1e3), StringTools.endsWith("", "ab"));
		var v46:E0 = E0.E0D(("-7").replace("a", "b"));
		var v47 = (Reflect.compare(23, 137400157)).ext26((-917341282));
		return ((switch (E0.E0A) {
			case E0A: true;
			case E0B: false;
			case E0C: (v45).contains(v47);
			case E0D(_): false;
			case _: (E3.E3B).match(E3B);
		}) ? (1e3 < (-2.5)) : StringTools.startsWith("", ("0").replace("a", "b")));
	}
	public static function fn9(a10:String, a11:Box<Int>, a12:String = "d"):Void {
		H.tick();
		var v48 = Lambda.count(([] : Array<Int>), v49 -> StringTools.startsWith(a12, a10));
		H.out("o50 " + Std.string(H.at(([] : Array<Int>), (--v48), 0)));
		{
			var v51 = ([v48]).contains(v48);
			var v52:Int = v48;
			var v53:Map<String, Int> = (["k0" => v52, "k1" => v48] : Map<String, Int>);
		}
	}
	public static function fn13(a14:Int, a15:Int, a16:Bool):String {
		H.tick();
		var v54 = a14;
		if (a16) {
			Main.fn9(("42").replace("a", "b"), new Box(844357469));
			if (a16) {
				H.out("o55 " + Std.string(a14));
				H.out("o56 " + Std.string(new Box<Int>(a15)));
				fn8();
			} else {
				H.out("o57 " + Std.string(1e-7));
			}
			var v58:Int = (Std.parseInt("ab") ?? 0);
		} else {
			v54 -= Reflect.compare(v54, 141);
		}
		final v59 = (295 + 165);
		var v60 = H.at(([] : Array<Int>), a14, 0);
		switch (v54) {
			case 0: {
				H.out("o61 " + Std.string(a15));
				if (false) {
					var v62:Float = a14;
				}
			};
			case 2 | 6: {
				if (a16) return "Haxe";
				H.out("o63 " + Std.string(E0.E0A));
			};
			case _: {
				v54--;
			};
		}
		var v64:Array<Box<Int>> = (([new Box(11), new Box(118)] : Array<Box<Int>>)).filter(v65 -> ([297, v54, a15]).contains(a15));
		H.out("o66 " + Std.string(v60));
		if (("a" != (("\\").split(" ")).join(""))) {
			if ((E0.E0D("\t")).match(E0C)) {
				final v67 = "A-B-C";
			} else {
				var v68:Int = v59;
				Main.fn6();
			}
			if (false) {
				var v69 = 299;
				var v70:Map<String, Map<String, Int>> = (["k0" => new Map<String, Int>()] : Map<String, Map<String, Int>>);
			}
			v60 ^= v54;
		}
		return '-${"日本語"}-${Std.string((273).ext26(a15))}-${Std.string((true || true))}';
	}
	public static function fn17(a18:Int, a19:String, a20:Int):Float {
		H.tick();
		a19 = H.cap(a19);
		var v71:Array<String> = ((false ? ["  pad  ", a19] : ["0", "zz"]) : Array<String>);
		final v72:Array<Bool> = [([a20]).contains(a18)];
		return 3.0;
	}
	public static function section0():Void {
		H.tick();
		H.out("o84 " + Std.string((Math.round(100.75) >>> ((Std.parseInt(Std.string(19)) ?? 0) & 31))));
		if ((cast ((([-3 => "42", 4 => "0"] : Map<Int, String>)).exists(4)) : Bool)) {
			var v85 = true;
			fn13(Reflect.compare("0", "\\"), (-931953562), (E0.E0C).match(E0B));
		} else {
			var v86:E0 = E0.E0B;
			var v87:Box<Int> = new Box(94);
		}
		H.out("o88 " + Std.string(Math.floor(0xC127)));
		H.out("o89 " + Std.string((Math.round(123456.789) | 136)));
		var v90:E0 = (cast (E0.E0D("Haxe")) : E0);
		var v91:Int = (cast (193) : Int);
		switch ((~v91)) {
			case 0: {
				H.out("o92 " + Std.string((new A4(v91) : Int)));
				H.out("o93 " + Std.string(Lambda.fold(([] : Array<Int>), (v94:Int, v95:Int) -> ([82]).indexOf((-2116959500)), 0)));
			};
			case 3 | 6: {
				if ((E0.E0B).match(E0B)) {
					final v96:Int = v91;
				} else {
					H.out("o97 " + Std.string(v91));
					(v91).ext26(1482593702);
				}
			};
			case c98 if (c98 > 10): {
				switch (Std.string(false)) {
					case "a" | "b": {
						var v99:E3 = E3.E3A;
					};
					case "Haxe": {
						var v100 = "42";
						final v101:(Int, String) -> String = function(p102:Int, p103:String):String {
							H.tick();
							H.out("o104 " + Std.string(v91));
							H.out("o105 " + Std.string(false));
							v91 <<= (260 & 7);
							return v100;
						};
					};
					case _: {
						H.out("o106 " + Std.string(false));
						Ext.ext26(9, c98);
					};
				}
			};
			case _: {
				v91 <<= ((["\x41\x42", "a"]).length & 7);
			};
		}
		H.out("o107 " + Std.string(Ext.ext26(0xB9F8, Type.enumIndex(E3.E3A))));
		H.out("o108 " + Std.string(276));
	}
	public static function section1():Void {
		H.tick();
		var v109:Int = 0xEB4F;
		var v110:E3 = E3.E3A;
		H.out("o111 " + Std.string(v109));
		var v112:Array<Box<A4>> = ([new Box<A4>(new A4(v109)), new Box<A4>((229 : A4)), new Box<A4>(new A4(14))] : Array<Box<A4>>);
		var v113:Float = 1e21;
	}
	public static function section2():Void {
		H.tick();
		H.out("o114 " + Std.string(([224, 90]).length));
		H.out("o115 " + Std.string(E0.E0A));
		var v116:Array<Array<Int>> = ([[166], ([] : Array<Int>), ([] : Array<Int>)] : Array<Array<Int>>);
		var v117 = (switch (E0.E0A) {
			case E0A: ("ab").substring(2, (0x1C2A & 7));
			case E0B: "日本語";
			case E0D(_): ("\u{1F600}").charAt((141 & 7));
			case _: ("-7").toLowerCase();
		});
		H.out("o118 " + Std.string(E0.E0A));
		H.out("o119 " + Std.string(197));
	}
	public static function section3():Void {
		H.tick();
		H.out("o120 " + Std.string(!false));
		var v121 = (((186 : A4) : Int) & ("ab").length);
		var v122:A4 = H.id((v121 : A4));
		switch ((54 != (new A4(65535)).get())) {
			case true: {
				Main.fn6(("42").lastIndexOf("-7"));
				final v123:Float = 105;
			};
			case false: {
				H.out("o124 " + Std.string(false));
			};
		}
		{
			var v125:Int = (("é").charCodeAt(v121) ?? -1);
			((["\n", "ab"]).indexOf("ünï")).ext26(130);
			H.out("o126 " + Std.string(v125));
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
