package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext23(a21:Int, a22:Bool):Array<Int> {
		H.tick();
		if ((a22 && true)) return [(Std.parseInt("  pad  ") ?? 0), (("zz").charCodeAt(a21) ?? -1)];
		var v73:String = StringTools.trim(("ab").replace("a", "b"));
		H.out("o74 " + v73);
		if (a22) {
			a21++;
			a21 = (-2069169943);
		}
		if (a22) {
			H.out("o75 " + StringTools.replace(v73, "b", ""));
			Main.fn5();
			Main.fn5();
		} else {
			a21 -= (new A4(a21) : Int);
		}
		var v76 = (((([-3 => a21] : Map<Int, Int>)).get(18) ?? 0) ^ a21);
		return (([a21, v76, 100.75] : Array<Float>)).map((v77:Float) -> v76);
	}
	public static function ext26(a24:Int, a25:Int):Int {
		H.tick();
		var v78 = 243;
		var v79:Float = v78;
		Ext.ext23(a25, (false || (new Map<String, Float>()).exists("k0")));
		var v80 = (StringTools.contains("0", "-7") ? (-1778837996) : Reflect.compare(0x80000000, a24));
		H.out("o81 " + Std.string((v80--)));
		var v82:Array<Int> = Ext.ext23(281, ([56, a24, 65535]).contains((-2147483647)));
		if (([(-5), a24, v78]).contains((Std.parseInt(Std.string(a25)) ?? 0))) {
			Ext.ext23(a24, (E0.E0D("a\rb")).match(E0B));
			H.out("o83 " + Std.string(v78));
		} else {
			a25 *= v78;
			a24 = ("A-B-C").lastIndexOf("\n");
		}
		Main.fn6();
		if ((StringTools.trim("é") <= "x,y,z")) return ((new Map<Int, E0>()).exists(11) ? v78 : H.at(v82, 0xFFFFFFFF, 0));
		return v78;
	}
}
