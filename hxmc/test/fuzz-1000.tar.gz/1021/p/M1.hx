package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
	E0B;
	E0C;
	E0D(a2:String);
}

abstract A4(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A4, b:A4):A4
		return new A4(a.get() + b.get());

	@:op(A * B) public static function mul(a:A4, b:A4):A4
		return new A4(a.get() * b.get());

	@:op(-A) public static function neg(a:A4):A4
		return new A4(-a.get());
}
