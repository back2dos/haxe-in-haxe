import H;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Int, a2:Float);
	E0C(a3:String, a4:Int);
	E0D;
}

enum E5 {
	E5A;
	E5B(a6:Int);
}

typedef S7 = {x8:String, x9:Int, x10:String};

typedef S11 = {x12:Int, x13:String, x14:String};

enum abstract K15(Int) to Int {
	var K15A = 1;
	var K15B = 4;
}

interface I16 {
	function m17():String;
	function m18(a19:Bool):E5;
}

class C20 {
	public function new() {}
	public static function m21():Int {
		H.tick();
		for (k57 => v58 in ((true ? (["k0" => 158666247, "k1" => 160] : Map<String, Int>) : (["k0" => 56, "k1" => 21, "k2" => 192] : Map<String, Int>)) : Map<String, Int>)) {
			H.tick();
			var v59 = k57;
		}
		var v60:Map<Int, Float> = (cast (new Map<Int, Float>()) : Map<Int, Float>);
		var v61:S11 = ({x12: ([0xEACA, 154, 28]).indexOf(190), x13: ([true, false]).join("|"), x14: ("ab").replace("a", "b")} : S11);
		for (x62 in [for (i63 in ["é", ""]) if (false) (Std.downcast((new C23() : C23), C23) != null)]) {
			H.tick();
			var v64:C23 = new C23();
		}
		var v65 = (true ? ("x,y,z").replace("a", "b") : "ünï");
		return ((K15.K15A : Int) + 154);
	}
	public function m22():Int {
		H.tick();
		H.out("o66 " + Std.string((K15.K15A : Int)));
		var v67 = (([3.0, (-2.5), 1e100] : Array<Float>)).length;
		var v68:Map<Int, C20> = new Map<Int, C20>();
		H.out("o69 " + Std.string(true));
		if ((v67 >= 228)) {
			(new C23()).m17();
			if (((["k0" => "\x41\x42", "k1" => "\\"] : Map<String, String>)).exists("k2")) {
				H.out("o70 " + "\x41\x42");
				var v71:E0 = E0.E0A;
				H.out("o72 " + Std.string(v67));
			} else {
				H.out("o73 " + Std.string(E5.E5A));
			}
			final v74 = (([] : Array<Int>)).length;
		}
		v67 = (~v67);
		return (v67 | Std.int(41));
	}
}

class C23 implements I16 {
	public var f24:Int;
	public function new() {
		this.f24 = 0xFC6B;
	}
	public function m17():String {
		H.tick();
		this.f24 &= (H.at([128, 84], 50, 0) + this.f24);
		for (i75 in 0...H.lim(({ var v76 = ("x,y,z").lastIndexOf("ab"); this.f24; }))) {
			H.tick();
			if (true) {
				var v77:Map<Int, Float> = ([-3 => 2.5e-3] : Map<Int, Float>);
				this.f24 &= i75;
			} else {
				H.out("o78 " + Std.string(i75));
			}
		}
		var v79:E5 = E5B(286);
		H.out("o80 " + Std.string(Math.sin(1e-7)));
		final v81:Bool = (true ? ([186, 102]).contains(0x8A57) : true);
		var v82:Float = 0.30000000000000004;
		if (v81) {
			var v83:C20 = new C20();
			if (StringTools.endsWith("\"q\"", "-7")) {
				var v84:Map<Int, String> = ([-3 => "日本語"] : Map<Int, String>);
			} else {
				H.out("o85 " + Std.string(v79));
				var v86:Array<Int> = [214, 55, 55];
			}
		} else {
			H.out("o87 " + Std.string(StringTools.startsWith("-7", "é")));
			var v88:Int = Type.enumIndex(v79);
		}
		return StringTools.replace((new Box("q")).get(), ",", ("\"q\"" + Std.string(18)));
	}
	public function m18(a19:Bool):E5 {
		H.tick();
		H.out("o89 " + Std.string(({x8: Std.string(3.0), x9: (Std.parseInt("-7") ?? 0), x10: "  pad  "} : S7)));
		if (a19) {
			this.f24 = ([28, 65]).indexOf(60);
			for (i90 in 0...H.lim(([false, a19]).indexOf(a19))) {
				H.tick();
				this.f24 = i90;
				H.out("o91 " + Std.string(15));
				var v92:Map<String, Int> = new Map<String, Int>();
			}
			var v93 = 27;
		} else {
			for (i94 in 1...1) {
				H.tick();
				var v95:Float = 0.1;
				v95 = H.id(v95);
			}
		}
		for (x96 in [for (i97 in 0...1) ([i97, i97, i97]).join(",")]) {
			H.tick();
			var v98 = "-7";
			H.out("o99 " + Std.string(237));
		}
		var v100:Array<Int> = [for (i101 in 0...1) ((new Map<Int, Int>()).get(18) ?? 0)];
		final lf102:(Int) -> String = (p103:Int) -> ("\t" + String.fromCharCode(65 + ((70) & 15)));
		var v104:String = (new C23()).m17();
		var v105 = a19;
		if ((2.5e-3 != 62)) {
			var v106:Array<Array<Int>> = ([] : Array<Array<Int>>);
			this.f24 = 271;
		}
		final v107:Map<String, Int> = (["k0" => this.f24] : Map<String, Int>);
		return H.apply(({ var v109 = v104; 136; }), (v108:Int) -> (cast (E5.E5A) : E5));
	}
	public function m25(a26:Int):Float {
		H.tick();
		var v110:Bool = (a26 < this.f24);
		var v111:Array<Int> = [for (i112 in 0...0) H.at([i112], i112, 0)];
		var v113:Array<Float> = ([for (i114 in 0...0) Math.sin(7.0)] : Array<Float>);
		Main.fn41(5e-324, ((true ? ({x8: "abc", x9: a26, x10: "hello world"} : S7) : ({x8: "\\", x9: a26, x10: "q"} : S7)) : S7), (Std.parseInt(Std.string(a26)) ?? 0));
		var v115:Bool = v110;
		H.out("o116 " + Std.string((K15.K15A : Int)));
		return 1e3;
	}
	public function m27(a28:Bool, a29:Bool):Void {
		H.tick();
		var v117:Int = Type.enumIndex(E5.E5B(147));
		C20.m21();
		for (x118 in ([v117]).concat([v117])) {
			H.tick();
			var w119 = 0;
while (w119 < 1 && false) {
				w119++;
				H.tick();
				var v120:Array<Int> = ([] : Array<Int>);
			}
		}
	}
	public function m30(a31:E5, a32:String):Int {
		H.tick();
		final v121:S11 = ({x13: a32, x12: 293, x14: Std.string(false)} : S11);
		if ((43 <= (a32).indexOf(a32))) {
			H.out("o122 " + (a32).toLowerCase());
			Main.fn45(E0.E0A, (-15));
		} else {
			for (i123 in 2...3) {
				H.tick();
				H.out("o124 " + a32);
			}
			if (([287, 223, 88]).contains((-19))) {
				this.f24 = 0xCD9;
				this.f24--;
			} else {
				var v125:Float = 1.25;
				Main.fn41(1.25, ({x10: a32, x9: 153, x8: a32} : S7), 147);
			}
		}
		if ((false && true)) {
			this.f24 <<= ((-334161287) & 7);
			var v126:Map<String, Int> = new Map<String, Int>();
			var v127:Null<Int> = null;
		} else {
			for (x128 in [false, true, false]) {
				H.tick();
				H.out("o129 " + Std.string(a31));
				H.out("o130 " + Std.string(true));
			}
		}
		var v131:Array<Int> = [for (i132 in ([] : Array<Bool>)) if (true) Math.floor(7.0)];
		H.out("o133 " + a32);
		(new C20()).m22();
		H.out("o134 " + Std.string(C20.m21()));
		return 174;
	}
	public function m33(a34:Int):Int {
		H.tick();
		if (StringTools.startsWith("\\", "zz")) return (({x8: "日本語", x9: a34, x10: "A-B-C"} : S7)).x9;
		H.out("o135 " + Std.string((("zz").charCodeAt(a34) ?? -1)));
		a34 = C20.m21();
		(new C35("\n", a34)).m17();
		H.out("o136 " + (StringTools.trim("\x41\x42")).toUpperCase());
		return (m17()).lastIndexOf(({ var v137 = 100.75; ("0").toLowerCase(); }));
	}
}

class C35 implements I16 {
	public final f36:Int;
	public final f37:Bool;
	public static var f38:Array<String> = ([] : Array<String>);
	public function new(a39:String, a40:Float) {
		this.f36 = Math.floor(123456.789);
		this.f37 = false;
	}
	public function m17():String {
		H.tick();
		if ((("\t").indexOf("é") == (Std.parseInt(Std.string(7)) ?? 0))) {
			H.out("o138 " + Std.string(null));
			H.out("o139 " + Std.string((-2147483647)));
		} else {
			var v140:S11 = ({x13: "x,y,z", x14: "é", x12: 71} : S11);
		}
		H.out("o141 " + Std.string((true ? this.f36 : Type.enumIndex(E5.E5B((-974343219))))));
		final v142:Array<Bool> = ([] : Array<Bool>);
		final v143:Array<E0> = ([E0C("x,y,z", 0x3E93), E0D] : Array<E0>);
		if ((Std.string(81) == StringTools.trim("Haxe"))) {
			H.out("o144 " + Std.string(new Box<I16>(new C35("zz", 100.75))));
		} else {
			var v145:C23 = new C23();
			for (i146 in 1...3) {
				H.tick();
				var v147:Array<K15> = ([K15.K15A, K15.K15A] : Array<K15>);
				final v148:Float = 0.1;
				H.out("o149 " + "q");
			}
		}
		var v150:Box<Int> = new Box(187);
		var v151:Array<Float> = (([] : Array<Float>)).copy();
		return "ünï";
	}
	public function m18(a19:Bool):E5 {
		H.tick();
		a19 = (a19 && a19);
		H.out("o152 " + Std.string(new Box<String>("a")));
		H.out("o153 " + Std.string(new C23()));
		return E5.E5A;
	}
}

class Main {
	public static function fn41(a42:Float, a43:S7, a44:Int):Array<String> {
		H.tick();
		H.out("o154 " + Std.string((cast (Std.isOfType(new C23(), C23)) : Bool)));
		H.out("o155 " + StringTools.lpad("日本語", "*", -1));
		H.out("o156 " + Std.string(Lambda.count([a44, 298], v157 -> false)));
		return [(StringTools.lpad("q", "*", (a44 & 7))).toUpperCase()];
	}
	public static function fn45(a46:E0, a47:Int):Int {
		H.tick();
		final v158 = a47;
		final v159:Null<Int> = a47;
		for (x160 in ([7.0, 1e100, a47] : Array<Float>)) {
			H.tick();
			var v161:Float = 69;
			fn41(v158, ({x8: "-7", x9: v158, x10: "  pad  "} : S7), a47);
		}
		H.out("o162 " + Std.string((([] : Array<I16>)).filter(v163 -> ([170, v158, v158]).contains(170))));
		var v164:Map<String, String> = new Map<String, String>();
		H.out("o165 " + Std.string(Type.enumIndex(E0.E0D)));
		fn41(v158, ({x8: "é", x9: (Std.parseInt(Std.string(a47)) ?? 0), x10: (("Haxe").split(" ")).join(" ")} : S7), (-(([] : Array<Int>)).length));
		for (k167 => x166 in C35.f38) {
			H.tick();
			a47 ^= ((x166).charCodeAt(46) ?? -1);
		}
		(new C23()).m17();
		return (20 - (([] : Array<Float>)).length);
	}
	public static function fn48():String {
		H.tick();
		var v168 = H.at([185, (-923589171)], (([] : Array<Int>)).length, 0);
		var w169 = 0;
while (w169 < 2 && (true ? ([v168, v168, 99]).contains(v168) : true)) {
			w169++;
			H.tick();
			var v170:Int = v168;
			var v171:String = ([false]).join("");
		}
		var v172:I16 = new C35(([v168]).join(" "), v168);
		H.out("o173 " + Std.string((("0").toUpperCase() >= Std.string(true))));
		v168 = ({ var v174 = v168; (K15.K15B : Int); });
		return (({ var sb175 = new StringBuf(); sb175.add(Std.string(false)); sb175.add(Std.string(Std.isOfType(new C20(), C20))); sb175.addChar(74); sb175.toString(); }) + (((([-3 => v168] : Map<Int, Int>)).get(4) ?? 0) > v168));
	}
	public static function fn49(?a50:Null<Bool>):String {
		H.tick();
		var v176 = StringTools.lpad(("").replace("a", "b"), "*", 3);
		final v177:Array<Int> = (([] : Array<Int>)).filter(v178 -> ([v178]).contains(275));
		var v179:Int = ((v176).lastIndexOf(v176) << ((v177).indexOf(97) & 31));
		final v180 = (new Box("\n")).get();
		for (i181 in 0...2) {
			H.tick();
			final lf182:() -> Void = function():Void {
				H.tick();
				(new C23()).m33(56);
				(new C23()).m33(0x5BAD);
				v179 += i181;
			};
		}
		final lf183:(Bool, Int) -> Void = function(p184:Bool, p185:Int):Void {
			H.tick();
			var v186:S11 = ({x12: 257, x13: v180, x14: v176} : S11);
			if (false) {
				final v187:Null<Int> = p185;
			}
		};
		(new C23()).m17();
		var v188:Bool = false;
		var w189 = 0;
while (w189 < 5 && ("42" >= v180)) {
			w189++;
			H.tick();
			var v190:E5 = E5B(v179);
		}
		return (82 + v180);
	}
	public static function fn51(a52:E5, a53:Array<String>):Float {
		H.tick();
		for (k192 => x191 in ([] : Array<Int>)) {
			H.tick();
			var v193:K15 = K15.K15A;
			var v194 = Reflect.compare("42", "ab");
		}
		var v195:E0 = E0B((Std.parseInt("42") ?? 0), 1.25);
		var v196:Bool = Std.isOfType(new C35("abc", 2.5e-3), I16);
		return (({ var sb197 = new StringBuf(); sb197.add(Std.string(183)); sb197.add("42"); sb197.add(Std.string(false)); sb197.addChar(90); sb197.toString(); })).ext56();
	}
	public static function fn54():Float {
		H.tick();
		for (i198 in 0...H.lim((("é").length * Lambda.count([0], v199 -> false)))) {
			H.tick();
			H.out("o200 " + Std.string(Type.enumIndex(E0.E0B(i198, i198))));
		}
		if (((-2.5) <= (-1259450869))) {
			if (Std.isOfType(new C35("hello world", 0.1), C35)) {
				var v201:Null<Int> = null;
				H.out("o202 " + Std.string(259));
			} else {
				var v203:Box<Box<Int>> = new Box<Box<Int>>(new Box(271));
			}
			final v204:S11 = ({x12: 220, x13: "ünï", x14: "0"} : S11);
		}
		var w205 = 0;
while (w205 < 5 && (Std.parseFloat("-7") == 8)) {
			w205++;
			H.tick();
			H.out("o206 " + Std.string(0x4E2));
			H.out("o207 " + Std.string((-9)));
			var v208 = "\\";
		}
		final v209 = (new C35("  pad  ", (-2.5))).m17();
		fn41(0.30000000000000004, ({x8: "hello world", x9: (({x8: v209, x10: v209, x9: 0x7FFFFFFF} : S7)).x9, x10: (v209).toLowerCase()} : S7), 13);
		final v210:C23 = new C23();
		final v211:S7 = ({x8: "zz", x9: (({x8: v209, x9: 0x8C82, x10: "\t"} : S7)).x9, x10: v209} : S7);
		var v212:E0 = E0B(([0x7196, 0x1C31, 847876667]).indexOf(86), 100.75);
		var v213:Float = Main.fn51(E5.E5A, C35.f38);
		return 1.25;
	}
	public static function section0():Void {
		H.tick();
		final v217 = (false ? "Haxe" : "a");
		var v218:Bool = (false && StringTools.contains(v217, v217));
		var v219:Bool = v218;
		var v220:Map<Int, String> = ([-3 => "Haxe", 4 => "é", 11 => v217] : Map<Int, String>);
		var v221:Int = (-1488798303);
		var v222:Float = Main.fn54();
		for (k224 => x223 in [true]) {
			H.tick();
			fn49();
		}
	}
	public static function section1():Void {
		H.tick();
		var v225:Array<Bool> = [false];
		function lf226(n227:Int):Int {
			H.tick();
			return n227 <= 0 ? (cast ((-7)) : Int) : (lf226(n227 - 1) + (n227 + Type.enumIndex(E0B(n227, n227))));
		}
		H.out("lf226 " + lf226(1));
		var v228:Array<Int> = ([68, 0xE7BF, 149]).map((v229:Int) -> v229);
		H.out("o230 " + (C35.f38).join(" "));
		var v231 = C20.m21();
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
