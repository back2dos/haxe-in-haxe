package p;

import Main;
import H;
using StringTools;

class Ext {
	public static function ext56(a55:String):Int {
		H.tick();
		H.out("o214 " + Std.string(((Math.isNaN(7.0) ? 0.30000000000000004 : Std.parseFloat("12.5")) : Float)));
		final v215:() -> Bool = () -> false;
		var v216:String = "\u{1F600}";
		return (282 >>> (((a55).length & 222) & 31));
	}
}
