package p;

import Main;
import H;

class Ext {
	public static function ext47(a46:Int):String {
		H.tick();
		var v203:Array<Null<Int>> = ([] : Array<Null<Int>>);
		switch (K4.K4C) {
			case K4.K4A: {
				final v204 = (([] : Array<Int>)).contains(a46);
				switch (K4.K4C) {
					case K4.K4A: {
						a46 = H.id(a46);
					};
					case K4.K4B: {
						var v205:Int = a46;
					};
					case K4.K4C: {
						(new C5(a46)).m9(new C5(a46));
					};
					case K4.K4D: {
						a46 *= 256;
					};
				}
			};
			case K4.K4B: {
				H.out("o206 " + Std.string(Lambda.count([a46, a46], v207 -> ([a46, 144]).contains(135))));
				H.out("o208 " + Std.string(a46));
			};
			case K4.K4C: {
				var v209:Array<Bool> = [false, true, true];
			};
			case K4.K4D: {
				a46 <<= (([145, a46, 275]).indexOf(a46) & 7);
				final v210:(Int, Bool) -> Bool = function(p211:Int, p212:Bool):Bool {
					H.tick();
					a46 ^= a46;
					var v213:Int = a46;
					H.out("o214 " + Std.string((new A3(241) : Int)));
					return p212;
				};
			};
		}
		H.out("o215 " + Std.string(({x1: true, x2: (new A3(a46) : Int)} : S0)));
		return ('${Std.string(true)}x${"é"} = ${Std.string(C5.f7)}' + "\"q\"");
	}
	public static function ext50(a48:Array<Int>, a49:Array<Int>):Int {
		H.tick();
		for (i216 in 0...0) {
			H.tick();
			var w217 = 0;
while (w217 < 5 && Std.isOfType(new C5(210), C5)) {
				w217++;
				H.tick();
				var v218:A3 = new A3(258);
				var v219 = i216;
				Main.fn25(K4.K4A, true);
			}
		}
		for (i220 in 0...4) {
			H.tick();
			var v221 = true;
			for (x222 in [false, v221]) {
				H.tick();
				var v223:Int = i220;
			}
			for (x224 in [true]) {
				H.tick();
				H.out("o225 " + Std.string((new A3(i220) : Int)));
				Main.fn25(K4.K4C, x224);
				var v226 = i220;
			}
		}
		var v227 = (252 >> ((Std.parseInt(Std.string(1844648562)) ?? 0) & 31));
		var v228 = true;
		return v227;
	}
	public static function ext53(a51:Int, a52:Array<Bool>):Int {
		H.tick();
		Main.fn32((a51 + 136), (a51 | H.at([a51], a51, 0)));
		H.out("o229 " + Std.string((new A3(a51)).get()));
		H.out("o230 " + Std.string(a51));
		if (((Std.parseInt("-7") ?? 0) < a51)) return (H.at(([] : Array<Int>), 118, 0) + 196);
		{ var dyn231:Dynamic = ({x2: (new A3(a51) : Int), x1: true} : S0); H.out("dyn " + Std.string(dyn231.x1) + " " + Std.string(Reflect.field(dyn231, "x1"))); }
		for (x232 in ([a51, a51]).map((v233:Int) -> (Std.parseInt(Std.string(32)) ?? 0))) {
			H.tick();
			var v234:Int = (K4.K4B : Int);
			a51 = (new A3(x232)).twice;
		}
		for (i235 in 0...1) {
			H.tick();
			var v236:K4 = K4.K4B;
		}
		switch (H.id(([a51, a51, a51]).copy())) {
			case []: {
				(new C5(a51)).m11(Lambda.count([a51], v237 -> ([a51]).contains(v237)), new A3(a51), (({x1: false, x2: (-2147483647)} : S0)).x2, 132);
			};
			case [c238]: {
				var w239 = 0;
while (w239 < 4 && ([a51]).contains(c238)) {
					w239++;
					H.tick();
					var v240:Int = a51;
				}
			};
			case [_, c241]: {
				H.out("o242 " + Std.string([c241, c241]));
				var v243:Int = Lambda.count([35, 128, c241], v244 -> false);
			};
			case _: {
				try {
					if (true) throw "boom";
					final v245:Array<String> = ["zz", "\u{1F600}", "zz"];
					H.out("o246 " + Std.string(true));
				} catch (ex247:Err) {
					H.out("caught Err " + ex247.errCode);
					C5.f7 = false;
					H.out("o248 " + Std.string((new A3(a51) : Int)));
				} catch (ex249:haxe.Exception) {
					H.out("caught " + H.exn(ex249));
					final v250:K4 = K4.K4B;
					a51 = H.id(a51);
				}
			};
		}
		final v251 = (K4.K4C : Int);
		return v251;
	}
}
