import H;
using p.Ext;

typedef S0 = {x1:Bool, x2:Int};

abstract A3(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A3, b:A3):A3
		return new A3(a.get() + b.get());

	@:op(A * B) public static function mul(a:A3, b:A3):A3
		return new A3(a.get() * b.get());

	@:op(-A) public static function neg(a:A3):A3
		return new A3(-a.get());
}

enum abstract K4(Int) to Int {
	var K4A = 1;
	var K4B = 4;
	var K4C = 7;
	var K4D = 10;
}

class C5 {
	var _f6:Bool;

	public var f6(get, set):Bool;

	function get_f6():Bool
		return _f6;

	function set_f6(v:Bool):Bool
		return _f6 = v;
	public static var f7:Bool = false;
	public function new(a8:Int) {
		this._f6 = false;
	}
	public function m9(a10:C5):Array<Int> {
		H.tick();
		final v54 = ((({x1: true, x2: 0x80000000} : S0)).x2 << (202 & 31));
		H.out("o55 " + Std.string((v54 > v54)));
		var v56:Int = (-1427425419);
		return [((({x1: false, x2: v56} : S0)).x2 - v54), (v54 >> (v54 & 31))];
	}
	public function m11(a12:Int, a13:A3, ...r14:Int):Int {
		H.tick();
		var v57 = ({ var v58 = 176; (Std.parseInt(Std.string(v58)) ?? 0); });
		var v59:S0 = ({x1: Std.isOfType(null, C15), x2: (r14.toArray()).indexOf(v57)} : S0);
		a12 = v57;
		a12 = (a12 << (v57 & 31));
		r14.toArray().reverse();
		return v57;
	}
}

abstract class C15 {
	public var f16:Bool;
	public var f17:Bool;
	public function new(a18:Bool) {
		this.f16 = true;
		this.f17 = a18;
	}
	abstract public function m19(a20:Int):K4;
	public function m21(a22:Bool, a23:Int):Int {
		H.tick();
		H.out("o60 " + Std.string(34));
		(254).ext53(([] : Array<Bool>));
		if ((a22 && true)) {
			try {
				(a23).ext53([a22, a22, a22]);
				H.out("o61 " + Std.string(false));
				if (([186]).contains(a23)) throw new Err(a23);
			} catch (ex62:Err) {
				H.out("caught Err " + ex62.errCode);
				var v63:Int = 92;
				Main.fn28("abc", a23, (-2147483647));
			} catch (ex64:haxe.Exception) {
				H.out("caught " + H.exn(ex64));
				Main.fn32(132, a23);
			}
			for (k66 => x65 in [a23, a23]) {
				H.tick();
				H.out("o67 " + Std.string(([new A3((-7))] : Array<A3>)));
			}
			try {
				if (a22) throw 98;
				Main.fn25(K4.K4B, a22);
				var v68:Int = a23;
				var v69:C5 = new C5(v68);
			} catch (ex70:Err) {
				H.out("caught Err " + ex70.errCode);
				H.out("o71 " + Std.string([0xFFFFFFFF]));
			} catch (ex72:haxe.Exception) {
				H.out("caught " + H.exn(ex72));
				a23 ^= 0xDF4F;
				var v73 = a23;
			}
		}
		a23 ^= a23;
		Main.fn28('-${"\\"}', ((({x2: a23, x1: a22} : S0)).x2 & Lambda.count([a23], v74 -> (Std.downcast((null : C15), C15) != null))), 29);
		H.out("o75 " + Std.string(new C5(227)));
		return a23;
	}
	public function m24():Void {
		H.tick();
		H.out("o76 " + Std.string((10 <= 65535)));
		var v77:C5 = new C5(133);
		final v78:Array<Int> = ((C5.f7 ? [251, 290, 230] : [19, 186]) : Array<Int>);
		final v79:() -> String = function():String {
			H.tick();
			Main.fn25(K4.K4C, true);
			final v80:C5 = v77;
			var v81 = (-10);
			return Std.string(v81);
		};
	}
}

class Main {
	public static function fn25(a26:K4, a27:Bool):Int {
		H.tick();
		for (i82 in 0...3) {
			H.tick();
			var w83 = 0;
while (w83 < 1 && true) {
				w83++;
				H.tick();
				var v84:Int = 65535;
				H.out("o85 " + Std.string(true));
			}
		}
		if ((C5.f7 && a27)) {
			switch (a26) {
				case K4.K4A: {
					(new C5(616309942)).m11(265, new A3(110));
				};
				case K4.K4B: {
					H.out("o86 " + Std.string(169));
					var v87:Array<Int> = [47];
				};
				case K4.K4C: {
					var v88 = 83;
					var v89:Array<Int> = [v88, v88, v88];
				};
				case K4.K4D: {
					var v90:Array<Bool> = [a27, false];
				};
			}
			C5.f7 = false;
		}
		H.out("o91 " + Std.string((new C5(0x23AF)).m11((-1454914838), (148 : A3), 1094280319)));
		final v92:Null<Int> = (new C5(11)).m11((new A3(0x80000000)).twice, new A3((-2147483647)), (a26 : Int), (Std.parseInt(Std.string((-646723417))) ?? 0));
		var v93:Null<Int> = null;
		if (((-2147483647) < 35)) {
			for (k95 => x94 in [210]) {
				H.tick();
				var v96:Array<Int> = ([] : Array<Int>);
			}
			for (i97 in 0...0) {
				H.tick();
				var v98 = i97;
				var v99 = v98;
			}
			final v100:() -> Int = () -> 65535;
		} else {
			var v101:Array<Bool> = [a27, a27];
			final v102:Int = (new A3(235)).get();
		}
		final v103:Array<Int> = ([125, 68, 153]).map((v104:Int) -> v104);
		return (a27 ? 237 : (126 + ([(-1469158543), 0xFFFFFFFF]).indexOf((-1460775743))));
	}
	public static function fn28(a29:String, a30:Int, a31:Int):Int {
		H.tick();
		var v105:Int = (K4.K4A : Int);
		for (i106 in 0...1) {
			H.tick();
			if (true) continue;
			var v107:Array<Bool> = [true, true, false];
			a31 = i106;
		}
		++v105;
		{
			{ var dyn108:Dynamic = ({x1: false, x2: 0x2EEB} : S0); H.out("dyn " + Std.string(dyn108.x1) + " " + Std.string(Reflect.field(dyn108, "x1"))); }
			(new C5(a31)).m9(new C5(631005256));
		}
		(new C5(295)).m11(278, (-new A3(v105)), (new C5(262)).m11(a30, new A3(a31)));
		if (true) {
			if (true) {
				final v109:(Int, Int) -> Int = (p110:Int, p111:Int) -> 271;
				var v112:S0 = ({x1: true, x2: a31} : S0);
				var v113:Null<Int> = a30;
			} else {
				fn25(K4.K4C, true);
				final v114:Bool = true;
			}
			final v115 = false;
		} else {
			final v116:(Int) -> Void = function(p117:Int):Void {
				H.tick();
				(new C5(p117)).m9(new C5(a30));
			};
			for (x118 in ([] : Array<Int>)) {
				H.tick();
				v105 = H.id(v105);
				(new C5(x118)).m11(v105, new A3(297), x118);
			}
		}
		H.out("o119 " + (Std.string(a30) + "\u{1F600}"));
		final v120:Array<Int> = (new C5(2073532636)).m9(new C5(a30));
		a30 += Main.fn25(K4.K4D, false);
		return (47 | a31);
	}
	public static function fn32(a33:Int, a34:Int = 2):S0 {
		H.tick();
		(new C5(a33)).m9(new C5(219));
		var v121:Bool = (switch (K4.K4C) {
			case K4.K4A: ([a33]).contains(a34);
			case K4.K4B: ([a34]).contains(a33);
			case K4.K4C: Std.isOfType(new C5(a34), C5);
			case K4.K4D: true;
			case _: true;
		});
		var v122:Array<Array<Bool>> = ((([a33, a33, 183]).contains(a33) ? ([[false, true], [v121]] : Array<Array<Bool>>) : ([[v121, v121, v121], [true]] : Array<Array<Bool>>)) : Array<Array<Bool>>);
		a34 -= a33;
		switch (({x1: v121, x2: ([a33, 154]).length} : S0)) {
			case {x1: true}: {
				var w124 = 0;
while (w124 < 4 && Std.isOfType(new C5(137), C5)) {
					w124++;
					H.tick();
					var v125:Array<Int> = ([] : Array<Int>);
					var v126:S0 = ({x1: false, x2: a34} : S0);
				}
				H.out("o127 " + Std.string((Std.parseInt("\t") ?? 0)));
			};
			case {x1: c123}: {
				{ var dyn128:Dynamic = ({x1: v121, x2: a33} : S0); H.out("dyn " + Std.string(dyn128.x1) + " " + Std.string(Reflect.field(dyn128, "x1"))); }
				a33 += 68;
			};
		}
		fn25(K4.K4A, (switch (69) {
			case 0: false;
			case 2 | 6: false;
			case _: Std.isOfType(null, C15);
		}));
		var w129 = 0;
while (w129 < 1 && true) {
			w129++;
			H.tick();
			H.out("o130 " + Std.string(a33));
			if (([a33, 288, a33]).contains(172)) {
				H.out("o131 " + Std.string((new A3(a33) : Int)));
				H.out("o132 " + Std.string(a34));
			}
			if (false) break;
		}
		(new C5(Reflect.compare(a33, 16))).m11(212, (-new A3(a33)), a34, (75 >> ((K4.K4D : Int) & 31)));
		return ({x2: (switch (a34) {
			case 0: a33;
			case 2 | 5: a34;
			case c133 if (c133 > 10): 0x54A1;
			case _: a34;
		}), x1: (false && ([a34, 43]).contains(a33))} : S0);
	}
	public static function fn35():Int {
		H.tick();
		H.out("o134 " + Std.string(([true, true]).filter(v135 -> false)));
		final v136:(Bool, String) -> Void = ((false ? function(p137:Bool, p138:String):Void {
			H.tick();
			H.out("o139 " + Std.string(new C5(397602863)));
			var v140:Array<Bool> = [false];
			Ext.ext47(249);
		} : function(p141:Bool, p142:String):Void {
			H.tick();
			(new C5(158)).m9(new C5(1303884012));
			var v143 = 176;
		}) : (Bool, String) -> Void);
		switch (H.id(([216, 210, (-15)]).copy())) {
			case []: {
				var v144 = true;
				(new C5(206)).m11((({x2: 65535, x1: v144} : S0)).x2, new A3(0xFFFFFFFF), (({x1: v144, x2: 0x24F5} : S0)).x2, Lambda.fold(([] : Array<Int>), (v145:Int, v146:Int) -> ([v145]).length, 0));
			};
			case [c147]: {
				H.out("o148 " + Std.string(true));
				switch (H.id([21])) {
					case []: {
						final v149:(Int, String) -> Bool = (p150:Int, p151:String) -> false;
						var v152 = true;
					};
					case [c153]: {
						final v154 = true;
						final v155 = c147;
					};
					case [_, c156]: {
						var v157 = c156;
						var v158:Bool = true;
					};
					case _: {
						H.out("o159 " + Std.string((new A3(c147) : Int)));
					};
				}
			};
			case [_, c160]: {
				H.out("o161 " + Std.string((new A3(c160) : Int)));
			};
			case _: {
				final v162:S0 = ({x1: true, x2: 0xFFFFFFFF} : S0);
				(new C5(233)).m11((["\n", "  pad  ", "ünï"]).indexOf("a\rb"), (227 : A3), (v162).x2, 291);
			};
		}
		var v163 = Lambda.count([0x7FFFFFFF, 265], v164 -> ([v164, v164, v164]).contains(v164));
		H.out("o165 " + Std.string((H.at(([] : Array<Int>), 0xF55A, 0) >>> ((K4.K4A : Int) & 31))));
		if (C5.f7) {
			var v166:Array<Int> = ([] : Array<Int>);
			if (Std.isOfType(null, C15)) {
				var v167:Array<Bool> = [false, false, true];
				H.out("o168 " + Std.string(288));
				(54).ext47();
			} else {
				H.out("o169 " + Std.string(({x1: true, x2: v163} : S0)));
			}
		}
		(([] : Array<Int>)).ext50((([] : Array<Int>)).copy());
		v163 |= (v163 & v163);
		return (new C5(v163)).m11(v163, ((v163 : A3) + new A3(v163)), (0x7FFFFFFF - v163));
	}
	public static function fn36(a37:Int, ?a38:Null<Int>):Int {
		H.tick();
		Main.fn35();
		C5.f7 = (true && true);
		for (i170 in 0...1) {
			H.tick();
			a37 = 140;
			H.out("o171 " + Std.string((new A3(a37) : Int)));
			final v172:Array<Bool> = [true];
		}
		var w173 = 0;
while (w173 < 5 && (a37 == (Std.parseInt("\x41\x42") ?? 0))) {
			w173++;
			H.tick();
			var v174 = a37;
			for (i175 in 0...2) {
				H.tick();
				H.out("o176 " + Std.string(222));
			}
		}
		a37 += a37;
		return ({ var v177 = (false || (Std.downcast((new C5(a37) : C5), C5) != null)); a37; });
	}
	public static function fn39(a40:Int, a41:Int):Int {
		H.tick();
		(new C5(a40)).m9(new C5((Std.parseInt(Std.string(a40)) ?? 0)));
		var v178:Array<Int> = [([(-10)]).indexOf(a40), (({x1: true, x2: a40} : S0)).x2];
		v178.push((a41 - (new A3(a41)).get()));
		var w179 = 0;
while (w179 < 2 && true) {
			w179++;
			H.tick();
			var v180:A3 = (a40 : A3);
			H.out("o181 " + Std.string((({x1: false, x2: 0x80000000} : S0)).x2));
		}
		final v182:() -> Int = () -> a41;
		final v183:Int = a40;
		return v182();
	}
	public static function fn42(a43:Int, a44:Int, a45:Bool):Bool {
		H.tick();
		H.out("o184 " + "\x41\x42");
		Ext.ext47((-(new A3(158)).get()));
		(a44).ext47();
		if (({ var v185 = (Std.parseInt("  pad  ") ?? 0); true; })) {
			a44++;
			switch (a44) {
				case 0: {
					Main.fn32(274);
				};
				case 1 | 6: {
					H.out("o186 " + Std.string(({x1: a45, x2: a44} : S0)));
				};
				case c187 if (c187 > 10): {
					H.out("o188 " + Std.string(true));
					final v189:Int = 268;
				};
				case _: {
					a43 ^= a44;
					var v190 = a44;
				};
			}
		} else {
			if (true) {
				H.out("o191 " + Std.string(a43));
				final v192 = 206;
				var v193:Int = a43;
			} else {
				a44 = H.id(a44);
			}
			var v194:S0 = ({x1: false, x2: 208} : S0);
		}
		(([0x154B, 46, a44]).copy()).ext50([a44]);
		for (x195 in (new C5(a44)).m9(new C5(286))) {
			H.tick();
			H.out("o196 " + Std.string((new A3(a44) : Int)));
			H.out("o197 " + Std.string(a43));
		}
		var v198 = (a43 >>> ((K4.K4B : Int) & 31));
		H.out("o199 " + Std.string(v198));
		for (i200 in 0...1) {
			H.tick();
			var v201:C5 = new C5(v198);
		}
		return (({ var v202 = a44; ([a43, v198]).indexOf(v202); }) <= (new A3(a43) : Int));
	}
	public static function section0():Void {
		H.tick();
		if (((Std.parseInt("A-B-C") ?? 0) < (-1007146422))) {
			try {
				var v252:S0 = ({x2: 206, x1: true} : S0);
				var v253 = 236;
				var v254 = 31;
				if (false) throw 3;
			} catch (ex255:Dynamic) {
				H.out("caught " + H.exn(ex255));
				var v256:Null<Int> = 750200248;
				var v257:K4 = K4.K4D;
			}
		} else {
			([158, 69]).ext50([45, 249, 265]);
		}
		{
			switch (K4.K4A) {
				case K4.K4A: {
					final v258:Int = 256;
				};
				case K4.K4B: {
					Main.fn35();
					var v259 = 273;
				};
				case K4.K4C: {
					var v260:Int = (-2147483647);
				};
				case K4.K4D: {
					var v261:S0 = ({x1: true, x2: 147} : S0);
				};
			}
			final v262:(Int, Int) -> Void = function(p263:Int, p264:Int):Void {
				H.tick();
				H.out("o265 " + Std.string(1));
			};
			if (true) {
				final v266 = true;
			} else {
				var v267:C5 = new C5(0xC0FC);
				var v268 = true;
			}
		}
		switch ((({x1: true, x2: 814696890} : S0)).x2) {
			case 0: {
				H.out("o269 " + Std.string(([(-1468714313), (-3)]).length));
			};
			case 1 | 4: {
				switch (Lambda.fold([213, 256, 70], (v270:Int, v271:Int) -> 0xBEA8, 0)) {
					case 0: {
						H.out("o272 " + Std.string(((70 : A3) : Int)));
					};
					case 1 | 6: {
						var v273:Int = 44;
						v273 &= 0xCAB8;
					};
					case _: {
						var v274:Null<Int> = 29;
					};
				}
				try {
					if (true) throw new Err(197);
					var v275 = 246;
					var v276:Array<Int> = [v275, v275, v275];
				} catch (ex277:Dynamic) {
					H.out("caught " + H.exn(ex277));
					var v278:Array<Int> = [103, 0x28FD, 0x80000000];
				}
			};
			case _: {
				final v279:(Int, String) -> Int = (p280:Int, p281:String) -> p280;
			};
		}
		{
			final v282:Array<Int> = [229];
			var v283:Array<C5> = ([new C5(0xA81C), new C5(0xB9B6)] : Array<C5>);
		}
		var v284:Int = 170;
		var v285:Array<String> = ["A-B-C", "a"];
		var v286 = v284;
		v286 |= ((K4.K4A : Int) * (({x2: v284, x1: false} : S0)).x2);
		v284 = Lambda.count([290, v286, v284], v287 -> true);
	}
	public static function section1():Void {
		H.tick();
		if ((Std.isOfType(null, C15) ? false : true)) {
			var v288:Int = 0xF933;
		} else {
			var v289:A3 = (250 : A3);
			H.out("o290 " + Std.string(C5.f7));
		}
		fn39(83, (262 * 0x3104));
		var v291:Int = (Lambda.fold([(-1370278682), 125], (v292:Int, v293:Int) -> 109, 0) >> ((Std.parseInt(Std.string((-2147483647))) ?? 0) & 31));
	}
	public static function section2():Void {
		H.tick();
		for (i294 in 0...3) {
			H.tick();
			H.out("o295 " + Std.string(73605570));
		}
		var v296 = (new A3(0x4C67)).get();
		H.out("o297 " + Std.string((new C5(v296)).m11(0x80000000, (216 : A3), v296, Reflect.compare(v296, v296))));
		var v298:Int = 298;
		try {
			if (false) throw new Err(((["A-B-C"]).length % H.nz(860587711)));
			for (i299 in 0...3) {
				H.tick();
				var v300:Array<Int> = [(-1), v298];
				final v301:C5 = new C5(v296);
			}
		} catch (ex302:Dynamic) {
			H.out("caught " + H.exn(ex302));
			v296++;
			fn32(v298, v296);
		}
		H.out("o303 " + Std.string(C5.f7));
	}
	public static function section3():Void {
		H.tick();
		final v304:A3 = (0x7FFFFFFF : A3);
		var v305:Int = ((([] : Array<Int>)).contains(222) ? 141 : 270);
		for (x306 in (new C5(0xFFFFFFFF)).m9(new C5(88))) {
			H.tick();
			if (false) {
				H.out("o307 " + Std.string((v304 : Int)));
				Main.fn35();
			}
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
