import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:E0);
	E0C;
}

typedef S2 = {x3:Int, x4:Int, x5:Int};

class Main {
	public static function fn39(a40:Bool, a41:Int):Int {
		H.tick();
		final v148:C26 = (new Box<C26>(new C26(29, "日本語"))).value;
		var v149:Map<Int, String> = new Map<Int, String>();
		H.out("o150 " + Std.string(a41));
		a41 |= a41;
		if (!a40) {
			final v151:Array<Int> = ([] : Array<Int>);
			if ((v151).contains(a41)) return ((new Map<String, Int>()).get("k0") ?? 0);
		}
		return ((K10.K10A : Int) & a41);
	}
	public static inline function fn42():Bool {
		H.tick();
		var v152:Int = Main.fn39(StringTools.startsWith("x,y,z", "é"), Lambda.count([215, 19, 108], v153 -> Std.isOfType(new C26(207, "\x41\x42"), C21)));
		C26.m36((new C26((-2147483647), "  pad  ")).m30((({x3: v152, x4: 39, x5: 17} : S2)).x3, ((([-3 => 123] : Map<Int, Int>)).get(4) ?? 0)), (new C11(v152, E0.E0A)).m19("  pad  "));
		if (!false) {
			final v154:Array<String> = ["é"];
			final v155:Bool = StringTools.startsWith("日本語", "Haxe");
			final v156:(String) -> Void = function(p157:String):Void {
				H.tick();
				C26.m36("-7", p157);
				var v158:Int = v152;
				v152 <<= (v158 & 7);
			};
		} else {
			v152 -= v152;
		}
		var v159:String = Std.string(E0A);
		H.out("o160 " + Std.string((new C11(v152, E0A)).m15(({x7: v152, x8: "é"} : S6))));
		var v161:Map<String, String> = new Map<String, String>();
		var v162 = (new Map<String, S2>()).exists("k3");
		final v163:() -> Void = function():Void {
			H.tick();
			H.out("o164 " + Std.string(v152));
			final v165:C26 = new C26(174, v159);
			H.out("o166 " + Std.string(v152));
		};
		return false;
	}
	public static function fn43():Int {
		H.tick();
		if ((new Map<Int, S2>()).exists(18)) {
			if (true) {
				var v167:Int = 0x80000000;
			} else {
				var v168 = 132;
			}
			C26.f27 = H.cap(C26.f27);
			var v169:S2 = ({x3: 267, x4: 65535, x5: 171} : S2);
		}
		var v170:Map<Int, Array<String>> = new Map<Int, Array<String>>();
		var v171:Map<Int, String> = new Map<Int, String>();
		switch (H.id(((false ? [151] : [(-433038456), 0xA118]) : Array<Int>))) {
			case []: {
				(new C11((-1), E0C)).m15(({x8: "\u{1F600}", x7: 40} : S6));
				if (false) {
					var v172:E0 = E0.E0A;
				}
			};
			case [c173]: {
				final v174:Int = (-2);
			};
			case [_, c175]: {
				var v176 = ("\t").indexOf("");
				v176 = ("A-B-C").lastIndexOf("  pad  ");
			};
			case _: {
				H.out("o177 " + Std.string(new C11(290, E0A)));
				var v178:Array<C26> = ([new C26(1938389943, "\u{1F600}"), new C26(0x80000000, "A-B-C"), new C26(42, "\t")] : Array<C26>);
			};
		}
		final v179:Int = (new A9(65535) : Int);
		var v180 = v179;
		return (((false ? new C11(v180, E0C) : new C11(v179, E0C)) : C11)).m18();
	}
	public static function fn44():Int {
		H.tick();
		var v181:Array<Int> = [151, ((new Map<Int, Int>()).get(11) ?? 0), (["zz", "0"]).length];
		H.out("o182 " + Std.string(new Box(246)));
		final v183:Box<String> = (cast (new Box("0")) : Box<String>);
		final v184:(String) -> Void = function(p185:String):Void {
			H.tick();
			H.out("o186 " + Std.string([true, false]));
			var v187:A9 = new A9((-15));
		};
		{
			final v188 = ("ab").indexOf("");
			H.out("o189 " + Std.string(new C26(v188, "")));
		}
		H.out("o190 " + C26.f27);
		H.out("o191 " + String.fromCharCode(65 + ((Reflect.compare("42", "A-B-C")) & 15)));
		return ((K10.K10A : Int) % H.nz((0x7FFFFFFF | 65535)));
	}
	public static function fn45(a46:Array<Int>):A9 {
		H.tick();
		final lf192:(String, Bool) -> Int = function(p193:String, p194:Bool):Int {
			H.tick();
			H.out("o195 " + p193);
			var v196:Bool = Std.isOfType(new C26(299, p193), C21);
			H.out("o197 " + Std.string(((p193).charCodeAt(243) ?? -1)));
			return ((Std.string(132)).charCodeAt(((p193).charCodeAt(65535) ?? -1)) ?? -1);
		};
		final v198:C26 = new C26((["zz"]).length, StringTools.lpad("q", "*", 0));
		var v199:Bool = true;
		return (fn44() : A9);
	}
	public static function fn47(a48:E0, a49:Int):Int {
		H.tick();
		H.out("o200 " + C26.m33(true, a48));
		H.out("o201 " + Std.string(new C11(a49, a48)));
		final v202 = "  pad  ";
		switch (E0C) {
			case E0A: {
				H.out("o203 " + Std.string((new A9((-620014364))).get()));
				a49 = 105;
			};
			case E0B(c204): {
				{
					final v205:C11 = new C11(191, c204);
					var v206:Map<Int, String> = new Map<Int, String>();
					var v207 = a49;
				}
			};
			case E0C: {
				final v208:Map<String, Int> = new Map<String, Int>();
				var v209:Map<String, Bool> = (["k0" => false, "k1" => false] : Map<String, Bool>);
			};
		}
		(new C11(a49, a48)).m19(Std.string(([a49, 161, a49]).contains(0xB06D)));
		H.out("o210 " + Std.string(a49));
		return (a49 - (new C11(127, E0.E0A)).m18());
	}
	public static function fn50(a51:E0):Int {
		H.tick();
		Main.fn45([Reflect.compare(252, 38), (("  pad  ").charCodeAt(101) ?? -1)]);
		if (false) {
			var v211:String = "42";
			fn47(E0A, 0x38B7);
		} else {
			final v212 = ("Haxe").toUpperCase();
			var v213:Int = 0xA402;
		}
		var v214:C11 = new C11(([false]).indexOf(true), a51);
		if (fn42()) {
			if (StringTools.startsWith("q", "0")) {
				H.out("o215 " + Std.string(true));
				Ext.ext64("ab", 263);
			}
			final v216:() -> Void = function():Void {
				H.tick();
				var v217:S6 = ({x7: 267391933, x8: "\"q\""} : S6);
				(v214).m15(v217);
				(v214).m19("a");
			};
		}
		var v218:Box<Array<E0>> = new Box<Array<E0>>(([a51] : Array<E0>));
		(new C26(("\u{1F600}").indexOf("ünï"), "0")).m30(143, fn44());
		return 182;
	}
	public static function fn52(a53:String, a54:Int, a55:E0):Bool {
		H.tick();
		H.out("o219 " + (false + "A-B-C"));
		a54 &= a54;
		a55 = H.id(a55);
		H.out("o220 " + Std.string((([a54]).contains(a54) ? a54 : a54)));
		C11.m17();
		return (cast (Std.isOfType(new C26((-340999561), "\x41\x42"), C21)) : Bool);
	}
	public static function section0():Void {
		H.tick();
		H.out("o232 " + C26.f27);
		H.out("o233 " + Std.string((new A9((-2147483647)) : Int)));
		var v234:Map<String, Int> = (cast (new Map<String, Int>()) : Map<String, Int>);
	}
	public static function section1():Void {
		H.tick();
		if (((([] : Array<Bool>)).length != 127)) {
			if ((new Map<Int, Int>()).exists(0x9318)) {
				H.out("o235 " + Std.string(E0.E0C));
				H.out("o236 " + Std.string((-2147483647)));
			}
			var v237 = 76;
			var v238:Array<Int> = [v237, 220];
		} else {
			final lf239:() -> Int = function():Int {
				H.tick();
				var v240:C11 = new C11((-903687469), E0A);
				var v241:Map<String, Int> = new Map<String, Int>();
				var v242 = true;
				return 222;
			};
			final v243:(Bool) -> String = (p244:Bool) -> "x,y,z";
		}
		var v245 = (55 & 115);
		Main.fn47(E0C, (({x7: v245, x8: "日本語"} : S6)).x7);
	}
	public static function section2():Void {
		H.tick();
		var v246:Map<String, String> = new Map<String, String>();
		if ((true || (E0.E0C).match(E0B(_)))) {
			if ((new Map<Int, E0>()).exists(18)) {
				final v247 = 180;
				H.out("o248 " + Std.string(13));
			}
		}
		H.out("o249 " + Std.string((false ? ([127, 141]).contains(69) : true)));
		H.out("o250 " + "A-B-C");
		fn42();
		if (((Std.parseInt(Std.string(1991150519)) ?? 0) >= 264)) {
			var v251:Array<A9> = ([new A9(2115160719), new A9(116)] : Array<A9>);
			{
				var v252:C11 = new C11(148, E0.E0C);
				H.out("o253 " + Std.string(v252));
			}
		}
		var v254:Array<String> = (cast (["x,y,z", "\u{1F600}"]) : Array<String>);
		final v255:Array<Int> = ([] : Array<Int>);
	}
	public static function section3():Void {
		H.tick();
		fn44();
		H.out("o256 " + Std.string(((new Map<Int, Int>()).get(4) ?? 0)));
		final v257:Array<Int> = ([] : Array<Int>);
	}
	public static function section4():Void {
		H.tick();
		var v258:Array<Int> = [(Std.parseInt(Std.string(35)) ?? 0)];
		function lf259(n260:Int):Int {
			H.tick();
			return n260 <= 0 ? ((StringTools.replace("\"q\"", ",", "-7")).charCodeAt(n260) ?? -1) : (lf259(n260 - 1) + (switch (("\u{1F600}").length) {
			case 0: (("").split("a")).length;
			case 1 | 6: n260;
			case c261 if (c261 > 10): 20;
			case _: Type.enumIndex(E0A);
		}));
		}
		H.out("lf259 " + lf259(0));
		final v262:Bool = (90 == (("日本語").charCodeAt((-331911953)) ?? -1));
		switch (Lambda.fold(([] : Array<Int>), (v263:Int, v264:Int) -> 236, 0)) {
			case 0: {
				if (v262) {
					var v265 = 18;
					v265 = H.id(v265);
					C26.f27 += "abc";
				}
				H.out("o266 " + Std.string(0x80000000));
			};
			case 3 | 6: {
				H.out("o267 " + Std.string(0x80000000));
			};
			case c268 if (c268 > 10): {
				final v269:A9 = (c268 : A9);
				final lf270:(Bool) -> String = function(p271:Bool):String {
					H.tick();
					H.out("o272 " + "q");
					final v273:String = "\u{1F600}";
					var v274 = p271;
					return v273;
				};
			};
			case _: {
				var v275:Array<C21> = ([new C21(230, ([] : Array<Bool>)), new C21(284, [v262, v262, v262])] : Array<C21>);
			};
		}
		H.out("o276 " + Std.string((K10.K10A : Int)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
