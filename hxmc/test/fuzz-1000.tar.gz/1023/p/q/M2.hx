package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

abstract A9(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A9, b:A9):A9
		return new A9(a.get() + b.get());

	@:op(A * B) public static function mul(a:A9, b:A9):A9
		return new A9(a.get() * b.get());

	@:op(-A) public static function neg(a:A9):A9
		return new A9(-a.get());
}

enum abstract K10(Int) to Int {
	var K10A = 1;
	var K10B = 4;
}

class C11 {
	public var cb12:(Int) -> Int;
	public function new(a13:Int, a14:E0) {
		this.cb12 = (p65:Int) -> p65;
	}
	public function m15(a16:S6):Int {
		H.tick();
		var v66 = (~(new A9(0xFFFFFFFF)).twice);
		final v67:E0 = E0.E0A;
		v66 = (false ? 175 : v66);
		return (100 % H.nz(v66));
	}
	public static inline function m17():Box<Int> {
		H.tick();
		{
			if (true) {
				var v68:E0 = E0.E0A;
				var v69:Array<String> = ("\\").split("-");
				(new C11(165, v68)).m15(({x8: "hello world", x7: 255} : S6));
			} else {
				var v70 = "a";
				var v71 = 262;
			}
			final v72:(String, Bool) -> String = (p73:String, p74:Bool) -> p73;
		}
		final v75:String = C26.f27;
		function lf76(n77:Int):Int {
			H.tick();
			return n77 <= 0 ? 0x80000000 : (lf76(n77 - 1) + ("-7").length);
		}
		H.out("lf76 " + lf76(3));
		var v78 = true;
		if ((true ? false : (E0.E0A).match(E0B(_)))) {
			var v79:Map<String, S6> = new Map<String, S6>();
		} else {
			final v80:String = v75;
			var v81 = "a\rb";
		}
		{
			H.out("o82 " + Std.string(((252 : A9) : Int)));
		}
		if ((StringTools.contains(v75, v75) || v78)) {
			H.out("o83 " + v75);
			(new C11(253, E0.E0C)).m15(({x7: 29, x8: "\"q\""} : S6));
		} else {
			var v84 = 194;
		}
		switch ((v78 ? (({x5: 93, x3: 12, x4: 831553504} : S2)).x4 : (v75).indexOf("-7"))) {
			case 0: {
				H.out("o85 " + Std.string(new C26(106, v75)));
				(new C11(151, E0.E0C)).m15(({x7: 222, x8: "hello world"} : S6));
			};
			case 1 | 6: {
				if (([294, (-478159000)]).contains(238)) {
					H.out("o86 " + Std.string((-540467951)));
					(new C11(45, E0.E0A)).m15(({x8: v75, x7: 23} : S6));
				} else {
					var v87:Map<String, E0> = (["k0" => E0.E0A, "k1" => E0.E0A, "k2" => E0.E0C] : Map<String, E0>);
				}
			};
			case _: {
				var v88 = Std.string(145);
			};
		}
		((((E0.E0C).match(E0B(_)) ? new C11((-1907534791), E0.E0A) : new C11(290, E0.E0C)) : C11)).m15(((v78 ? ({x7: 103, x8: v75} : S6) : ({x7: 117, x8: "\u{1F600}"} : S6)) : S6));
		return ((StringTools.contains("A-B-C", "A-B-C") ? (new Box<Box<Int>>(new Box(205))).value : new Box((-640185293))) : Box<Int>);
	}
	public function m18():Int {
		H.tick();
		H.out("o89 " + Std.string(E0.E0A));
		final v90:Box<Null<Int>> = ((true ? new Box<Null<Int>>(65) : new Box<Null<Int>>(0xFFFFFFFF)) : Box<Null<Int>>);
		if (true) return ((Std.parseInt("\x41\x42") ?? 0) | (Std.parseInt("A-B-C") ?? 0));
		var v91:Box<String> = ((StringTools.endsWith("é", "\t") ? new Box("A-B-C") : new Box("\"q\"")) : Box<String>);
		if ((StringTools.replace("ünï", ",", "Haxe") >= "a\rb")) {
			var v92 = ("a").toLowerCase();
		} else {
			var v93:Box<Int> = new Box(0x7EE3);
			switch (156) {
				case 0: {
					H.out("o94 " + Std.string(E0.E0A));
				};
				case 2 | 5: {
					Main.fn39(false, (-2));
					var v95:Array<C11> = ([new C11(293, E0.E0C), new C11(24, E0.E0C), new C11(7, E0.E0C)] : Array<C11>);
				};
				case _: {
					this.m15(({x7: 93, x8: "A-B-C"} : S6));
					var v96:Map<Int, String> = ([-3 => "日本語", 4 => "42", 11 => "x,y,z"] : Map<Int, String>);
				};
			}
		}
		return 565952736;
	}
	public function m19(a20:String):String {
		H.tick();
		{
			var v97:Map<String, Int> = (["k0" => 0x7FFFFFFF, "k1" => (-2147483647)] : Map<String, Int>);
		}
		var v98:Int = (a20).length;
		var v99:C26 = new C26((([] : Array<Bool>)).length, C26.f27);
		var v100:Map<String, String> = new Map<String, String>();
		H.out("o101 " + Std.string((((true ? (v98 : A9) : (50 : A9)) : A9) : Int)));
		v98 ^= 35;
		var v102:K10 = K10.K10B;
		final v103:Int = ((([-3 => true] : Map<Int, Bool>)).exists(v98) ? (v102 : Int) : v98);
		return String.fromCharCode(65 + ((v98) & 15));
	}
}

class C21 {
	public var f22:String;
	public var cb23:(Int) -> Int;
	public function new(a24:Int, a25:Array<Bool>) {
		this.f22 = String.fromCharCode(65 + ((a24) & 15));
		this.cb23 = function(p104:Int):Int {
			H.tick();
			H.out("o105 " + "x,y,z");
			H.out("o106 " + Std.string(true));
			var v107 = "\u{1F600}";
			return a24;
		};
	}
}

class C26 extends C21 {
	public static var f27:String = "\x41\x42";
	public function new(a28:Int, a29:String) {
		super(Reflect.compare(a28, a28), [false]);
	}
	public function m30(a31:Int, a32:Int):String {
		H.tick();
		var v108 = a32;
		H.out("o109 " + Std.string(([v108, v108]).concat([a32, a32])));
		switch (E0.E0C) {
			case E0A: {
				var v110:Bool = Std.isOfType(new C21(0x80000000, [false, true, false]), C21);
				function lf111(n112:Int):Int {
					H.tick();
					return n112 <= 0 ? ([v110, true]).length : (lf111(n112 - 1) + 80);
				}
				H.out("lf111 " + lf111(1));
			};
			case E0B(_): {
				var v113:String = Std.string(65535);
			};
			case E0C: {
				final lf114:(String) -> String = (p115:String) -> "a\rb";
				H.out("o116 " + Std.string(false));
			};
		}
		H.out("o117 " + Std.string(((new A9(a31) + (263 : A9)) : Int)));
		a32--;
		final v118 = ((new A9(a31)).get() ^ ([false]).indexOf(true));
		C11.m17();
		return H.apply((true && true), (v119:Bool) -> "ab");
	}
	public static function m33(a34:Bool, a35:E0):String {
		H.tick();
		if (("\t" == ([156, 0x80000000, 99]).join(","))) {
			switch (121) {
				case 0: {
					var v120 = 278;
					H.out("o121 " + Std.string(a34));
				};
				case 1 | 4: {
					var v122:C11 = new C11(80, a35);
					var v123:Map<String, Bool> = new Map<String, Bool>();
				};
				case c124 if (c124 > 10): {
					var v125:Array<Bool> = [a34, a34];
				};
				case _: {
					H.out("o126 " + Std.string(null));
					final v127 = 129;
				};
			}
			H.out("o128 " + Std.string((K10.K10A : Int)));
		} else {
			var v129:C11 = new C11(0x22C3, a35);
			(new C11(11, a35)).m18();
		}
		H.out("o130 " + Std.string(((Std.parseInt(Std.string(30)) ?? 0) - ("q").lastIndexOf("x,y,z"))));
		var v131:S6 = ({x7: Reflect.compare(46, 257), x8: ("-7").replace("a", "b")} : S6);
		H.out("o132 " + Std.string(((switch (K10.K10B) {
			case K10.K10A: new C26(283, "\"q\"");
			case K10.K10B: new C26((-9), "ünï");
		}) : C26)));
		var v133:S2 = ({x3: (-1174777370), x5: (-19), x4: (K10.K10B : Int)} : S2);
		return Std.string((false && a34));
	}
	public static function m36(a37:String, a38:String):Array<Int> {
		H.tick();
		final v134:Array<String> = ([true, false]).map((v135:Bool) -> String.fromCharCode(65 + ((0x7897) & 15)));
		v134.remove(C26.f27);
		H.out("o136 " + Std.string(new C11(Type.enumIndex(E0.E0C), E0.E0C)));
		final v137:Int = (("\u{1F600}").length * 28);
		final v138:() -> String = () -> Std.string(false);
		H.out("o139 " + C26.f27);
		if ((((a38).charCodeAt(v137) ?? -1) >= (({x7: v137, x8: a38} : S6)).x7)) {
			final v140:(Bool, Bool) -> Bool = (p141:Bool, p142:Bool) -> p141;
			var v143:Array<Int> = ([] : Array<Int>);
			H.out("o144 " + Std.string(v137));
		} else {
			final v145:Bool = true;
			C11.m17();
		}
		H.out("o146 " + Std.string(v137));
		final v147 = (((["k0" => v137, "k1" => v137, "k2" => v137] : Map<String, Int>)).exists("k2") && (Std.downcast((new C26(v137, "hello world") : C26), C26) != null));
		return (([] : Array<Int>)).copy();
	}
}
