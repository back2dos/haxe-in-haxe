package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext58(a56:String, a57:String):Int {
		H.tick();
		final lf221:(Bool, Int) -> Void = function(p222:Bool, p223:Int):Void {
			H.tick();
			C26.m36("q", (a57).replace("a", "b"));
			a56 = H.cap(Std.string(p223));
			H.out("o224 " + C26.f27);
		};
		H.out("o225 " + Std.string((115 & (("abc").charCodeAt(0xABEC) ?? -1))));
		H.out("o226 " + Std.string(((new Map<String, Int>()).get("k3") ?? 0)));
		return (([] : Array<Bool>)).length;
	}
	public static function ext61(a59:String, a60:String):E0 {
		H.tick();
		Ext.ext58((StringTools.hex((0xB1FD) & 0xFFFF, 4)).toLowerCase(), "q");
		H.out("o227 " + Std.string(true));
		H.out("o228 " + Std.string(63));
		if ((true || (([] : Array<Int>)).contains(67))) {
			if ((Std.downcast((new C26(204, a60) : C26), C26) != null)) {
				var v229:C11 = new C11(218, E0.E0C);
				Main.fn42();
				Main.fn42();
			}
			C26.m36(C26.f27, Std.string(280));
		} else {
			(new C11(0x57D3, E0.E0C)).m15(({x7: (-12), x8: a59} : S6));
		}
		return E0.E0C;
	}
	public static function ext64(a62:String, a63:Int):String {
		H.tick();
		var v230:Array<Int> = C26.m36((a62).replace("a", "b"), a62);
		(new C26((a62).indexOf(a62), a62)).m30((a63 - (new A9(a63) : Int)), Main.fn39(true, a63));
		a63 = 294;
		if (((new A9(a63)).get() != (Std.parseInt(a62) ?? 0))) return ({ var v231 = C26.f27; ([true, true]).join(" "); });
		return a62;
	}
}
