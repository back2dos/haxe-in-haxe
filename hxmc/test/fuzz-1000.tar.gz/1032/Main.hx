import H;
import p.M1;
import p.q.M2;

typedef S0 = {x1:Float, x2:Int};

abstract A3(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A3, b:A3):A3
		return new A3(a.get() + b.get());

	@:op(A * B) public static function mul(a:A3, b:A3):A3
		return new A3(a.get() * b.get());

	@:op(-A) public static function neg(a:A3):A3
		return new A3(-a.get());
}

class Main {
	public static function fn36():Array<String> {
		H.tick();
		var v200:String = ("0" + Std.string(0.5));
		if (true) {
			H.out("o201 " + Std.string(((258 : A3) : Int)));
		} else {
			if (false) return [v200, v200, "Haxe"];
			(new C23(65535, "-7")).m28(([(-2.5), (-2.5)] : Array<Float>));
		}
		(new C23(50, v200)).m28(([for (i202 in 0...1) i202] : Array<Float>));
		var v203:Float = Math.ffloor((-2.5));
		final lf204:(Bool, String) -> Bool = (p205:Bool, p206:String) -> p205;
		var v207:Array<Int> = [for (i208 in ([] : Array<Int>)) if (([i208, 174]).contains(i208)) (({x1: v203, x2: i208} : S0)).x2];
		final v209:String = v200;
		switch (v200) {
			case "a" | "b": {
				switch ((-1272369793)) {
					case 0: {
						var v210:Array<String> = [v209, v209];
					};
					case 1 | 5: {
						H.out("o211 " + Std.string(93));
					};
					case _: {
						var v212:Int = 282;
						(new C23(v212, "abc")).m19(([new C23(v212, v200), new C15(), new C23(v212, "ünï")] : Array<C15>), v212);
					};
				}
				H.out("o213 " + Std.string(([(-2147483647), 63]).contains(299)));
			};
			case "Haxe": {
				var v214:S0 = ({x1: 1.25, x2: (-19)} : S0);
			};
			case _: {
				var v215 = Reflect.compare(v200, v209);
			};
		}
		var v216:S0 = ({x1: Std.parseFloat(v209), x2: (new A3(0x1185) : Int)} : S0);
		return ((switch (H.id(([] : Array<Int>))) {
			case []: (([] : Array<String>)).copy();
			case [c217]: [v200, v200, (([] : Array<Bool>)).join("|")];
			case [_, c218]: ["42", StringTools.hex((c218) & 0xFFFF, 4), String.fromCharCode(65 + ((c218) & 15))];
			case _: ([v200]).slice(2, -2);
		}) : Array<String>);
	}
	public static inline function fn37(a38:Int, a39:Bool):C15 {
		H.tick();
		H.out("o219 " + Std.string(((true ? ({x1: 0.5, x2: a38} : S0) : ({x1: 1e100, x2: a38} : S0)) : S0)));
		var v220:C15 = new C15();
		switch ((a39 && ((["k0" => new C23(a38, "\\"), "k1" => new C23(a38, "q")] : Map<String, C23>)).exists("k0"))) {
			case true: {
				var v221:Int = (({x1: a38, x2: a38} : S0)).x2;
			};
			case false: {
				var v222 = Std.int(a38);
			};
		}
		var v223 = a38;
		final v224:C15 = new C15();
		return v224;
	}
	public static function fn40(a41:Bool, a42:Int):Array<String> {
		H.tick();
		var v225 = (new A3(a42) : Int);
		var v226:Array<String> = [for (i227 in 0...3) ("").substr((156 & 7), 1)];
		for (x228 in ([for (i229 in [v225, a42]) if (false) v225] : Array<Float>)) {
			H.tick();
			H.out("o230 " + Std.string(v225));
			H.out("o231 " + Std.string(null));
			v225 = ([false]).length;
		}
		a42 = v225;
		return ([for (i232 in 0...4) String.fromCharCode(65 + ((a42) & 15))]).copy();
	}
	public static inline function fn43(a44:String, a45:Float, a46:Int):Null<Int> {
		H.tick();
		for (i233 in 0...H.lim(110)) {
			H.tick();
			a46 |= a46;
			final v234:Box<Array<String>> = new Box<Array<String>>(["-7", "\u{1F600}"]);
			(new C23(i233, "\u{1F600}")).m19(([new C23(77, "\\")] : Array<C15>), a46);
		}
		var v235:Box<String> = new Box(([a44, a44]).join("|"));
		H.out("o236 " + Std.string(new C23(7, ("ab").toLowerCase())));
		a46 = (new C23(a46, a44)).m19(([new C15()] : Array<C15>), 0x80000000);
		return (((false ? new C23(a46, "ab") : new C23((-2147483647), "A-B-C")) : C23)).m33((([] : Array<String>)).join(""), new C15());
	}
	public static function fn47(a48:Int):Void {
		H.tick();
		for (i237 in 0...4) {
			H.tick();
			var v238:Array<String> = ([] : Array<String>);
			if (true) {
				var v239:C15 = new C23(i237, "ab");
			} else {
				H.out("o240 " + Std.string(new C15()));
				H.out("o241 " + "zz");
			}
		}
		var v242:String = (switch (({x1: a48, x2: a48} : S0)) {
			case {x1: c243}: ("\n").charAt(1);
		});
		a48 |= (cast ((a48 -= 1)) : Int);
		var v244:Map<Int, Int> = ([-3 => 249, 4 => Std.int(a48)] : Map<Int, Int>);
		for (i245 in 0...H.lim((false ? Std.int(a48) : a48))) {
			H.tick();
			H.out("o246 " + v242);
		}
		final v247:Array<Array<A3>> = ([([(a48 : A3), new A3(a48)] : Array<A3>)] : Array<Array<A3>>);
	}
	public static function fn49(a50:Int, a51:String):Int {
		H.tick();
		var v248:Box<Float> = ((false ? new Box<Float>(a50) : new Box<Float>(1e21)) : Box<Float>);
		a50 = H.id(a50);
		var v249:A3 = (cast (new A3(20)) : A3);
		for (k251 => x250 in ((switch (a51) {
			case "a" | "b": ([a50, a50, 1e3] : Array<Float>);
			case "Haxe": ([(-2.5)] : Array<Float>);
			case "": ([] : Array<Float>);
			case _: ([a50, 0.1, a50] : Array<Float>);
		}) : Array<Float>)) {
			H.tick();
			H.out("o252 " + "ab");
		}
		return ((((["k0" => ({x1: a50, x2: a50} : S0)] : Map<String, S0>)).exists("k0") ? a51 : a51)).indexOf(a51);
	}
	public static function fn52(a53:Int, a54:Int, a55:Bool):Array<Int> {
		H.tick();
		a53 = H.id(a53);
		switch (((true ? ({x2: a54, x1: 123456.789} : S0) : ({x1: 1.25, x2: a54} : S0)) : S0)) {
			case {x1: c253}: {
				if (a55) {
					final v254:Int = a54;
					final v255:Bool = a55;
					var v256:Map<String, Array<Int>> = (["k0" => ([] : Array<Int>)] : Map<String, Array<Int>>);
				}
			};
		}
		for (x257 in ([for (i258 in 0...0) 7.0] : Array<Float>)) {
			H.tick();
			{
				(new C23(a54, "a\rb")).m30(x257);
			}
			a54 = 173;
		}
		final v259:Float = a54;
		{ var dyn260:Dynamic = ({x1: a53, x2: a54} : S0); H.out("dyn " + Std.string(dyn260.x1) + " " + Std.string(Reflect.field(dyn260, "x1"))); }
		var v261:Map<Int, String> = new Map<Int, String>();
		{
			if (a55) {
				H.out("o262 " + Std.string(a54));
				final v263:Map<String, Int> = (["k0" => a53, "k1" => a54, "k2" => a54] : Map<String, Int>);
				H.out("o264 " + Std.string(a53));
			}
		}
		return [5];
	}
	public static function fn56(a57:Int, a58:Bool):Bool {
		H.tick();
		for (i265 in 0...H.lim((false ? Reflect.compare(a57, a57) : a57))) {
			H.tick();
			if (Math.isNaN(i265)) return (([] : Array<Int>)).contains(188);
		}
		a57 -= (a57 = 5);
		var v266:Array<Int> = ((false ? [a57] : [a57, a57, a57]) : Array<Int>);
		var v267 = a58;
		Main.fn40(v267, (a57 | Reflect.compare(a57, 106)));
		a57 = (221 | 244);
		H.out("o268 " + Std.string(a57));
		return v267;
	}
	public static function fn59(a60:Int):Void {
		H.tick();
		try {
			if ((5e-324 >= 2.5e-3)) throw StringTools.replace(("\n").charAt(5), " ", ("q").toLowerCase());
			for (k269 => v270 in (["k0" => 0x4EDD, "k1" => 217] : Map<String, Int>)) {
				H.tick();
				Main.fn43(k269, a60, v270);
				final v271:Box<C4> = new Box<C4>(new C4());
				Main.fn56(237, false);
			}
			var v272:Float = a60;
			var v273 = "日本語";
		} catch (ex274:Err) {
			H.out("caught Err " + ex274.errCode);
			var v275 = ("\t").charAt(5);
		} catch (ex276:haxe.Exception) {
			H.out("caught " + H.exn(ex276));
			try {
				if ((new Map<String, Bool>()).exists("k1")) throw 14;
				var v277:Float = a60;
			} catch (ex278:Err) {
				H.out("caught Err " + ex278.errCode);
				H.out("o279 " + Std.string(a60));
				var v280:Int = 276;
			} catch (ex281:haxe.Exception) {
				H.out("caught " + H.exn(ex281));
				final v282:Float = a60;
				final v283:Array<S0> = ([({x2: a60, x1: a60} : S0), ({x1: v282, x2: a60} : S0), ({x1: a60, x2: a60} : S0)] : Array<S0>);
			}
		}
		if (([a60, a60]).contains((a60 += 3))) {
			switch (H.id(([] : Array<Int>))) {
				case []: {
					H.out("o284 " + Std.string(new Box(a60)));
				};
				case [c285]: {
					a60 = 0xF09B;
					final v286:Array<Box<Int>> = ([new Box((-403769008)), new Box(0x14E)] : Array<Box<Int>>);
				};
				case [_, c287]: {
					(new C15()).m22();
					(new C15()).m22();
				};
				case _: {
					var v288:Int = 26;
					var v289:Box<Bool> = new Box<Bool>(true);
				};
			}
			var v290 = (a60 = 5);
			H.out("o291 " + Std.string(a60));
		}
		var v292:Array<Int> = ((false ? ([] : Array<Int>) : [a60, 112]) : Array<Int>);
		a60 = (StringTools.contains("\\", "ab") ? (({x1: 123456.789, x2: a60} : S0)).x2 : a60);
		a60 = (a60 += 3);
	}
	public static function fn61(a62:String, a63:Bool):String {
		H.tick();
		for (i293 in 0...3) {
			H.tick();
			if (([i293, (-2147483647), 281]).contains(238)) {
				H.out("o294 " + a62);
				(new C15()).m22();
				final v295:String = a62;
			} else {
				if (a63) break;
			}
		}
		(new C15()).m22();
		var w296 = 0;
while (w296 < 2 && (true && false)) {
			w296++;
			H.tick();
			if (a63) {
				H.out("o297 " + Std.string(a63));
			} else {
				H.out("o298 " + Std.string(({x1: 2.5e-3, x2: 0x80000000} : S0)));
				var v299:C15 = new C23(0x7FFFFFFF, a62);
			}
			function lf300(n301:Int):Int {
				H.tick();
				return n301 <= 0 ? (new A3(187) : Int) : (lf300(n301 - 1) + ((a62).charCodeAt(n301) ?? -1));
			}
			H.out("lf300 " + lf300(0));
			var v302:Map<String, Bool> = (["k0" => a63, "k1" => a63] : Map<String, Bool>);
		}
		switch (a62) {
			case "a" | "b": {
				final v303 = (a62).length;
				final v304 = (new A3(v303) : Int);
			};
			case "Haxe": {
				if (false) {
					final v305:A3 = (65535 : A3);
					var v306:C4 = new C12(123456.789, "");
					(new C4()).m9(286, [0x7FFFFFFF]);
				} else {
					Main.fn40(a63, 56);
					H.out("o307 " + a62);
				}
				var v308:A3 = new A3(237);
			};
			case _: {
				var v309:Array<String> = ("a").split("a");
			};
		}
		final v310:Map<String, Bool> = (["k0" => (([] : Array<Int>)).contains(42)] : Map<String, Bool>);
		var v311:Bool = (a62 != StringTools.lpad(a62, "*", (62 & 7)));
		return (new C4()).m8();
	}
	public static function section0():Void {
		H.tick();
		final v312:Array<Bool> = (new C12(0.30000000000000004, "")).m9((["\x41\x42"]).length, [(-9), 296, (-793610069)]);
		(new C23(("\\").length, ("abc").substr((297 & 7), 0))).m19(([new C23(0x8779, "abc")] : Array<C15>), (new A3(212)).get());
		final v313:Map<String, String> = new Map<String, String>();
		{ var dyn314:Dynamic = ({x2: (-1715288807), x1: (-16)} : S0); H.out("dyn " + Std.string(dyn314.x1) + " " + Std.string(Reflect.field(dyn314, "x1"))); }
		try {
			if ((Std.string(3.0) > "  pad  ")) throw "boom";
			final v315:S0 = ({x2: (-7), x1: 0.5} : S0);
			var v316:Array<Null<Int>> = ([] : Array<Null<Int>>);
			var v317 = Math.round(1e3);
		} catch (ex318:Err) {
			H.out("caught Err " + ex318.errCode);
			final v319:C4 = new C4();
			var v320 = false;
		} catch (ex321:haxe.Exception) {
			H.out("caught " + H.exn(ex321));
			var v322:Box<Bool> = new Box(true);
		}
		var v323:Map<String, Int> = (["k0" => 0xAB88, "k1" => (({x1: 1e3, x2: 276} : S0)).x2] : Map<String, Int>);
	}
	public static function section1():Void {
		H.tick();
		var v324:Array<Int> = (([] : Array<Int>)).concat(([] : Array<Int>));
		var v325:Float = 3.0;
		var v326:Array<String> = Main.fn40(true, (v324).length);
	}
	public static function section2():Void {
		H.tick();
		for (i327 in 0...H.lim(284)) {
			H.tick();
			var v328 = Math.floor(i327);
			switch ((({x1: v328, x2: i327} : S0)).x2) {
				case 0: {
					var v329 = "-7";
				};
				case 1 | 4: {
					H.out("o330 " + Std.string((-17)));
				};
				case c331 if (c331 > 10): {
					H.out("o332 " + Std.string(true));
					final v333:Float = i327;
				};
				case _: {
					if (false) break;
					var v334:Map<String, Int> = (["k0" => i327, "k1" => (-1556750294), "k2" => v328] : Map<String, Int>);
				};
			}
		}
		for (i335 in 0...2) {
			H.tick();
			var v336:Int = 0xDC2A;
		}
		var v337:S0 = ({x1: 123456.789, x2: 251} : S0);
		var v338:Array<Int> = ((StringTools.endsWith("0", "a") ? [(-1636160344), 262, (-546804187)] : [174, 0xEECA, 294]) : Array<Int>);
		var v339 = (139 ^ (-2147483647));
		if ((v338).contains(204)) {
			v338.push(("  pad  ").length);
		}
		{ var dyn340:Dynamic = v337; H.out("dyn " + Std.string(dyn340.x1) + " " + Std.string(Reflect.field(dyn340, "x1"))); }
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
