package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

class C4 {
	public var f5:Int;
	public var f6:Bool;
	public var f7:Bool;
	public function new() {
		this.f5 = Math.floor(1e-7);
		this.f6 = Math.isNaN(0.5);
		this.f7 = StringTools.contains("Haxe", "\x41\x42");
	}
	public function m8():String {
		H.tick();
		for (i64 in 0...3) {
			H.tick();
			switch ("Haxe") {
				case "a" | "b": {
					this.f5 -= 38;
					H.out("o65 " + Std.string(i64));
				};
				case "Haxe": {
					var v66 = false;
				};
				case "": {
					H.out("o67 " + Std.string(i64));
					var v68:Int = 241;
				};
				case _: {
					var v69:Array<Float> = ([i64, 1e100] : Array<Float>);
				};
			}
		}
		H.out("o70 " + (StringTools.trim("Haxe") + "hello world"));
		final v71:Map<Int, String> = new Map<Int, String>();
		switch (119) {
			case 0: {
				{
					var v72:Int = 0x8E77;
				}
				H.out("o73 " + Std.string(this.f7));
			};
			case 3 | 5: {
				try {
					if (true) throw ("zz").toLowerCase();
					var v74:C12 = new C12(100.75, "\\");
					H.out("o75 " + "q");
				} catch (ex76:String) {
					H.out("caught String " + ex76);
					(new C15()).m19(([new C23(295, "abc")] : Array<C15>), (-5));
					(new C23(0x4628, "x,y,z")).m28(([100.75, 3.0] : Array<Float>));
				} catch (ex77:Int) {
					H.out("caught Int " + ex77);
					var v78 = 140;
				} catch (ex79:Err) {
					H.out("caught Err " + ex79.errCode);
					H.out("o80 " + Std.string(140));
				} catch (ex81:Dynamic) {
					H.out("caught " + H.exn(ex81));
					(new C23(1800254766, "ab")).m28(([2.5e-3, 100.75] : Array<Float>));
				}
				if (false) {
					H.out("o82 " + Std.string(false));
					H.out("o83 " + Std.string(19));
					H.out("o84 " + Std.string(0x5894));
				}
			};
			case _: {
				var w85 = 0;
while (w85 < 2 && false) {
					w85++;
					H.tick();
					var v86:Array<Int> = [265, 0xB6E4, 65535];
				}
				if (false) {
					var v87:Bool = false;
					var v88:Int = 44;
				}
			};
		}
		for (x89 in ((Math.isNaN(0.30000000000000004) ? [279, 21, 0x80000000] : [252, 238, 190]) : Array<Int>)) {
			H.tick();
			this.f5 &= ("ünï").length;
		}
		return (new Box<String>("  pad  ")).get();
	}
	public function m9(a10:Int, a11:Array<Int>):Array<Bool> {
		H.tick();
		(new C23(215, ("0").substr(-2, (30 & 7)))).m33(({ var v90 = "ünï"; v90; }), Main.fn37(Std.int(a10), true));
		for (k92 => x91 in ([] : Array<Int>)) {
			H.tick();
			a10 = (-14);
			Main.fn37(Reflect.compare(a10, 85), (a11).contains(x91));
		}
		var v93:Int = (new C15()).m19(([] : Array<C15>), 190);
		final lf94:(String) -> Int = (p95:String) -> v93;
		v93 = (Std.int(a10) % H.nz(this.f5));
		return ((false ? [for (i96 in a11) if (StringTools.startsWith("Haxe", "\u{1F600}")) this.f6] : [for (i97 in ([] : Array<Int>)) if (false) StringTools.endsWith("\u{1F600}", "ünï")]) : Array<Bool>);
	}
}

class C12 extends C4 {
	public function new(a13:Float, a14:String) {
		super();
	}
}

class C15 {
	public var f16:Float;
	public var f17:Float;
	public var f18:Map<Int, String>;
	public function new() {
		this.f16 = 13;
		this.f17 = 1.25;
		this.f18 = ([-3 => "\x41\x42", 4 => "\u{1F600}"] : Map<Int, String>);
	}
	public function m19(a20:Array<C15>, a21:Int):Int {
		H.tick();
		final v98:A3 = new A3(Math.floor(a21));
		a21 = H.id(a21);
		var v99:Array<C15> = ((false ? a20 : ([new C15(), new C23(a21, "a\rb")] : Array<C15>)) : Array<C15>);
		if (true) {
			final lf100:(String) -> Float = (p101:String) -> a21;
			a21 = H.id(a21);
		} else {
			if (false) {
				H.out("o102 " + "a");
				var v103:S0 = ({x1: 7.0, x2: 150} : S0);
				var v104 = false;
			} else {
				H.out("o105 " + Std.string(false));
			}
			var v106:Map<String, Int> = (["k0" => a21, "k1" => a21, "k2" => 115] : Map<String, Int>);
		}
		a21 |= (StringTools.contains("A-B-C", "\u{1F600}") ? 30 : a21);
		H.out("o107 " + "\\");
		H.out("o108 " + (a21 + Std.string(true)));
		H.out("o109 " + Std.string(123456.789));
		return H.at([Reflect.compare(83, 285)], (new A3(a21)).get(), 0);
	}
	public function m22():Float {
		H.tick();
		final v110:C4 = (cast (new C4()) : C4);
		H.out("o111 " + Std.string((new C23(62, "42")).m19(([new C23(223, "\x41\x42"), new C15()] : Array<C15>), (Std.parseInt(Std.string(539003471)) ?? 0))));
		var v112 = (v110).m8();
		if (((v112).toLowerCase() <= (v112).substring(0, -2))) return Math.min(100.75, 2.5e-3);
		for (x113 in ((switch ((v112).lastIndexOf(v112)) {
			case 0: ([] : Array<Int>);
			case 3 | 4: [0x941F];
			case c114 if (c114 > 10): [c114, (-1730681456)];
			case _: [9];
		}) : Array<Int>)) {
			H.tick();
			var v115:Int = x113;
			final v116:C15 = new C15();
			H.out("o117 " + Std.string(false));
		}
		H.out("o118 " + Std.string(new Box<C15>(new C15())));
		return ((({x1: 100.75, x2: 53} : S0)).x2 - (new C23(156, v112)).m19(([new C15(), new C23(102, v112)] : Array<C15>), 227));
	}
}

class C23 extends C15 {
	public var f24:Bool;
	public var f25:Int;
	public function new(a26:Int, a27:String) {
		super();
		this.f24 = false;
		this.f25 = ((new Map<Int, Int>()).get(a26) ?? 0);
	}
	override public function m19(a20:Array<C15>, a21:Int):Int {
		H.tick();
		var v119:C12 = new C12(a21, "é");
		H.out("o120 " + (([] : Array<Int>)).join(""));
		var v121:Int = a21;
		var v122:Array<Bool> = ([] : Array<Bool>);
		H.out("o123 " + Std.string((-136645041)));
		H.out("o124 " + Std.string((H.id((a21 : A3)) : Int)));
		if ((0.5 < v121)) {
			var v125 = ("\u{1F600}").length;
			var v126:A3 = (v125 : A3);
			final v127 = ("\u{1F600}").substring(0, 3);
		} else {
			var w128 = 0;
while (w128 < 4 && this.f24) {
				w128++;
				H.tick();
				var v129 = false;
			}
		}
		return (Std.parseInt("zz") ?? 0);
	}
	override public function m22():Float {
		H.tick();
		switch ((switch ("\\") {
			case "a" | "b": (({x2: 66, x1: 1e3} : S0)).x2;
			case "Haxe": (Std.parseInt(Std.string(206)) ?? 0);
			case "": ((new Map<Int, Int>()).get(12) ?? 0);
			case _: 0x4198;
		})) {
			case 0: {
				H.out("o130 " + StringTools.hex((34) & 0xFFFF, 4));
			};
			case 2 | 6: {
				var v131:String = ("x,y,z").substr(4, 6);
			};
			case _: {
				final v132:S0 = ({x1: 1e21, x2: 23} : S0);
				H.out("o133 " + Std.string(true));
			};
		}
		if (!true) {
			Main.fn40(([159]).contains(147), 138);
			function lf134(n135:Int):Int {
				H.tick();
				return n135 <= 0 ? 167 : (lf134(n135 - 1) + Math.floor(n135));
			}
			H.out("lf134 " + lf134(4));
			for (i136 in 0...3) {
				H.tick();
				var v137:Int = i136;
			}
		}
		for (x138 in [(([] : Array<Int>)).contains(270)]) {
			H.tick();
			switch (70) {
				case 0: {
					H.out("o139 " + "ab");
				};
				case 2 | 6: {
					H.out("o140 " + Std.string(new C12(0.30000000000000004, "\\")));
				};
				case _: {
					final v141:Array<String> = ([] : Array<String>);
					Main.fn40(x138, (-313616687));
				};
			}
		}
		(new C12(3.0, "\t")).m8();
		var v142:Int = (Std.isOfType(new C12(1e-7, "A-B-C"), C12) ? this.f25 : (Std.parseInt(Std.string(283)) ?? 0));
		return v142;
	}
	public function m28(a29:Array<Float>):Int {
		H.tick();
		this.f25 = ((({x1: 0.1, x2: 16} : S0)).x2 % H.nz(0x456D));
		final lf143:(Float, String) -> Bool = function(p144:Float, p145:String):Bool {
			H.tick();
			H.out("o146 " + Std.string(true));
			H.out("o147 " + Std.string(Math.floor(0.1)));
			var w148 = 0;
while (w148 < 2 && StringTools.endsWith(p145, "é")) {
				w148++;
				H.tick();
				H.out("o149 " + Std.string(110));
				var v150:Null<Int> = null;
			}
			return (154 != 194);
		};
		try {
			this.f25 = 262;
			m19(([new C15()] : Array<C15>), this.f25);
			if ((new Map<Int, Int>()).exists(18)) throw "a\rb";
		} catch (ex151:String) {
			H.out("caught String " + ex151);
			if (((["k0" => 131, "k1" => 0x48AC, "k2" => (-1517492602)] : Map<String, Int>)).exists("k3")) {
				H.out("o152 " + Std.string(260));
			} else {
				this.f25 -= 133;
				var v153:Map<Int, Int> = ([-3 => 14, 4 => 263, 11 => 82] : Map<Int, Int>);
			}
		} catch (ex154:Int) {
			H.out("caught Int " + ex154);
			switch (false) {
				case true: {
					H.out("o155 " + Std.string(({x1: ex154, x2: ex154} : S0)));
					var v156:String = "zz";
				};
				case false: {
					H.out("o157 " + Std.string([ex154, ex154, ex154]));
					var v158:Map<Int, String> = new Map<Int, String>();
				};
			}
		} catch (ex159:Err) {
			H.out("caught Err " + ex159.errCode);
			m19(([] : Array<C15>), (({x1: 0.5, x2: (-10)} : S0)).x2);
		} catch (ex160:Dynamic) {
			H.out("caught " + H.exn(ex160));
			var w161 = 0;
while (w161 < 3 && this.f24) {
				w161++;
				H.tick();
				final v162:Float = 0.5;
			}
		}
		H.out("o163 " + Std.string((StringTools.trim("A-B-C")).length));
		if ((("\x41\x42").substr((0xCBB4 & 7), (0x80000000 & 7)) >= "日本語")) return (new C23(24, "a")).m19(([] : Array<C15>), (([] : Array<Bool>)).length);
		var w164 = 0;
do {
			w164++;
			H.tick();
			H.out("o165 " + ("0").substr((178 & 7), 1));
		} while (w164 < 4 && !false);
		return (([] : Array<String>)).indexOf("a");
	}
	public function m30(a31:Float):Int {
		H.tick();
		this.f25 <<= ((new C23(271, "ünï")).m19(([] : Array<C15>), this.f25) & 7);
		for (x166 in ((switch (Std.string((-182159765))) {
			case "a" | "b": ("42").split(" ");
			case "Haxe": ([] : Array<String>);
			case "": ("\u{1F600}").split(",");
			case _: ("zz").split("-");
		}) : Array<String>)) {
			H.tick();
			H.out("o167 " + Std.string(254));
			switch (((x166).charCodeAt(0xFC46) ?? -1)) {
				case 0: {
					m28(([a31] : Array<Float>));
				};
				case 1 | 6: {
					final v168:Float = a31;
				};
				case _: {
					if (false) break;
				};
			}
		}
		var w169 = 0;
while (w169 < 3 && (false ? true : StringTools.endsWith("zz", "ünï"))) {
			w169++;
			H.tick();
			var v170 = 70;
			var v171:Float = 1e3;
			var v172:Float = 1e100;
		}
		for (i173 in 0...4) {
			H.tick();
			H.out("o174 " + Std.string(i173));
			H.out("o175 " + Std.string(i173));
			var v176:Array<Int> = [i173];
		}
		return (Std.parseInt((Std.string(3.0) + "q")) ?? 0);
	}
	public function m32():Float {
		H.tick();
		for (i177 in 0...H.lim(((new Map<Int, Int>()).get(11) ?? 0))) {
			H.tick();
			for (k179 => x178 in ([] : Array<Int>)) {
				H.tick();
				this.m19(([] : Array<C15>), k179);
				var v180:Box<Bool> = new Box(false);
			}
			var w181 = 0;
do {
				w181++;
				H.tick();
				H.out("o182 " + Std.string(i177));
				this.f25 *= i177;
				H.out("o183 " + "A-B-C");
			} while (w181 < 2 && Math.isNaN(i177));
			H.out("o184 " + Std.string((new A3(i177) : Int)));
		}
		function lf185(n186:Int):Int {
			H.tick();
			return n186 <= 0 ? n186 : (lf185(n186 - 1) + (cast (296) : Int));
		}
		H.out("lf185 " + lf185(1));
		for (i187 in 0...H.lim(this.m33(("hello world").toLowerCase(), new C15()))) {
			H.tick();
			try {
				if (true) throw "boom";
				var v188:S0 = ({x1: i187, x2: 0x8A11} : S0);
				this.m28(([] : Array<Float>));
			} catch (ex189:Dynamic) {
				H.out("caught " + H.exn(ex189));
				H.out("o190 " + Std.string(i187));
			}
			if ((new Map<Int, Int>()).exists(4)) continue;
			H.out("o191 " + Std.string(7));
		}
		return (((false ? Math.isNaN(0.1) : true) ? ((switch ("a") {
			case "a" | "b": 7.0;
			case "Haxe": 0.5;
			case _: 942174861;
		}) : Float) : (0.5 - (-1726000455))) : Float);
	}
	public function m33(a34:String, a35:C15):Int {
		H.tick();
		final v192:Float = (1e-7 - 100.75);
		switch ((true ? Std.string(true) : (a34).charAt((0x7FFFFFFF & 7)))) {
			case "a" | "b": {
				this.f25 = 255;
			};
			case "Haxe": {
				for (i193 in 0...4) {
					H.tick();
					final v194 = i193;
				}
			};
			case "": {
				var v195:Array<Bool> = [false];
			};
			case _: {
				this.f25 = Reflect.compare(21, 0xE23);
				final v196:Array<S0> = ([] : Array<S0>);
			};
		}
		for (x197 in [79]) {
			H.tick();
			this.f25 = 0x7FFFFFFF;
		}
		H.out("o198 " + Std.string([for (i199 in [0x3007, 282, 0x80000000]) if ((Std.downcast((new C23(i199, a34) : C23), C23) != null)) a34]));
		return 7;
	}
}
