import H;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B;
}

abstract A3(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A3, b:A3):A3
		return new A3(a.get() + b.get());

	@:op(A * B) public static function mul(a:A3, b:A3):A3
		return new A3(a.get() * b.get());

	@:op(-A) public static function neg(a:A3):A3
		return new A3(-a.get());
}

enum abstract K4(Int) to Int {
	var K4A = 1;
	var K4B = 4;
}

interface I5 {
	function m6():Int;
}

interface I7 {
	function m8(a9:Bool, a10:Float):String;
	function m11():Array<Int>;
}

class C12 {
	var _f13:Float;

	public var f13(get, set):Float;

	function get_f13():Float
		return _f13;

	function set_f13(v:Float):Float
		return _f13 = v;
	public var f14:Int;
	public function new(a15:E0) {
		this._f13 = 7.0;
		this.f14 = (-17);
	}
	public function m16(a17:Int):E0 {
		H.tick();
		a17 *= this.f14;
		for (i92 in 0...3) {
			H.tick();
			if (true) {
				var v93 = i92;
				var v94:Float = a17;
				a17 = i92;
			}
		}
		if (true) {
			var v95 = (Std.parseInt(Std.string(a17)) ?? 0);
			var w96 = 0;
do {
				w96++;
				H.tick();
				this.f14 *= 106;
				var v97:Int = v95;
			} while (w96 < 4 && false);
		} else {
			for (k99 => x98 in [a17, a17, a17]) {
				H.tick();
				var v100:C28 = new C28(a17);
				var v101 = false;
				var v102:A3 = new A3(k99);
			}
		}
		this.f14++;
		H.out("o103 " + Std.string((switch (Std.string(45)) {
			case "a" | "b": this.f14;
			case "Haxe": a17;
			case _: 0x2BA3;
		})));
		{
			var v104:Null<Int> = a17;
			a17 = 111;
			if (Math.isNaN(a17)) {
				a17 = H.id(a17);
				var v105:Int = 75;
			}
		}
		var v106:E0 = E0B;
		var w107 = 0;
while (w107 < 3 && (String.fromCharCode(65 + ((a17) & 15)) >= "abc")) {
			w107++;
			H.tick();
			{
				this.f14 = a17;
				var v108:Null<Int> = a17;
				this.f14 = 35;
			}
			H.out("o109 " + Std.string(this.f13));
			H.out("o110 " + Std.string(a17));
		}
		return (cast (v106) : E0);
	}
	public function m18(a19:E0):Int {
		H.tick();
		var w111 = 0;
do {
			w111++;
			H.tick();
			H.out("o112 " + Std.string(([263]).contains(0x7FFFFFFF)));
		} while (w111 < 2 && (new C47(121, false)).m60((("hello world").charCodeAt(75) ?? -1), false));
		var v113 = Main.fn64(Reflect.compare("Haxe", "  pad  "));
		H.out("o114 " + Std.string(H.apply("é", (v115:String) -> new C12(a19))));
		if ((this.f14 == (v113).length)) {
			(new C20()).m11();
		}
		return Main.fn66(C20.f22, (0xBAF9 >> ((new A3((-1))).get() & 31)), K4.K4A);
	}
}

class C20 implements I7 {
	public final f21:String;
	public static var f22:String = "-7";
	public function new() {
		this.f21 = "hello world";
	}
	public function m8(a9:Bool, a10:Float):String {
		H.tick();
		H.out("o116 " + Std.string(73));
		if (a9) {
			var v117 = false;
		}
		H.out("o118 " + Std.string((K4.K4A : Int)));
		return (297 + (StringTools.hex((136) & 0xFFFF, 4)).substr(((Std.parseInt("abc") ?? 0) & 7), ((new A3(287) : Int) & 7)));
	}
	public function m11():Array<Int> {
		H.tick();
		H.out("o119 " + Std.string(H.at([122], 231, 0)));
		var v120 = true;
		for (k122 => x121 in C20.m23(0x6947)) {
			H.tick();
			var v123:K4 = K4.K4B;
			var v124:Array<String> = ["-7"];
		}
		var v125:Int = Type.enumIndex(E0A);
		H.out("o126 " + Std.string(v125));
		return [169, (v125 ^ 0x2EC6)];
	}
	public static inline function m23(a24:Int):Array<String> {
		H.tick();
		var v127:C47 = new C47(0x1CBB, Std.isOfType(new C47(a24, true), C35));
		var v128:E0 = E0A;
		for (x129 in (["ünï", "a\rb", "42"]).copy()) {
			H.tick();
			H.out("o130 " + Std.string([53]));
		}
		final v131:Array<Array<A3>> = (([([new A3(274)] : Array<A3>), ([] : Array<A3>), ([new A3(a24), new A3(118), new A3(a24)] : Array<A3>)] : Array<Array<A3>>)).slice(-1, 3);
		(new C12(v128)).m16(a24);
		for (i132 in 0...H.lim(a24)) {
			H.tick();
			final v133:Array<Bool> = [false, false, false];
			var v134:K4 = K4.K4B;
			final v135:Array<String> = ["\"q\""];
		}
		(new C12(E0.E0B)).m16(a24);
		for (i136 in 0...0) {
			H.tick();
			H.out("o137 " + Std.string(Reflect.compare("日本語", "q")));
			H.out("o138 " + Std.string(Math.round(1e3)));
			final v139:Bool = ([102, 146, i136]).contains(i136);
		}
		a24 = H.id(a24);
		return [for (i140 in 0...4) Std.string(123456.789)];
	}
	public static function m25(a26:Int, a27:Int):Bool {
		H.tick();
		var w141 = 0;
while (w141 < 3 && (false || true)) {
			w141++;
			H.tick();
			switch (K4.K4B) {
				case K4.K4A: {
					(new C20()).m8(true, a26);
				};
				case K4.K4B: {
					H.out("o142 " + "\\");
				};
			}
			for (k144 => x143 in ([] : Array<String>)) {
				H.tick();
				var v145 = k144;
				v145 = (-338454942);
			}
		}
		var v146:String = (switch (E0.E0A) {
			case E0A: "\t";
			case E0B: ("A-B-C").substr(5, -2);
		});
		var v147:Bool = (false && true);
		if ((a26 < 1.25)) return (switch (E0.E0A) {
			case E0A: false;
			case E0B: v147;
		});
		try {
			var v148:C28 = new C28(a27);
			if (((("日本語").charCodeAt(2024619566) ?? -1) == a26)) throw 56;
		} catch (ex149:Err) {
			H.out("caught Err " + ex149.errCode);
			for (i150 in 0...H.lim(18)) {
				H.tick();
				H.out("o151 " + Std.string(a27));
				H.out("o152 " + Std.string(291));
				(new C47(a26, v147)).m6();
			}
			var v153 = a26;
		} catch (ex154:haxe.Exception) {
			H.out("caught " + H.exn(ex154));
			H.out("o155 " + Std.string(([] : Array<Bool>)));
		}
		try {
			try {
				if (v147) throw "boom";
				H.out("o156 " + Std.string(a26));
			} catch (ex157:Err) {
				H.out("caught Err " + ex157.errCode);
				H.out("o158 " + Std.string([v146]));
			} catch (ex159:haxe.Exception) {
				H.out("caught " + H.exn(ex159));
				var v160:Bool = v147;
			}
			if (v147) throw 53;
		} catch (ex161:Dynamic) {
			H.out("caught " + H.exn(ex161));
			var v162:Bool = v147;
		}
		return StringTools.contains((Std.string(false)).substring(1, 1), v146);
	}
}

class C28 implements I5 {
	public function new(a29:Int) {}
	public function m6():Int {
		H.tick();
		var v163:Float = 0.1;
		var v164 = ({ var v165 = (("abc").charCodeAt(257) ?? -1); "ünï"; });
		var v166:Array<String> = ((switch (E0.E0B) {
			case E0A: (v164).split("a");
			case E0B: ([] : Array<String>);
		}) : Array<String>);
		return 276916465;
	}
	public function m30(a31:Box<String>, a32:Float):Bool {
		H.tick();
		final v167:Int = 154;
		var v168 = H.at([v167, 89], Type.enumIndex(E0.E0B), 0);
		try {
			try {
				var v169:String = "42";
				final v170:Array<String> = [v169];
				var v171:String = v169;
				if (StringTools.startsWith("A-B-C", v171)) throw "a";
			} catch (ex172:Err) {
				H.out("caught Err " + ex172.errCode);
				var v173 = "ünï";
			} catch (ex174:haxe.Exception) {
				H.out("caught " + H.exn(ex174));
				H.out("o175 " + Std.string(new C28(v167)));
				var v176:Int = 61;
			}
			if ((99 > v168)) throw new Err((([] : Array<Int>)).length);
		} catch (ex177:Err) {
			H.out("caught Err " + ex177.errCode);
			for (i178 in 0...H.lim(Reflect.compare("\x41\x42", ""))) {
				H.tick();
				H.out("o179 " + Std.string(v167));
			}
		} catch (ex180:haxe.Exception) {
			H.out("caught " + H.exn(ex180));
			v168 &= ("a\rb").lastIndexOf("-7");
		}
		H.out("o181 " + Std.string(new C47(0xC372, ([v168, v167]).contains((-2147483647)))));
		for (i182 in 0...H.lim(v168)) {
			H.tick();
			switch ("hello world") {
				case "a" | "b": {
					(new C37()).m39("x,y,z");
				};
				case "Haxe": {
					H.out("o183 " + Std.string(([] : Array<String>)));
				};
				case _: {
					var v184:E0 = E0.E0B;
					var v185:Array<E0> = ([E0A, v184, v184] : Array<E0>);
				};
			}
			H.out("o186 " + Std.string(true));
			switch (E0A) {
				case E0A: {
					(new C20()).m8(false, i182);
					var v187:Bool = true;
				};
				case E0B: {
					v168 ^= i182;
					(new C20()).m11();
				};
				case _: {
					(new C37()).m39("\u{1F600}");
					var v188 = "a\rb";
				};
			}
		}
		return StringTools.endsWith((true ? "  pad  " : ("\u{1F600}").charAt(6)), "q");
	}
	public function m33(a34:I7):Int {
		H.tick();
		H.out("o189 " + Std.string(((Std.parseInt("A-B-C") ?? 0) - (-486538707))));
		H.out("o190 " + Std.string(E0.E0B));
		final v191:Array<Array<K4>> = ((([(-17)]).contains(215) ? ([] : Array<Array<K4>>) : ([([K4.K4B, K4.K4A] : Array<K4>), ([] : Array<K4>), ([K4.K4A, K4.K4B, K4.K4B] : Array<K4>)] : Array<Array<K4>>)) : Array<Array<K4>>);
		for (i192 in 0...3) {
			H.tick();
			if (StringTools.endsWith("-7", "-7")) {
				var v193:Array<Float> = ([i192] : Array<Float>);
				C20.f22 += "\x41\x42";
			} else {
				var v194 = 0x7FFFFFFF;
				var v195 = i192;
			}
			var v196:Box<Int> = new Box<Int>(i192);
		}
		(new C20()).m8((StringTools.endsWith("-7", "日本語") ? StringTools.endsWith("\u{1F600}", "q") : false), 2.5e-3);
		switch (((["a", "", "ünï"]).indexOf("a\rb") >>> ((Std.parseInt("a\rb") ?? 0) & 31))) {
			case 0: {
				for (i197 in 0...H.lim(109)) {
					H.tick();
					H.out("o198 " + Std.string(112));
					var v199:C37 = new C37();
				}
				var v200 = (-4);
			};
			case 1 | 6: {
				if (false) {
					final v201:C37 = new C37();
					var v202:I7 = a34;
					var v203:Array<String> = ["日本語"];
				} else {
					H.out("o204 " + Std.string(54));
				}
			};
			case _: {
				switch ((([3.0] : Array<Float>)).length) {
					case 0: {
						var v205:Array<String> = ("\"q\"").split("-");
						final v206:Array<Int> = ([] : Array<Int>);
					};
					case 3 | 5: {
						var v207 = true;
					};
					case _: {
						var v208:K4 = K4.K4A;
					};
				}
				for (i209 in 0...H.lim((["a\rb", "0", ""]).indexOf("\\"))) {
					H.tick();
					var v210:Array<String> = ("").split("a");
					var v211:E0 = E0.E0B;
					if (true) continue;
				}
			};
		}
		var v212:I7 = a34;
		switch (!true) {
			case true: {
				H.out("o213 " + Std.string((Std.parseInt(Std.string(0xBAC3)) ?? 0)));
			};
			case false: {
				final v214:A3 = new A3(150);
			};
		}
		return (Std.parseInt(Std.string((291 - (([1.7976931348623157e308] : Array<Float>)).length))) ?? 0);
	}
}

class C35 implements I5 {
	public function new(a36:Int) {}
	public function m6():Int {
		H.tick();
		try {
			var w215 = 0;
while (w215 < 3 && Math.isNaN(1e3)) {
				w215++;
				H.tick();
				H.out("o216 " + Std.string(E0B));
				var v217:C28 = new C28(46);
				final v218 = 23;
			}
			Main.fn63();
			if (true) throw "0";
		} catch (ex219:Dynamic) {
			H.out("caught " + H.exn(ex219));
			var v220:A3 = new A3(163);
			Main.fn70(("zz").replace("a", "b"), (K4.K4B : Int), E0.E0B);
		}
		var v221 = ((("Haxe").charCodeAt(84) ?? -1) > H.at(([] : Array<Int>), 161, 0));
		final v222 = ([(-905249087), (-1727661894), 147]).indexOf((([] : Array<Int>)).indexOf(274));
		switch (Std.string(H.at([(-11)], v222, 0))) {
			case "a" | "b": {
				H.out("o223 " + Std.string(222));
			};
			case "Haxe": {
				final v224:C20 = new C20();
				H.out("o225 " + Std.string(Std.int(v222)));
			};
			case _: {
				var v226:C12 = new C12(E0B);
			};
		}
		return ((v221 ? 74 : (Std.parseInt("") ?? 0)) >>> ((v222 >> (202 & 31)) & 31));
	}
}

class C37 {
	public final f38:Int;
	public function new() {
		this.f38 = Type.enumIndex(E0B);
	}
	public function m39(a40:String = "d"):K4 {
		H.tick();
		var v227:Float = Math.PI;
		final v228:K4 = K4.K4B;
		if ((false && false)) {
			H.out("o229 " + Std.string((new A3(102) : Int)));
			var v230:Bool = false;
		}
		H.out("o231 " + Std.string(new Box<C47>(new C47(85, false))));
		var v232:Array<Int> = ((StringTools.contains("Haxe", "zz") ? [283, 280, 50] : [137]) : Array<Int>);
		return K4.K4B;
	}
	public function m41(a42:Int = -3):A3 {
		H.tick();
		var v233:I5 = new C35(a42);
		a42 = (83 % H.nz((([] : Array<Float>)).length));
		var v234:E0 = E0A;
		(v233).m6();
		var v235:Array<Bool> = [false, false];
		for (i236 in 1...1) {
			H.tick();
			var v237:Int = 37;
			v237 |= ("a\rb").indexOf("-7");
			switch (K4.K4A) {
				case K4.K4A: {
					H.out("o238 " + Std.string(E0B));
				};
				case K4.K4B: {
					(new C47(v237, true)).m53(([] : Array<Int>), "a", 187);
					var v239:C20 = new C20();
				};
			}
		}
		(new C20()).m8(([a42, 0x7FFFFFFF, a42]).contains(this.f38), (new C47(a42, true)).m6());
		H.out("o240 " + Std.string((new A3(294)).twice));
		H.out("o241 " + Std.string(v234));
		return new A3((a42 | ("  pad  ").length));
	}
	public function m43():Bool {
		H.tick();
		for (i242 in 0...H.lim(this.f38)) {
			H.tick();
			for (i243 in 0...0) {
				H.tick();
				H.out("o244 " + Std.string(new C47(i243, false)));
			}
		}
		final v245 = "\\";
		var v246:Array<String> = ([] : Array<String>);
		for (x247 in ([false, true, false]).copy()) {
			H.tick();
			var v248 = Std.string(229);
		}
		var v249:String = C20.f22;
		var v250 = Type.enumIndex(E0.E0A);
		var v251:Null<Int> = ((switch ((v245).substr((v250 & 7), 2)) {
			case "a" | "b": v250;
			case "Haxe": v250;
			case _: v250;
		}) : Null<Int>);
		return H.id((100.75 == 0.5));
	}
	public static function m44(a45:String, a46:Int = 7):A3 {
		H.tick();
		(new C28(75)).m6();
		var v252:Bool = (Std.downcast((new C35(a46) : C35), C35) != null);
		var v253:String = a45;
		for (i254 in 0...0) {
			H.tick();
			var v255:I7 = new C20();
			(new C28(a46)).m33(v255);
		}
		return (-(new C37()).m41(268));
	}
}

class C47 implements I5 {
	var _f48:Float;

	public var f48(get, set):Float;

	function get_f48():Float
		return _f48;

	function set_f48(v:Float):Float
		return _f48 = v;
	public function new(a49:Int, a50:Bool) {
		this._f48 = a49;
	}
	public function m6():Int {
		H.tick();
		C20.f22 = H.cap(({ var sb256 = new StringBuf(); sb256.add(Std.string(E0.E0A)); sb256.add(Std.string(Math.isNaN(1e-7))); sb256.toString(); }));
		for (x257 in ((false ? ([] : Array<Int>) : [0xA409]) : Array<Int>)) {
			H.tick();
			if (true) {
				m51(false);
				var v258:Box<String> = new Box("日本語");
			}
			m53([x257], C20.f22, (K4.K4B : Int), ([true, false]).length);
			final v259 = Std.string(x257);
		}
		var v260:A3 = new A3(("ünï").lastIndexOf("A-B-C"));
		return (((true ? "0" : Std.string(100.75))).charCodeAt(((K4.K4B : Int) << ((K4.K4A : Int) & 31))) ?? -1);
	}
	public function m51(a52:Bool):String {
		H.tick();
		final v261 = (a52 ? 0xB58E : 185);
		for (i262 in 0...4) {
			H.tick();
			var v263:Int = v261;
			var w264 = 0;
while (w264 < 2 && ([v261, v263, v261]).contains(i262)) {
				w264++;
				H.tick();
				H.out("o265 " + Std.string(E0B));
				H.out("o266 " + Std.string(v261));
			}
			if (a52) continue;
		}
		if ((a52 ? a52 : true)) return (String.fromCharCode(65 + ((v261) & 15))).replace("a", "b");
		var v267 = !a52;
		var v268 = (0x7FFFFFFF >> (Type.enumIndex(E0A) & 31));
		for (i269 in 0...H.lim(v261)) {
			H.tick();
			var v270:Int = 171;
			H.out("o271 " + Std.string(([new C20(), new C20()] : Array<I7>)));
			var v272:String = Std.string(a52);
		}
		return (v267 ? C20.f22 : (String.fromCharCode(65 + ((274) & 15)) + v268));
	}
	public function m53(a54:Array<Int>, a55:String, ...r56:Int):Bool {
		H.tick();
		var v273 = ({ var v274 = StringTools.trim("\t"); 1586011929; });
		v273 |= (new A3(v273)).twice;
		var v275:Float = v273;
		if ((Reflect.compare(129, v273) <= ("hello world").length)) {
			switch (v273) {
				case 0: {
					v273 += v273;
					++v273;
				};
				case 3 | 5: {
					this.m51(false);
					var v276 = true;
				};
				case _: {
					var v277 = true;
				};
			}
			var v278:C47 = new C47(v273, true);
			var v279:Int = Type.enumIndex(E0.E0B);
		}
		final v280:String = a55;
		v273 = H.id(v273);
		for (i281 in 1...H.lim(v273)) {
			H.tick();
			{
				(new C37()).m39("a");
			}
			v273 &= 12;
			this.m51(false);
		}
		H.out("o282 " + Std.string(!StringTools.contains(v280, a55)));
		((new Box<C12>(new C12(E0A))).value).m16(((K4.K4B : Int) + (Std.parseInt(Std.string(v273)) ?? 0)));
		return (((true ? v273 : v275) : Float) == v273);
	}
	public function m57(a58:Bool, a59:E0):String {
		H.tick();
		var v283 = 163;
		var v284 = 0x80000000;
		final v285:String = C20.f22;
		H.out("o286 " + Std.string(new C20()));
		H.out("o287 " + ({ var v288 = v285; "\x41\x42"; }));
		H.out("o289 " + Std.string(v284));
		H.out("o290 " + Std.string(a59));
		v283 -= ((v285).charCodeAt(2) ?? -1);
		return (cast (m51(([v284, v284, v284]).contains(v283))) : String);
	}
	public function m60(a61:Int, a62:Bool):Bool {
		H.tick();
		for (i291 in 1...H.lim(a61)) {
			H.tick();
			m51(([a61]).contains(a61));
			H.out("o292 " + Std.string(new C37()));
		}
		H.out("o293 " + Std.string((K4.K4B : Int)));
		var v294:A3 = (a61 : A3);
		a61 = (a61 + (([] : Array<String>)).length);
		H.out("o295 " + Std.string(([a61, a61]).concat([a61])));
		if (m53(([] : Array<Int>), "\"q\"")) {
			H.out("o296 " + Std.string(true));
			for (x297 in ["x,y,z", "ab", "hello world"]) {
				H.tick();
				(new C12(E0B)).m16((-2147483647));
			}
		}
		final v298:Array<Bool> = ((false ? ([] : Array<Bool>) : [a62, a62, a62]) : Array<Bool>);
		a61 += 65535;
		(new C12(E0B)).m16((Std.parseInt(Std.string((("hello world").charCodeAt(a61) ?? -1))) ?? 0));
		return (Std.string(([228, a61]).contains(a61)) == Std.string(a62));
	}
}

class Main {
	public static inline function fn63():Int {
		H.tick();
		var v299 = (-941890522);
		for (i300 in 0...1) {
			H.tick();
			if (true) {
				(new C37()).m39("zz");
				if (true) break;
			}
			final v301 = 127;
			for (i302 in 0...1) {
				H.tick();
				H.out("o303 " + Std.string(0xFFFFFFFF));
				H.out("o304 " + Std.string(E0.E0A));
				H.out("o305 " + Std.string(true));
			}
		}
		switch (v299) {
			case 0: {
				final v306 = (new A3((-18))).get();
			};
			case 2 | 5: {
				for (i307 in 0...H.lim(219)) {
					H.tick();
					var v308:C28 = new C28(69);
				}
			};
			case _: {
				var w309 = 0;
do {
					w309++;
					H.tick();
					H.out("o310 " + Std.string(E0A));
					v299 ^= v299;
					v299 = H.id(v299);
				} while (w309 < 2 && true);
			};
		}
		if (([v299]).contains(Type.enumIndex(E0A))) {
			v299 = H.id(v299);
		}
		for (i311 in 2...H.lim(v299)) {
			H.tick();
			var v312:K4 = K4.K4B;
			var v313:Int = ("\x41\x42").indexOf("日本語");
		}
		switch (({ var v314 = C20.f22; C20.f22; })) {
			case "a" | "b": {
				{ var dyn315:Dynamic = H.at(([] : Array<Int>), v299, 0); H.out("dyn " + Std.string(dyn315 + 1)); }
				H.out("o316 " + Std.string((("ünï").charCodeAt(v299) ?? -1)));
			};
			case "Haxe": {
				H.out("o317 " + Std.string(new C20()));
			};
			case _: {
				H.out("o318 " + Std.string((K4.K4A : Int)));
				C20.f22 += "\"q\"";
			};
		}
		for (i319 in 0...H.lim(((Std.string(v299)).charCodeAt(("42").lastIndexOf("a\rb")) ?? -1))) {
			H.tick();
			v299 = 133;
			H.out("o320 " + Std.string(("hello world").split(",")));
			try {
				if (true) throw "boom";
				H.out("o321 " + Std.string(true));
			} catch (ex322:Err) {
				H.out("caught Err " + ex322.errCode);
				v299 = 64;
			} catch (ex323:haxe.Exception) {
				H.out("caught " + H.exn(ex323));
				var v324:Int = v299;
				var v325:Box<String> = new Box("\u{1F600}");
			}
		}
		return ((Std.string(v299)).substr(-2, (v299 & 7))).indexOf(Std.string(StringTools.endsWith("\u{1F600}", "\"q\"")));
	}
	public static inline function fn64(a65:Int):String {
		H.tick();
		var v326 = ((([true, true, false]).join("")).charCodeAt(202) ?? -1);
		switch (E0.E0A) {
			case E0A: {
				var v327 = "-7";
				var v328:Float = (-2.5);
			};
			case E0B: {
				var w329 = 0;
do {
					w329++;
					H.tick();
					a65++;
				} while (w329 < 3 && ([0x7FFFFFFF]).contains(a65));
			};
		}
		final v330:I7 = new C20();
		a65 += (("Haxe").indexOf("\"q\"") >>> (Type.enumIndex(E0B) & 31));
		return (new C47(133, true)).m51(!true);
	}
	public static function fn66(a67:String, a68:Int, a69:K4):Int {
		H.tick();
		var w331 = 0;
while (w331 < 5 && false) {
			w331++;
			H.tick();
			H.out("o332 " + Std.string(null));
			a68 = H.id(a68);
		}
		var v333:Float = Main.fn63();
		H.out("o334 " + Std.string((new C47(a68, true)).m53([102], Std.string(false))));
		var v335:Array<Float> = ((true ? ([a68] : Array<Float>) : ([v333] : Array<Float>)) : Array<Float>);
		return Main.fn63();
	}
	public static function fn70(a71:String, a72:Int, a73:E0):Int {
		H.tick();
		H.out("o336 " + Std.string(a72));
		for (x337 in [for (i338 in 0...1) ("a").replace("a", "b")]) {
			H.tick();
			if (StringTools.endsWith(x337, a71)) return H.at([a72], 0xFFFFFFFF, 0);
			var w339 = 0;
do {
				w339++;
				H.tick();
				var v340:K4 = K4.K4B;
				H.out("o341 " + Std.string([a72, (-1005510558), 23]));
			} while (w339 < 1 && true);
			var v342:Null<Int> = a72;
		}
		(new C37()).m39();
		var v343 = (cast (a71) : String);
		var v344:Bool = (true && true);
		if ((new C47(a72, v344)).m60(H.at(([] : Array<Int>), a72, 0), (Std.downcast((new C28(a72) : I5), C28) != null))) return (Math.ceil(a72) >> (a72 & 31));
		var v345:Array<Bool> = [for (i346 in 0...1) false];
		var w347 = 0;
while (w347 < 4 && (new C47(a72, v344)).m60(a72, v344)) {
			w347++;
			H.tick();
			var w348 = 0;
while (w348 < 5 && v344) {
				w348++;
				H.tick();
				final v349:Int = 182;
				var v350:String = v343;
			}
			if (v344) {
				final v351:Int = 60;
			} else {
				var v352:Int = 65535;
			}
			final v353 = 199;
		}
		var v354:I7 = ((switch (("hello world").indexOf(v343)) {
			case 0: new C20();
			case 3 | 6: new C20();
			case _: new C20();
		}) : I7);
		return 148;
	}
	public static function fn74(a75:Int, a76:Bool, ?a77:Null<Bool>):Bool {
		H.tick();
		a75 |= (([] : Array<Float>)).length;
		final v355 = a75;
		((cast (new C47(a75, true)) : C47)).m6();
		switch (C20.f22) {
			case "a" | "b": {
				a75 += v355;
				Ext.ext91([v355, a75, v355]);
			};
			case "Haxe": {
				H.out("o356 " + Std.string(Math.floor(v355)));
			};
			case "": {
				H.out("o357 " + ("hello world").substr(1, 3));
				H.out("o358 " + Std.string(a76));
			};
			case _: {
				H.out("o359 " + Std.string((Std.parseInt("") ?? 0)));
			};
		}
		if (a76) {
			var v360:Array<Float> = ([a75] : Array<Float>);
		} else {
			var v361 = 253;
		}
		try {
			if (true) throw new Err(11);
			var v362:String = StringTools.hex((237) & 0xFFFF, 4);
			final v363:C37 = new C37();
			if (StringTools.endsWith(v362, "a")) {
				(new C37()).m41(v355);
			} else {
				var v364 = 170;
				a75 = v355;
			}
		} catch (ex365:Dynamic) {
			H.out("caught " + H.exn(ex365));
			for (i366 in 0...H.lim(Type.enumIndex(E0.E0A))) {
				H.tick();
				a75 &= v355;
				var v367:I5 = new C28(62);
				H.out("o368 " + "x,y,z");
			}
			{
				a75 = v355;
			}
		}
		var v369:E0 = E0B;
		a75 ^= (Std.parseInt(Std.string((Std.parseInt("\\") ?? 0))) ?? 0);
		H.out("o370 " + Std.string(v355));
		return ((a76 ? ("  pad  ").lastIndexOf("ünï") : (-448893439)) > (if (([v355]).contains(124)) 206 else Math.ceil(v355)));
	}
	public static function fn78():E0 {
		H.tick();
		var v371 = (new C28((-1808527528))).m30(new Box("\"q\""), 69);
		var v372:Bool = (new C28(171)).m30(new Box("Haxe"), 0.5);
		try {
			var v373:Int = Type.enumIndex(E0.E0A);
			if (v371) {
				var v374:Int = v373;
				var v375:Int = v374;
				H.out("o376 " + Std.string(E0B));
			}
			if ((false && v372)) throw 11;
		} catch (ex377:Dynamic) {
			H.out("caught " + H.exn(ex377));
			if (v372) return E0.E0A;
		}
		var v378:Box<Bool> = H.id(new Box<Bool>(v372));
		var v379:Int = Reflect.compare(Std.string(1e-7), "\n");
		switch (E0.E0B) {
			case E0A: {
				v379 = ("é").length;
			};
			case E0B: {
				var v380:E0 = E0B;
			};
		}
		H.out("o381 " + "a\rb");
		final v382 = v379;
		var v383:Array<String> = ((switch (("\t").replace("a", "b")) {
			case "a" | "b": ["", "x,y,z"];
			case "Haxe": ("\"q\"").split("a");
			case _: ["\\", "日本語", "-7"];
		}) : Array<String>);
		return E0A;
	}
	public static function fn79():Void {
		H.tick();
		var v384:Int = Math.floor(1e-7);
		for (x385 in ([for (i386 in 0...1) 1e-7] : Array<Float>)) {
			H.tick();
			var v387 = "a";
			for (i388 in 0...H.lim(v384)) {
				H.tick();
				var v389:Array<Int> = ([] : Array<Int>);
				final v390:Int = i388;
				v384++;
			}
		}
		var v391:E0 = ((false ? E0.E0B : E0.E0A) : E0);
		H.out("o392 " + Std.string(((true ? [v384] : ([] : Array<Int>)) : Array<Int>)));
		for (i393 in 0...3) {
			H.tick();
			var v394:Int = ([279, (-1408546949), i393]).length;
			final v395:Array<String> = ["Haxe", "", "A-B-C"];
			try {
				if (false) throw "boom";
				H.out("o396 " + Std.string(false));
			} catch (ex397:String) {
				H.out("caught String " + ex397);
				C20.m25((-1309187595), v394);
				v394 -= i393;
			} catch (ex398:Int) {
				H.out("caught Int " + ex398);
				var v399:A3 = new A3(v394);
			} catch (ex400:Err) {
				H.out("caught Err " + ex400.errCode);
				final v401 = i393;
				var v402:C12 = new C12(v391);
			} catch (ex403:Dynamic) {
				H.out("caught " + H.exn(ex403));
				H.out("o404 " + Std.string(i393));
			}
		}
		H.out("o405 " + Std.string(v384));
		var w406 = 0;
while (w406 < 4 && (true && true)) {
			w406++;
			H.tick();
			H.out("o407 " + Std.string((Std.parseInt(Std.string(v384)) ?? 0)));
			for (i408 in 0...H.lim(239)) {
				H.tick();
				v384 <<= (i408 & 7);
			}
			var v409:C28 = new C28(v384);
		}
		v384 <<= (v384 & 7);
		final v410:E0 = (cast (v391) : E0);
	}
	public static function fn80():Int {
		H.tick();
		var v411 = (new C28(176)).m33(new C20());
		H.out("o412 " + Std.string(StringTools.endsWith(C20.f22, "\x41\x42")));
		var v413:Array<Float> = (([v411, 0.5, v411] : Array<Float>)).copy();
		var v414 = (new A3(v411) : Int);
		v413.remove(v411);
		v414 = Reflect.compare("é", ("hello world").toUpperCase());
		if ((switch (E0B) {
			case E0A: StringTools.startsWith("\"q\"", "日本語");
			case E0B: Std.isOfType(new C28(v414), I5);
		})) {
			H.out("o415 " + Std.string((new A3(265) : Int)));
		} else {
			if (true) {
				(new C37()).m41(138);
			} else {
				H.out("o416 " + Std.string(v414));
			}
			fn66(("ünï").toUpperCase(), v414, K4.K4B);
		}
		var v417:A3 = (-new A3(84));
		return (v411 + (v414 >>> (0x1248 & 31)));
	}
	public static function fn81(a82:Int, a83:Float):Int {
		H.tick();
		var v418:Float = (new C35(52)).m6();
		C20.m23((cast (58) : Int));
		var v419:A3 = new A3(([false]).indexOf(true));
		H.out("o420 " + "\\");
		a82 = (a82 % H.nz(Std.int(a83)));
		var v421 = (a82 % H.nz(("\"q\"").indexOf("hello world")));
		var v422 = (([a82]).indexOf(292) % H.nz(("q").length));
		var v423 = (switch (K4.K4B) {
			case K4.K4A: Type.enumIndex(E0A);
			case K4.K4B: a82;
			case _: (Std.parseInt("Haxe") ?? 0);
		});
		(new C28(("x,y,z").length)).m33(new C20());
		return (C20.m23(67)).indexOf(Std.string(a82));
	}
	public static function fn84(a85:Int, a86:String, a87:Int):Int {
		H.tick();
		if (!true) {
			for (i424 in 2...H.lim(a87)) {
				H.tick();
				var v425:Float = a85;
				var v426 = a87;
				H.out("o427 " + Std.string(new C20()));
			}
		} else {
			if (Math.isNaN(a87)) {
				Main.fn63();
				H.out("o428 " + Std.string(false));
			}
		}
		a85++;
		var v429 = "a";
		for (x430 in ([] : Array<Bool>)) {
			H.tick();
			H.out("o431 " + Std.string(183));
			a85 = 106;
		}
		H.out("o432 " + Std.string((switch (a87) {
			case 0: 762497092;
			case 3 | 5: Reflect.compare(a86, "日本語");
			case _: a87;
		})));
		return a85;
	}
	public static function fn88(a89:String):C12 {
		H.tick();
		Main.fn80();
		final v433:Box<C47> = new Box<C47>(new C47(136, false));
		H.out("o434 " + (([47, 90]).contains(0x755D) ? a89 : ("\"q\"").replace("a", "b")));
		H.out("o435 " + a89);
		(new C20()).m8(false, (Std.parseFloat("-0.25") - Math.round(1e3)));
		var v436 = (true ? (K4.K4A : Int) : (new A3(0xFFFFFFFF)).get());
		H.out("o437 " + Std.string(Math.ceil(Std.parseFloat("12.5"))));
		(new C12(E0.E0B)).m16((-17));
		final v438:Bool = (true ? false : ([65535, 108]).contains(v436));
		return ((true ? new C12(E0A) : new C12(E0A)) : C12);
	}
	public static function section0():Void {
		H.tick();
		(new C37()).m43();
		for (i443 in 0...0) {
			H.tick();
			for (x444 in ("\u{1F600}").split("-")) {
				H.tick();
				H.out("o445 " + Std.string(new C20()));
			}
		}
		H.out("o446 " + Std.string(([new A3(0x7FFFFFFF), new A3(0x80000000)] : Array<A3>)));
	}
	public static function section1():Void {
		H.tick();
		final v447:Null<Int> = ("\"q\"").length;
		try {
			var v448:Bool = false;
			{ var dyn449:Dynamic = Math.floor(5e-324); H.out("dyn " + Std.string(dyn449 + 1)); }
			if (v448) throw ({ var sb450 = new StringBuf(); sb450.add(Std.string(false)); sb450.toString(); });
		} catch (ex451:Err) {
			H.out("caught Err " + ex451.errCode);
			{ var dyn452:Dynamic = (Std.parseInt("zz") ?? 0); H.out("dyn " + Std.string(dyn452 + 1)); }
		} catch (ex453:haxe.Exception) {
			H.out("caught " + H.exn(ex453));
			var v454 = "日本語";
		}
		for (i455 in 0...1) {
			H.tick();
			var w456 = 0;
while (w456 < 1 && StringTools.endsWith("é", "-7")) {
				w456++;
				H.tick();
				var v457:Float = 3.0;
				var v458:String = "é";
				var v459 = v458;
			}
		}
		final v460:C35 = new C35(H.at([163], 128, 0));
		var v461:Float = 0.5;
	}
	public static function section2():Void {
		H.tick();
		var v462:Float = 1.7976931348623157e308;
		if ((switch (Math.ceil(1.25)) {
			case 0: false;
			case 1 | 5: StringTools.contains("é", "42");
			case _: true;
		})) {
			(new C20()).m8(false, 197);
		} else {
			var v463 = true;
			H.out("o464 " + Std.string(E0B));
		}
		var w465 = 0;
while (w465 < 5 && (Math.PI < 1.7976931348623157e308)) {
			w465++;
			H.tick();
			if (StringTools.startsWith("0", "\x41\x42")) break;
			try {
				var v466:Int = 261;
				final v467:I7 = new C20();
				var v468:Array<String> = ["  pad  ", "A-B-C"];
				if (StringTools.endsWith("Haxe", "ab")) throw ([false, false, false]).join(",");
			} catch (ex469:Dynamic) {
				H.out("caught " + H.exn(ex469));
				H.out("o470 " + Std.string(false));
			}
		}
		var v471:Box<Int> = ((true ? new Box(286) : new Box(225)) : Box<Int>);
	}
	public static function section3():Void {
		H.tick();
		for (i472 in 0...4) {
			H.tick();
			H.out("o473 " + Std.string((new A3(i472) : Int)));
		}
		H.out("o474 " + (C20.f22 + C20.f22));
		H.out("o475 " + Std.string(new C20()));
		var v476:Array<Int> = (new C20()).m11();
		H.out("o477 " + Std.string((("x,y,z").split(",")).length));
	}
	public static function section4():Void {
		H.tick();
		var w478 = 0;
while (w478 < 2 && (("hello world").substr((0xB15E & 7), 4) > ("\u{1F600}").toUpperCase())) {
			w478++;
			H.tick();
			(new C28((-17))).m6();
			var v479:I7 = new C20();
		}
		if ((false || false)) {
			H.out("o480 " + Std.string(E0.E0A));
		} else {
			var v481:C12 = new C12(E0B);
		}
		(new C47((([2.5e-3, 2.5e-3] : Array<Float>)).length, StringTools.startsWith("\u{1F600}", "hello world"))).m60((Reflect.compare("日本語", "zz") & 129), false);
		for (i482 in 0...H.lim(Main.fn80())) {
			H.tick();
			final v483:String = StringTools.replace("abc", " ", "ab");
		}
		var v484:Array<Int> = (([] : Array<Int>)).copy();
		H.out("o485 " + "-7");
		final v486:Array<Float> = ({ var v487 = false; ([] : Array<Float>); });
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
