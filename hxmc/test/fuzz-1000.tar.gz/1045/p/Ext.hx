package p;

import Main;
import H;
using StringTools;

class Ext {
	public static function ext91(a90:Array<Int>):Int {
		H.tick();
		final v439:C28 = new C28(Type.enumIndex(E0.E0A));
		final v440:Int = ({ var v441 = ("A-B-C").replace("a", "b"); 69; });
		C20.m23(v440);
		var v442:Int = Math.round(v440);
		return v440;
	}
}
