import H;
import p.M1;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
}

class Main {
	public static inline function fn8(a9:Int, a10:Bool):Void {
		H.tick();
		var v29:E0 = E0A;
		final v30:(Int, Int) -> String = (new Box<(Int, Int) -> String>(function(p31:Int, p32:Int):String {
			H.tick();
			H.out("o33 " + "\\");
			final v34:Array<Bool> = ([] : Array<Bool>);
			H.out("o35 " + Std.string(true));
			return "Haxe";
		})).value;
		{ var dyn36:Dynamic = ({x6: ("0").toLowerCase()} : S5); H.out("dyn " + Std.string(dyn36.x6) + " " + Std.string(Reflect.field(dyn36, "x6"))); }
		a9++;
		var v37:String = (Std.string(a10) + a10);
		if ((cast (a10) : Bool)) {
			var v38:Int = (Std.parseInt(Std.string(a9)) ?? 0);
			switch (v38) {
				case 0: {
					final v39:(String, String) -> Int = function(p40:String, p41:String):Int {
						H.tick();
						H.out("o42 " + p40);
						H.out("o43 " + Std.string((K7.K7C : Int)));
						return v38;
					};
				};
				case 3 | 5: {
					var v44 = a9;
					var v45:Array<S5> = ([] : Array<S5>);
				};
				case _: {
					H.out("o46 " + v37);
				};
			}
			try {
				H.out("o47 " + v37);
				var v48:Array<String> = (v37).split("a");
				v37 = H.cap("-7");
				if (a10) throw new Err(Lambda.fold(([] : Array<Int>), (v49:Int, v50:Int) -> ("\x41\x42").lastIndexOf("a\rb"), 0));
			} catch (ex51:Dynamic) {
				H.out("caught " + H.exn(ex51));
				var v52 = 287;
				v38 = H.id(v38);
			}
		}
		var v53:String = StringTools.hex((a9) & 0xFFFF, 4);
		try {
			v37 = H.cap(v37 + v53);
			try {
				if (true) throw 43;
				H.out("o54 " + Std.string(true));
				H.out("o55 " + Std.string(a9));
			} catch (ex56:Err) {
				H.out("caught Err " + ex56.errCode);
				H.out("o57 " + "abc");
			} catch (ex58:haxe.Exception) {
				H.out("caught " + H.exn(ex58));
				var v59:Array<E0> = ([] : Array<E0>);
				final v60:() -> Void = function():Void {
					H.tick();
					var v61 = a9;
					v61 = a9;
					a9 = v61;
				};
			}
			if (a10) throw "boom";
		} catch (ex62:Dynamic) {
			H.out("caught " + H.exn(ex62));
			var v63 = a9;
			var v64 = v37;
		}
	}
	public static inline function fn11(...r12:Int):Bool {
		H.tick();
		H.out("o65 " + ("\x41\x42").toUpperCase());
		final v66 = "x,y,z";
		Main.fn8((Reflect.compare(v66, v66) * 276), (switch (H.id(r12.toArray())) {
			case []: (E2.E2A).match(E2B(_, _));
			case [c67]: false;
			case [_, c68]: (E2.E2A).match(E2A);
			case _: ([4, 1550388301, 95]).contains(59);
		}));
		var v69:Array<String> = (cast ([v66, v66, v66]) : Array<String>);
		var v70:Array<S5> = ([({x6: v66} : S5), ({x6: v66} : S5), ({x6: v66} : S5)] : Array<S5>);
		var v71:Int = (-("ünï").lastIndexOf("Haxe"));
		return (StringTools.lpad("hello world", "*", (v71 & 7)) != Std.string(false));
	}
	public static function fn13(a14:Int):Void {
		H.tick();
		if (("Haxe" == ("a").charAt(-1))) {
			Main.fn11(163);
		} else {
			var v72:Bool = false;
		}
		final v73:String = "hello world";
		if ((191 <= a14)) {
			H.out("o74 " + Std.string([a14, a14]));
			var v75:Int = (Std.parseInt(Std.string(169)) ?? 0);
		}
		switch (E0.E0A) {
			case E0A: {
				{ var dyn76:Dynamic = ({x6: v73} : S5); H.out("dyn " + Std.string(dyn76.x6) + " " + Std.string(Reflect.field(dyn76, "x6"))); }
			};
		}
		var v77:Array<Int> = [for (i78 in [a14, a14]) if (false) 325152994];
		try {
			if (((E0.E0A).match(E0A) && (E1.E1A).match(E1A))) throw new Err(H.id(a14));
			H.out("o79 " + Std.string(({x6: "  pad  "} : S5)));
			H.out("o80 " + Std.string(new Box(291)));
			var v81:Int = 92;
		} catch (ex82:Err) {
			H.out("caught Err " + ex82.errCode);
			if (StringTools.startsWith(v73, v73)) {
				H.out("o83 " + Std.string(new Box(v73)));
				var v84:E2 = E2.E2A;
			}
		} catch (ex85:haxe.Exception) {
			H.out("caught " + H.exn(ex85));
			{
				var v86:S5 = ({x6: v73} : S5);
				a14 -= a14;
				var v87 = a14;
			}
			var v88 = ([v73]).length;
		}
		a14 -= a14;
	}
	public static inline function fn15(a16:Int, a17:Int, a18:Int):Void {
		H.tick();
		var v89:Int = (a18 - a16);
		H.out("o90 " + Std.string(E2.E2A));
		var v91:Int = ((K7.K7B : Int) - (K7.K7C : Int));
		v89 -= v91;
		fn8(172, (E1.E1A).match(E1A));
		a17 = (-a18);
		var v92 = (0xDFF4 > a17);
		final v93:Int = (2047188062 % H.nz(59));
	}
	public static function fn19(a20:Int):Int {
		H.tick();
		var v94:Array<Int> = ((true ? [a20, a20] : [0xFBCF, a20, a20]) : Array<Int>);
		H.out("o95 " + (("ab").replace("a", "b") + (a20 += 3)));
		fn8(a20, (switch (K7.K7B) {
			case K7.K7A: (E2.E2B(480615096, a20)).match(E2B(_, _));
			case K7.K7B: true;
			case K7.K7C: false;
			case K7.K7D: true;
		}));
		return (("x,y,z").charCodeAt((true ? a20 : ("  pad  ").lastIndexOf(""))) ?? -1);
	}
	public static function fn21(a22:Int):Array<String> {
		H.tick();
		var v96 = "\t";
		var v97:Array<Int> = ([a22]).filter(v98 -> true);
		a22 = (([] : Array<Int>)).ext28(a22);
		return [(false ? "0" : v96), '<${Std.string((K7.K7C : Int))}-${Std.string(Type.enumIndex(E1.E1A))}'];
	}
	public static function fn23(a24:E2):Void {
		H.tick();
		var v99:Int = (-153);
		switch (H.id([220, Type.enumIndex(E0A)])) {
			case []: {
				if (true) {
					var v100:Bool = false;
					fn15(253, 141, 42);
				}
			};
			case [c101]: {
				H.out("o102 " + Std.string(E1.E1A));
				var v103 = Reflect.compare(v99, v99);
			};
			case [_, c104]: {
				{
					v99 += c104;
				}
			};
			case _: {
				switch (E0.E0A) {
					case E0A: {
						var v105:K7 = K7.K7D;
					};
				}
			};
		}
		var v106 = ([v99, 14, v99]).length;
		var v107:Int = (v99--);
		{ var dyn108:Dynamic = ({x6: "A-B-C"} : S5); H.out("dyn " + Std.string(dyn108.x6) + " " + Std.string(Reflect.field(dyn108, "x6"))); }
		a24 = H.id(a24);
		v106 = 21;
		try {
			if ((a24).match(E2B(_, _))) throw (Std.string(false) + "Haxe");
			H.out("o109 " + Std.string([v107, v99]));
			H.out("o110 " + Std.string(0xCDFA));
			{ var dyn111:Dynamic = ({x6: "\"q\""} : S5); H.out("dyn " + Std.string(dyn111.x6) + " " + Std.string(Reflect.field(dyn111, "x6"))); }
		} catch (ex112:String) {
			H.out("caught String " + ex112);
			H.out("o113 " + ex112);
		} catch (ex114:Int) {
			H.out("caught Int " + ex114);
			var v115:Null<Int> = null;
		} catch (ex116:Err) {
			H.out("caught Err " + ex116.errCode);
			var v117 = StringTools.contains("  pad  ", "\n");
			v106 *= (K7.K7B : Int);
		} catch (ex118:Dynamic) {
			H.out("caught " + H.exn(ex118));
			Main.fn13(v106);
		}
		H.out("o119 " + "  pad  ");
	}
	public static function fn25():Bool {
		H.tick();
		try {
			var v120:Array<String> = ["Haxe", "a", "x,y,z"];
			var v121 = "42";
			if (((E2.E2A).match(E2A) ? StringTools.contains(v121, "ünï") : StringTools.endsWith(v121, v121))) throw "boom";
		} catch (ex122:Err) {
			H.out("caught Err " + ex122.errCode);
			fn15((Std.parseInt(Std.string(1482846073)) ?? 0), 273, 262);
			switch (K7.K7A) {
				case K7.K7A: {
					(([] : Array<Int>)).ext28(7);
				};
				case K7.K7B: {
					H.out("o123 " + Std.string(new Box(72)));
				};
				case K7.K7C: {
					var v124:Array<Int> = ([] : Array<Int>);
					var v125:Bool = true;
				};
				case K7.K7D: {
					var v126:K7 = K7.K7B;
				};
				case _: {
					H.out("o127 " + Std.string(({x6: "\n"} : S5)));
					H.out("o128 " + Std.string(65535));
				};
			}
		} catch (ex129:haxe.Exception) {
			H.out("caught " + H.exn(ex129));
			final v130:Int = ("\\").indexOf("A-B-C");
			{
				var v131:Bool = true;
				var v132:Array<String> = ["0", "hello world", "  pad  "];
				H.out("o133 " + "q");
			}
		}
		final v134:Array<String> = (StringTools.trim("a")).split(",");
		switch (0x1975) {
			case 0: {
				if (true) {
					Main.fn21(267);
					H.out("o135 " + Std.string(153));
					H.out("o136 " + Std.string(true));
				} else {
					H.out("o137 " + "\x41\x42");
				}
				if (false) {
					var v138:Array<Bool> = [false, false, true];
					var v139:String = "abc";
				} else {
					var v140:Array<String> = v134;
					var v141 = 32;
				}
			};
			case 3 | 5: {
				if ((E1.E1A).match(E1A)) {
					H.out("o142 " + Std.string(172));
				} else {
					var v143:String = "\u{1F600}";
					H.out("o144 " + Std.string(true));
				}
			};
			case _: {
				var v145:E1 = E1.E1A;
			};
		}
		final v146 = H.apply(51, (v147:Int) -> v147);
		if (H.id(true)) {
			try {
				final v148:Null<Int> = v146;
				if (false) throw 79;
			} catch (ex149:String) {
				H.out("caught String " + ex149);
				var v150 = v146;
				var v151 = ex149;
			} catch (ex152:Int) {
				H.out("caught Int " + ex152);
				var v153:K7 = K7.K7C;
			} catch (ex154:Err) {
				H.out("caught Err " + ex154.errCode);
				H.out("o155 " + Std.string(({x6: "日本語"} : S5)));
			} catch (ex156:Dynamic) {
				H.out("caught " + H.exn(ex156));
				var v157:Box<Array<S5>> = new Box<Array<S5>>(([({x6: "a\rb"} : S5)] : Array<S5>));
				fn15(v146, v146, v146);
			}
			fn13((Std.parseInt("0") ?? 0));
			Main.fn13((Std.parseInt("\x41\x42") ?? 0));
		} else {
			var v158 = true;
		}
		H.out("o159 " + Std.string((([E1.E1A, E1.E1A, E1.E1A] : Array<E1>)).concat(([E1.E1A, E1.E1A, E1.E1A] : Array<E1>))));
		var v160:Int = fn19(v146);
		var v161:Int = ((Std.parseInt(Std.string(v160)) ?? 0) - v160);
		var v162:String = (switch (E2.E2A) {
			case E2A: ("q").toUpperCase();
			case E2B(c163, c164): ("\\").substring(3, (v161 & 7));
		});
		return ((237 == Reflect.compare(0xDA10, v160)) || (true ? true : false));
	}
	public static function section0():Void {
		H.tick();
		var v168:Bool = fn11();
		var v169 = Type.enumIndex(E0.E0A);
		H.out("o170 " + Std.string(v169));
		final v171:Int = v169;
	}
	public static function section1():Void {
		H.tick();
		if ((switch (K7.K7B) {
			case K7.K7A: true;
			case K7.K7B: false;
			case K7.K7C: false;
			case K7.K7D: false;
			case _: false;
		})) {
			var v172 = 65535;
		} else {
			H.out("o173 " + Std.string(([(-9), 278] : Array<Null<Int>>)));
			try {
				if (false) throw 27;
				var v174:Bool = false;
				var v175 = v174;
				var v176:E0 = E0A;
			} catch (ex177:Err) {
				H.out("caught Err " + ex177.errCode);
				var v178:Box<Bool> = new Box(false);
				final v179 = (-2147483647);
			} catch (ex180:haxe.Exception) {
				H.out("caught " + H.exn(ex180));
				var v181:E2 = E2.E2B((-1499221398), 65535);
			}
		}
		fn25();
		fn11((if (StringTools.startsWith("\n", "A-B-C")) ("-7").length else ("").lastIndexOf("\t")), (cast (254) : Int));
		var v182 = 0xFFFFFFFF;
	}
	public static function section2():Void {
		H.tick();
		H.out("o183 " + Std.string(({x6: "hello world"} : S5)));
		fn13((false ? 81 : (-716917521)));
		final v184:Array<E2> = ([] : Array<E2>);
		var v185:E0 = E0A;
		var v186:S5 = (((E1.E1A).match(E1A) ? ({x6: "é"} : S5) : ({x6: "ünï"} : S5)) : S5);
		H.out("o187 " + Std.string([6, 144, 133]));
		switch (E0A) {
			case E0A: {
				switch (119) {
					case 0: {
						var v188:K7 = K7.K7D;
					};
					case 2 | 6: {
						var v189:String = "\\";
						H.out("o190 " + Std.string((K7.K7B : Int)));
					};
					case _: {
						final v191 = "\"q\"";
						var v192 = 0xFFFFFFFF;
					};
				}
				if (StringTools.contains("q", "\x41\x42")) {
					H.out("o193 " + Std.string(new Box(10)));
					var v194:Array<Bool> = ([] : Array<Bool>);
				} else {
					var v195:E1 = E1.E1A;
				}
			};
		}
		H.out("o196 " + Std.string(v185));
		var v197:Array<Int> = ([] : Array<Int>);
	}
	public static function section3():Void {
		H.tick();
		var v198:Array<String> = [String.fromCharCode(65 + ((155) & 15))];
		var v199 = 251;
		v199 = 260;
		{
			switch (({x6: "A-B-C"} : S5)) {
				case {x6: c200}: {
					H.out("o201 " + c200);
					var v202:Array<Int> = [23];
				};
			}
			if (false) {
				var v203 = v199;
				fn13(v203);
				H.out("o204 " + Std.string(true));
			} else {
				H.out("o205 " + Std.string(({x6: "0"} : S5)));
			}
		}
		if ((E2.E2B(v199, v199)).match(E2B(_, _))) {
			v199 *= (Std.parseInt(Std.string(v199)) ?? 0);
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
