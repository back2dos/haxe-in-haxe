package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

enum E1 {
	E1A;
}

enum E2 {
	E2A;
	E2B(a3:Int, a4:Int);
}

typedef S5 = {x6:String};

enum abstract K7(Int) to Int {
	var K7A = 1;
	var K7B = 4;
	var K7C = 7;
	var K7D = 10;
}
