package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext28(a26:Array<Int>, a27:Int):Int {
		H.tick();
		H.out("o165 " + Std.string(0x3F18));
		var v166 = 0xE45B;
		Main.fn8(H.id(v166), false);
		a27 *= (v166 += 3);
		H.out("o167 " + Std.string((true && true)));
		return (-(v166 * v166));
	}
}
