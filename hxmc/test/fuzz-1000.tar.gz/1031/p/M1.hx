package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

typedef S15 = {x16:Int, x17:Float, x18:Int};

class C28 {
	public var cb29:(Int) -> Int;
	public function new(a30:Int) {
		this.cb29 = function(p120:Int):Int {
			H.tick();
			H.out("o121 " + Std.string(p120));
			return 187;
		};
	}
	public function m31():String {
		H.tick();
		var v122 = Reflect.compare(214, Lambda.fold([118], (v123:Int, v124:Int) -> Math.round(1e-7), 0));
		if ((new C44()).m26()) return String.fromCharCode(65 + ((272) & 15));
		var v125 = ({ var v126 = StringTools.replace("\n", " ", "  pad  "); v122; });
		return ((Std.string(v125) + (v122 = 5))).substring(((v125 << ((([] : Array<Int>)).indexOf((-2147483647)) & 31)) & 7), 0);
	}
	public static function m32():Array<Int> {
		H.tick();
		final v127:Bool = !([106, 31977096]).contains(161);
		var v128:Int = ((([] : Array<Bool>)).indexOf(v127) % H.nz((Std.parseInt(Std.string(231)) ?? 0)));
		v128 = 1716343897;
		(new C44()).m27();
		H.out("o129 " + Std.string(((StringTools.endsWith("日本語", "a") ? new C34() : new C34()) : C28)));
		if ((Reflect.compare("", "abc") == (("a").charCodeAt(v128) ?? -1))) {
			for (x130 in ([v128, v128, v128] : Array<Float>)) {
				H.tick();
				(new C44()).m27();
				var v131:Box<(Bool) -> String> = new Box<(Bool) -> String>((p132:Bool) -> "a\rb");
			}
		}
		C44.f46 &= v128;
		return [for (i133 in 0...1) (cast (i133) : Int)];
	}
	public function m33():S15 {
		H.tick();
		C44.f46 = Type.enumIndex(E0.E0A);
		(new C44()).m27();
		var w134 = 0;
do {
			w134++;
			H.tick();
			for (i135 in 0...4) {
				H.tick();
				(new C44()).m27();
				C44.f46 = i135;
				H.out("o136 " + Std.string(({x12: i135, x13: "\x41\x42", x14: "a"} : S11)));
			}
			(new C19()).m23();
			if (StringTools.contains("ünï", "ünï")) return ({x16: 186, x17: (-2.5), x18: 170} : S15);
		} while (w134 < 3 && (Std.downcast((new C34() : C28), C28) != null));
		var v137:Array<String> = ([] : Array<String>);
		var v138:Box<String> = new Box(("-7").substr((244 & 7), 2));
		return ({x16: H.apply(57, (v139:Int) -> v139), x17: Math.max(1.25, 200), x18: 214} : S15);
	}
}
