package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

class C19 {
	public static var f20:Float = 1.25;
	public var f21:Int;
	public var f22:Array<Float>;
	public function new() {
		this.f21 = ("x,y,z").indexOf("\"q\"");
		this.f22 = ([] : Array<Float>);
	}
	public function m23():Void {
		H.tick();
		if (!true) {
			var v80:Int = 192;
			final v81:Null<Int> = null;
			H.out("o82 " + Std.string(new C44()));
		}
		H.out("o83 " + Std.string(this.f21));
		var w84 = 0;
while (w84 < 2 && (Std.isOfType(new C37(), C19) ? true : true)) {
			w84++;
			H.tick();
			var v85:Array<Int> = [0xBDB0, 103, 264];
			var v86:Int = (("ab").charCodeAt(226) ?? -1);
		}
		if (Std.isOfType(new C44(), C19)) {
			H.out("o87 " + Std.string(((new Map<String, Int>()).get("k0") ?? 0)));
			H.out("o88 " + Std.string(StringTools.contains("ünï", "\"q\"")));
		} else {
			final v89:Float = Math.sin(3.0);
			H.out("o90 " + Std.string(new C44()));
		}
		for (k92 => x91 in [StringTools.replace("a", "b", "\\")]) {
			H.tick();
			this.f21 |= 179;
		}
	}
	public static function m24(?a25:Null<Bool>):String {
		H.tick();
		final v93:Int = Main.fn64(false, "日本語", 151);
		C44.f46 -= (("ab").charCodeAt(1966969728) ?? -1);
		var v94:Int = v93;
		var w95 = 0;
while (w95 < 3 && !((["k0" => v94] : Map<String, Null<Int>>)).exists("k3")) {
			w95++;
			H.tick();
			H.out("o96 " + Std.string(([] : Array<Float>)));
			for (x97 in [v94]) {
				H.tick();
				H.out("o98 " + Std.string(new Box(v93)));
			}
		}
		final v99:Array<String> = [for (i100 in ["\t", "", ""]) if ((([] : Array<Int>)).contains(0x497E)) i100];
		C44.f46 = v93;
		if (true) {
			C44.f46 -= Math.floor(v93);
			if (([v93]).contains(v93)) {
				final v101:Box<Array<Int>> = new Box<Array<Int>>([v94, v94]);
			}
			var v102:Int = v93;
		} else {
			v94 &= 268;
			var v103 = Math.round(v94);
		}
		var v104:Bool = (Std.string(E0.E0B(v94, 0.30000000000000004)) >= "-7");
		return "";
	}
	public function m26():Bool {
		H.tick();
		var v105:E0 = E0.E0B(207, 0.1);
		final lf106:(Bool, String) -> Int = function(p107:Bool, p108:String):Int {
			H.tick();
			v105 = H.id(v105);
			H.out("o109 " + Std.string(new C37()));
			return (C44.f46 + this.f21);
		};
		var v110:Box<Bool> = new Box<Bool>(true);
		H.out("o111 " + Std.string(new C44()));
		H.out("o112 " + Std.string(28));
		return (7.0 > Main.fn64(Std.isOfType(null, C55), String.fromCharCode(65 + (((-1859091306)) & 15)), (("ünï").charCodeAt(0xA8A1) ?? -1)));
	}
	public function m27():String {
		H.tick();
		var v113:Int = 274;
		H.out("o114 " + Std.string((160 << (Math.ceil(v113) & 31))));
		for (i115 in 0...0) {
			H.tick();
			var v116 = i115;
		}
		var w117 = 0;
while (w117 < 1 && (StringTools.endsWith("\u{1F600}", "x,y,z") || true)) {
			w117++;
			H.tick();
			this.m23();
			var v118 = (Std.parseInt(Std.string(v113)) ?? 0);
		}
		this.m23();
		{
			var v119:Null<Int> = v113;
		}
		return '-${Std.string((Std.isOfType(new C19(), C44) ? (Std.parseInt(Std.string(v113)) ?? 0) : (({x14: "\n", x12: v113, x13: "Haxe"} : S11)).x12))} = ${Std.string(v113)}-${(true + "ünï")}';
	}
}

class C37 extends C19 {
	public var cb38:(Int) -> Int;
	public function new() {
		super();
		this.cb38 = (p169:Int) -> p169;
	}
	override public function m27():String {
		H.tick();
		H.out("o170 " + StringTools.trim(("q").charAt(5)));
		var v171:String = StringTools.trim("\"q\"");
		this.m23();
		var v172:Int = H.at([0x80000000, 15, 109], 0x80000000, 0);
		v172 -= (-(v172 -= 1));
		m23();
		H.out("o173 " + Std.string((((new Map<String, Int>()).get(v171) ?? 0) >> (Math.floor(v172) & 31))));
		return v171;
	}
	public function m39():Void {
		H.tick();
		H.out("o174 " + (Std.string(49)).charAt((("Haxe").length & 7)));
		{
			this.f21 &= 42;
		}
		var v175 = Math.round(3.0);
		var v176 = v175;
		var v177:Null<Int> = Main.fn64(false, "ab", this.f21);
		final v178 = "\t";
		H.out("o179 " + Std.string(((false ? ([] : Array<E0>) : ([] : Array<E0>)) : Array<E0>)));
		(new C28(v175)).m31();
	}
	public function m40():Int {
		H.tick();
		if ((0.5 >= 3.0)) {
			H.out("o180 " + Std.string(252));
			var v181 = false;
		}
		C44.f46 = H.at([(-333861181), 0x80000000], 1344776523, 0);
		H.out("o182 " + Std.string(new C28(272)));
		return 46;
	}
	public function m41(a42:Int, a43:String):Int {
		H.tick();
		var v183 = (([a42, 0x8167, 0x7FFFFFFF]).contains(a42) && false);
		C44.f46 = (a42 = 5);
		var v184:Box<Int> = new Box(H.at([a42, 203], a42, 0));
		if (v183) {
			var v185 = C44.f46;
			(new C34()).m31();
		} else {
			var v186:Array<Bool> = [v183, v183];
			a42 &= a42;
		}
		return this.f21;
	}
}

abstract class C55 {
	public final f56:E5;
	public final f57:Array<Int>;
	public var cb58:(Int) -> Int;
	public function new(a59:Float) {
		this.f56 = E5.E5A;
		this.f57 = [289, 113];
		this.cb58 = function(p263:Int):Int {
			H.tick();
			var v264:Map<String, String> = (["k0" => "\n", "k1" => "\x41\x42", "k2" => "q"] : Map<String, String>);
			H.out("o265 " + Std.string(p263));
			return p263;
		};
	}
	public static function m60():(Int, String) -> Bool {
		H.tick();
		var v266:Map<Int, String> = new Map<Int, String>();
		var v267:Array<Int> = C28.m32();
		H.out("o268 " + Std.string(({x16: Lambda.count(v267, v269 -> false), x17: C44.f46, x18: ("abc").lastIndexOf("\x41\x42")} : S15)));
		var v270:Float = 7.0;
		var v271:C44 = new C44();
		(new C37()).m26();
		H.out("o272 " + Std.string((cast (new C44()) : C44)));
		for (k273 => v274 in ((Math.isNaN(v270) ? new Map<String, Int>() : new Map<String, Int>()) : Map<String, Int>)) {
			H.tick();
			if (([127, v274, v274]).contains(v274)) continue;
		}
		H.out("o275 " + Std.string([200, ("q").lastIndexOf("a"), Type.enumIndex(E0.E0A)]));
		return (p276:Int, p277:String) -> (([false, false, true]).join("|") >= "\n");
	}
}
