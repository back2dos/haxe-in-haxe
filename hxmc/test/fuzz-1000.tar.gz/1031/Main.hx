import H;
import p.M1;
import p.q.M2;

enum E0 {
	E0A;
	E0B(a3:Int, a4:Float);
}

enum E5 {
	E5A;
	E5B(a8:Bool);
	E5C(a9:Bool);
	E5D(a10:Int);
}

typedef S11 = {x12:Int, x13:String, x14:String};

class C34 extends C28 {
	public var f35:String;
	public function new() {
		super((Std.parseInt(Std.string(257)) ?? 0));
		this.f35 = (("a\rb").split(" ")).join(",");
	}
	override public function m31():String {
		H.tick();
		var v140:Array<Map<String, S11>> = (([new Map<String, S11>(), (["k0" => ({x12: 187, x13: "42", x14: "é"} : S11)] : Map<String, S11>), (["k0" => ({x13: "\x41\x42", x14: "abc", x12: 122} : S11)] : Map<String, S11>)] : Array<Map<String, S11>>)).copy();
		for (i141 in 0...3) {
			H.tick();
			for (k143 => x142 in ([] : Array<String>)) {
				H.tick();
				C44.f46 = (-1919187887);
			}
		}
		var v144 = Reflect.compare("0", "日本語");
		H.out("o145 " + Std.string((~v144)));
		var v146:Float = Math.sqrt(Math.abs(2.5e-3));
		v144 |= (("42").lastIndexOf("-7") ^ (({x14: "x,y,z", x13: "0", x12: v144} : S11)).x12);
		return '${Std.string(H.apply(false, (v147:Bool) -> true))}${(cast (this.f35) : String)}';
	}
	override public function m33():S15 {
		H.tick();
		if (true) {
			(new C44()).m23();
			for (i148 in 0...0) {
				H.tick();
				final v149 = i148;
			}
			C44.f46 ^= 298;
		} else {
			final v150:String = StringTools.lpad("a\rb", "*", (0x9748 & 7));
		}
		H.out("o151 " + StringTools.hex(((-1605488376)) & 0xFFFF, 4));
		if ((([(-8), 287560264, 298]).contains(52) ? true : true)) {
			var v152:E5 = E5D(0x4B37);
		}
		var v153 = String.fromCharCode(65 + ((1920703651) & 15));
		var w154 = 0;
while (w154 < 2 && false) {
			w154++;
			H.tick();
			if (StringTools.startsWith(v153, "\u{1F600}")) {
				var v155 = false;
			} else {
				var v156:Int = 37;
			}
			H.out("o157 " + Std.string(0xD0B8));
		}
		for (i158 in 0...4) {
			H.tick();
			H.out("o159 " + Std.string(C44.f46));
			var v160:C37 = new C44();
		}
		return ({x16: ({ var v161 = ("-7").indexOf(v153); C44.f46; }), x17: ([(-2147483647), 126]).length, x18: (if (true) (Std.parseInt("zz") ?? 0) else Math.floor(2.5e-3))} : S15);
	}
	public function m36():E5 {
		H.tick();
		if ((new C19()).m26()) return E5.E5A;
		H.out("o162 " + this.f35);
		for (i163 in 0...3) {
			H.tick();
			{
				C44.f46 = i163;
				if (true) break;
				(new C44()).m48(i163, 102);
			}
		}
		final v164:(String) -> Bool = (p165:String) -> true;
		var v166:Map<String, E5> = (["k0" => E5C(true)] : Map<String, E5>);
		C44.f46 *= (7 & (-3));
		var v167:Array<String> = (StringTools.hex((0x7FFFFFFF) & 0xFFFF, 4)).split("a");
		{ var dyn168:Dynamic = (new C28(276)).m33(); H.out("dyn " + Std.string(dyn168.x16) + " " + Std.string(Reflect.field(dyn168, "x16"))); }
		return E5.E5A;
	}
}

class C44 extends C37 {
	public var f45:String;
	public static var f46:Int = 236;
	public var cb47:(Int) -> Int;
	public function new() {
		super();
		this.f45 = "0";
		this.cb47 = (p187:Int) -> p187;
	}
	override public function m23():Void {
		H.tick();
		var v188:Array<Int> = [("\\").length, (("\t").charCodeAt((-2115222647)) ?? -1), Reflect.compare("abc", "0")];
		for (k189 => v190 in new Map<String, Int>()) {
			H.tick();
			if ((Std.downcast((new C19() : C19), C44) != null)) break;
			final v191 = v190;
			final v192:Box<Array<String>> = new Box<Array<String>>([k189, k189]);
		}
		v188.sort((x, y) -> x - y);
	}
	override public function m27():String {
		H.tick();
		if ((cast (([(-1912995002), 65535]).contains(104)) : Bool)) {
			H.out("o193 " + "0");
			for (i194 in 0...3) {
				H.tick();
				var v195 = 3;
				var v196:S15 = ({x16: 0x2F92, x17: v195, x18: (-2147483647)} : S15);
				final v197:Bool = true;
			}
			final v198:Map<Int, String> = ([-3 => "ab"] : Map<Int, String>);
		} else {
			this.f45 = H.cap(Std.string(E5C(true)));
		}
		var v199:String = "A-B-C";
		final lf200:(String, Float) -> String = (p201:String, p202:Float) -> (cast (p201) : String);
		return ((this.f45).toUpperCase() + this.f45);
	}
	override public function m39():Void {
		H.tick();
		if (false) {
			var v203:Float = 1e-7;
			H.out("o204 " + Std.string(new C34()));
		}
		H.out("o205 " + Std.string(Main.fn64(StringTools.endsWith("日本語", "\"q\""), ("zz").charAt(1), C44.f46)));
		var v206 = !false;
		if (Std.isOfType(new C44(), C19)) {
			H.out("o207 " + Std.string((({x16: (-848393579), x17: 1e21, x18: 110} : S15)).x18));
			(new C28(0xD5C1)).m33();
			{
				var v208:Array<String> = ["\t", "0", "q"];
				var v209:S11 = ({x13: "  pad  ", x14: "", x12: 206} : S11);
				this.f21 = 267;
			}
		}
		H.out("o210 " + Std.string(((-12) >>> (Math.floor(1.7976931348623157e308) & 31))));
	}
	override public function m41(a42:Int, a43:String):Int {
		H.tick();
		H.out("o211 " + StringTools.hex(((++a42)) & 0xFFFF, 4));
		var v212 = a43;
		a42 = H.id(a42);
		var w213 = 0;
while (w213 < 3 && this.m26()) {
			w213++;
			H.tick();
			var v214:Array<Int> = [0x80000000, a42];
		}
		(new C44()).m27();
		final v215:Bool = (Std.downcast((new C37() : C37), C44) != null);
		final v216:Map<String, String> = new Map<String, String>();
		return ({ var v217 = a42; v217; });
	}
	public function m48(a49:Float, ...r50:Int):E0 {
		H.tick();
		var v218:Float = ((-2.5) / 36);
		var v219:Map<String, Int> = (["k0" => 180, "k1" => 196, "k2" => 83] : Map<String, Int>);
		H.out("o220 " + Std.string((r50.toArray()).filter(v221 -> true)));
		var v222:S11 = ({x12: ("q").length, x13: this.f45, x14: "hello world"} : S11);
		var v223 = true;
		H.out("o224 " + Std.string(Lambda.count(r50.toArray(), v225 -> true)));
		if ((false && Math.isNaN(v218))) return E0.E0A;
		return (cast (({ var v226 = ([v223, true, true]).indexOf(true); E0B(v226, 3.0); })) : E0);
	}
	public function m51(a52:Int = 9):Void {
		H.tick();
		H.out("o227 " + Std.string(new C34()));
		for (x228 in [this.f45, "\x41\x42"]) {
			H.tick();
			var w229 = 0;
while (w229 < 4 && Std.isOfType(new C37(), C19)) {
				w229++;
				H.tick();
				H.out("o230 " + Std.string(([] : Array<E5>)));
			}
			if (true) {
				var v231:Box<Int> = new Box(a52);
			} else {
				C44.f46 ^= a52;
				var v232 = 23;
			}
		}
		if (true) {
			for (x233 in [0x2AF1, a52]) {
				H.tick();
				final v234 = x233;
				H.out("o235 " + "hello world");
				final v236:Int = 3;
			}
			H.out("o237 " + Std.string(Math.floor(1.7976931348623157e308)));
		} else {
			this.f45 = H.cap(this.f45);
		}
		m27();
		var w238 = 0;
while (w238 < 2 && true) {
			w238++;
			H.tick();
			var w239 = 0;
do {
				w239++;
				H.tick();
				var v240:Array<String> = ["\x41\x42", "\x41\x42"];
				var v241:Map<Int, Int> = new Map<Int, Int>();
				var v242:Float = a52;
			} while (w239 < 4 && StringTools.contains("-7", "\u{1F600}"));
		}
	}
	public function m53(a54:Int):(Int, String) -> Bool {
		H.tick();
		{
			if (true) {
				this.f22 = H.capa(this.f22);
				var v243:Box<String> = new Box("\"q\"");
			}
			var v244 = a54;
			if (true) return function(p245:Int, p246:String):Bool {
				H.tick();
				H.out("o247 " + Std.string(p245));
				var v248:Map<String, Float> = (["k0" => v244] : Map<String, Float>);
				H.out("o249 " + Std.string(a54));
				return false;
			};
		}
		var v250:Map<String, Array<String>> = (cast (new Map<String, Array<String>>()) : Map<String, Array<String>>);
		if (("42" == (["\u{1F600}", "Haxe", "ab"]).join(","))) {
			var v251:Int = Math.round(a54);
		} else {
			H.out("o252 " + Std.string(a54));
		}
		for (x253 in [a54]) {
			H.tick();
			H.out("o254 " + Std.string(new C37()));
			var v255:E5 = E5A;
		}
		var w256 = 0;
while (w256 < 1 && H.id(Math.isNaN(a54))) {
			w256++;
			H.tick();
			H.out("o257 " + Std.string(a54));
		}
		var v258:Null<Int> = C44.f46;
		return ({ var v259 = "ab"; function(p260:Int, p261:String):Bool {
			H.tick();
			var v262 = p260;
			v262 += a54;
			return Std.isOfType(new C44(), C44);
		}; });
	}
}

class Main {
	public static function fn61(a62:Int, a63:Int):String {
		H.tick();
		final v278:(Float) -> String = function(p279:Float):String {
			H.tick();
			var v280:Array<String> = ["\n", "42", "-7"];
			var v281:Int = 30;
			var v282:Array<Int> = [162, a63];
			return StringTools.trim("ünï");
		};
		C44.f46 *= (("a").indexOf("a\rb") >>> (148 & 31));
		var v283 = (12 - a63);
		var v284:Int = Lambda.count([a62, v283], v285 -> false);
		var v286:S11 = ({x12: 0x60C3, x14: "\n", x13: "é"} : S11);
		{ var dyn287:Dynamic = ((false ? ({x17: a62, x16: v284, x18: 128} : S15) : ({x18: a62, x16: a62, x17: a62} : S15)) : S15); H.out("dyn " + Std.string(dyn287.x16) + " " + Std.string(Reflect.field(dyn287, "x16"))); }
		for (i288 in 0...2) {
			H.tick();
			H.out("o289 " + Std.string(v283));
		}
		(new C44()).m51();
		final v290:(String) -> String = (new Box<(String) -> String>((p291:String) -> "")).get();
		return (((Std.isOfType(new C44(), C37) ? [false, false, false] : ([] : Array<Bool>)) : Array<Bool>)).join(",");
	}
	public static inline function fn64(a65:Bool, a66:String, a67:Int):Int {
		H.tick();
		final v292 = a65;
		var v293 = C44.f46;
		if (a65) {
			for (x294 in ([] : Array<String>)) {
				H.tick();
				(new C44()).m48(100.75, a67);
				H.out("o295 " + Std.string(new C44()));
				(new C19()).m23();
			}
		} else {
			var v296:C44 = new C44();
		}
		var v297:Bool = v292;
		Main.fn61(a67, (-456016480));
		return (C44.f46 >> ((((a66).charCodeAt(v293) ?? -1) & 159) & 31));
	}
	public static function fn68(a69:Int, a70:Array<Bool>):String {
		H.tick();
		for (x298 in ([a69]).map((v299:Int) -> ("hello world").substring(2, 6))) {
			H.tick();
			(new C44()).m27();
			(new C44()).m27();
			if (true) {
				var v300:Array<String> = [x298];
				H.out("o301 " + Std.string(new C44()));
			}
		}
		final v302:(String) -> String = function(p303:String):String {
			H.tick();
			H.out("o304 " + Std.string(true));
			a69++;
			var v305 = true;
			return p303;
		};
		if (([a69]).contains(a69)) {
			for (i306 in 0...H.lim(Lambda.count([a69], v307 -> false))) {
				H.tick();
				var v308 = a69;
				H.out("o309 " + Std.string(({x16: v308, x17: a69, x18: i306} : S15)));
				var v310:C19 = new C19();
			}
			H.out("o311 " + "hello world");
			a69 = 284;
		}
		fn64((new C37()).m26(), ("a\rb").substring(-1, 6), ([203]).length);
		var v312 = (Std.isOfType(new C34(), C34) || false);
		return (H.apply(a69, (v313:Int) -> new C34())).m31();
	}
	public static function fn71(a72:String, a73:E0):Float {
		H.tick();
		var v314:Array<Int> = [53];
		for (x315 in [Std.string(true), a72]) {
			H.tick();
			H.out("o316 " + StringTools.replace(a72, "b", "-7"));
		}
		final lf317:(String, Int) -> String = (p318:String, p319:Int) -> '${Std.string((((["k0" => p319, "k1" => p319, "k2" => p319] : Map<String, Int>)).get(p318) ?? 0))}';
		H.out("o320 " + Std.string(new C34()));
		if ((false && (v314).contains(0x6D25))) {
			var w321 = 0;
while (w321 < 3 && true) {
				w321++;
				H.tick();
				H.out("o322 " + "\"q\"");
			}
			a72 = H.cap(StringTools.lpad(a72, "*", (70 & 7)));
		}
		final v323:Array<Bool> = ([] : Array<Bool>);
		C44.f46 -= (-681541014);
		C44.f46 = (new C37()).m41(74, Std.string(false));
		return (cast (1.25) : Float);
	}
	public static function fn74(a75:Int = 6):Array<Int> {
		H.tick();
		(new C44()).m23();
		H.out("o324 " + Std.string(["A-B-C", Std.string((-16))]));
		function lf325(n326:Int):Int {
			H.tick();
			return n326 <= 0 ? (n326 ^ n326) : (lf325(n326 - 1) + (a75 >> (a75 & 31)));
		}
		H.out("lf325 " + lf325(4));
		if (((-19) > (("a\rb").charCodeAt(a75) ?? -1))) {
			(new C44()).m51(a75);
			C44.f46++;
			var v327:Array<Int> = [a75];
		}
		final v328 = Main.fn64(([a75]).contains(a75), "\u{1F600}", 136);
		return [for (i329 in 0...1) (false ? Math.floor(i329) : 689192600)];
	}
	public static function fn76(a77:Int, a78:Array<String>, a79:String = "d"):Int {
		H.tick();
		{
			H.out("o330 " + Std.string(81));
			var w331 = 0;
while (w331 < 4 && StringTools.contains("A-B-C", a79)) {
				w331++;
				H.tick();
				var v332:Array<String> = a78;
				H.out("o333 " + Std.string(157));
				var v334 = a77;
			}
			if (StringTools.startsWith("  pad  ", a79)) {
				C44.f46 = a77;
				var v335:Array<Int> = [582374920, a77];
				var v336:Int = a77;
			} else {
				H.out("o337 " + "hello world");
			}
		}
		var w338 = 0;
while (w338 < 1 && (Lambda.count([a77, a77, 33], v339 -> true) == (-17))) {
			w338++;
			H.tick();
			fn71((a78).join(","), E0.E0A);
			H.out("o340 " + (a79).toUpperCase());
		}
		(new C44()).m48((64 - a77), (new C37()).m41(293, "\"q\""), (a79).lastIndexOf(StringTools.lpad(a79, "*", (a77 & 7))));
		for (i341 in 1...3) {
			H.tick();
			if (false) {
				var v342:Map<String, Float> = new Map<String, Float>();
			}
		}
		H.out("o343 " + a79);
		return Main.fn64(false, a79, a77);
	}
	public static function section0():Void {
		H.tick();
		H.out("o344 " + Std.string((cast (({x17: 1e100, x16: 0x7FFFFFFF, x18: 22} : S15)) : S15)));
		final v345 = ((-2) & Math.ceil(0.5));
		var w346 = 0;
while (w346 < 2 && false) {
			w346++;
			H.tick();
			++C44.f46;
			var v347:String = Std.string(E0A);
		}
		var v348:Array<Int> = [for (i349 in 0...2) v345];
		H.out("o350 " + Std.string(199));
		H.out("o351 " + Std.string(new C19()));
		(new C44()).m27();
		var v352:S15 = (new C34()).m33();
	}
	public static function section1():Void {
		H.tick();
		H.out("o353 " + Std.string(Main.fn76(("日本語").lastIndexOf("Haxe"), ("  pad  ").split(","), Std.string(false))));
		for (i354 in 2...H.lim(Math.ceil(C19.f20))) {
			H.tick();
			var v355:Map<Int, Bool> = ([-3 => false] : Map<Int, Bool>);
			(new C28(i354)).m31();
			var v356:Int = C44.f46;
		}
		H.out("o357 " + H.id(Std.string(true)));
	}
	public static function section2():Void {
		H.tick();
		for (x358 in [([(-6)]).contains(127), ([169, 207]).contains(146)]) {
			H.tick();
			var v359:String = "zz";
		}
		for (i360 in 0...H.lim(C44.f46)) {
			H.tick();
			var v361:String = ("ab").charAt((0xDCDB & 7));
		}
		if ((("\u{1F600}").lastIndexOf("a\rb") != (-1577894544))) {
			H.out("o362 " + Std.string((-6)));
			H.out("o363 " + Std.string(([235, 290, (-14)]).contains((-39736682))));
			(new C37()).m40();
		}
		H.out("o364 " + Std.string(new C44()));
		var v365:Int = ((([] : Array<Int>)).length << (C44.f46 & 31));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
