import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

abstract A2(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A2, b:A2):A2
		return new A2(a.get() + b.get());

	@:op(A * B) public static function mul(a:A2, b:A2):A2
		return new A2(a.get() * b.get());

	@:op(-A) public static function neg(a:A2):A2
		return new A2(-a.get());
}

class C16 extends C12 {
	public static var f17:Int = 0xFFFFFFFF;
	public var f18:Int;
	public static var f19:Float = 1e-7;
	public var cb20:(Int) -> Int;
	public function new(a21:Int, a22:Int) {
		super([a22, 0xFFFFFFFF]);
		this.f18 = a22;
		this.cb20 = function(p176:Int):Int {
			H.tick();
			a21 = 30;
			H.out("o177 " + Std.string(p176));
			var v178:Array<Int> = [a22, 99, a22];
			return a21;
		};
	}
	override public function m7():Int {
		H.tick();
		var v179 = C26.m32(false);
		try {
			H.out("o180 " + Std.string((-415773480)));
			Main.fn70("abc", [false, true]);
			++this.f18;
			if ((([v179]).contains(v179) ? StringTools.endsWith("ab", "\x41\x42") : Std.isOfType(new C16(0x80000000, v179), C26))) throw "boom";
		} catch (ex181:Dynamic) {
			H.out("caught " + H.exn(ex181));
			if ((new Map<String, A2>()).exists("ab")) {
				this.f18 += v179;
				final v182:Float = (-2.5);
			} else {
				H.out("o183 " + "q");
			}
			H.out("o184 " + Std.string(false));
		}
		var w185 = 0;
while (w185 < 5 && true) {
			w185++;
			H.tick();
			for (i186 in 0...4) {
				H.tick();
				H.out("o187 " + Std.string(i186));
				H.out("o188 " + Std.string(false));
			}
			H.out("o189 " + Std.string(false));
			var v190:A2 = new A2(v179);
		}
		var v191:Float = Math.ffloor(2.5e-3);
		return 218;
	}
	public function m23():Void {
		H.tick();
		var v192:Map<Int, C3> = new Map<Int, C3>();
		if (true) {
			var v193 = ("é").lastIndexOf("Haxe");
		} else {
			final v194:Bool = false;
			(new C16(194, 0x7E58)).m8(({x1: 244} : S0));
		}
		var v195:Array<A2> = ([new A2((-1721027558)), new A2(0x31FC)] : Array<A2>);
		H.out("o196 " + Std.string(126));
		var v197 = StringTools.startsWith(("zz").substr(6, (36 & 7)), C34.f37);
		var v198:C12 = new C12([0x6478, 262]);
		final v199 = (Std.parseInt(this.f13) ?? 0);
		H.out("o200 " + Std.string((v199 | v199)));
		var v201:Float = (new A2(v199)).twice;
	}
	public static function m24(a25:Float):Float {
		H.tick();
		(new C3()).m8(({x1: 200} : S0), (Math.isNaN(a25) ? C34.f37 : String.fromCharCode(65 + ((0x80000000) & 15))));
		var v202:A2 = new A2(153);
		var v203 = ("-7" + ("a\rb").substring(1, (55 & 7)));
		try {
			final v204:Array<S0> = ([({x1: 291} : S0)] : Array<S0>);
			final v205:Array<Float> = ([] : Array<Float>);
			for (i206 in 1...3) {
				H.tick();
				var v207 = i206;
			}
			if (false) throw (false + ("\n").toLowerCase());
		} catch (ex208:Dynamic) {
			H.out("caught " + H.exn(ex208));
			var v209:Array<String> = ([] : Array<String>);
			C44.m56([true]);
		}
		Main.fn58(v203);
		for (x210 in ([Math.pow(a25, 2), 138] : Array<Float>)) {
			H.tick();
			var v211:Array<Float> = ([0.5, 7.0, x210] : Array<Float>);
			C26.f27 ^= H.at([97, 256, 136], 837420704, 0);
		}
		return a25;
	}
}

class C34 {
	public final f35:Float;
	public final f36:Int;
	public static var f37:String = "\n";
	public function new() {
		this.f35 = 1e3;
		this.f36 = (([] : Array<Int>)).length;
	}
	public static function m38(?a39:Null<String>):Void {
		H.tick();
		H.out("o285 " + Std.string((if (([205]).contains(16)) Lambda.count(([] : Array<Int>), v286 -> false) else (("\n").charCodeAt(0xBB13) ?? -1))));
		for (i287 in 0...H.lim((true ? (-14) : (({x1: 144} : S0)).x1))) {
			H.tick();
			var v288:String = "\t";
		}
		H.out("o289 " + Std.string(Std.int(0.30000000000000004)));
		C26.f27 += (new C16(1676741529, 0xD924)).m7();
		var v290:Array<Int> = Ext.ext90("\x41\x42");
	}
	public static function m40(a41:Map<String, String>):Int {
		H.tick();
		(new C3()).m4(({ var v291 = (("zz").charCodeAt(169) ?? -1); ([v291, v291]).contains(v291); }), (new C26(0x234F)).m30(C34.f37));
		try {
			if (true) throw 52;
			var v292 = (("  pad  ").charCodeAt(159) ?? -1);
			final v293:Map<Int, Int> = ([-3 => (-10)] : Map<Int, Int>);
			for (x294 in ([] : Array<String>)) {
				H.tick();
				(new C12(([] : Array<Int>))).m8(({x1: v292} : S0));
			}
		} catch (ex295:String) {
			H.out("caught String " + ex295);
			try {
				if ((Std.downcast((new C12([259, 251]) : C12), C16) != null)) throw "boom";
				C16.f17 <<= (201 & 7);
			} catch (ex296:Err) {
				H.out("caught Err " + ex296.errCode);
				var v297:String = "ab";
			} catch (ex298:haxe.Exception) {
				H.out("caught " + H.exn(ex298));
				C26.f27 = 234;
			}
		} catch (ex299:Int) {
			H.out("caught Int " + ex299);
			(new C26(130)).m4(false, ex299);
			(new C26(89)).m8(({x1: ex299} : S0));
		} catch (ex300:Err) {
			H.out("caught Err " + ex300.errCode);
			function lf301(n302:Int):Int {
				H.tick();
				return n302 <= 0 ? C26.f27 : (lf301(n302 - 1) + n302);
			}
			H.out("lf301 " + lf301(0));
		} catch (ex303:Dynamic) {
			H.out("caught " + H.exn(ex303));
			for (k304 => v305 in new Map<String, Int>()) {
				H.tick();
				var v306:Int = (-220773382);
			}
		}
		(new C16(Math.floor(3.0), Math.round(123456.789))).m8(({x1: 27} : S0));
		return 20;
	}
	public function m42():Int {
		H.tick();
		if (!(([] : Array<Int>)).contains(0xCE83)) {
			for (k307 => v308 in new Map<String, Int>()) {
				H.tick();
				C16.f17 <<= (98 & 7);
				if (true) continue;
			}
			H.out("o309 " + Std.string(100.75));
			var v310:Map<String, Int> = new Map<String, Int>();
		}
		for (i311 in 0...H.lim((new C16(38, 1157799870)).m7())) {
			H.tick();
			if (false) break;
			H.out("o312 " + Std.string(({x1: 28} : S0)));
			([i311]).ext88();
		}
		var v313:C16 = new C16(0xFFFFFFFF, this.f36);
		var v314 = ({ var v315 = (-16); String.fromCharCode(65 + ((971539029) & 15)); });
		var v316:Int = (new A2(155) : Int);
		var v317 = Std.string(false);
		C26.f27 *= (new C26(v316)).m7();
		var v318:Bool = ((([-3 => v314] : Map<Int, String>)).exists(0xCF6A) && true);
		H.out("o319 " + Std.string(({x1: (v316--)} : S0)));
		return v316;
	}
	public function m43():Bool {
		H.tick();
		for (i320 in 0...4) {
			H.tick();
			final v321:Array<Int> = [i320];
		}
		H.out("o322 " + (false + "-7"));
		C16.f17 = (if (false) 143 else C16.f17);
		var v323 = 148;
		var v324 = 293;
		final lf325:() -> Void = function():Void {
			H.tick();
			var v326:Float = v323;
			var v327 = ([true]).join("|");
		};
		v324 -= 93;
		v323 += C34.m40(new Map<String, String>());
		final v328:(Float) -> Void = function(p329:Float):Void {
			H.tick();
			var v330:Array<String> = ("\u{1F600}").split(",");
			var v331:Int = 239;
		};
		return (v323 <= v323);
	}
}

class Main {
	public static inline function fn58(a59:String):Float {
		H.tick();
		(new C26((new A2(229) : Int))).m8(({x1: 218} : S0));
		var v443:Map<String, Bool> = new Map<String, Bool>();
		H.out("o444 " + C34.f37);
		var v445:Array<String> = ((StringTools.startsWith("-7", a59) ? [a59] : [a59, a59]) : Array<String>);
		if ((true ? false : ([(-2147483647), 120]).contains(1302429041))) {
			var v446:Int = Reflect.compare(0xF04D, 0xF63D);
		}
		C16.f17 = 108;
		return ((Math.round(0.1) + 0.1) - C26.f27);
	}
	public static inline function fn60(a61:Int, a62:Array<Float>):Bool {
		H.tick();
		function lf447(n448:Int):Int {
			H.tick();
			return n448 <= 0 ? a61 : (lf447(n448 - 1) + a61);
		}
		H.out("lf447 " + lf447(0));
		if ((new C34()).m43()) {
			var v449:Bool = Std.isOfType(new C3(), C16);
			for (x450 in [a61, a61]) {
				H.tick();
				(new C26(a61)).m8(({x1: 121} : S0), "\"q\"");
			}
			C44.m53(C16.f19, C34.f37);
		}
		(new C26(C26.f27)).m30('x${Std.string(true)}${Std.string(false)}');
		var v451:Int = C16.f17;
		var v452:Map<String, String> = new Map<String, String>();
		var v453:Int = ("hello world").indexOf(([true]).join(""));
		var v454 = v451;
		return !true;
	}
	public static inline function fn63(a64:String, a65:Array<Int>, ...r66:Int):String {
		H.tick();
		H.out("o455 " + Std.string(new C26(H.at(a65, 295, 0))));
		var v456:String = Std.string(150);
		C26.m29();
		try {
			if (fn60((new A2(0xF34E)).twice, ([] : Array<Float>))) throw "boom";
			var v457:Map<Int, Int> = new Map<Int, Int>();
		} catch (ex458:Dynamic) {
			H.out("caught " + H.exn(ex458));
			if (true) {
				var v459:Int = (-805551536);
				v459 |= v459;
				var v460:Int = v459;
			}
		}
		H.out("o461 " + Std.string((true && (r66.toArray()).contains(1355780104))));
		if ((1e100 == 100.75)) {
			H.out("o462 " + Std.string(287));
			C16.f17 <<= (([false]).indexOf(false) & 7);
		} else {
			final v463:Array<Bool> = [false];
		}
		C26.f27--;
		return v456;
	}
	public static function fn67(a68:Int, a69:String):Null<Int> {
		H.tick();
		final v464:Array<String> = ((StringTools.contains(a69, a69) ? ["q"] : (a69).split("a")) : Array<String>);
		if ((Std.string((-1843740549)) != "hello world")) return a68;
		try {
			if (false) throw (a69 + a69);
			H.out("o465 " + Std.string(true));
		} catch (ex466:Err) {
			H.out("caught Err " + ex466.errCode);
			if (true) {
				var v467:Int = a68;
				H.out("o468 " + Std.string(([] : Array<Int>)));
			} else {
				(new C3()).m4(true, a68);
			}
			var v469:Bool = StringTools.startsWith("a", a69);
		} catch (ex470:haxe.Exception) {
			H.out("caught " + H.exn(ex470));
			H.out("o471 " + Std.string((Std.parseInt(a69) ?? 0)));
		}
		return Math.round(a68);
	}
	public static function fn70(a71:String, a72:Array<Bool>):Float {
		H.tick();
		H.out("o472 " + Std.string(C16.f17));
		if (!true) return 1e100;
		fn60((("q").charCodeAt(1419834575) ?? -1), ([2.5e-3, 7.0, 1e21] : Array<Float>));
		var v473:Array<Float> = (([] : Array<Float>)).filter(v474 -> Math.isNaN((-2.5)));
		C16.f17 ^= (([0x378F]).indexOf(251) | (a71).indexOf(a71));
		return (((({x1: 0x113} : S0)).x1 | (a71).indexOf(a71)) / C26.m32(StringTools.startsWith(a71, a71)));
	}
	public static function fn73(a74:S0, a75:Map<String, Bool>, a76:S0):Float {
		H.tick();
		H.out("o475 " + '${Std.string(true)}');
		final lf476:(Float) -> Float = function(p477:Float):Float {
			H.tick();
			try {
				if (StringTools.startsWith("zz", "\t")) throw "boom";
				var v478:Array<String> = ["\\", "\n"];
				C16.f17 <<= (209 & 7);
			} catch (ex479:Dynamic) {
				H.out("caught " + H.exn(ex479));
				C34.f37 = H.cap("0");
			}
			for (i480 in 0...2) {
				H.tick();
				var v481:Array<Array<C34>> = ([([new C34(), new C34(), new C34()] : Array<C34>), ([new C34()] : Array<C34>)] : Array<Array<C34>>);
				H.out("o482 " + Std.string(([] : Array<Int>)));
				H.out("o483 " + Std.string(i480));
			}
			return 100.75;
		};
		for (i484 in 0...2) {
			H.tick();
			fn67(C26.f27, StringTools.hex((i484) & 0xFFFF, 4));
			H.out("o485 " + Std.string(i484));
			for (i486 in 0...H.lim(0x80000000)) {
				H.tick();
				H.out("o487 " + Std.string(false));
				if (true) break;
			}
		}
		return Math.max(Math.ffloor(1e3), (new C3()).m7());
	}
	public static function fn77(a78:Bool, a79:Int):Null<Int> {
		H.tick();
		for (i488 in 2...4) {
			H.tick();
			if ((Std.downcast((new C16(132, 141) : C16), C16) != null)) return i488;
		}
		final v489 = a79;
		C26.f27 *= (new C12(([] : Array<Int>))).m7();
		H.out("o490 " + C34.f37);
		var v491:Float = ((false ? 3.0 : 136) : Float);
		for (k492 => v493 in new Map<String, Int>()) {
			H.tick();
			var v494:Map<String, Bool> = (["k0" => a78] : Map<String, Bool>);
			for (k495 => v496 in (["k0" => a79] : Map<String, Int>)) {
				H.tick();
				C16.m24(0.5);
				H.out("o497 " + Std.string(new C26(219)));
			}
			var w498 = 0;
while (w498 < 2 && a78) {
				w498++;
				H.tick();
				var v499 = v489;
				final v500:Array<Int> = [v493];
			}
		}
		return ((((["k0" => v489] : Map<String, Int>)).get("k2") ?? 0) * v489);
	}
	public static function fn80():Int {
		H.tick();
		if (Main.fn60(((new Map<Int, Int>()).get(129) ?? 0), ([] : Array<Float>))) return 77;
		Main.fn63(([97]).join("|"), ([0x7FFFFFFF]).concat([235]), (Std.parseInt(Std.string(true)) ?? 0), (([0x4A7C]).length * (((["k0" => 227] : Map<String, Int>)).get("42") ?? 0)));
		H.out("o501 " + (C34.f37 + Std.string(1e100)));
		for (x502 in [([298]).join(",")]) {
			H.tick();
			H.out("o503 " + Std.string((("-7").charCodeAt(206) ?? -1)));
			try {
				if (false) throw "boom";
				H.out("o504 " + Std.string(true));
			} catch (ex505:Err) {
				H.out("caught Err " + ex505.errCode);
				var v506 = "ab";
			} catch (ex507:haxe.Exception) {
				H.out("caught " + H.exn(ex507));
				H.out("o508 " + Std.string(new C12([9, 211, 0xC691])));
			}
		}
		function lf509(n510:Int):Int {
			H.tick();
			return n510 <= 0 ? C26.m32(StringTools.startsWith("0", "\t")) : (lf509(n510 - 1) + ((StringTools.trim("q")).charCodeAt(([n510]).indexOf(n510)) ?? -1));
		}
		H.out("lf509 " + lf509(5));
		H.out("o511 " + Std.string((("0").replace("a", "b")).lastIndexOf((([] : Array<Bool>)).join(""))));
		try {
			if ((Std.downcast((new C3() : C3), C3) != null)) throw new Err(C26.m32(true));
			H.out("o512 " + Std.string(false));
		} catch (ex513:Err) {
			H.out("caught Err " + ex513.errCode);
			if (Std.isOfType(new C12([101]), C3)) return ([false, false]).indexOf(false);
		} catch (ex514:haxe.Exception) {
			H.out("caught " + H.exn(ex514));
			C16.f17 = 261;
			final v515:Bool = true;
		}
		if (Main.fn60(0x2B92, ([2.5e-3, 3.0, 0.5] : Array<Float>))) {
			H.out("o516 " + Std.string(Math.ceil((-2.5))));
			try {
				C16.m24(7.0);
				if (true) throw StringTools.replace("日本語", "a", "\"q\"");
			} catch (ex517:String) {
				H.out("caught String " + ex517);
				var v518:Map<Int, String> = ([-3 => "a\rb"] : Map<Int, String>);
				var v519 = ex517;
			} catch (ex520:Int) {
				H.out("caught Int " + ex520);
				(ex520).ext86();
			} catch (ex521:Err) {
				H.out("caught Err " + ex521.errCode);
				C26.m32(true);
			} catch (ex522:Dynamic) {
				H.out("caught " + H.exn(ex522));
				var v523:C26 = new C26(234);
			}
		}
		return (Std.parseInt((([0x7FFFFFFF, 31, 167]).join("")).substring(((Std.parseInt(Std.string(64)) ?? 0) & 7), 0)) ?? 0);
	}
	public static function fn81():S0 {
		H.tick();
		final lf524:(Float) -> Float = function(p525:Float):Float {
			H.tick();
			C16.f17 <<= (205 & 7);
			H.out("o526 " + "a\rb");
			for (i527 in 0...H.lim(Std.int(p525))) {
				H.tick();
				final v528:Float = p525;
				if (true) break;
				var v529:Float = i527;
			}
			return ((([] : Array<Int>)).indexOf((-1943803241)) - 88);
		};
		function lf530(n531:Int):Int {
			H.tick();
			return n531 <= 0 ? (~113) : (lf530(n531 - 1) + C16.f17);
		}
		H.out("lf530 " + lf530(1));
		if ((new C34()).m43()) {
			var v532:Float = 5e-324;
			H.out("o533 " + Std.string(StringTools.contains("日本語", "\u{1F600}")));
			try {
				if (true) throw ("x,y,z").replace("a", "b");
				var v534:Int = 106;
			} catch (ex535:Dynamic) {
				H.out("caught " + H.exn(ex535));
				final v536:Map<String, String> = (["k0" => "\t", "k1" => ""] : Map<String, String>);
			}
		} else {
			final v537:() -> Int = () -> 26;
			C44.m56([false, false]);
		}
		var w538 = 0;
while (w538 < 4 && (Std.isOfType(new C26(26), C3) || true)) {
			w538++;
			H.tick();
			H.out("o539 " + Std.string(C16.f17));
			if (true) return ({x1: (-2147483647)} : S0);
		}
		var v540 = (([10, (-1533394359)]).indexOf(236) < 142);
		return ({x1: 120} : S0);
	}
	public static function fn82(a83:Bool, a84:Int):String {
		H.tick();
		for (x541 in ((a83 ? [a84, a84] : [a84]) : Array<Int>)) {
			H.tick();
			if (false) {
				H.out("o542 " + Std.string(a84));
				var v543:Bool = true;
			}
		}
		final lf544:() -> Bool = () -> ([a84, a84, 3]).contains((({x1: a84} : S0)).x1);
		H.out("o545 " + Std.string(fn81()));
		return "q";
	}
	public static function section0():Void {
		H.tick();
		C26.m29();
		var v580:Array<String> = ["", Std.string(1e3)];
		final lf581:() -> String = function():String {
			H.tick();
			if (true) {
				H.out("o582 " + Std.string(false));
				H.out("o583 " + Std.string(["日本語"]));
			} else {
				C16.f17 = 94;
			}
			if (false) {
				var v584:Array<Int> = [200, (-485941909)];
			} else {
				fn70("42", ([] : Array<Bool>));
			}
			return C34.f37;
		};
		var v585:Null<Int> = C16.f17;
		if ((C16.f19 == 2.5e-3)) {
			var v586:Map<String, Int> = (["k0" => 171, "k1" => 258, "k2" => 162290291] : Map<String, Int>);
		}
		var v587:S0 = ({x1: ("zz").length} : S0);
		var v588:A2 = new A2((v587).x1);
		for (x589 in ([144] : Array<Float>)) {
			H.tick();
			try {
				C16.f17 = 58;
				if (([131, 131, 41]).contains((-1788523381))) throw C34.f37;
			} catch (ex590:Err) {
				H.out("caught Err " + ex590.errCode);
				H.out("o591 " + Std.string((v588 : Int)));
			} catch (ex592:haxe.Exception) {
				H.out("caught " + H.exn(ex592));
				var v593:Array<Int> = [583778414];
			}
			var v594:A2 = new A2(87430463);
			final v595:Array<Int> = ([] : Array<Int>);
		}
		H.out("o596 " + (C34.f37).toLowerCase());
	}
	public static function section1():Void {
		H.tick();
		var v597:Int = (195 >> (C26.f27 & 31));
		H.out("o598 " + Std.string(Math.abs(1.25)));
		v597 = H.id(v597);
		H.out("o599 " + Std.string(v597));
	}
	public static function section2():Void {
		H.tick();
		((false ? (Std.parseInt("日本語") ?? 0) : ("a\rb").length)).ext86();
		{
			var v600:Bool = StringTools.startsWith("ünï", "");
			Main.fn67((({x1: 260} : S0)).x1, Std.string(3.0));
		}
		H.out("o601 " + Std.string(((true ? new C16(259, 0xAA41) : new C12([(-1728720319)])) : C3)));
		var v602:Array<String> = [for (i603 in 0...3) "A-B-C"];
		final v604:String = C44.m53(Math.pow(1e3, 2), ("abc").substr((278 & 7), (36 & 7)));
		final v605:Map<Int, String> = new Map<Int, String>();
		var v606:Bool = fn60((({x1: 180} : S0)).x1, ([0.5, 1.25, 1.25] : Array<Float>));
		var w607 = 0;
while (w607 < 2 && (new C34()).m43()) {
			w607++;
			H.tick();
			var v608:Map<String, Int> = new Map<String, Int>();
			var w609 = 0;
do {
				w609++;
				H.tick();
				H.out("o610 " + Std.string(new C16(213, 85)));
				final v611 = v606;
			} while (w609 < 4 && false);
		}
		H.out("o612 " + Std.string((new C16(0xB1D3, (-11))).m7()));
	}
	public static function section3():Void {
		H.tick();
		C16.m24(C16.f17);
		C26.f27 = 0xAEB1;
		C26.m29();
		C44.m56((("Haxe").split("-")).map((v613:String) -> false));
		H.out("o614 " + Std.string(({ var v615 = "hello world"; new C26(0x4F0); })));
		H.out("o616 " + Std.string((63 ^ 254)));
	}
	public static function section4():Void {
		H.tick();
		(0xEF32).ext86();
		for (i617 in 0...4) {
			H.tick();
			for (i618 in 0...3) {
				H.tick();
				C34.f37 = H.cap("ab");
				Main.fn77(false, i618);
				var v619:Array<Int> = [i618];
			}
			var v620:Array<C26> = ([] : Array<C26>);
		}
		if ((true || StringTools.contains("  pad  ", "a"))) {
			if (Math.isNaN((-2.5))) {
				H.out("o621 " + Std.string(new C26((-2))));
				C16.f17 ^= 277;
				var v622:Array<String> = ["日本語"];
			}
			H.out("o623 " + Std.string(0x5316));
		} else {
			H.out("o624 " + Std.string(100));
		}
		C26.f27 ^= (Std.parseInt(Std.string((("hello world").charCodeAt(272) ?? -1))) ?? 0);
		var v625:C34 = new C34();
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
