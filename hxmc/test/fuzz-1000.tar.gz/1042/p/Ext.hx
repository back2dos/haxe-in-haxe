package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext86(a85:Int):Array<String> {
		H.tick();
		H.out("o546 " + Std.string(C16.f17));
		{
			var v547:A2 = new A2(a85);
			var v548:Bool = true;
			H.out("o549 " + Std.string(([a85, a85]).indexOf(a85)));
		}
		a85 = (new C26(192)).m30(Std.string(true));
		Main.fn70((("  pad  ").replace("a", "b")).toUpperCase(), ([] : Array<Bool>));
		final lf550:() -> Void = function():Void {
			H.tick();
			C26.f27 = (a85 += 3);
			a85++;
			H.out("o551 " + Std.string(a85));
		};
		(new C16(a85, a85)).m8(({x1: a85} : S0));
		var v552:String = C34.f37;
		var v553 = H.at([a85, a85], a85, 0);
		H.out("o554 " + Std.string((false ? Lambda.fold([v553], (v555:Int, v556:Int) -> (-10), 0) : v553)));
		return ([v552, (v552).charAt((a85 & 7)), "hello world"]).filter(v557 -> (v553 == v553));
	}
	public static function ext88(a87:Array<Int>):Bool {
		H.tick();
		for (k559 => x558 in [7]) {
			H.tick();
			try {
				final v560:Bool = false;
				(new C26(75)).m30("q");
				if (((["k0" => new C12(a87)] : Map<String, C3>)).exists("")) throw 44;
			} catch (ex561:Err) {
				H.out("caught Err " + ex561.errCode);
				(new C34()).m43();
				var v562:Map<Int, Float> = ([-3 => k559] : Map<Int, Float>);
			} catch (ex563:haxe.Exception) {
				H.out("caught " + H.exn(ex563));
				var v564:Map<Int, String> = ([-3 => "ünï", 4 => "ünï", 11 => "é"] : Map<Int, String>);
				H.out("o565 " + Std.string(C26.f27));
			}
		}
		for (i566 in 2...H.lim((a87).indexOf(Reflect.compare(571966949, 1308765114)))) {
			H.tick();
			final v567 = Std.isOfType(new C12(a87), C12);
			var v568:String = "ab";
			C44.m56([true, v567, v567]);
		}
		C26.f27 <<= (189 & 7);
		H.out("o569 " + Std.string((new C26(224)).m30("\u{1F600}")));
		H.out("o570 " + C34.f37);
		var w571 = 0;
while (w571 < 5 && true) {
			w571++;
			H.tick();
			if (Std.isOfType(new C26(1539980607), C44)) {
				if (false) break;
				C26.f27 |= 150;
				(new C16(185, (-1663640494))).m8(({x1: 56} : S0));
			} else {
				C26.f27 <<= (256 & 7);
			}
			final v572 = C16.f17;
		}
		Main.fn58((("\u{1F600}").indexOf("q") + (["A-B-C"]).join("|")));
		return false;
	}
	public static function ext90(a89:String):Array<Int> {
		H.tick();
		for (i573 in 0...1) {
			H.tick();
			var v574:Array<Bool> = [true];
		}
		var v575:Int = ([95, 166, 72]).indexOf((a89).length);
		final lf576:(Bool, Int) -> Float = (p577:Bool, p578:Int) -> (0.5 * 2.5e-3);
		H.out("o579 " + Std.string(new C26(v575)));
		return [204, 0x32C9, (new C26(v575)).m30(a89)];
	}
}
