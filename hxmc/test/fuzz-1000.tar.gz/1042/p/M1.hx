package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

typedef S0 = {x1:Int};

class C12 extends C3 {
	public final f13:String;
	public var cb14:(Int) -> Int;
	public function new(a15:Array<Int>) {
		super();
		this.f13 = Std.string(true);
		this.cb14 = function(p163:Int):Int {
			H.tick();
			var v164 = 124;
			H.out("o165 " + Std.string(true));
			final v166:(Int, Int) -> Bool = (p167:Int, p168:Int) -> false;
			return 294;
		};
	}
	override public function m8(a9:S0, ?a10:Null<String>):Float {
		H.tick();
		++C16.f17;
		if (true) {
			H.out("o169 " + Std.string(new C34()));
			var w170 = 0;
while (w170 < 5 && ((["k0" => new C16(275, 5), "k1" => new C3()] : Map<String, C3>)).exists("-7")) {
				w170++;
				H.tick();
				var v171 = false;
			}
		} else {
			for (i172 in 0...1) {
				H.tick();
				var v173 = "ab";
			}
			var v174 = C26.f27;
		}
		var v175 = "\u{1F600}";
		return Math.max(C26.f27, (123456.789 / 2.5e-3));
	}
}

class C26 extends C3 {
	public static var f27:Int = 265;
	public function new(a28:Int) {
		super();
	}
	override public function m4(a5:Bool, a6:Int):Void {
		H.tick();
		C16.f17 |= (--a6);
		H.out("o212 " + (C34.f37 + "42"));
		var v213:Int = a6;
	}
	override public function m7():Int {
		H.tick();
		++C26.f27;
		var v214:Array<String> = (["42", "日本語"]).filter(v215 -> ([9]).contains(146));
		var v216:S0 = ({x1: 0xFFFFFFFF} : S0);
		var v217 = C26.m32(Math.isNaN(2.5e-3));
		return ((-23306015) >> ((new C26(v217)).m30(("Haxe").toUpperCase()) & 31));
	}
	override public function m8(a9:S0, ?a10:Null<String>):Float {
		H.tick();
		for (x218 in [for (i219 in 0...1) "q"]) {
			H.tick();
			m4(([(-1988125067), 48, 24]).contains(257), (new A2(0x7FFFFFFF)).get());
			if (true) {
				if (true) break;
				final v220:(Int) -> Int = (p221:Int) -> p221;
			} else {
				if (true) continue;
			}
		}
		C16.f17--;
		final v222:Array<Int> = [(([0.1] : Array<Float>)).length];
		H.out("o223 " + "Haxe");
		H.out("o224 " + Std.string([(("abc").charCodeAt(204) ?? -1), (Std.parseInt("zz") ?? 0)]));
		if (false) {
			for (i225 in 0...1) {
				H.tick();
				H.out("o226 " + Std.string(i225));
				var v227:S0 = a9;
			}
		}
		H.out("o228 " + Std.string(123456.789));
		var w229 = 0;
while (w229 < 4 && true) {
			w229++;
			H.tick();
			if (true) break;
			final v230:(Int, Bool) -> Int = (p231:Int, p232:Bool) -> 281;
		}
		var v233 = (0x7FFFFFFF >>> (C26.f27 & 31));
		return 1e3;
	}
	public static function m29():String {
		H.tick();
		var v234:Int = (-C26.f27);
		(new C16(C16.f17, 0xFC2D)).m4(([v234, v234]).contains(v234), 191840603);
		v234 = (~v234);
		try {
			var v235 = ("").replace("a", "b");
			if (false) throw 1;
		} catch (ex236:Dynamic) {
			H.out("caught " + H.exn(ex236));
			if (false) {
				var v237:Int = v234;
				C16.f17 = v237;
				H.out("o238 " + Std.string(v234));
			}
		}
		H.out("o239 " + Std.string(new C16(C16.f17, 98)));
		{
			var v240:Array<C26> = ([new C26(v234), new C26(v234), new C26(v234)] : Array<C26>);
		}
		if (false) {
			var v241 = v234;
			function lf242(n243:Int):Int {
				H.tick();
				return n243 <= 0 ? v241 : (lf242(n243 - 1) + v241);
			}
			H.out("lf242 " + lf242(3));
			if ((([] : Array<Int>)).contains(v241)) {
				var v244:String = "x,y,z";
			} else {
				(new C26(v234)).m8(({x1: v234} : S0), "a\rb");
			}
		}
		return "q";
	}
	public function m30(a31:String):Int {
		H.tick();
		if (true) return ((a31).length + C16.f17);
		if ((156 < 182)) {
			var v245:S0 = ({x1: 77} : S0);
			var v246:Map<Int, Float> = new Map<Int, Float>();
			try {
				var v247:Array<Int> = ([] : Array<Int>);
				if ((v247).contains(0x80000000)) throw "  pad  ";
			} catch (ex248:String) {
				H.out("caught String " + ex248);
				var v249 = false;
				++C16.f17;
			} catch (ex250:Int) {
				H.out("caught Int " + ex250);
				H.out("o251 " + Std.string(ex250));
			} catch (ex252:Err) {
				H.out("caught Err " + ex252.errCode);
				H.out("o253 " + Std.string(199));
				H.out("o254 " + a31);
			} catch (ex255:Dynamic) {
				H.out("caught " + H.exn(ex255));
				var v256 = (-1412386018);
			}
		} else {
			final v257:Array<String> = [a31];
		}
		var v258 = ((a31).replace("a", "b")).length;
		final v259:Bool = false;
		return (({x1: v258} : S0)).x1;
	}
	public static function m32(a33:Bool):Int {
		H.tick();
		var v260 = (233 >> (220 & 31));
		var v261:Int = 235;
		try {
			C26.f27 = v261;
			C26.m29();
			C26.m29();
			if (!StringTools.contains("ab", "a")) throw 8;
		} catch (ex262:String) {
			H.out("caught String " + ex262);
			var v263:Int = (ex262).lastIndexOf(ex262);
			try {
				if (true) throw 16;
				var v264:String = ex262;
				var v265:Array<Float> = ([0.1, v261] : Array<Float>);
				var v266 = v264;
			} catch (ex267:String) {
				H.out("caught String " + ex267);
				var v268:C34 = new C34();
				var v269:String = "\x41\x42";
			} catch (ex270:Int) {
				H.out("caught Int " + ex270);
				var v271 = ex262;
				var v272:A2 = new A2(ex270);
			} catch (ex273:Err) {
				H.out("caught Err " + ex273.errCode);
				var v274:Null<Int> = v260;
				var v275:Array<S0> = ([({x1: 89} : S0)] : Array<S0>);
			} catch (ex276:Dynamic) {
				H.out("caught " + H.exn(ex276));
				var v277:Map<Int, Int> = new Map<Int, Int>();
				var v278:String = ex262;
			}
		} catch (ex279:Int) {
			H.out("caught Int " + ex279);
			H.out("o280 " + Std.string(244));
		} catch (ex281:Err) {
			H.out("caught Err " + ex281.errCode);
			(new C16(v261, v261)).m8(({x1: v260} : S0), ("x,y,z").charAt((0xFFFFFFFF & 7)));
		} catch (ex282:Dynamic) {
			H.out("caught " + H.exn(ex282));
			v260 = Reflect.compare(v260, v260);
		}
		final v283 = (Std.string(0xABC5) == C34.f37);
		var v284:Float = Math.sqrt(Math.abs(1.25));
		return v261;
	}
}
