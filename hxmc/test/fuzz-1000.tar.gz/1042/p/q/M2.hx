package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

class C3 {
	public function new() {}
	public function m4(a5:Bool, a6:Int):Void {
		H.tick();
		for (k92 => x91 in ([false, a5]).copy()) {
			H.tick();
			var v93:Map<String, String> = new Map<String, String>();
			for (k94 => v95 in (["k0" => a6, "k1" => 228] : Map<String, Int>)) {
				H.tick();
				var v96:Map<Int, Float> = ([-3 => k92, 4 => 1e-7, 11 => k92] : Map<Int, Float>);
				var v97 = false;
				H.out("o98 " + Std.string(({x1: v95} : S0)));
			}
			a6 = ("\n").length;
		}
		H.out("o99 " + Std.string(a5));
		H.out("o100 " + "ünï");
		for (k101 => v102 in new Map<String, Int>()) {
			H.tick();
			for (i103 in 0...0) {
				H.tick();
				H.out("o104 " + Std.string(v102));
				final v105:Array<Bool> = [a5];
				H.out("o106 " + Std.string(65535));
			}
			try {
				final v107 = v102;
				if (([v102, 171]).contains(v102)) throw 98;
			} catch (ex108:String) {
				H.out("caught String " + ex108);
				H.out("o109 " + Std.string(true));
				var v110 = (-2147483647);
			} catch (ex111:Int) {
				H.out("caught Int " + ex111);
				var v112:Int = a6;
			} catch (ex113:Err) {
				H.out("caught Err " + ex113.errCode);
				C16.f17 = v102;
			} catch (ex114:Dynamic) {
				H.out("caught " + H.exn(ex114));
				H.out("o115 " + Std.string(a5));
			}
			var v116 = a6;
		}
		if (true) {
			H.out("o117 " + Std.string(null));
		} else {
			var v118:Map<String, Int> = new Map<String, Int>();
		}
		if (a5) {
			C16.f17 = a6;
			for (x119 in [a6, a6]) {
				H.tick();
				var v120:Array<String> = ["abc", "abc", "Haxe"];
			}
		} else {
			{
				H.out("o121 " + Std.string(a5));
				C26.f27 += 122;
				var v122:Bool = a5;
			}
			var v123:Map<Int, Array<Int>> = ([-3 => ([] : Array<Int>), 4 => [a6, a6, a6]] : Map<Int, Array<Int>>);
		}
		for (x124 in [C34.f37, StringTools.hex((24) & 0xFFFF, 4)]) {
			H.tick();
			if ((new Map<Int, Int>()).exists(11)) break;
			H.out("o125 " + Std.string((x124).indexOf(x124)));
			H.out("o126 " + Std.string(Reflect.compare(x124, x124)));
		}
		try {
			for (i127 in 0...3) {
				H.tick();
				var v128 = 163;
				H.out("o129 " + Std.string(56));
			}
			C26.f27 = ("\n").length;
			{
				var v130:Array<C34> = ([new C34(), new C34(), new C34()] : Array<C34>);
				final v131 = false;
				var v132:Array<String> = ["ab", "A-B-C", "\"q\""];
			}
			if (a5) throw 96;
		} catch (ex133:String) {
			H.out("caught String " + ex133);
			H.out("o134 " + Std.string(Lambda.fold(([] : Array<Int>), (v135:Int, v136:Int) -> ((ex133).charCodeAt(v136) ?? -1), 0)));
			{
				C26.f27 <<= (a6 & 7);
				H.out("o137 " + Std.string(a6));
			}
		} catch (ex138:Int) {
			H.out("caught Int " + ex138);
			H.out("o139 " + Std.string(a6));
			var v140:Array<Float> = ([5e-324] : Array<Float>);
		} catch (ex141:Err) {
			H.out("caught Err " + ex141.errCode);
			final v142:Array<S0> = ([({x1: a6} : S0)] : Array<S0>);
		} catch (ex143:Dynamic) {
			H.out("caught " + H.exn(ex143));
			H.out("o144 " + Std.string(a6));
			a6 = (Std.parseInt("a\rb") ?? 0);
		}
	}
	public function m7():Int {
		H.tick();
		final lf145:() -> String = () -> C26.m29();
		H.out("o146 " + Std.string(3));
		H.out("o147 " + Std.string((Math.isNaN(3.0) ? 65 : ([20, 73, 57]).indexOf(212))));
		C26.f27 *= C26.m32(false);
		C16.f17 = (("\\").substring((78 & 7), 6)).indexOf("\n");
		H.out("o148 " + Std.string((("x,y,z").charCodeAt(140) ?? -1)));
		final v149:(Int) -> String = (p150:Int) -> ("日本語").toUpperCase();
		var w151 = 0;
while (w151 < 1 && ([(-1), 1811713128, (-1415945086)]).ext88()) {
			w151++;
			H.tick();
			var v152 = Math.ceil(2.5e-3);
			for (i153 in 0...2) {
				H.tick();
				var v154 = true;
			}
		}
		return Lambda.count([for (i155 in 0...0) i155], v156 -> true);
	}
	public function m8(a9:S0, ?a10:Null<String>):Float {
		H.tick();
		var v157:C16 = ({ var v158 = 0x7FFFFFFF; new C16(v158, v158); });
		C26.f27 = (true ? 0xFFFFFFFF : 271);
		var v159:String = (StringTools.trim("\"q\"") + 24);
		return C16.f19;
	}
	public static function m11():String {
		H.tick();
		H.out("o160 " + Std.string(([1e100] : Array<Float>)));
		var v161 = (([246, 20]).length * C26.f27);
		H.out("o162 " + Std.string(new C16((v161 -= 1), ([v161, (-1939557340)]).length)));
		return ((262 < ("\u{1F600}").length) ? ([false]).join("") : Main.fn63("ünï", [v161, v161, v161], C26.f27));
	}
}

abstract class C44 extends C26 {
	public var cb45:(Int) -> Int;
	public function new(a46:Int, a47:Float) {
		super(0x80000000);
		this.cb45 = function(p332:Int):Int {
			H.tick();
			var v333 = p332;
			return 95;
		};
	}
	override public function m4(a5:Bool, a6:Int):Void {
		H.tick();
		if (a5) {
			final lf334:(Float) -> Void = function(p335:Float):Void {
				H.tick();
				H.out("o336 " + Std.string(a6));
			};
			for (i337 in 0...2) {
				H.tick();
				var v338:Array<Int> = ([] : Array<Int>);
				var v339:S0 = ({x1: i337} : S0);
				H.out("o340 " + "42");
			}
		} else {
			final v341:Array<String> = ["é", "-7", "日本語"];
			if (a5) {
				C16.f17 += a6;
			} else {
				C26.f27 |= 273;
				C16.f17 = a6;
			}
		}
		var v342:Int = a6;
		var v343 = 123;
		H.out("o344 " + Std.string(225));
		var v345:C26 = new C26(58);
		var v346 = a6;
		try {
			if ((v342 >= C16.f17)) throw 85;
			H.out("o347 " + Std.string(Math.floor(a6)));
			for (i348 in 1...H.lim(v346)) {
				H.tick();
				var v349:C34 = new C34();
			}
		} catch (ex350:Dynamic) {
			H.out("caught " + H.exn(ex350));
			C34.f37 = H.cap("a\rb");
		}
		if ((a6 < ("ünï").length)) {
			var v351 = v346;
			var v352:Int = C26.f27;
		} else {
			for (x353 in [(-2147483647), v342]) {
				H.tick();
				H.out("o354 " + Std.string(x353));
			}
			var v355:Int = ("hello world").indexOf("\u{1F600}");
		}
		C26.f27 = ((("\"q\"").charCodeAt((-2147483647)) ?? -1) << ((-19) & 31));
	}
	override public function m7():Int {
		H.tick();
		function lf356(n357:Int):Int {
			H.tick();
			return n357 <= 0 ? Math.floor(Std.parseFloat("hello world")) : (lf356(n357 - 1) + n357);
		}
		H.out("lf356 " + lf356(3));
		H.out("o358 " + ' = ${Std.string(0x80000000)}');
		var v359:C34 = new C34();
		return (({ var v360 = Math.floor(123456.789); false; }) ? ((("日本語").charCodeAt(67) ?? -1) % H.nz(970803708)) : H.at([251, 145], (Std.parseInt(Std.string(1935338756)) ?? 0), 0));
	}
	override public function m30(a31:String):Int {
		H.tick();
		var v361:S0 = ({x1: 289} : S0);
		C16.f17 -= ((a31).charCodeAt(Lambda.count([201, 65535, 0xE976], v362 -> false)) ?? -1);
		H.out("o363 " + '${Std.string(StringTools.contains("  pad  ", "a\rb"))}');
		for (x364 in [H.at([230, 107, 299], 166, 0), C26.f27]) {
			H.tick();
			H.out("o365 " + Std.string([0x187E, x364, x364]));
		}
		H.out("o366 " + Std.string(7.0));
		if (!false) return (~(-4));
		try {
			if ((([266, (-652645908), 186527334]).contains(200) && false)) throw 83;
			H.out("o367 " + Std.string(0));
			var v368 = 50;
			var w369 = 0;
do {
				w369++;
				H.tick();
				var v370:String = a31;
				final v371:Bool = true;
			} while (w369 < 3 && true);
		} catch (ex372:Dynamic) {
			H.out("caught " + H.exn(ex372));
			C16.f17 ^= (new A2(179)).get();
		}
		return C26.f27;
	}
	public function m48(a49:String, a50:String):S0 {
		H.tick();
		var v373:Array<String> = (([] : Array<String>)).filter(v374 -> true);
		if ((false || StringTools.startsWith(a49, "\n"))) {
			H.out("o375 " + Std.string(null));
			for (i376 in 0...H.lim(146)) {
				H.tick();
				C34.m40(new Map<String, String>());
				H.out("o377 " + Std.string(i376));
				H.out("o378 " + a50);
			}
		}
		for (x379 in v373) {
			H.tick();
			C26.f27 = 36;
			var v380:Int = Math.round(0.30000000000000004);
			var w381 = 0;
while (w381 < 5 && StringTools.contains(x379, a50)) {
				w381++;
				H.tick();
				C16.f17 = v380;
				var v382 = 0x59C4;
				var v383:A2 = new A2(v380);
			}
		}
		if ((new C34()).m43()) return ({x1: 0xC2FE} : S0);
		{
			var v384:Array<Null<Int>> = ([] : Array<Null<Int>>);
		}
		if (((("").charCodeAt(257) ?? -1) < 235)) return ({x1: (({x1: 0xD281} : S0)).x1} : S0);
		return ({x1: 0x11AB} : S0);
	}
	public function m51(a52:Bool):Int {
		H.tick();
		H.out("o385 " + Std.string(new C16((new A2(202)).get(), (([123456.789] : Array<Float>)).length)));
		if (true) {
			final v386:(Bool) -> Int = C26.m32;
			(new C34()).m43();
		} else {
			for (k388 => x387 in [100]) {
				H.tick();
				var v389:S0 = ({x1: k388} : S0);
				C26.f27 <<= ((-1120436514) & 7);
				C26.f27 = k388;
			}
		}
		function lf390(n391:Int):Int {
			H.tick();
			return n391 <= 0 ? n391 : (lf390(n391 - 1) + (new A2(n391)).twice);
		}
		H.out("lf390 " + lf390(3));
		{
			final lf392:(Float) -> Int = function(p393:Float):Int {
				H.tick();
				H.out("o394 " + Std.string(213));
				return (({x1: 88} : S0)).x1;
			};
			for (i395 in 0...1) {
				H.tick();
				H.out("o396 " + "日本語");
				H.out("o397 " + Std.string(a52));
				(new C34()).m43();
			}
			var v398 = ("-7").substr((279 & 7), 1);
		}
		C16.f17 -= (~([a52, a52, a52]).indexOf(a52));
		for (x399 in [for (i400 in 0...1) ("42").lastIndexOf("\\")]) {
			H.tick();
			for (x401 in [a52, true]) {
				H.tick();
				C26.f27 *= 61;
			}
			var v402:Array<Int> = ([] : Array<Int>);
		}
		for (i403 in 0...H.lim(146)) {
			H.tick();
			C16.f17 <<= (H.at([(-1), i403, i403], i403, 0) & 7);
		}
		var w404 = 0;
while (w404 < 4 && (([] : Array<Int>)).contains(C26.f27)) {
			w404++;
			H.tick();
			final lf405:(String, Float) -> Float = function(p406:String, p407:Float):Float {
				H.tick();
				var v408 = a52;
				return 100.75;
			};
			if (true) continue;
		}
		H.out("o409 " + Std.string(new C16(("hello world").length, 122)));
		return (if (Math.isNaN(0.5)) C16.f17 else C26.m32(true));
	}
	public static function m53(a54:Float, a55:String):String {
		H.tick();
		C26.f27 |= 0xFFFFFFFF;
		var v410:Int = C26.f27;
		var v411:Array<String> = (Std.string(true)).split(",");
		try {
			if ((v410 > 7.0)) throw 50;
			var v412:Bool = false;
			C16.f17 -= v410;
		} catch (ex413:Dynamic) {
			H.out("caught " + H.exn(ex413));
			C16.f17 = (("ab").charCodeAt(v410) ?? -1);
		}
		var v414:C26 = ((([(-529869916), 16, v410]).contains(v410) ? new C26(v410) : new C26(v410)) : C26);
		if ((v410 <= v410)) {
			if (true) return a55;
		}
		H.out("o415 " + C26.m29());
		return a55;
	}
	public static inline function m56(a57:Array<Bool>):Array<String> {
		H.tick();
		final v416 = (String.fromCharCode(65 + ((49) & 15))).indexOf("");
		C26.f27 = ((new Map<String, Float>()).exists("k0") ? 0xFFFFFFFF : (new A2(v416)).twice);
		var w417 = 0;
while (w417 < 2 && (("ünï").substr((101 & 7), 5) > ("  pad  ").replace("a", "b"))) {
			w417++;
			H.tick();
			H.out("o418 " + Std.string(new C3()));
		}
		var v419 = C44.m53(v416, C34.f37);
		C16.f17 = v416;
		if (true) {
			var w420 = 0;
while (w420 < 3 && false) {
				w420++;
				H.tick();
				final v421:Null<Int> = v416;
			}
		} else {
			var w422 = 0;
while (w422 < 3 && false) {
				w422++;
				H.tick();
				var v423 = false;
				(new C12([v416])).m8(({x1: v416} : S0), "zz");
				final v424:(Int, Bool) -> Void = function(p425:Int, p426:Bool):Void {
					H.tick();
					var v427:Array<String> = [v419, "\n"];
					C16.f17 = p425;
					var v428:Array<Int> = [v416];
				};
			}
			try {
				if (true) throw "boom";
				var v429:Map<String, Bool> = (["k0" => false, "k1" => false, "k2" => false] : Map<String, Bool>);
				final v430:(Bool) -> String = (p431:Bool) -> v419;
				final v432 = true;
			} catch (ex433:Err) {
				H.out("caught Err " + ex433.errCode);
				C44.m53(0.1, v419);
			} catch (ex434:haxe.Exception) {
				H.out("caught " + H.exn(ex434));
				C16.f17 |= v416;
				var v435:Float = v416;
			}
		}
		for (i436 in 0...H.lim((new C26(v416)).m30(StringTools.lpad(v419, "*", -2)))) {
			H.tick();
			var v437 = ([true]).join("");
			C26.f27--;
		}
		if (true) {
			var v438:Int = v416;
			v438 = 167;
		} else {
			(new C26(38)).m30("Haxe");
			var v439 = true;
		}
		return (([for (i441 in ([] : Array<Bool>)) if (Std.isOfType(null, C3)) 1.7976931348623157e308] : Array<Float>)).map((v440:Float) -> ({ var v442 = 1e-7; v419; }));
	}
}
