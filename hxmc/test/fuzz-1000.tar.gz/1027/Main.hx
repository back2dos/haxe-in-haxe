import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Int, a2:Int);
	E0C(a3:Int);
}

abstract A9(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A9, b:A9):A9
		return new A9(a.get() + b.get());

	@:op(A * B) public static function mul(a:A9, b:A9):A9
		return new A9(a.get() * b.get());

	@:op(-A) public static function neg(a:A9):A9
		return new A9(-a.get());
}

enum abstract K10(Int) to Int {
	var K10A = 1;
	var K10B = 4;
}

class Main {
	public static inline function fn11(a12:Int, a13:E4):Int {
		H.tick();
		var v32:Array<Bool> = ([false, false, true]).copy();
		if (false) {
			final v33 = a12;
			switch ("q") {
				case "a" | "b": {
					a12 = H.id(a12);
					a12 = 102;
				};
				case "Haxe": {
					H.out("o34 " + Std.string([v33, 234]));
				};
				case _: {
					H.out("o35 " + Std.string(v32));
				};
			}
			H.out("o36 " + Std.string(E0A));
		}
		var v37 = "a";
		var v38:Map<String, String> = (["k0" => (v37).replace("a", "b"), "k1" => "日本語", "k2" => v37] : Map<String, String>);
		return ((([] : Array<String>)).copy()).length;
	}
	public static inline function fn14():Float {
		H.tick();
		for (x39 in [for (i40 in [false, false, true]) if ((E0B(1871316329, 0x8EA1)).match(E0C(_))) Lambda.count([295], v41 -> true)]) {
			H.tick();
			switch (Std.string(E4.E4A)) {
				case "a" | "b": {
					if (true) continue;
					if (false) break;
				};
				case "Haxe": {
					H.out("o42 " + Std.string(({x6: false, x7: false, x8: 12} : S5)));
					var v43:Float = 5e-324;
				};
				case _: {
					var v44:Array<Bool> = [true, true, false];
					fn11(0x20A0, E4.E4A);
				};
			}
			var v45:S5 = ({x8: x39, x7: false, x6: true} : S5);
		}
		final v46 = (true ? true : false);
		H.out("o47 " + Std.string((switch (E4.E4A) {
			case E4A: Type.enumIndex(E0B(128, 69));
		})));
		var w48 = 0;
while (w48 < 1 && ((({x8: 44, x7: true, x6: v46} : S5)).x8 == 95)) {
			w48++;
			H.tick();
			if ((([-3 => E4.E4A] : Map<Int, E4>)).exists(21)) break;
			var v49:Int = Math.round(0.30000000000000004);
			var v50:Bool = v46;
		}
		try {
			if (((([] : Array<String>)).join(" ") <= (("\"q\"").split(",")).join(","))) throw new Err(1552841298);
			fn11(255, E4.E4A);
			H.out("o51 " + Std.string(E0A));
			fn11((-1071547921), E4.E4A);
		} catch (ex52:String) {
			H.out("caught String " + ex52);
			H.out("o53 " + Std.string(Lambda.count([(-484591028), 225], v54 -> Math.isNaN(v54))));
			final v55 = ex52;
		} catch (ex56:Int) {
			H.out("caught Int " + ex56);
			var v57:E4 = E4.E4A;
			final lf58:(Bool, Float) -> Bool = function(p59:Bool, p60:Float):Bool {
				H.tick();
				final v61:Array<String> = ["ünï"];
				H.out("o62 " + Std.string(E4.E4A));
				v61.reverse();
				return v46;
			};
		} catch (ex63:Err) {
			H.out("caught Err " + ex63.errCode);
			var v64:S5 = ({x8: 180, x7: v46, x6: false} : S5);
		} catch (ex65:Dynamic) {
			H.out("caught " + H.exn(ex65));
			var v66:Map<String, Map<Int, Null<Int>>> = (["k0" => ([-3 => 281, 4 => 65535] : Map<Int, Null<Int>>), "k1" => new Map<Int, Null<Int>>()] : Map<String, Map<Int, Null<Int>>>);
		}
		var v67:String = ("Haxe" + "ab");
		Main.fn11(14, E4.E4A);
		H.out("o68 " + Std.string(true));
		return 0.1;
	}
	public static function fn15(a16:Bool):E0 {
		H.tick();
		H.out("o69 " + Std.string(fn11(230, E4.E4A)));
		var w70 = 0;
while (w70 < 2 && (Type.enumIndex(E0A) > H.at(([] : Array<Int>), 1223135768, 0))) {
			w70++;
			H.tick();
			var v71:Array<Int> = ([] : Array<Int>);
			H.out("o72 " + Std.string(([a16, false, true]).length));
		}
		Main.fn14();
		Main.fn11(fn11((K10.K10B : Int), E4.E4A), ((switch (String.fromCharCode(65 + (((-1452003261)) & 15))) {
			case "a" | "b": E4.E4A;
			case "Haxe": E4.E4A;
			case _: E4.E4A;
		}) : E4));
		return (cast (((a16 ? E0.E0C(184) : E0.E0A) : E0)) : E0);
	}
	public static function fn17(a18:Bool):String {
		H.tick();
		H.out("o73 " + Std.string((294 - (({x6: a18, x7: a18, x8: 199} : S5)).x8)));
		H.out("o74 " + Std.string(StringTools.contains("a", "ab")));
		{ var dyn75:Dynamic = ((switch (Std.string(214)) {
			case "a" | "b": ({x7: a18, x8: 65535, x6: a18} : S5);
			case "Haxe": ({x6: a18, x7: a18, x8: 1752336258} : S5);
			case "": ({x6: true, x7: a18, x8: 27} : S5);
			case _: ({x6: a18, x7: true, x8: 0xEA69} : S5);
		}) : S5); H.out("dyn " + Std.string(dyn75.x6) + " " + Std.string(Reflect.field(dyn75, "x6"))); }
		return ("Haxe").replace("a", "b");
	}
	public static function fn19(a20:Array<String>, a21:String):Int {
		H.tick();
		H.out("o76 " + Std.string((if (false) (a21).length else Reflect.compare(0x8B69, 141))));
		Ext.ext31([94]);
		H.out("o77 " + Std.string(Reflect.compare((a20).join("|"), a21)));
		var v78:K10 = K10.K10B;
		Main.fn15(false);
		{
			if (true) {
				H.out("o79 " + a21);
			} else {
				var v80 = 138;
			}
		}
		(([299, 65535]).filter(v81 -> false)).ext26();
		return (Main.fn11(((a21).charCodeAt(274) ?? -1), E4.E4A) * Lambda.count(([] : Array<Int>), v82 -> StringTools.contains(a21, a21)));
	}
	public static function fn22(a23:String, a24:String):Int {
		H.tick();
		var v83:Int = (261 * Type.enumIndex(E0.E0A));
		for (i84 in 0...H.lim(((new Map<String, Int>()).get("k1") ?? 0))) {
			H.tick();
			var v85:Map<Int, String> = ([-3 => a23, 4 => a24, 11 => a24] : Map<Int, String>);
			if ((E0.E0C(v83)).match(E0C(_))) {
				v83++;
				H.out("o86 " + Std.string(true));
			}
			if (true) continue;
		}
		for (i87 in 0...0) {
			H.tick();
			final lf88:(String, Int) -> Int = (p89:String, p90:Int) -> (Std.parseInt(a24) ?? 0);
		}
		return Reflect.compare((switch (H.id([v83, v83, 252])) {
			case []: a23;
			case [c91]: ("a").toUpperCase();
			case [_, c92]: "";
			case _: a24;
		}), Std.string(v83));
	}
	public static function section0():Void {
		H.tick();
		var v171:E4 = E4.E4A;
		var v172:Float = ([81, 2146070131]).ext31();
		H.out("o173 " + Std.string((Std.parseInt(Std.string(62)) ?? 0)));
	}
	public static function section1():Void {
		H.tick();
		("ünï").ext29(fn17(false));
		if (true) {
			H.out("o174 " + Std.string((new A9(269) : Int)));
			fn11(([290, 129]).indexOf(242), E4.E4A);
			if (StringTools.endsWith("\n", "q")) {
				final v175 = 82;
			}
		}
		H.out("o176 " + Std.string(({x8: 236, x7: true, x6: false} : S5)));
		var v177 = Main.fn11((new A9(285)).twice, E4.E4A);
		if ((v177 >= v177)) {
			var v178:Null<Int> = v177;
		} else {
			function lf179(n180:Int):Int {
				H.tick();
				return n180 <= 0 ? (({x8: v177, x7: false, x6: false} : S5)).x8 : (lf179(n180 - 1) + Math.ceil(0.5));
			}
			H.out("lf179 " + lf179(3));
		}
		var v181:A9 = new A9(Lambda.count([v177, v177], v182 -> Math.isNaN(v182)));
		var v183:Array<Float> = ([v177, v177] : Array<Float>);
		H.out("o184 " + Std.string((["q", "é", "é"]).indexOf(Std.string(true))));
	}
	public static function section2():Void {
		H.tick();
		var v185:String = ({ var v186 = (-2.5); ("x,y,z").charAt((288 & 7)); });
		H.out("o187 " + Std.string(181));
		var v188 = (Math.isNaN(2.5e-3) && true);
		for (i189 in 0...H.lim(({ var v190 = 1e21; (({x6: true, x8: 45, x7: true} : S5)).x8; }))) {
			H.tick();
			var v191:Map<String, String> = new Map<String, String>();
			if (((["k0" => i189, "k1" => i189] : Map<String, Null<Int>>)).exists(v185)) continue;
		}
		var w192 = 0;
do {
			w192++;
			H.tick();
			H.out("o193 " + Std.string(0.5));
			if (v188) break;
		} while (w192 < 2 && ((v185).replace("a", "b") != Std.string(0.1)));
	}
	public static function section3():Void {
		H.tick();
		final lf194:(Int, Int) -> Int = (p195:Int, p196:Int) -> p195;
		final v197:Int = (true ? 164 : 70);
		H.out("o198 " + Std.string((cast (([] : Array<Int>)) : Array<Int>)));
		Main.fn15(true);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
