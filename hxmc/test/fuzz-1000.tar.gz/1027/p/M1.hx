package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

typedef S5 = {x6:Bool, x7:Bool, x8:Int};
