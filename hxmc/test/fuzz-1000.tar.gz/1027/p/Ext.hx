package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext26(a25:Array<Int>):Float {
		H.tick();
		var v93 = (-H.at(a25, 808529388, 0));
		try {
			if ((StringTools.hex((v93) & 0xFFFF, 4) < StringTools.lpad("x,y,z", "*", (v93 & 7)))) throw 83;
			if (StringTools.contains("\n", "a")) {
				var v94 = v93;
				H.out("o95 " + Std.string(false));
				final v96:Int = v93;
			} else {
				Main.fn14();
			}
			H.out("o97 " + Std.string(Math.PI));
			if ((a25).contains(v93)) return Std.parseFloat("");
		} catch (ex98:String) {
			H.out("caught String " + ex98);
			final lf99:(Bool) -> String = (p100:Bool) -> Std.string(false);
		} catch (ex101:Int) {
			H.out("caught Int " + ex101);
			final v102:Map<Int, String> = new Map<Int, String>();
		} catch (ex103:Err) {
			H.out("caught Err " + ex103.errCode);
			try {
				if (false) throw new Err((a25).indexOf(v93));
				H.out("o104 " + Std.string(true));
			} catch (ex105:Err) {
				H.out("caught Err " + ex105.errCode);
				a25.sort((x, y) -> x - y);
				final v106:S5 = ({x6: true, x7: false, x8: v93} : S5);
			} catch (ex107:haxe.Exception) {
				H.out("caught " + H.exn(ex107));
				var v108:Int = 112;
				var v109:Int = 68;
			}
		} catch (ex110:Dynamic) {
			H.out("caught " + H.exn(ex110));
			switch (E0.E0B(v93, v93)) {
				case E0A: {
					Main.fn14();
					var v111 = v93;
				};
				case E0B(_, c112): {
					H.out("o113 " + Std.string(false));
				};
				case E0C(2 | 4): {
					v93 = H.id(v93);
					var v114:E0 = E0.E0C(v93);
				};
				case _: {
					v93 = 160;
				};
			}
		}
		switch (({x6: ((["k0" => v93, "k1" => v93] : Map<String, Float>)).exists("k0"), x7: true, x8: (("q").charCodeAt(v93) ?? -1)} : S5)) {
			case {x6: true}: {
				v93 = (-15);
			};
			case {x6: c115}: {
				var v116:Int = v93;
			};
		}
		return (100.75 + v93);
	}
	public static function ext29(a27:String, a28:String):String {
		H.tick();
		H.out("o117 " + Std.string(Main.fn11(78, E4.E4A)));
		var v118:S5 = ((switch (E0.E0C(122)) {
			case E0A: ({x6: false, x7: false, x8: 80} : S5);
			case E0C(c119) if (c119 > 4): ({x6: true, x7: false, x8: 70} : S5);
			case _: ({x7: true, x8: 219, x6: false} : S5);
		}) : S5);
		final v120:Array<A9> = ([for (i121 in 0...4) new A9(i121)] : Array<A9>);
		final v122:A9 = new A9(Math.floor(123456.789));
		var v123:Map<Int, Float> = new Map<Int, Float>();
		try {
			var v124:Array<String> = ([] : Array<String>);
			if (!(([] : Array<Int>)).contains((-2147483647))) throw new Err(266);
		} catch (ex125:String) {
			H.out("caught String " + ex125);
			var v126:Float = 0.30000000000000004;
		} catch (ex127:Int) {
			H.out("caught Int " + ex127);
			try {
				if (([ex127, 65535]).contains(ex127)) throw StringTools.replace(a28, ",", "Haxe");
				H.out("o128 " + Std.string(ex127));
				var v129:Array<K10> = ([K10.K10A] : Array<K10>);
				Main.fn15(true);
			} catch (ex130:Err) {
				H.out("caught Err " + ex130.errCode);
				var v131:Map<String, String> = new Map<String, String>();
				v118 = H.id(v118);
			} catch (ex132:haxe.Exception) {
				H.out("caught " + H.exn(ex132));
				final v133:() -> Float = () -> ex127;
			}
			var v134:Array<Array<S5>> = ([([({x6: true, x7: false, x8: ex127} : S5), v118] : Array<S5>)] : Array<Array<S5>>);
		} catch (ex135:Err) {
			H.out("caught Err " + ex135.errCode);
			if (true) {
				var v136 = 220;
				var v137:S5 = v118;
			}
			try {
				H.out("o138 " + Std.string(117));
				if (false) throw "boom";
			} catch (ex139:Dynamic) {
				H.out("caught " + H.exn(ex139));
				var v140 = 236;
				var v141:Array<Int> = ([] : Array<Int>);
			}
		} catch (ex142:Dynamic) {
			H.out("caught " + H.exn(ex142));
			a28 = H.cap(a28);
			var v143 = (K10.K10A : Int);
		}
		var v144:E0 = E0.E0A;
		var v145:Int = (((new Map<Int, Int>()).get(11) ?? 0) * Reflect.compare(a28, a28));
		if ((100.75 != 3.0)) {
			Main.fn15(StringTools.endsWith(a27, a28));
			v145 += ((a28).charCodeAt(v145) ?? -1);
		}
		return ((switch ((a27).indexOf(a27)) {
			case 0: (v144).match(E0A);
			case 2 | 5: true;
			case _: ((["k0" => v145] : Map<String, Null<Int>>)).exists("k1");
		}) ? ("42").substr(6, ((v118).x8 & 7)) : a27);
	}
	public static function ext31(a30:Array<Int>):Float {
		H.tick();
		var v146:Float = 123456.789;
		var v147 = "a";
		switch (H.id([H.at(a30, 145, 0), (-7)])) {
			case []: {
				var v148:E0 = E0.E0A;
				H.out("o149 " + Std.string(false));
			};
			case [c150]: {
				final v151:Bool = (new Map<String, String>()).exists("ünï");
				Ext.ext29("ab", "ab");
			};
			case [_, c152]: {
				if (false) {
					H.out("o153 " + Std.string(c152));
					final v154:S5 = ({x6: true, x7: true, x8: c152} : S5);
				}
			};
			case _: {
				H.out("o155 " + Std.string(true));
				var v156:S5 = ({x6: false, x7: false, x8: 198} : S5);
			};
		}
		{
			H.out("o157 " + Std.string(Std.int(v146)));
			for (i158 in 0...3) {
				H.tick();
				H.out("o159 " + Std.string(198));
				var v160:Float = 100.75;
			}
			var v161 = 197;
		}
		var v162 = (true ? (v147).lastIndexOf("") : 0x35FF);
		try {
			H.out("o163 " + Std.string((K10.K10A : Int)));
			final v164:Array<Bool> = [false, false, false];
			H.out("o165 " + v147);
			if ((false || (new Map<String, Int>()).exists("k2"))) throw new Err(Main.fn11(v162, E4.E4A));
		} catch (ex166:Dynamic) {
			H.out("caught " + H.exn(ex166));
			var v167:Int = ("\x41\x42").length;
		}
		var v168:String = (([] : Array<Bool>)).join("");
		var v169:Array<Float> = ([] : Array<Float>);
		H.out("o170 " + Std.string(v146));
		return (((switch (Std.string(154)) {
			case "a" | "b": false;
			case "Haxe": (E0.E0B((-2), v162)).match(E0A);
			case _: StringTools.startsWith(v147, "x,y,z");
		}) ? Main.fn14() : Main.fn14()) : Float);
	}
}
