import H;

enum E0 {
	E0A;
	E0B;
}

enum E2 {
	E2A;
	E2B(a4:E2);
}

enum E5 {
	E5A;
}

typedef S6 = {x7:Int, x8:Bool, x9:Int};

abstract A10(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A10, b:A10):A10
		return new A10(a.get() + b.get());

	@:op(A * B) public static function mul(a:A10, b:A10):A10
		return new A10(a.get() * b.get());

	@:op(-A) public static function neg(a:A10):A10
		return new A10(-a.get());
}

enum abstract K11(Int) to Int {
	var K11A = 1;
	var K11B = 4;
	var K11C = 7;
}

interface I12 {
	function m13(a14:Int):Int;
}

interface I15 {
	function m16(a17:Int):Int;
}

abstract class C18 {
	public static var f19:Bool = true;
	public var f20:String;
	public final f21:Bool;
	public var cb22:(Int) -> Int;
	public function new() {
		this.f20 = Std.string(true);
		this.f21 = C18.f19;
		this.cb22 = (p90:Int) -> 126;
	}
	public function m23(?a24:Null<Int>):Void {
		H.tick();
		for (i91 in 0...H.lim(0x80000000)) {
			H.tick();
			for (i92 in 0...H.lim(i91)) {
				H.tick();
				H.out("o93 " + "Haxe");
				H.out("o94 " + Std.string(i92));
				var v95:Array<Int> = [i92, i92, i91];
			}
		}
		H.out("o96 " + Std.string((((["k0" => 160, "k1" => 65] : Map<String, Int>)).get("k3") ?? 0)));
		if ((44 <= 23)) {
			for (k97 => v98 in (["k0" => 248, "k1" => 76] : Map<String, Int>)) {
				H.tick();
				var v99 = v98;
				v99 *= v98;
			}
		} else {
			for (i100 in 0...2) {
				H.tick();
				H.out("o101 " + Std.string(0x7FFFFFFF));
				var v102:Array<Bool> = ([] : Array<Bool>);
			}
			for (i103 in 1...4) {
				H.tick();
				var v104 = i103;
			}
		}
		H.out("o105 " + Std.string(({x7: (Std.parseInt("  pad  ") ?? 0), x8: false, x9: Type.enumIndex(E0.E0B)} : S6)));
		var v106:Array<Int> = [215, (Std.parseInt(Std.string(133)) ?? 0)];
		for (k107 => v108 in new Map<String, Int>()) {
			H.tick();
			var v109 = (Std.parseInt("abc") ?? 0);
		}
		var v110:S6 = ({x9: (K11.K11C : Int), x7: (({x7: 0xD673, x8: true, x9: 53} : S6)).x9, x8: true} : S6);
		H.out("o111 " + Std.string(182));
		H.out("o112 " + (v106).join(" "));
	}
	public static function m25(a26:Int, ?a27:Null<Bool>):Array<Int> {
		H.tick();
		H.out("o113 " + Std.string(E5A));
		for (x114 in ["  pad  ", "hello world", "x,y,z"]) {
			H.tick();
			H.out("o115 " + Std.string(new C36()));
			final v116 = Reflect.compare(a26, 39);
			H.out("o117 " + Std.string(v116));
		}
		var v118:K11 = K11.K11B;
		H.out("o119 " + Std.string(([a26, 44, a26]).indexOf(a26)));
		for (i120 in 0...H.lim(H.at([a26, (-8), a26], a26, 0))) {
			H.tick();
			for (k122 => x121 in [106, i120]) {
				H.tick();
				a26 += k122;
				var v123:Bool = true;
			}
			a26 = i120;
			a26 = H.id(a26);
		}
		{
			final v124:() -> Bool = () -> true;
			var v125:Bool = true;
			H.out("o126 " + Std.string((-9)));
		}
		var v127:Array<E5> = ([for (i128 in 0...0) E5.E5A] : Array<E5>);
		if ((false || C18.f19)) {
			Main.fn67(Reflect.compare(198, 282), a26);
		}
		var v129 = !true;
		return Main.fn64((v129 && false), false);
	}
	public function m28():Void {
		H.tick();
		var v130 = Lambda.fold(([] : Array<Int>), (v131:Int, v132:Int) -> ([v131, 8, v132]).indexOf(v131), 0);
		var v133 = ((K11.K11B : Int) % H.nz(v130));
		final v134:Map<Int, Int> = new Map<Int, Int>();
		var v135:Map<String, Int> = (["k0" => v130] : Map<String, Int>);
		v133 *= (({x7: 6, x8: false, x9: v133} : S6)).x9;
		if (Main.fn55()) {
			for (i136 in 2...6) {
				H.tick();
				H.out("o137 " + Std.string(0xFFFFFFFF));
				H.out("o138 " + Std.string(E2.E2A));
				Main.fn56(5, v130, i136);
			}
		}
		if (((v134).exists(11) || false)) {
			H.out("o139 " + Std.string((Std.parseInt(Std.string(149)) ?? 0)));
		} else {
			var v140:C18 = new C45();
			var v141:I12 = new C45();
		}
	}
	public function m29():String {
		H.tick();
		var v142:E2 = E2.E2B(E2.E2A);
		final v143:Array<Int> = (([] : Array<Int>)).filter(v144 -> false);
		final v145 = 194;
		{
			if (false) {
				H.out("o146 " + Std.string(true));
				var v147:A10 = new A10(82);
				H.out("o148 " + Std.string(new C45()));
			} else {
				final v149 = v145;
			}
			H.out("o150 " + Std.string(({x7: 52, x8: true, x9: 41} : S6)));
		}
		H.out("o151 " + Std.string((({x8: false, x7: 107, x9: 0x5BD8} : S6)).x9));
		var v152:I12 = Main.fn59();
		return (new C30((-2147483647))).m35();
	}
}

class C30 implements I12 {
	public var f31:Int;
	public function new(a32:Int) {
		this.f31 = (K11.K11C : Int);
	}
	public function m13(a14:Int):Int {
		H.tick();
		final v153 = a14;
		if ((switch (0xC636) {
			case 0: false;
			case 1 | 4: C18.f19;
			case _: C18.f19;
		})) {
			for (i154 in 0...H.lim(this.f31)) {
				H.tick();
				H.out("o155 " + Std.string(E2.E2A));
			}
		}
		var v156 = this.f31;
		var v157 = Main.fn55();
		for (k158 => v159 in ({ var v160 = a14; new Map<String, Int>(); })) {
			H.tick();
			var v161:C45 = new C45();
			++v156;
		}
		for (i162 in 0...4) {
			H.tick();
			{
				var v163:S6 = ({x7: a14, x8: false, x9: 86} : S6);
				var v164:S6 = ({x7: v153, x8: v157, x9: 0x62E} : S6);
				var v165 = a14;
			}
		}
		var v166:S6 = ({x8: v157, x9: v153, x7: (Std.parseInt(Std.string(v153)) ?? 0)} : S6);
		return (cast (([v156, a14, v156]).indexOf(0xEF2D)) : Int);
	}
	public function m33():Void {
		H.tick();
		var v167 = (new C45()).m47();
		var v168 = this.f31;
		final v169 = (switch (E0.E0A) {
			case E0A: Type.enumIndex(E0.E0B);
			case E0B: Reflect.compare(v167, v168);
		});
		var v170:Int = this.f31;
		var v171:Array<String> = (cast (["42"]) : Array<String>);
		if ((v168 < v169)) {
			var v172:C36 = new C36();
		} else {
			final v173:C30 = new C36();
			if (true) {
				v167 = v168;
			} else {
				v168 += v168;
				final v174:Int = v169;
			}
		}
		{ var dyn175:Dynamic = ({x7: 312815244, x8: false, x9: (({x7: v169, x9: v168, x8: false} : S6)).x9} : S6); H.out("dyn " + Std.string(dyn175.x7) + " " + Std.string(Reflect.field(dyn175, "x7"))); }
	}
	public function m34():Int {
		H.tick();
		Main.fn59();
		H.out("o176 " + Std.string((new C45()).m47()));
		var v177:E2 = E2.E2A;
		final v178:Int = H.at(([] : Array<Int>), Reflect.compare((-2055297347), 165), 0);
		var v179 = (v178 >= v178);
		this.f31 *= 65535;
		for (i180 in 0...4) {
			H.tick();
			var v181 = true;
			var v182:Array<Int> = [v178];
			var v183 = (["hello world"]).length;
		}
		final v184:E0 = E0.E0B;
		return v178;
	}
	public function m35():String {
		H.tick();
		var v185:E2 = E2B(E2A);
		var v186:Map<Int, Int> = ([-3 => 1443233453] : Map<Int, Int>);
		H.out("o187 " + Std.string(new C36()));
		var v188:Int = (Std.parseInt(Std.string(179)) ?? 0);
		final v189:() -> Int = function():Int {
			H.tick();
			H.out("o190 " + Std.string(46));
			return v188;
		};
		H.out("o191 " + Std.string(({x9: 26, x8: ([v188]).contains(112), x7: this.f31} : S6)));
		return (Std.string(false) + Std.string(this.f31));
	}
}

class C36 extends C30 implements I12 {
	public var cb37:(Int) -> Int;
	public function new() {
		super((Std.parseInt("0") ?? 0));
		this.cb37 = function(p192:Int):Int {
			H.tick();
			var v193:K11 = K11.K11A;
			return p192;
		};
	}
	override public function m13(a14:Int):Int {
		H.tick();
		switch (K11.K11A) {
			case K11.K11A: {
				var v194:C36 = new C36();
				final v195:(Bool, Int) -> Bool = (p196:Bool, p197:Int) -> p196;
			};
			case K11.K11B: {
				var v198:C18 = new C45();
				var w199 = 0;
while (w199 < 3 && (new Map<Int, Bool>()).exists(-3)) {
					w199++;
					H.tick();
					var v200:Map<String, Int> = (["k0" => a14] : Map<String, Int>);
					H.out("o201 " + Std.string(({x8: false, x9: 0xB9E7, x7: 142} : S6)));
					var v202:Int = 79;
				}
			};
			case K11.K11C: {
				var v203:Bool = ([214]).contains(171);
				v203 = H.id(v203);
			};
		}
		if ((50 < a14)) {
			var v204 = (((["k0" => 296, "k1" => 249, "k2" => a14] : Map<String, Int>)).get("k2") ?? 0);
			var v205:S6 = ({x7: v204, x8: true, x9: a14} : S6);
			var v206 = (Std.downcast((new C45() : C18), C45) != null);
		} else {
			var v207:Bool = false;
			H.out("o208 " + Std.string(133));
		}
		Main.fn67(a14);
		var v209 = this.f31;
		switch (v209) {
			case 0: {
				C18.f19 = true;
			};
			case 1 | 5: {
				switch (E5.E5A) {
					case E5A: {
						var v210 = false;
					};
				}
				{
					this.f31--;
					this.m41(a14, false);
				}
			};
			case _: {
				var v211:Map<Int, Int> = ([-3 => v209, 4 => v209] : Map<Int, Int>);
				var w212 = 0;
while (w212 < 2 && false) {
					w212++;
					H.tick();
					(new C45()).m53(([] : Array<Bool>));
				}
			};
		}
		var v213 = ((new Map<Int, E5>()).exists(a14) || false);
		Main.fn59();
		H.out("o214 " + Std.string(((v213 ? new C45() : new C45()) : C45)));
		(new C45()).m47();
		return this.f31;
	}
	override public function m34():Int {
		H.tick();
		switch ((H.at([61, 0xBC50], 430941072, 0) - 101)) {
			case 0: {
				var w215 = 0;
while (w215 < 3 && C18.f19) {
					w215++;
					H.tick();
					this.f31 *= (-13);
					final v216:C45 = new C45();
				}
			};
			case 3 | 6: {
				(new C45()).m23(248);
			};
			case _: {
				for (i217 in 0...H.lim(([0x17CD]).length)) {
					H.tick();
					++this.f31;
					(new C45()).m28();
				}
				final v218 = 65535;
			};
		}
		switch (E2.E2B(E2A)) {
			case E2A: {
				{
					Main.fn55();
					this.m35();
				}
			};
			case E2B(_): {
				for (i219 in 0...H.lim(this.f31)) {
					H.tick();
					H.out("o220 " + Std.string(E5.E5A));
					this.f31 = i219;
					var v221:Map<String, Int> = new Map<String, Int>();
				}
				for (k223 => x222 in [208, 0x70E4]) {
					H.tick();
					var v224:C36 = new C36();
				}
			};
		}
		(new C45()).m23((new A10(1315902527)).twice);
		return this.f31;
	}
	public function m38(a39:Int, a40:Int):Int {
		H.tick();
		var v225 = (a39 = 5);
		var v226:E5 = E5.E5A;
		final v227:Map<String, Bool> = ((switch (K11.K11B) {
			case K11.K11A: (["k0" => true, "k1" => false, "k2" => false] : Map<String, Bool>);
			case K11.K11B: new Map<String, Bool>();
			case K11.K11C: (["k0" => true, "k1" => false] : Map<String, Bool>);
			case _: new Map<String, Bool>();
		}) : Map<String, Bool>);
		(new C45()).m28();
		final v228:Int = Lambda.fold([a39], (v229:Int, v230:Int) -> 168, 0);
		a40 *= (278 + Reflect.compare(a39, v228));
		Main.fn67(((new Map<Int, Int>()).get(-3) ?? 0), (-0xA527));
		return a40;
	}
	public function m41(a42:Int, a43:Bool):Bool {
		H.tick();
		var w231 = 0;
while (w231 < 5 && C18.f19) {
			w231++;
			H.tick();
			(new C45()).m23(Reflect.compare(a42, a42));
			if ((([] : Array<Int>)).contains(a42)) {
				H.out("o232 " + Std.string(true));
				final v233:(Int, Bool) -> Bool = (p234:Int, p235:Bool) -> p235;
			} else {
				var v236:E0 = E0B;
			}
		}
		var v237:Map<String, Int> = (["k0" => (new A10(a42)).twice, "k1" => 221] : Map<String, Int>);
		H.out("o238 " + Std.string(151));
		final v239:Map<Int, Int> = ((false ? new Map<Int, Int>() : ([-3 => a42] : Map<Int, Int>)) : Map<Int, Int>);
		var v240:E0 = E0.E0A;
		final v241:Int = (a42 * a42);
		var v242:Array<Int> = ([280, v241]).copy();
		return (a43 ? (switch (E2A) {
			case E2A: a43;
			case E2B(c243): true;
		}) : C18.f19);
	}
	public function m44():Array<Int> {
		H.tick();
		if ((this.f31 >= 260)) {
			var v244:Array<Int> = ([] : Array<Int>);
		} else {
			this.f31 *= 226;
		}
		var v245:S6 = ({x7: (({x8: true, x7: 287, x9: 1925039184} : S6)).x7, x8: true, x9: H.at(([] : Array<Int>), 24, 0)} : S6);
		var v246:Int = (154 + (Std.parseInt(Std.string(0x2841)) ?? 0));
		return [for (i247 in 0...3) i247];
	}
}

class C45 extends C18 implements I12 {
	public var cb46:(Int) -> Int;
	public function new() {
		super();
		this.cb46 = function(p248:Int):Int {
			H.tick();
			var v249:Int = 42;
			return p248;
		};
	}
	public function m13(a14:Int):Int {
		H.tick();
		final v250 = (Lambda.fold(([] : Array<Int>), (v251:Int, v252:Int) -> H.at(([] : Array<Int>), v251, 0), 0) * a14);
		final v253:E5 = E5A;
		switch ((261 > (++a14))) {
			case true: {
				var w254 = 0;
while (w254 < 5 && (([-3 => E2A, 4 => E2.E2A, 11 => E2A] : Map<Int, E2>)).exists(-3)) {
					w254++;
					H.tick();
					m23((-12));
					var v255 = true;
				}
			};
			case false: {
				switch (a14) {
					case 0: {
						H.out("o256 " + Std.string(a14));
					};
					case 3 | 4: {
						var v257:C30 = new C36();
						var v258:Array<K11> = ([] : Array<K11>);
					};
					case _: {
						H.out("o259 " + Std.string(((v250 : A10) : Int)));
						final v260:K11 = K11.K11A;
					};
				}
				H.out("o261 " + Std.string(v250));
			};
		}
		H.out("o262 " + Std.string(([for (i263 in ([] : Array<Int>)) if (false) new C45()] : Array<C45>)));
		final v264:C36 = new C36();
		var v265:Int = m47();
		if (this.f21) {
			var v266:Int = (-287429629);
			H.out("o267 " + Std.string([a14]));
		} else {
			var v268:Array<C30> = ([new C36()] : Array<C30>);
			H.out("o269 " + Std.string(Lambda.fold([v265, 7, 273], (v270:Int, v271:Int) -> ((new Map<String, Int>()).get("k3") ?? 0), 0)));
		}
		var v272:Map<String, (Int) -> Int> = (["k0" => (p273:Int) -> p273, "k1" => (p274:Int) -> a14, "k2" => function(p275:Int):Int {
			H.tick();
			var v276:Map<String, Int> = (["k0" => v265] : Map<String, Int>);
			return p275;
		}] : Map<String, (Int) -> Int>);
		return v250;
	}
	override public function m23(?a24:Null<Int>):Void {
		H.tick();
		var v277:Int = (115 + (-14));
		for (i278 in 0...H.lim(v277)) {
			H.tick();
			var v279:E2 = E2A;
		}
		var v280 = v277;
		var v281:Array<Int> = [for (i282 in 0...0) 0x80000000];
		final v283:Map<String, Int> = ({ var v284 = (K11.K11A : Int); (["k0" => v284] : Map<String, Int>); });
	}
	override public function m28():Void {
		H.tick();
		var w285 = 0;
do {
			w285++;
			H.tick();
			H.out("o286 " + Std.string(1547997820));
		} while (w285 < 2 && (new C36()).m41(([80, 70, 87]).length, (([-3 => new C30(134), 4 => new C45(), 11 => new C45()] : Map<Int, I12>)).exists(18)));
		for (x287 in ([1828430446, 233]).map((v288:Int) -> v288)) {
			H.tick();
			if (false) continue;
		}
		{
			var v289 = 64;
		}
		H.out("o290 " + Std.string(257));
		var v291:Array<Int> = C18.m25((-2147483647));
		C18.f19 = (new C36()).m41((Std.parseInt(Std.string(272)) ?? 0), true);
		switch (E5A) {
			case E5A: {
				final v292:E2 = E2A;
				var v293:A10 = ((-14) : A10);
			};
		}
	}
	public function m47():Int {
		H.tick();
		var v294:A10 = new A10(H.at([0x7FFFFFFF], 9, 0));
		switch (K11.K11B) {
			case K11.K11A: {
				final v295:(Bool) -> Int = (p296:Bool) -> 281;
			};
			case K11.K11B: {
				switch (K11.K11A) {
					case K11.K11A: {
						var v297 = false;
					};
					case K11.K11B: {
						var v298:E2 = E2.E2A;
					};
					case K11.K11C: {
						(new C30(196)).m35();
						H.out("o299 " + Std.string(false));
					};
				}
			};
			case K11.K11C: {
				{ var dyn300:Dynamic = ({x8: false, x9: (-638411731), x7: 868055239} : S6); H.out("dyn " + Std.string(dyn300.x7) + " " + Std.string(Reflect.field(dyn300, "x7"))); }
			};
			case _: {
				var v301 = ([249, 290]).indexOf(253);
				switch (E0B) {
					case E0A: {
						H.out("o302 " + Std.string(new C36()));
						H.out("o303 " + Std.string(E5.E5A));
					};
					case E0B: {
						v301++;
					};
				}
			};
		}
		H.out("o304 " + Std.string(((false ? new C45() : new C45()) : C45)));
		H.out("o305 " + Std.string((([0x1D81, 96]).indexOf(76) > Type.enumIndex(E0.E0B))));
		(new C36()).m35();
		switch (E5A) {
			case E5A: {
				for (i306 in 0...0) {
					H.tick();
					var v307 = true;
					(new C36()).m41(i306, v307);
				}
			};
		}
		return (((Std.parseInt(Std.string(192)) ?? 0) + 186) % H.nz(1631589481));
	}
	public function m48(a49:Int):Int {
		H.tick();
		var v308:Map<String, Int> = new Map<String, Int>();
		final v309:() -> Int = () -> (a49 -= 1);
		H.out("o310 " + "-7");
		a49 = H.id(a49);
		var v311 = a49;
		(new C36()).m13(v311);
		return (cast ((new C30(a49)).m34()) : Int);
	}
	public static function m50(a51:Int, a52:Int):Void {
		H.tick();
		H.out("o312 " + Std.string(({x7: (K11.K11A : Int), x9: Reflect.compare(a51, 161), x8: (([] : Array<Int>)).contains(a51)} : S6)));
		var v313 = a51;
		H.out("o314 " + Std.string(false));
	}
	public function m53(a54:Array<Bool>):Void {
		H.tick();
		m23();
		(new C45()).m47();
		final v315:(Bool, Bool) -> String = (p316:Bool, p317:Bool) -> "a";
	}
}

class Main {
	public static function fn55():Bool {
		H.tick();
		{
			var v318:Map<String, Int> = new Map<String, Int>();
		}
		for (k320 => x319 in [([252, 112, 37]).length]) {
			H.tick();
			switch (Type.enumIndex(E0.E0B)) {
				case 0: {
					var v321:Map<Int, Int> = new Map<Int, Int>();
				};
				case 3 | 5: {
					final v322:(Bool) -> Int = (p323:Bool) -> x319;
				};
				case _: {
					final v324:Map<String, E2> = new Map<String, E2>();
					var v325:E2 = E2.E2A;
				};
			}
			var v326:Int = 77;
		}
		(new C36()).m41((new C45()).m47(), (switch (0x7FFFFFFF) {
			case 0: Std.isOfType(new C36(), C30);
			case 3 | 4: ([37, 225]).contains(270);
			case _: true;
		}));
		(new C45()).m47();
		H.out("o327 " + Std.string((((([-3 => new C45(), 4 => new C45()] : Map<Int, C45>)).exists(11) ? ({x7: (-18), x8: true, x9: 0x80000000} : S6) : ({x7: 1800738932, x8: true, x9: (-1069850225)} : S6)) : S6)));
		return ([261]).contains(((296 : A10)).twice);
	}
	public static inline function fn56(a57:Int, ...r58:Int):Int {
		H.tick();
		if (C18.f19) {
			var v328:Map<Int, S6> = new Map<Int, S6>();
		}
		final v329:S6 = ({x9: 1308872918, x8: (r58.toArray()).contains(a57), x7: (({x9: a57, x7: 95, x8: false} : S6)).x9} : S6);
		(new C45()).m23((new C45()).m47());
		H.out("o330 " + Std.string((new C45()).m47()));
		switch (a57) {
			case 0: {
				H.out("o331 " + Std.string(((a57 : A10)).get()));
			};
			case 2 | 5: {
				if (false) {
					var v332:A10 = new A10(44);
				}
			};
			case _: {
				var w333 = 0;
while (w333 < 2 && (r58.toArray()).contains((-7))) {
					w333++;
					H.tick();
					a57 = 277;
					var v334:K11 = K11.K11C;
				}
			};
		}
		H.out("o335 " + Std.string((-a57)));
		for (i336 in 0...H.lim((((["k0" => a57, "k1" => a57] : Map<String, Int>)).get("Haxe") ?? 0))) {
			H.tick();
			for (i337 in 0...4) {
				H.tick();
				var v338:Int = i337;
				(new C45()).m23();
			}
		}
		for (i339 in 1...4) {
			H.tick();
			H.out("o340 " + Std.string((r58.toArray()).contains(i339)));
		}
		return 142;
	}
	public static function fn59():I12 {
		H.tick();
		var v341:Bool = (Lambda.fold([140], (v342:Int, v343:Int) -> 0xEE5C, 0) < 150);
		H.out("o344 " + Std.string(((true ? E2.E2A : E2A) : E2)));
		for (x345 in ({ var v346 = Type.enumIndex(E0A); ([] : Array<String>); })) {
			H.tick();
			(new C30(187)).m35();
			for (x347 in [v341, v341, v341]) {
				H.tick();
				fn56(213, 108106830, 277);
				var v348 = x347;
				var v349:Array<Map<String, Bool>> = ([] : Array<Map<String, Bool>>);
			}
		}
		var v350 = (H.at([168, 0x7FFFFFFF], (-306042419), 0) * 119);
		return new C36();
	}
	public static function fn60(a61:String, a62:Int, a63:Bool = true):E2 {
		H.tick();
		var w351 = 0;
while (w351 < 2 && C18.f19) {
			w351++;
			H.tick();
			switch (E2A) {
				case E2A: {
					H.out("o352 " + Std.string((K11.K11A : Int)));
					var v353:S6 = ({x9: a62, x8: a63, x7: (-782984629)} : S6);
				};
				case _: {
					var v354:Array<Bool> = [a63, false];
				};
			}
		}
		(new C36()).m41((switch (E5A) {
			case E5A: 0x442D;
			case _: (({x7: a62, x8: a63, x9: a62} : S6)).x9;
		}), (a62 <= a62));
		var v355:S6 = ({x8: a63, x9: Lambda.fold([a62, 30, a62], (v356:Int, v357:Int) -> 15, 0), x7: 0xE31} : S6);
		a62 += a62;
		var w358 = 0;
do {
			w358++;
			H.tick();
			a62 = 26;
			{
				final v359:(Bool, String) -> Int = (p360:Bool, p361:String) -> a62;
			}
		} while (w358 < 4 && true);
		return E2A;
	}
	public static function fn64(a65:Bool, a66:Bool):Array<Int> {
		H.tick();
		var v362:C18 = new C45();
		fn56((-(K11.K11A : Int)));
		var v363:E2 = E2B(E2.E2A);
		(new C45()).m47();
		for (x364 in (cast ([a65]) : Array<Bool>)) {
			H.tick();
			final v365:C36 = new C36();
			var v366:C18 = new C45();
		}
		var w367 = 0;
do {
			w367++;
			H.tick();
			for (x368 in [78, 113]) {
				H.tick();
				fn60("  pad  ", 108, false);
				H.out("o369 " + Std.string(v363));
				H.out("o370 " + Std.string(x368));
			}
			fn59();
			for (k372 => x371 in [156, (-13)]) {
				H.tick();
				final v373:Bool = false;
			}
		} while (w367 < 4 && a66);
		return ((([] : Array<Int>)).concat([0x1160, 159])).map((v374:Int) -> v374);
	}
	public static function fn67(a68:Int, ...r69:Int):Int {
		H.tick();
		for (i375 in 0...3) {
			H.tick();
			for (i376 in 0...H.lim((({x8: true, x9: 184, x7: a68} : S6)).x7)) {
				H.tick();
				final v377:(Int) -> Bool = function(p378:Int):Bool {
					H.tick();
					var v379 = a68;
					var v380:Int = 554267225;
					return true;
				};
			}
			if (C18.f19) {
				(new C36()).m41((-13), true);
				H.out("o381 " + Std.string(true));
			}
		}
		H.out("o382 " + Std.string(((((["k0" => a68, "k1" => a68] : Map<String, Int>)).get("k0") ?? 0) % H.nz(0x46CB))));
		H.out("o383 " + Std.string((({x7: (-944706003), x8: false, x9: 1533407838} : S6)).x9));
		if (C18.f19) {
			final v384:(Int) -> Int = (p385:Int) -> a68;
			var v386:E2 = E2A;
		}
		return (new C45()).m47();
	}
	public static function fn70(a71:Int, a72:Map<String, C30>, a73:Array<Int>):Void {
		H.tick();
		a71 = (-(++a71));
		final v387:Map<Int, Int> = ([-3 => 253, 4 => a71, 11 => H.at([a71, 147, a71], a71, 0)] : Map<Int, Int>);
		for (i388 in 2...H.lim(a71)) {
			H.tick();
			final v389:Int = a71;
		}
	}
	public static function fn74(a75:C18, a76:Array<Int>):Void {
		H.tick();
		var v390 = (new C45()).m47();
		if ((v390 >= v390)) {
			for (k391 => v392 in new Map<String, Int>()) {
				H.tick();
				var v393:C45 = new C45();
				v390 = v392;
			}
			for (i394 in 0...H.lim(192)) {
				H.tick();
				H.out("o395 " + Std.string(new C30(i394)));
				H.out("o396 " + '$$');
				H.out("o397 " + Std.string(i394));
			}
		}
		{
			for (x398 in [63, v390, (-636031041)]) {
				H.tick();
				H.out("o399 " + Std.string(({x7: x398, x8: false, x9: x398} : S6)));
			}
		}
		var v400:K11 = K11.K11B;
		v390 = 0x87CC;
		{ var dyn401:Dynamic = ({x7: (-2056403078), x8: false, x9: 230} : S6); H.out("dyn " + Std.string(dyn401.x7) + " " + Std.string(Reflect.field(dyn401, "x7"))); }
		var w402 = 0;
while (w402 < 5 && false) {
			w402++;
			H.tick();
			switch (v400) {
				case K11.K11A: {
					v390 += v390;
					H.out("o403 " + Std.string(E0.E0A));
				};
				case K11.K11B: {
					var v404:Int = v390;
				};
				case K11.K11C: {
					H.out("o405 " + Std.string((v400 : Int)));
					(new C36()).m34();
				};
			}
			if (false) {
				var v406:C45 = new C45();
				fn56(v390);
			}
			H.out("o407 " + Std.string(true));
		}
		var v408:Array<Bool> = (([] : Array<Int>)).map((v409:Int) -> false);
	}
	public static function fn77(a78:Int, a79:Bool, a80:E5):C30 {
		H.tick();
		for (i410 in 0...1) {
			H.tick();
			if (a79) {
				var v411:Array<Int> = [a78, i410];
				H.out("o412 " + Std.string(i410));
				a78 = H.id(a78);
			} else {
				(new C36()).m34();
			}
			H.out("o413 " + Std.string(({x8: a79, x7: a78, x9: i410} : S6)));
			var v414 = a78;
		}
		H.out("o415 " + Std.string(a79));
		(new C45()).m47();
		H.out("o416 " + Std.string((([new A10(48), new A10(a78), new A10(a78)] : Array<A10>)).filter(v417 -> true)));
		switch (((new Map<Int, Int>()).get(4) ?? 0)) {
			case 0: {
				for (i418 in 0...H.lim(23)) {
					H.tick();
					H.out("o419 " + Std.string(i418));
				}
			};
			case 2 | 6: {
				var w420 = 0;
while (w420 < 4 && true) {
					w420++;
					H.tick();
					var v421:C30 = new C30(147);
					var v422 = a79;
					final v423:E2 = E2.E2A;
				}
				H.out("o424 " + Std.string(({x7: a78, x8: true, x9: 12} : S6)));
			};
			case _: {
				a78 = ((new Map<String, Int>()).get("k1") ?? 0);
			};
		}
		return new C30((a78 % H.nz(a78)));
	}
	public static function fn81(...r82:Int):Void {
		H.tick();
		H.out("o425 " + (new C45()).m29());
		var v426:C30 = new C36();
		H.out("o427 " + Std.string(((({x7: 0x747C, x8: false, x9: 224} : S6)).x7 <= Type.enumIndex(E0B))));
		H.out("o428 " + Std.string(((K11.K11B : Int) % H.nz(Type.enumIndex(E5A)))));
		var v429:K11 = K11.K11A;
		H.out("o430 " + Std.string(({x7: (-1742797716), x8: (r82.toArray()).contains(32), x9: (new A10(45) : Int)} : S6)));
		H.out("o431 " + Std.string(new C36()));
		{ var dyn432:Dynamic = ({x7: (((["k0" => 115] : Map<String, Int>)).get("\t") ?? 0), x8: (r82.toArray()).contains(143), x9: ((69 : A10) : Int)} : S6); H.out("dyn " + Std.string(dyn432.x7) + " " + Std.string(Reflect.field(dyn432, "x7"))); }
		var v433:Map<String, Int> = ((false ? (["k0" => (-7), "k1" => 126, "k2" => 131] : Map<String, Int>) : (["k0" => 44, "k1" => 0xFFFFFFFF, "k2" => 290] : Map<String, Int>)) : Map<String, Int>);
	}
	public static function fn83(a84:Int, a85:Int, a86:Bool):Int {
		H.tick();
		(new C36()).m41((a85 = 5), a86);
		var v434:C36 = new C36();
		for (i435 in 0...H.lim(a85)) {
			H.tick();
			var v436:Int = 241;
			a85 = a84;
			final v437:E2 = E2.E2A;
		}
		var v438:C36 = v434;
		return a84;
	}
	public static function fn87(a88:Int, a89:Bool):Void {
		H.tick();
		H.out("o439 " + Std.string(292));
		var v440:I12 = new C36();
		var v441:I12 = new C36();
		H.out("o442 " + Std.string(false));
		if (Main.fn55()) {
			a88 *= (([] : Array<Int>)).indexOf(112);
			Main.fn81((new A10(a88)).get());
		} else {
			(new C45()).m48(a88);
			H.out("o443 " + Std.string((-9)));
		}
	}
	public static function section0():Void {
		H.tick();
		var v444:A10 = new A10(((63 : A10) : Int));
		switch (E2B(E2A)) {
			case E2A: {
				for (x445 in [0xFFFFFFFF, 104, 0xE445]) {
					H.tick();
					var v446:E0 = E0.E0B;
					(new C36()).m38(x445, x445);
				}
			};
			case E2B(c447): {
				(new C45()).m28();
			};
			case _: {
				var v448 = true;
			};
		}
		for (i449 in 0...3) {
			H.tick();
			{ var dyn450:Dynamic = ({x7: i449, x9: 0xFFFFFFFF, x8: true} : S6); H.out("dyn " + Std.string(dyn450.x7) + " " + Std.string(Reflect.field(dyn450, "x7"))); }
			for (i451 in 0...2) {
				H.tick();
				var v452:C30 = new C36();
				C45.m50(i449, i449);
			}
			for (i453 in 0...H.lim(0xFFFFFFFF)) {
				H.tick();
				var v454:Array<Bool> = [true];
				var v455:Bool = false;
				var v456 = i449;
			}
		}
		for (i457 in 1...4) {
			H.tick();
			(new C45()).m47();
			if (false) {
				var v458:E5 = E5.E5A;
			} else {
				var v459 = i457;
			}
		}
		var v460 = (((["k0" => E0.E0B, "k1" => E0.E0A] : Map<String, E0>)).exists("A-B-C") ? H.at([91], 272, 0) : 251);
		H.out("o461 " + Std.string((-1174611671)));
		for (i462 in 0...4) {
			H.tick();
			var v463 = 0xF5C1;
			var v464:Array<Bool> = [false];
		}
		final v465:Array<Int> = [for (i466 in [3]) if (false) Reflect.compare(v460, 173)];
	}
	public static function section1():Void {
		H.tick();
		H.out("o467 " + Std.string(({x7: 44, x9: (({x7: 65535, x8: true, x9: 122} : S6)).x7, x8: true} : S6)));
		for (x468 in [false, true]) {
			H.tick();
			var v469 = (K11.K11C : Int);
			H.out("o470 " + Std.string(H.at(([] : Array<Int>), v469, 0)));
			var v471 = v469;
		}
		H.out("o472 " + Std.string(E2A));
		var v473:E2 = E2.E2B(E2.E2A);
		switch (K11.K11A) {
			case K11.K11A: {
				var v474:I12 = new C45();
			};
			case K11.K11B: {
				var v475:Map<String, String> = new Map<String, String>();
			};
			case K11.K11C: {
				H.out("o476 " + Std.string(false));
				var v477:K11 = K11.K11C;
			};
			case _: {
				var v478:C36 = new C36();
			};
		}
		H.out("o479 " + Std.string((cast ((([] : Array<Int>)).length) : Int)));
		var v480:S6 = ({x9: 211, x8: ([28]).contains(275), x7: (new A10(200) : Int)} : S6);
		var v481:Array<Bool> = ((false ? [true, true, true] : [false]) : Array<Bool>);
		var v482 = ((Std.downcast((new C45() : C18), C45) != null) ? 60 : (new A10(6)).get());
	}
	public static function section2():Void {
		H.tick();
		H.out("o483 " + Std.string((([] : Array<Int>)).map((v484:Int) -> (E2A : E2))));
		fn74(new C45(), [for (i485 in 0...0) i485]);
		switch (E0.E0A) {
			case E0A: {
				var v486:Bool = ([121, 176]).contains(97);
			};
			case _: {
				switch (E5.E5A) {
					case E5A: {
						var v487:Bool = false;
					};
					case _: {
						final v488:S6 = ({x7: (-1605108992), x8: true, x9: (-1250706999)} : S6);
					};
				}
				switch (([false, true, true]).length) {
					case 0: {
						final v489:Int = 280;
						H.out("o490 " + Std.string(E5.E5A));
					};
					case 3 | 4: {
						var v491:Int = 0x39AE;
					};
					case _: {
						H.out("o492 " + Std.string(277));
						var v493 = (-987197764);
					};
				}
			};
		}
		H.out("o494 " + Std.string((([(-2147483647), 280303775]).contains(1526938841) || true)));
		H.out("o495 " + Std.string(((-new A10(68)) : Int)));
		var v496:E0 = ((Std.isOfType(new C45(), I12) ? E0.E0A : E0A) : E0);
		for (x497 in ([0x3793, 274]).map((v498:Int) -> (({x7: 0xFFFFFFFF, x9: v498, x8: true} : S6)).x9)) {
			H.tick();
			final v499:(Int) -> Bool = (p500:Int) -> false;
			(new C36()).m13(x497);
			var w501 = 0;
while (w501 < 4 && false) {
				w501++;
				H.tick();
				var v502:Int = x497;
			}
		}
		final v503:Int = Reflect.compare(Type.enumIndex(E0B), (Std.parseInt(Std.string(43)) ?? 0));
	}
	public static function section3():Void {
		H.tick();
		final v504:Map<Int, Int> = new Map<Int, Int>();
		if (true) {
			H.out("o505 " + Std.string(23));
			var v506 = 65;
		}
		final v507:E0 = E0.E0B;
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
