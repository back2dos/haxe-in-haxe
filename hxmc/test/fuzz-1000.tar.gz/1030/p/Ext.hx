package p;

import Main;
import H;
using StringTools;

class Ext {
	public static function ext75(a74:Array<Int>):Int {
		H.tick();
		if (Main.fn66(Std.int(100.75), C15.f17)) {
			H.out("o385 " + Std.string(C50.f53));
			switch (Reflect.compare("", "abc")) {
				case 0: {
					(new C23((-2.5), 0.5)).m31();
					final v386:(Bool, Int) -> Bool = function(p387:Bool, p388:Int):Bool {
						H.tick();
						var v389:I4 = new C19();
						return p387;
					};
				};
				case 3 | 4: {
					C50.f53 *= 0x80000000;
				};
				case _: {
					(new C32()).m38(a74, "\n");
					final v390:Array<Map<String, Int>> = ([new Map<String, Int>(), new Map<String, Int>(), (["k0" => 195, "k1" => 40, "k2" => 204] : Map<String, Int>)] : Array<Map<String, Int>>);
				};
			}
			C23.f24 = (({x1: "a", x3: (-2.5), x2: 147} : S0)).x2;
		} else {
			for (x391 in [true]) {
				H.tick();
				C23.f24 = 0x7FFFFFFF;
				var v392:Int = 0xA962;
			}
			try {
				if (true) throw new Err(C50.f53);
				var v393:Array<String> = ["-7"];
				var v394:Bool = true;
				var v395:Int = 151;
			} catch (ex396:String) {
				H.out("caught String " + ex396);
				Main.fn66(534055638, ex396);
			} catch (ex397:Int) {
				H.out("caught Int " + ex397);
				var v398 = ex397;
			} catch (ex399:Err) {
				H.out("caught Err " + ex399.errCode);
				var v400:String = "A-B-C";
				var v401:I4 = new C23(1.25, 7.0);
			} catch (ex402:Dynamic) {
				H.out("caught " + H.exn(ex402));
				C50.f52 = 175;
			}
		}
		if ((C23.f24 >= 84)) {
			var v403:Int = ("Haxe").length;
		}
		((cast (new C23(2.5e-3, 3.0)) : C23)).m31();
		return C23.f24;
	}
	public static function ext77(a76:String):Int {
		H.tick();
		(new C19()).m20((("q").indexOf('$$') ^ (({x1: a76, x2: 32, x3: 1.25} : S0)).x2));
		var w404 = 0;
do {
			w404++;
			H.tick();
			Main.fn64(0xD432);
		} while (w404 < 3 && C15.f16);
		H.out("o405 " + Std.string(C50.f52));
		for (i406 in 0...4) {
			H.tick();
			switch (226) {
				case 0: {
					var v407:String = "  pad  ";
				};
				case 3 | 6: {
					H.out("o408 " + Std.string(({x2: i406, x3: i406, x1: "hello world"} : S0)));
				};
				case c409 if (c409 > 10): {
					(new C23(c409, i406)).m31();
				};
				case _: {
					var v410:Array<Int> = [i406];
				};
			}
			C23.f24 |= 58;
			if ((([-3 => ({x1: a76, x2: i406, x3: i406} : S0), 4 => ({x2: i406, x1: a76, x3: i406} : S0), 11 => ({x2: 0x80000000, x1: a76, x3: i406} : S0)] : Map<Int, S0>)).exists(18)) {
				var v411 = a76;
				H.out("o412 " + Std.string(false));
			}
		}
		H.out("o413 " + Std.string(((switch (C50.f52) {
			case 0: ("A-B-C").split("-");
			case 1 | 4: ["x,y,z", "abc", a76];
			case c414 if (c414 > 10): [a76, a76];
			case _: ["x,y,z"];
		}) : Array<String>)));
		return (-2147483647);
	}
	public static function ext80(a78:Int, a79:String):Int {
		H.tick();
		final v415:S0 = ({x1: "-7", x2: (((["k0" => a78] : Map<String, Int>)).get("ab") ?? 0), x3: C50.f53} : S0);
		H.out("o416 " + Std.string(a78));
		var v417 = a79;
		final lf418:(Float) -> Void = function(p419:Float):Void {
			H.tick();
			final v420:Map<String, Int> = (["k0" => a78, "k1" => a78, "k2" => a78] : Map<String, Int>);
			try {
				if (C15.f16) throw a79;
				var v421 = a79;
			} catch (ex422:Err) {
				H.out("caught Err " + ex422.errCode);
				var v423:C41 = new C41(a78);
				var v424:Int = a78;
			} catch (ex425:haxe.Exception) {
				H.out("caught " + H.exn(ex425));
				var v426:Map<Int, Int> = ([-3 => a78, 4 => a78] : Map<Int, Int>);
				final v427:S0 = v415;
			}
			(new C41(a78)).m46(Reflect.compare(a78, a78), C50.f53);
		};
		try {
			if (Main.fn66((v415).x2, ("0").charAt((a78 & 7)))) throw a79;
			var v428 = a78;
			var v429:S0 = ({x3: a78, x1: "a", x2: 228} : S0);
		} catch (ex430:Err) {
			H.out("caught Err " + ex430.errCode);
			H.out("o431 " + a79);
			if (true) {
				Main.fn64(81);
				var v432:Null<Int> = a78;
				(new C23(a78, a78)).m31();
			}
		} catch (ex433:haxe.Exception) {
			H.out("caught " + H.exn(ex433));
			if (true) {
				var v434:Array<Float> = ([a78, 100.75, 7.0] : Array<Float>);
				var v435 = v417;
				a78 <<= (a78 & 7);
			} else {
				var v436:S0 = v415;
				Main.fn64(a78);
			}
		}
		return (([(-1552898151)]).concat([139, a78])).length;
	}
}
