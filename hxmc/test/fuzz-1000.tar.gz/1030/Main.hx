import H;
using p.Ext;
using StringTools;

typedef S0 = {x1:String, x2:Int, x3:Float};

interface I4 {
	function m5(a6:String, a7:Int):Int;
}

interface I8 {
	function m9(a10:String, a11:String):Bool;
	function m12(a13:Int, a14:Int):Void;
}

class C15 {
	public static var f16:Bool = true;
	public static var f17:String = "\t";
	public function new(a18:Bool) {}
}

class C19 implements I4 {
	public function new() {}
	public function m5(a6:String, a7:Int):Int {
		H.tick();
		switch (Lambda.count([a7, a7, 117], v81 -> false)) {
			case 0: {
				H.out("o82 " + Std.string(a7));
			};
			case 2 | 6: {
				for (x83 in [a6]) {
					H.tick();
					var v84:String = "x,y,z";
					var v85:Int = a7;
				}
				var v86:Int = (['$$', "42", "42"]).length;
			};
			case c87 if (c87 > 10): {
				if (true) {
					var v88:Array<Bool> = ([] : Array<Bool>);
					var v89:Array<Float> = ([c87] : Array<Float>);
					H.out("o90 " + Std.string(([new C32(), new C32(), new C32()] : Array<C32>)));
				} else {
					C50.f52 |= a7;
					H.out("o91 " + Std.string(c87));
				}
				H.out("o92 " + Std.string((Std.parseInt(Std.string(a7)) ?? 0)));
			};
			case _: {
				var v93:Int = 16;
				v93 |= C50.f53;
			};
		}
		for (i94 in 2...4) {
			H.tick();
			final lf95:(String, Int) -> Bool = (p96:String, p97:Int) -> true;
			for (i98 in 0...3) {
				H.tick();
				H.out("o99 " + Std.string((-3)));
				H.out("o100 " + Std.string(false));
			}
		}
		var w101 = 0;
while (w101 < 5 && true) {
			w101++;
			H.tick();
			H.out("o102 " + Std.string(H.at(([] : Array<Int>), a7, 0)));
		}
		return (switch (a7) {
			case 0: a7;
			case 3 | 6: (new C32()).m38(([] : Array<Int>), ("").substring(4, (a7 & 7)));
			case c103 if (c103 > 10): (((a6).charCodeAt(a7) ?? -1) % H.nz(a7));
			case _: a7;
		});
	}
	public function m20(a21:Int, ?a22:Null<Int>):Int {
		H.tick();
		if ((switch (({x3: a21, x2: a21, x1: "0"} : S0)) {
			case {x1: c104}: true;
		})) {
			for (i105 in 0...3) {
				H.tick();
				a21 -= a21;
				H.out("o106 " + Std.string(i105));
				H.out("o107 " + Std.string(false));
			}
			if ((new Map<String, Int>()).exists("k3")) return a21;
		} else {
			switch (C15.f16) {
				case true: {
					a21 = 29;
					var v108:S0 = ({x1: "  pad  ", x2: a21, x3: a21} : S0);
				};
				case false: {
					var v109:Int = a21;
					var v110:Bool = false;
				};
			}
		}
		if (false) {
			final v111:() -> Void = function():Void {
				H.tick();
				var v112:Bool = true;
				var v113:Int = 287;
			};
		} else {
			for (x114 in [a21, 145]) {
				H.tick();
				C15.f16 = false;
				final v115 = "q";
				C15.f16 = false;
			}
		}
		{
			for (x116 in ["\\", "abc"]) {
				H.tick();
				H.out("o117 " + Std.string(a21));
			}
		}
		var v118:C23 = new C23(C50.f53, 1.25);
		a21 = H.id(a21);
		return (switch (H.id(([a21]).filter(v119 -> false))) {
			case []: a21;
			case [c120]: ((([-3 => c120] : Map<Int, Int>)).exists(22) ? 0xC3DF : 293);
			case [_, c121]: a21;
			case _: a21;
		});
	}
}

class C23 implements I4 {
	public static var f24:Int = 1518826699;
	public var f25:Bool;
	public var f26:String;
	public var cb27:(Int) -> Int;
	public function new(a28:Float, a29:Float) {
		this.f25 = ([115, 0x1B85, 169]).contains(156);
		this.f26 = "42";
		this.cb27 = (p122:Int) -> 0x47E3;
	}
	public function m5(a6:String, a7:Int):Int {
		H.tick();
		Main.fn66(C50.f52, ((a6).toLowerCase()).toUpperCase());
		H.out("o123 " + Std.string(new C50()));
		try {
			if ((a7 <= a7)) throw (a6).substr((0x1C04 & 7), 6);
			var v124:S0 = ({x1: a6, x2: a7, x3: a7} : S0);
			if (this.f25) {
				C23.f24 *= a7;
			}
		} catch (ex125:String) {
			H.out("caught String " + ex125);
			if (StringTools.contains(a6, a6)) {
				var v126:Array<Int> = [0x8F31, a7];
			} else {
				H.out("o127 " + Std.string(([a7, a7, a7] : Array<Null<Int>>)));
				H.out("o128 " + Std.string(185));
			}
		} catch (ex129:Int) {
			H.out("caught Int " + ex129);
			final v130:I4 = new C19();
			(new C32()).m38([a7, a7], ("Haxe").substr(-1, 6));
		} catch (ex131:Err) {
			H.out("caught Err " + ex131.errCode);
			final lf132:(Int, Float) -> String = (p133:Int, p134:Float) -> StringTools.hex((p133) & 0xFFFF, 4);
			if (false) {
				var v135 = true;
				H.out("o136 " + Std.string(a7));
			}
		} catch (ex137:Dynamic) {
			H.out("caught " + H.exn(ex137));
			if (C15.f16) {
				H.out("o138 " + Std.string(0.1));
				final v139:Map<Int, Float> = new Map<Int, Float>();
			}
		}
		for (x140 in ([for (i141 in 0...2) a7] : Array<Float>)) {
			H.tick();
			switch (StringTools.endsWith(a6, a6)) {
				case true: {
					H.out("o142 " + Std.string(a7));
				};
				case false: {
					H.out("o143 " + Std.string(false));
				};
			}
		}
		H.out("o144 " + Std.string(Std.parseFloat(StringTools.replace("A-B-C", "a", a6))));
		C50.f53++;
		{
			if (StringTools.contains(a6, "\\")) {
				var v145:Map<Int, String> = ([-3 => a6, 4 => a6, 11 => "\\"] : Map<Int, String>);
				var v146:Map<Int, C41> = new Map<Int, C41>();
			}
			for (i147 in 0...2) {
				H.tick();
				C50.f52++;
			}
		}
		H.out("o148 " + Std.string((a6 == StringTools.lpad('$$', "*", 0))));
		var v149:Array<Int> = [a7, a7, a7];
		return ((new C19()).m20((Std.parseInt(Std.string(131)) ?? 0), a7) >>> ((a7 >> ((({x1: a6, x2: 0x506F, x3: a7} : S0)).x2 & 31)) & 31));
	}
	public function m30():Int {
		H.tick();
		var v150:I8 = new C32();
		H.out("o151 " + Std.string((100.75 != 47)));
		var v152 = Lambda.count(([] : Array<Int>), v153 -> true);
		C23.f24 *= (Std.string(v152)).lastIndexOf(Std.string(208));
		var v154:Array<Int> = [18, 102, v152];
		C50.f53 += (("ab").toUpperCase()).ext77();
		C15.f17 = H.cap((new C23((-2.5), v152)).m31());
		return v152;
	}
	public function m31():String {
		H.tick();
		H.out("o155 " + Std.string(258));
		final v156:Int = (if (true) (({x1: "A-B-C", x2: 142, x3: 1e-7} : S0)).x2 else C50.f53);
		H.out("o157 " + Std.string((v156 % H.nz(C23.f24))));
		switch ((Reflect.compare("\t", "Haxe") * v156)) {
			case 0: {
				var w158 = 0;
while (w158 < 2 && true) {
					w158++;
					H.tick();
					C23.f24 = 0x7D46;
				}
			};
			case 3 | 6: {
				(new C19()).m20(((new Map<Int, Int>()).get(11) ?? 0), ("ab").indexOf("Haxe"));
				C50.f52 = v156;
			};
			case _: {
				for (k159 => v160 in (["k0" => 280] : Map<String, Int>)) {
					H.tick();
					(new C19()).m20(v156);
					H.out("o161 " + Std.string(2.5e-3));
					C23.f24 = v156;
				}
				final v162:Map<String, Float> = (["k0" => 0.5, "k1" => v156] : Map<String, Float>);
			};
		}
		C50.f52 = v156;
		H.out("o163 " + Std.string(((C15.f16 ? new C19() : new C19()) : C19)));
		H.out("o164 " + Std.string((Std.parseInt("q") ?? 0)));
		return (({ var v165 = ("  pad  ").toLowerCase(); ([] : Array<Bool>); })).join("");
	}
}

class C32 implements I8 {
	public final f33:Float;
	public final f34:String;
	public var f35:Int;
	public function new() {
		this.f33 = 1.25;
		this.f34 = StringTools.trim("42");
		this.f35 = ("zz").indexOf("\"q\"");
	}
	public function m9(a10:String, a11:String):Bool {
		H.tick();
		try {
			if (true) throw new Err(C50.f52);
			H.out("o166 " + Std.string(new C41((-2147483647))));
		} catch (ex167:Dynamic) {
			H.out("caught " + H.exn(ex167));
			final lf168:(Bool, Int) -> String = (p169:Bool, p170:Int) -> String.fromCharCode(65 + ((120) & 15));
			m38([(-2147483647), 293, 44], a10);
		}
		var v171:Map<String, Int> = new Map<String, Int>();
		var v172:Int = Std.int(35);
		return (switch (v172) {
			case 0: (([v172, v172]).contains(v172) && true);
			case 1 | 5: (v172 != v172);
			case _: C15.f16;
		});
	}
	public function m12(a13:Int, a14:Int):Void {
		H.tick();
		function lf173(n174:Int):Int {
			H.tick();
			return n174 <= 0 ? (n174 + 0x80000000) : (lf173(n174 - 1) + ((a13 = 5) & this.f35));
		}
		H.out("lf173 " + lf173(0));
		var w175 = 0;
do {
			w175++;
			H.tick();
			switch (Std.string(a13)) {
				case "a" | "b": {
					H.out("o176 " + Std.string(a13));
					var v177 = 70;
				};
				case "Haxe": {
					H.out("o178 " + Std.string(77));
					m9("q", "Haxe");
				};
				case _: {
					var v179:Int = a14;
				};
			}
			(new C41(a14)).m44();
		} while (w175 < 2 && C15.f16);
		for (i180 in 0...H.lim((([a13, a13]).length >> (11 & 31)))) {
			H.tick();
			a14 = H.id(a14);
		}
		switch ("zz") {
			case "a" | "b": {
				for (i181 in 0...H.lim(this.f35)) {
					H.tick();
					var v182 = false;
				}
				var v183:Int = Math.ceil(1e-7);
			};
			case "Haxe": {
				switch (70) {
					case 0: {
						final v184:() -> String = () -> "0";
						var v185:Array<Int> = ([] : Array<Int>);
					};
					case 2 | 5: {
						var v186:Array<Int> = [a14, a13, a14];
					};
					case _: {
						var v187:Float = a14;
						(new C41(a13)).m46(264, 129);
					};
				}
				final v188:Int = a14;
			};
			case "": {
				var v189:Null<Int> = a14;
			};
			case _: {
				a13 -= (a14++);
				for (k190 => v191 in (["k0" => a13, "k1" => a14, "k2" => a14] : Map<String, Int>)) {
					H.tick();
					a13 |= v191;
					var v192:Map<String, String> = (["k0" => k190] : Map<String, String>);
					var v193 = true;
				}
			};
		}
		var v194:Float = (a14 - a14);
		final v195:Map<String, Bool> = (["k0" => (new Map<Int, Int>()).exists(-3), "k1" => false, "k2" => ([a14]).contains(a14)] : Map<String, Bool>);
		var v196:Array<Int> = (([7.0, v194, v194] : Array<Float>)).map((v197:Float) -> Std.int(1e100));
		H.out("o198 " + Std.string(({x1: ('$$').charAt((135 & 7)), x2: a14, x3: 1e3} : S0)));
		H.out("o199 " + Std.string(a13));
	}
	public static function m36(a37:Int):Int {
		H.tick();
		switch ((new C19()).m20(0x7140)) {
			case 0: {
				{ var dyn200:Dynamic = ({x1: "ab", x3: a37, x2: 0x1DF6} : S0); H.out("dyn " + Std.string(dyn200.x1) + " " + Std.string(Reflect.field(dyn200, "x1"))); }
			};
			case 2 | 4: {
				{
					a37 |= 0x7FFFFFFF;
					a37++;
				}
				(("hello world").substr((0x4EA9 & 7), (a37 & 7))).ext77();
			};
			case c201 if (c201 > 10): {
				for (i202 in 2...5) {
					H.tick();
					var v203:C32 = new C32();
				}
				var v204 = StringTools.endsWith("\n", '$$');
			};
			case _: {
				var w205 = 0;
while (w205 < 1 && true) {
					w205++;
					H.tick();
					C23.f24 = a37;
					var v206 = false;
					(new C32()).m12(a37, 254);
				}
				switch (("q").toUpperCase()) {
					case "a" | "b": {
						var v207 = 0x7E34;
						H.out("o208 " + Std.string(a37));
					};
					case "Haxe": {
						(new C23(a37, 7.0)).m31();
						var v209:Int = a37;
					};
					case _: {
						final v210:Array<String> = ("abc").split("-");
					};
				}
			};
		}
		var v211:Int = C50.f52;
		if (Std.isOfType(new C32(), I8)) {
			for (i212 in 0...2) {
				H.tick();
				var v213 = a37;
				var v214 = a37;
				H.out("o215 " + Std.string([57]));
			}
			if (Math.isNaN(v211)) {
				final v216:Map<String, Float> = new Map<String, Float>();
				var v217:Array<Float> = ([a37] : Array<Float>);
			}
		} else {
			var v218:Array<Int> = [v211, v211];
		}
		return a37;
	}
	public function m38(a39:Array<Int>, a40:String):Int {
		H.tick();
		var v219 = (16 << ((("abc").charCodeAt((-906692657)) ?? -1) & 31));
		var v220:Array<Int> = ([] : Array<Int>);
		switch ("a") {
			case "a" | "b": {
				H.out("o221 " + Std.string(true));
				(new C19()).m20((({x1: "\n", x2: 5, x3: v219} : S0)).x2, v219);
			};
			case "Haxe": {
				var v222:Float = v219;
				var w223 = 0;
while (w223 < 3 && true) {
					w223++;
					H.tick();
					v219 += v219;
					var v224 = a40;
					final v225:C50 = new C50();
				}
			};
			case "": {
				v219 = 158;
			};
			case _: {
				H.out("o226 " + Std.string(v219));
			};
		}
		if ((v219 == (({x1: a40, x3: 1e-7, x2: 164} : S0)).x2)) {
			for (x227 in v220) {
				H.tick();
				var v228:Map<String, String> = (["k0" => a40, "k1" => a40, "k2" => a40] : Map<String, String>);
				var v229:Int = v219;
			}
			var v230 = v219;
		} else {
			switch ("42") {
				case "a" | "b": {
					var v231 = true;
					H.out("o232 " + Std.string(v231));
				};
				case "Haxe": {
					final v233:String = '$$';
				};
				case _: {
					var v234 = v219;
				};
			}
			var w235 = 0;
do {
				w235++;
				H.tick();
				H.out("o236 " + Std.string(v219));
				(new C23(7.0, v219)).m31();
			} while (w235 < 1 && false);
		}
		final v237:(Int, Int) -> Bool = (p238:Int, p239:Int) -> false;
		H.out("o240 " + Std.string(a39));
		var v241:Array<String> = (([] : Array<String>)).filter(v242 -> Std.isOfType(new C19(), I4));
		for (i243 in 0...1) {
			H.tick();
			H.out("o244 " + Std.string(193));
			for (k246 => x245 in [v219, v219, v219]) {
				H.tick();
				H.out("o247 " + Std.string(i243));
				C50.f52 = v219;
			}
		}
		H.out("o248 " + Std.string((C50.f52 - v219)));
		return (51 >>> ((cast ((({x1: a40, x3: v219, x2: v219} : S0)).x2) : Int) & 31));
	}
}

class C41 {
	public var f42:Float;
	public function new(a43:Int) {
		this.f42 = (-2.5);
	}
	public function m44():Void {
		H.tick();
		H.out("o249 " + Std.string(((false ? new C23(1e-7, 2.5e-3) : new C23(7.0, 3.0)) : C23)));
		H.out("o250 " + Std.string((([0x203F]).contains(30) ? false : true)));
		final v251:Map<Int, Int> = ((([1365757656, 236]).contains(101) ? new Map<Int, Int>() : new Map<Int, Int>()) : Map<Int, Int>);
	}
	public function m45():Void {
		H.tick();
		H.out("o252 " + Std.string(0xFFFFFFFF));
		switch ((cast (75) : Int)) {
			case 0: {
				for (i253 in 0...1) {
					H.tick();
					(new C32()).m9('$$', "hello world");
				}
			};
			case 1 | 6: {
				var v254 = ([false]).join("");
			};
			case _: {
				if (false) {
					(new C41(299)).m46(0x7FFFFFFF);
					(new C19()).m20(10);
				}
			};
		}
		H.out("o255 " + Std.string((switch (H.id([203, 106, 150])) {
			case []: false;
			case [c256]: false;
			case [_, c257]: StringTools.endsWith("q", "-7");
			case _: ([108, 154, 110]).contains((-909847318));
		})));
		C50.f52 = (("abc").lastIndexOf("x,y,z") | H.at([295], 245, 0));
		H.out("o258 " + Std.string((-359504403)));
		final v259:Array<(Bool, Int) -> Int> = (([0.1, 1e-7, (-2.5)] : Array<Float>)).map((v260:Float) -> ((p261:Bool, p262:Int) -> p262 : (Bool, Int) -> Int));
		var v263:Map<String, Int> = (["k0" => 201, "k1" => C23.f24] : Map<String, Int>);
		{ var dyn264:Dynamic = ({x1: "abc", x2: Math.floor(0.30000000000000004), x3: 1.25} : S0); H.out("dyn " + Std.string(dyn264.x1) + " " + Std.string(Reflect.field(dyn264, "x1"))); }
		C50.f53 = ((("Haxe").charCodeAt(86) ?? -1) * 46);
	}
	public function m46(a47:Int, a48:Int = 6):Int {
		H.tick();
		final v265:Map<Int, String> = new Map<Int, String>();
		C23.f24 ^= (new C32()).m38([124, a47, a48], "ab");
		var w266 = 0;
while (w266 < 1 && (a47 != Std.parseFloat("1.5"))) {
			w266++;
			H.tick();
			final v267:Array<String> = ("x,y,z").split("-");
			if (false) {
				C15.f17 = H.cap("");
				H.out("o268 " + Std.string(true));
				a47 = a48;
			}
			C50.f52--;
		}
		H.out("o269 " + Std.string(((switch (C15.f17) {
			case "a" | "b": 1.25;
			case "Haxe": 0x5E64;
			case _: a48;
		}) : Float)));
		return a47;
	}
	public function m49():Array<String> {
		H.tick();
		C50.f53 = 192;
		var w270 = 0;
while (w270 < 2 && (new C32()).m9(("0").replace("a", "b"), "42")) {
			w270++;
			H.tick();
			{
				C50.f53 = 65535;
			}
			(new C23(3.0, 0.1)).m5(StringTools.hex((42) & 0xFFFF, 4), (({x1: "Haxe", x2: 119, x3: 0.1} : S0)).x2);
			H.out("o271 " + ("  pad  ").toUpperCase());
		}
		var v272 = (new C23(0.1, 7.0)).m31();
		return (((switch (Math.ceil(100.75)) {
			case 0: [v272, v272, v272];
			case 3 | 4: [v272, v272, v272];
			case c273 if (c273 > 10): ["ab", v272, "0"];
			case _: [v272, v272, v272];
		}) : Array<String>)).copy();
	}
}

class C50 {
	var _f51:String;

	public var f51(get, set):String;

	function get_f51():String
		return _f51;

	function set_f51(v:String):String
		return _f51 = v;
	public static var f52:Int = 121;
	public static var f53:Int = 20;
	public function new() {
		this._f51 = "a";
	}
	public function m54(a55:Bool, a56:Float):Void {
		H.tick();
		C50.f53 = (Std.parseInt("a") ?? 0);
		for (i274 in 0...H.lim(175)) {
			H.tick();
			var v275:I8 = new C32();
			C50.f52 &= ("hello world").indexOf("x,y,z");
			try {
				if (a55) throw "abc";
				([234]).ext75();
				var v276:Map<String, Int> = (["k0" => i274] : Map<String, Int>);
				var v277:Array<Int> = [68, 0x97D6];
			} catch (ex278:Dynamic) {
				H.out("caught " + H.exn(ex278));
				C50.f53 = i274;
				final v279:Int = i274;
			}
		}
		var v280:Int = (("0").substr((99 & 7), (119 & 7))).length;
	}
	public function m57(a58:Int):Int {
		H.tick();
		{
			var v281 = a58;
			for (x282 in [270, v281]) {
				H.tick();
				var v283:Float = x282;
				var v284:C50 = new C50();
				var v285:Array<String> = ("abc").split("a");
			}
			var v286:Int = C23.f24;
		}
		for (i287 in 0...2) {
			H.tick();
			var v288:Map<String, Float> = new Map<String, Float>();
			a58 = 249;
			{
				++C50.f53;
			}
		}
		H.out("o289 " + Std.string(a58));
		switch ((new C23(a58, a58)).m31()) {
			case "a" | "b": {
				for (x290 in [true]) {
					H.tick();
					C50.f52 <<= (a58 & 7);
					var v291:Array<String> = ["\"q\"", "abc"];
					var v292:Float = a58;
				}
			};
			case "Haxe": {
				final lf293:() -> String = function():String {
					H.tick();
					var v294:S0 = ({x1: "zz", x2: a58, x3: a58} : S0);
					final v295:(String) -> Int = (p296:String) -> a58;
					return "0";
				};
			};
			case "": {
				if (false) {
					(a58).ext80('$$');
					final v297:Array<String> = ("-7").split("-");
					final v298:() -> String = function():String {
						H.tick();
						final v299:(Int, Int) -> Int = (p300:Int, p301:Int) -> p301;
						return "hello world";
					};
				}
				H.out("o302 " + Std.string(new C50()));
			};
			case _: {
				for (i303 in 0...0) {
					H.tick();
					H.out("o304 " + Std.string(new C50()));
					H.out("o305 " + Std.string(null));
					final v306:Map<Int, Bool> = new Map<Int, Bool>();
				}
			};
		}
		return (new C41(161)).m46((-830663605), C50.f52);
	}
	public function m59(a60:Int, ?a61:Null<Int>):Void {
		H.tick();
		var v307:Map<String, Bool> = new Map<String, Bool>();
		var v308 = ([a60, a60]).ext75();
		var w309 = 0;
while (w309 < 1 && ('$$' < (["", "x,y,z"]).join(""))) {
			w309++;
			H.tick();
			H.out("o310 " + Std.string((('$$').charCodeAt(489743518) ?? -1)));
		}
		for (k311 => v312 in (["k0" => (([v308] : Array<Float>)).length, "k1" => (("\n").split(",")).indexOf("\n"), "k2" => 155] : Map<String, Int>)) {
			H.tick();
			var v313 = StringTools.endsWith("\"q\"", k311);
			var v314 = v312;
			final v315:() -> Int = () -> a60;
		}
		{ var dyn316:Dynamic = ({x3: Math.PI, x2: (Std.parseInt(Std.string(223)) ?? 0), x1: "\"q\""} : S0); H.out("dyn " + Std.string(dyn316.x1) + " " + Std.string(Reflect.field(dyn316, "x1"))); }
		{
			final v317:Array<String> = ("x,y,z").split("-");
		}
		try {
			if (Main.fn66(a60, "\t")) throw new Err(((-1578628051) % H.nz((Std.parseInt("-7") ?? 0))));
			H.out("o318 " + Std.string([v308, v308, a60]));
		} catch (ex319:Err) {
			H.out("caught Err " + ex319.errCode);
			switch (a60) {
				case 0: {
					var v320:Int = 262;
					H.out("o321 " + "-7");
				};
				case 1 | 6: {
					H.out("o322 " + Std.string(({x3: v308, x2: 0x8270, x1: "\"q\""} : S0)));
				};
				case _: {
					C50.f52 <<= (v308 & 7);
				};
			}
			var v323 = v308;
		} catch (ex324:haxe.Exception) {
			H.out("caught " + H.exn(ex324));
			(new C23(2.5e-3, v308)).m5("hello world", v308);
			C23.f24 = v308;
		}
		var v325:Bool = (StringTools.endsWith("\\", "abc") ? C15.f16 : StringTools.endsWith("hello world", "q"));
		var v326:Int = v308;
	}
	public function m62(?a63:Null<String>):Map<Int, Int> {
		H.tick();
		if ((Std.downcast((new C50() : C50), C50) != null)) {
			var v327 = "\t";
			try {
				var v328 = 144;
				var v329:Array<Int> = [v328];
				(new C41((-7))).m45();
				if ((Std.downcast((new C15(true) : C15), C15) != null)) throw new Err(8);
			} catch (ex330:String) {
				H.out("caught String " + ex330);
				final v331:S0 = ({x1: "\t", x2: 0x75CC, x3: 1.25} : S0);
			} catch (ex332:Int) {
				H.out("caught Int " + ex332);
				Main.fn64(ex332);
				H.out("o333 " + Std.string(({x1: v327, x3: ex332, x2: ex332} : S0)));
			} catch (ex334:Err) {
				H.out("caught Err " + ex334.errCode);
				this.f51 = H.cap("hello world");
				var v335 = 269;
			} catch (ex336:Dynamic) {
				H.out("caught " + H.exn(ex336));
				var v337 = v327;
				var v338 = 265;
			}
		}
		var v339:String = "42";
		var w340 = 0;
while (w340 < 5 && (new Map<String, Int>()).exists(C15.f17)) {
			w340++;
			H.tick();
			H.out("o341 " + Std.string((new Map<String, String>()).exists("k0")));
			var v342:Map<String, String> = (["k0" => "A-B-C", "k1" => v339] : Map<String, String>);
			H.out("o343 " + v339);
		}
		final v344:C19 = new C19();
		(new C32()).m9(v339, String.fromCharCode(65 + (((({x1: v339, x2: 69, x3: 1e3} : S0)).x2) & 15)));
		var v345 = ((new Map<String, Null<Int>>()).exists(v339) || Std.isOfType(new C32(), I8));
		for (i346 in 0...H.lim((~844047847))) {
			H.tick();
			H.out("o347 " + StringTools.hex((0x17D8) & 0xFFFF, 4));
			if (v345) {
				var v348:Array<Float> = ([] : Array<Float>);
			}
		}
		var v349:C32 = ((switch (78) {
			case 0: new C32();
			case 2 | 6: new C32();
			case _: new C32();
		}) : C32);
		var w350 = 0;
while (w350 < 4 && false) {
			w350++;
			H.tick();
			final lf351:(Int, Bool) -> Float = (p352:Int, p353:Bool) -> C50.f52;
			H.out("o354 " + Std.string([205, 190, 0xCCF8]));
		}
		return new Map<Int, Int>();
	}
}

class Main {
	public static function fn64(a65:Int):Int {
		H.tick();
		var v355:Int = (new C32()).m38(([] : Array<Int>), Std.string(a65));
		H.out("o356 " + Std.string(a65));
		var v357 = (0x9498 + v355);
		return v357;
	}
	public static function fn66(a67:Int, a68:String):Bool {
		H.tick();
		for (x358 in (([] : Array<Int>)).map((v359:Int) -> a68)) {
			H.tick();
			for (i360 in 0...H.lim(H.at([a67, 127], a67, 0))) {
				H.tick();
				var v361:C15 = new C15(true);
				C23.f24++;
				C23.f24 -= i360;
			}
		}
		for (i362 in 0...4) {
			H.tick();
			C15.f16 = H.id(C15.f16);
			H.out("o363 " + Std.string(C23.f24));
			var v364 = true;
		}
		(new C41(((a68).charCodeAt(a67) ?? -1))).m46(((a67 -= 1) >>> (a67 & 31)), (Math.floor(a67) & a67));
		var v365:String = a68;
		var v366:S0 = ({x3: a67, x2: C23.f24, x1: (a68).charAt((a67 & 7))} : S0);
		a68 = H.cap(a68 + (C15.f17).toLowerCase());
		C50.f52 = a67;
		if (C15.f16) {
			fn64((Std.parseInt(Std.string(220)) ?? 0));
			H.out("o367 " + Std.string(a67));
			try {
				if (StringTools.endsWith(v365, "a")) throw "boom";
				C50.f52 &= a67;
				H.out("o368 " + Std.string(0.30000000000000004));
			} catch (ex369:String) {
				H.out("caught String " + ex369);
				H.out("o370 " + ex369);
				final v371 = true;
			} catch (ex372:Int) {
				H.out("caught Int " + ex372);
				var v373:Int = 248;
			} catch (ex374:Err) {
				H.out("caught Err " + ex374.errCode);
				final v375:C50 = new C50();
				H.out("o376 " + Std.string(new C41(a67)));
			} catch (ex377:Dynamic) {
				H.out("caught " + H.exn(ex377));
				H.out("o378 " + Std.string(a67));
				var v379:Map<Int, Float> = ([-3 => a67, 4 => a67] : Map<Int, Float>);
			}
		}
		return ((["\n", v365]).join(",") != (C15.f17 + "x,y,z"));
	}
	public static function fn69(a70:String = "d"):Int {
		H.tick();
		var v380 = 276;
		(new C41(v380)).m46((new C19()).m5("\"q\"", v380));
		{ var dyn381:Dynamic = ({x1: "\\", x2: Math.floor((-2.5)), x3: Std.parseFloat("1.5")} : S0); H.out("dyn " + Std.string(dyn381.x1) + " " + Std.string(Reflect.field(dyn381, "x1"))); }
		return ((("  pad  ").split("-")).concat(["\t"])).length;
	}
	public static function fn71(a72:Int, a73:String = "d"):Void {
		H.tick();
		C23.f24 = 153;
		H.out("o382 " + Std.string(a72));
		H.out("o383 " + (C15.f16 + '$$'));
		{ var dyn384:Dynamic = ({x1: ('$$').toUpperCase(), x2: a72, x3: 1e3} : S0); H.out("dyn " + Std.string(dyn384.x1) + " " + Std.string(Reflect.field(dyn384, "x1"))); }
		(new C32()).m9("a", (a73 + a73));
	}
	public static function section0():Void {
		H.tick();
		{ var dyn437:Dynamic = ({x1: "zz", x2: Lambda.fold([186, 80, 61], (v438:Int, v439:Int) -> 60, 0), x3: C50.f53} : S0); H.out("dyn " + Std.string(dyn437.x1) + " " + Std.string(Reflect.field(dyn437, "x1"))); }
		var v440:Array<String> = ((true ? ("abc").split(" ") : ("zz").split(" ")) : Array<String>);
		for (k442 => x441 in ([1.25, 0x80000000] : Array<Float>)) {
			H.tick();
			var v443:Int = k442;
			(new C19()).m5(("q").toLowerCase(), k442);
		}
		var v444:Array<Int> = [Math.round(1e-7)];
	}
	public static function section1():Void {
		H.tick();
		C50.f52 &= (Std.parseInt(Std.string(Reflect.compare("x,y,z", "zz"))) ?? 0);
		(new C50()).m59(287, (new C19()).m5("-7", ("A-B-C").indexOf("\t")));
		var v445 = (new C19()).m20(C50.f52);
		H.out("o446 " + Std.string(((new Map<String, Int>()).get("q") ?? 0)));
		var v447:C50 = new C50();
		(new C41((([] : Array<Bool>)).indexOf(true))).m49();
	}
	public static function section2():Void {
		H.tick();
		C50.f53 = (new C23(0.1, 123456.789)).m5(Std.string(100.75), (Std.parseInt(Std.string(1965781990)) ?? 0));
		var v448:String = (178 + (([] : Array<Bool>)).join(","));
		var v449:C32 = new C32();
		var v450:Array<Int> = [115, ((([-3 => 128, 4 => 281] : Map<Int, Int>)).get(4) ?? 0), 264];
		var w451 = 0;
while (w451 < 1 && (([false]).join("") == StringTools.lpad(v448, "*", 4))) {
			w451++;
			H.tick();
			var v452:Bool = true;
			H.out("o453 " + Std.string(147));
			for (i454 in 0...4) {
				H.tick();
				var v455:String = v448;
				var v456 = v452;
			}
		}
		var v457:Array<Int> = [for (i458 in 0...1) i458];
		H.out("o459 " + Std.string(((((["k0" => 134, "k1" => (-15), "k2" => 80] : Map<String, Int>)).get("k1") ?? 0) / Std.parseFloat("1.5"))));
		final v460 = (Math.pow(0.30000000000000004, 2) >= 123456.789);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
