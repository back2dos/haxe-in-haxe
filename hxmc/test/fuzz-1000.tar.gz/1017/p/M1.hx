package p;

import Main;
import H;
import p.M1;

class M1 {}

abstract A3(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A3, b:A3):A3
		return new A3(a.get() + b.get());

	@:op(A * B) public static function mul(a:A3, b:A3):A3
		return new A3(a.get() * b.get());

	@:op(-A) public static function neg(a:A3):A3
		return new A3(-a.get());
}

interface I5 {
	function m6(a7:E1):Int;
	function m8(a9:Bool, a10:Int):Int;
}

class C11 implements I5 {
	public static var f12:Bool = false;
	public var cb13:(Int) -> Int;
	public function new() {
		this.cb13 = (p71:Int) -> 110;
	}
	public function m6(a7:E1):Int {
		H.tick();
		C37.f38 = C20.m29();
		final lf72:(Int) -> Void = function(p73:Int):Void {
			H.tick();
			C20.m25(p73);
		};
		var v74:E0 = (new C34(196, ([] : Array<Int>))).m33();
		final v75:A3 = new A3(Reflect.compare(59, 0xFFFFFFFF));
		C30.f31 = (228 > 85);
		switch (E0.E0A) {
			case E0A: {
				var v76:Int = Reflect.compare(59, 0x456C);
			};
			case _: {
				C37.f38 = 246;
			};
		}
		var v77:Bool = true;
		((cast (new C43(v74, 129)) : C34)).m33();
		var v78:Array<Int> = ([] : Array<Int>);
		return 145;
	}
	public function m8(a9:Bool, a10:Int):Int {
		H.tick();
		C20.m29();
		final v79 = Reflect.compare(a10, 164);
		C37.f38 = v79;
		return 264;
	}
	public static function m14(a15:Int):Bool {
		H.tick();
		var v80:Array<Int> = [for (i81 in 0...4) 35];
		final lf82:(Bool, Int) -> Bool = (p83:Bool, p84:Int) -> (cast ((Std.downcast((new C43(E0.E0A, a15) : C43), C43) != null)) : Bool);
		a15 -= (a15 + a15);
		H.out("o85 " + Std.string(lf82(true, C37.f38)));
		var v86 = a15;
		var v87:E0 = E0.E0A;
		return (v86 > a15);
	}
	public static function m16():C11 {
		H.tick();
		try {
			if (false) throw "boom";
			if (false) {
				C37.f38 += 38;
			} else {
				var v88:Array<() -> Bool> = ([function():Bool {
					H.tick();
					var v89:Array<Bool> = [true];
					var v90:A3 = new A3(0x852);
					return true;
				}, function():Bool {
					H.tick();
					H.out("o91 " + Std.string(E0.E0A));
					final v92:Int = 47;
					var v93:E0 = E0.E0A;
					return true;
				}] : Array<() -> Bool>);
				C37.f38 = 0x80000000;
			}
			(new C43(E0.E0A, 0xAD39)).m33();
		} catch (ex94:Dynamic) {
			H.out("caught " + H.exn(ex94));
			if (false) {
				H.out("o95 " + Std.string(true));
			}
			C37.f38 = 20;
		}
		if ((0x9F2B >= 1900621563)) {
			C37.f38 = Type.enumIndex(E1.E1B(222));
		} else {
			(new C11()).m6(E1.E1B(118));
		}
		if (C30.f31) {
			switch (Lambda.fold(([] : Array<Int>), (v96:Int, v97:Int) -> ((v96 : A3)).twice, 0)) {
				case 0: {
					H.out("o98 " + Std.string((-2)));
				};
				case 1 | 4: {
					final v99:Array<Int> = [272, (-14)];
					H.out("o100 " + Std.string(154));
				};
				case _: {
					C37.f38 = 24;
				};
			}
		} else {
			final v101:Int = (-1307114787);
		}
		H.out("o102 " + Std.string(121));
		return new C11();
	}
	public function m17():Int {
		H.tick();
		C37.f38 ^= 0x7FFFFFFF;
		var v103 = (if (false) 144 else 125);
		H.out("o104 " + Std.string(v103));
		H.out("o105 " + Std.string((cast (0xEBB1) : Int)));
		if ((false ? true : true)) {
			switch (259) {
				case 0: {
					v103 += v103;
				};
				case 3 | 6: {
					H.out("o106 " + Std.string(true));
					final v107:() -> Int = function():Int {
						H.tick();
						var v108:C43 = new C43(E0.E0A, 5);
						final v109:A3 = (18 : A3);
						return v103;
					};
				};
				case _: {
					H.out("o110 " + Std.string(v103));
				};
			}
			try {
				var v111:Int = 0x1854;
				if (true) throw "boom";
			} catch (ex112:Err) {
				H.out("caught Err " + ex112.errCode);
				var v113:Array<Int> = [v103];
			} catch (ex114:haxe.Exception) {
				H.out("caught " + H.exn(ex114));
				final v115:(Int) -> Int = (p116:Int) -> v103;
			}
			var v117:C37 = new C37(true, false);
		} else {
			if (([v103, v103, 1699012393]).contains(272)) {
				H.out("o118 " + Std.string(v103));
			} else {
				final v119:Array<Int> = [v103, v103];
			}
		}
		var v120:Array<Bool> = ([] : Array<Bool>);
		return (v103 - (65535 - C37.f38));
	}
	public function m18(a19:Bool):Int {
		H.tick();
		(((switch (K4.K4C) {
			case K4.K4A: new C11();
			case K4.K4B: new C11();
			case K4.K4C: new C11();
			case _: new C11();
		}) : C11)).m8(a19, (switch (218) {
			case 0: Reflect.compare(135, 182);
			case 2 | 5: C37.f38;
			case _: C37.f38;
		}));
		switch (E1.E1A) {
			case E1A: {
				var v121:Array<A3> = ([new A3(268), (179 : A3)] : Array<A3>);
				var v122:Int = C37.f38;
			};
			case E1B(_): {
				var v123:Int = (Std.parseInt("") ?? 0);
				switch (E1.E1A) {
					case E1A: {
						H.out("o124 " + Std.string(([new C43(E0.E0A, v123), new C43(E0.E0A, v123), new C43(E0.E0A, 21)] : Array<C30>)));
					};
					case E1B(c125): {
						final v126:(Int, Bool) -> Int = (p127:Int, p128:Bool) -> c125;
						v123 = 275;
					};
				}
			};
		}
		Main.fn59((Type.enumIndex(E1.E1B((-2147483647))) >= 21), new C37(true, a19));
		final v129 = 98;
		return v129;
	}
}

class C20 implements I5 {
	public final f21:Int;
	var _f22:Int;

	public var f22(get, set):Int;

	function get_f22():Int
		return _f22;

	function set_f22(v:Int):Int
		return _f22 = v;
	public var cb23:(Int) -> Int;
	public function new() {
		this.f21 = H.at([222], 0x7FFFFFFF, 0);
		this._f22 = 272;
		this.cb23 = (p130:Int) -> p130;
	}
	public function m6(a7:E1):Int {
		H.tick();
		var v131:Array<String> = [for (i132 in [2011842288, 0xD957]) if (false) Std.string(i132)];
		final lf133:(Int) -> Int = (p134:Int) -> (cast (p134) : Int);
		var v135:Array<Int> = ([13]).map((v136:Int) -> Lambda.count(([] : Array<Int>), v137 -> false));
		try {
			(new C11()).m17();
			switch (Lambda.fold(v135, (v138:Int, v139:Int) -> Reflect.compare(v139, 28), 0)) {
				case 0: {
					H.out("o140 " + Std.string(0xFFFFFFFF));
					this.f22 = 0x36E0;
				};
				case 3 | 6: {
					Main.fn53(33);
				};
				case _: {
					var v141 = 30;
				};
			}
			if (Main.fn59(true, new C37(true, true), 3, Type.enumIndex(E1.E1B(28)))) throw new Err(((Std.downcast((new C34((-2147483647), v135) : C34), C34) != null) ? this.f21 : Lambda.count([0x80000000, (-2142368188), 90], v142 -> true)));
		} catch (ex143:String) {
			H.out("caught String " + ex143);
			if (true) return 275;
		} catch (ex144:Int) {
			H.out("caught Int " + ex144);
			H.out("o145 " + Std.string(true));
		} catch (ex146:Err) {
			H.out("caught Err " + ex146.errCode);
			Main.fn53((K4.K4A : Int));
		} catch (ex147:Dynamic) {
			H.out("caught " + H.exn(ex147));
			{
				var v148:Array<Array<Int>> = ([v135, v135, v135] : Array<Array<Int>>);
				C37.f38 = 124;
			}
		}
		var v149:Int = (if (false) C37.f38 else this.f21);
		var v150:C30 = new C43(E0.E0A, 240);
		var v151:K4 = K4.K4C;
		(new C11()).m17();
		var v152:E0 = E0.E0A;
		return (new A3((v151 : Int))).twice;
	}
	public function m8(a9:Bool, a10:Int):Int {
		H.tick();
		if ((a10 != 84)) {
			H.out("o153 " + Std.string(([] : Array<E1>)));
			H.out("o154 " + Std.string((new A3(a10) : Int)));
		} else {
			H.out("o155 " + Std.string(a9));
		}
		Main.fn63(({ var v156 = 202; 195; }), a10);
		final v157:Array<Int> = [this.f22];
		switch ((a9 ? (v157).contains(0xFFFFFFFF) : a9)) {
			case true: {
				var v158:E1 = E1.E1B(65535);
			};
			case false: {
				try {
					var v159 = a10;
					final v160 = v159;
					if (false) throw new Err(63);
				} catch (ex161:String) {
					H.out("caught String " + ex161);
					var v162:Int = 58;
				} catch (ex163:Int) {
					H.out("caught Int " + ex163);
					var v164 = 0x2105;
				} catch (ex165:Err) {
					H.out("caught Err " + ex165.errCode);
					var v166:Int = a10;
				} catch (ex167:Dynamic) {
					H.out("caught " + H.exn(ex167));
					final v168 = a10;
				}
				v157.reverse();
			};
		}
		H.out("o169 " + Std.string(C37.f38));
		Main.fn63((new C43(E0.E0A, (-15))).m6(E1.E1A));
		final v170:Int = a10;
		(new C37(a9, true)).m33();
		return a10;
	}
	public function m24():Int {
		H.tick();
		if ((C11.f12 ? true : false)) return (false ? ([false, true]).indexOf(true) : Reflect.compare(212, 109));
		C37.f38 <<= ((this.f21 + Reflect.compare(9, 192)) & 7);
		H.out("o171 " + Std.string(true));
		return Main.fn63((([true]).indexOf(true) + 52), Reflect.compare(0x7FFFFFFF, (new A3(254)).twice));
	}
	public static function m25(a26:Int):Int {
		H.tick();
		try {
			if ((false || ([a26]).contains(a26))) throw 37;
			var v172:Array<A3> = ([new A3(a26), new A3(117), (a26 : A3)] : Array<A3>);
		} catch (ex173:String) {
			H.out("caught String " + ex173);
			final v174:() -> Int = () -> a26;
			var v175:Int = a26;
		} catch (ex176:Int) {
			H.out("caught Int " + ex176);
			C37.f38 *= ex176;
			H.out("o177 " + Std.string(ex176));
		} catch (ex178:Err) {
			H.out("caught Err " + ex178.errCode);
			var v179:Int = 285;
		} catch (ex180:Dynamic) {
			H.out("caught " + H.exn(ex180));
			if (false) {
				(new C11()).m17();
				(new C11()).m17();
				var v181:Array<Int> = [164, a26];
			} else {
				H.out("o182 " + Std.string(a26));
			}
		}
		function lf183(n184:Int):Int {
			H.tick();
			return n184 <= 0 ? n184 : (lf183(n184 - 1) + 9);
		}
		H.out("lf183 " + lf183(2));
		if (!C11.f12) {
			(new C11()).m17();
			final lf185:() -> Bool = () -> ([a26, 150, a26]).contains(a26);
			function lf186(n187:Int):Int {
				H.tick();
				return n187 <= 0 ? Reflect.compare(0xFFFFFFFF, 0x6149) : (lf186(n187 - 1) + n187);
			}
			H.out("lf186 " + lf186(4));
		}
		final v188:() -> Int = function():Int {
			H.tick();
			(new C11()).m17();
			var v189 = false;
			a26 = H.id(a26);
			return Reflect.compare(259, 0x80000000);
		};
		return a26;
	}
	public static inline function m27(a28:E0):Int {
		H.tick();
		var v190:Array<Bool> = ([false]).slice(2, 4);
		final lf191:(Int) -> Int = C20.m25;
		final lf192:(String) -> Int = (p193:String) -> C37.f38;
		var v194 = (false && false);
		return ((179 + (-1733832371)) | C20.m25((([] : Array<Int>)).length));
	}
	public static function m29():Int {
		H.tick();
		(new C11()).m17();
		var v195:Array<Bool> = [for (i196 in 0...3) true];
		final v197:E0 = E0.E0A;
		C20.m27(E0.E0A);
		C37.f38 = ((-1550546942) * 78);
		var v198:Array<Int> = (([] : Array<Int>)).filter(v199 -> true);
		H.out("o200 " + Std.string((K4.K4A : Int)));
		return (C20.m25(73) % H.nz((-(v198).indexOf(273))));
	}
}

class C30 extends C20 {
	public static var f31:Bool = false;
	public var f32:String;
	public function new() {
		super();
		this.f32 = Std.string(1057440804);
	}
	override public function m6(a7:E1):Int {
		H.tick();
		var v201:Array<Int> = ([65, (-2147483647), 178]).slice(-2, -1);
		var v202:Int = ((Std.parseInt("zz") ?? 0) >> ((Std.parseInt("q") ?? 0) & 31));
		this.f22 = this.f21;
		v201.push(((([] : Array<Bool>)).indexOf(false) | v202));
		return Main.fn55((v202 | (Std.parseInt("\u{1F600}") ?? 0)), 91, v202);
	}
	override public function m8(a9:Bool, a10:Int):Int {
		H.tick();
		(new C11()).m6(((false ? E1.E1A : E1.E1A) : E1));
		a10 = H.id(a10);
		H.out("o203 " + Std.string((K4.K4A : Int)));
		try {
			if (C30.f31) {
				H.out("o204 " + Std.string(true));
				var v205:Int = a10;
				var v206:Int = a10;
			}
			Main.fn53(([a9, false]).indexOf(true));
			var v207:A3 = new A3(a10);
			if (a9) throw "boom";
		} catch (ex208:Err) {
			H.out("caught Err " + ex208.errCode);
			if (a9) {
				final v209 = a10;
				var v210:Array<Bool> = [a9, a9, false];
			} else {
				var v211 = a9;
			}
			H.out("o212 " + Std.string(C11.f12));
		} catch (ex213:haxe.Exception) {
			H.out("caught " + H.exn(ex213));
			if (([a10]).contains(a10)) {
				a10 -= (-17);
				a10--;
			}
			++C37.f38;
		}
		H.out("o214 " + Std.string(([] : Array<Int>)));
		var v215:Array<Bool> = ([a10]).map((v216:Int) -> false);
		return (switch (E1.E1B(a10)) {
			case E1A: a10;
			case _: a10;
		});
	}
	override public function m24():Int {
		H.tick();
		if (Main.fn59(false, new C37(true, true))) return (-15);
		H.out("o217 " + Std.string((K4.K4A : Int)));
		switch (E0.E0A) {
			case E0A: {
				var v218:Int = 0x80000000;
			};
		}
		return (Std.parseInt(Std.string(Reflect.compare(0x7FFFFFFF, (new A3(805178707)).get()))) ?? 0);
	}
	public function m33():E0 {
		H.tick();
		if ((Type.enumIndex(E0.E0A) >= (K4.K4C : Int))) {
			if (true) return E0.E0A;
			H.out("o219 " + Std.string((new A3(3) : Int)));
			H.out("o220 " + Std.string(new C30()));
		} else {
			var v221:C43 = new C43(E0.E0A, 0x74EC);
		}
		this.f22 = (61 << ((K4.K4B : Int) & 31));
		this.f22 = (Std.parseInt(Std.string(0xFFFFFFFF)) ?? 0);
		H.out("o222 " + Std.string(({ var v223 = C37.f38; E0.E0A; })));
		this.f22 = ((new A3(105) : Int) >>> (0x7FFFFFFF & 31));
		H.out("o224 " + Std.string((new A3(115)).twice));
		C20.m29();
		switch (K4.K4B) {
			case K4.K4A: {
				try {
					H.out("o225 " + Std.string(248506172));
					if (Std.isOfType(new C11(), I5)) throw "boom";
				} catch (ex226:Err) {
					H.out("caught Err " + ex226.errCode);
					H.out("o227 " + Std.string(E1.E1A));
					H.out("o228 " + Std.string(51));
				} catch (ex229:haxe.Exception) {
					H.out("caught " + H.exn(ex229));
					H.out("o230 " + Std.string(false));
					var v231:C34 = new C43(E0.E0A, 0x7FFFFFFF);
				}
				C20.m25(Lambda.fold([33], (v232:Int, v233:Int) -> ([true, false]).indexOf(false), 0));
			};
			case K4.K4B: {
				final v234:K4 = K4.K4B;
			};
			case K4.K4C: {
				if (true) {
					final v235:Array<String> = ([] : Array<String>);
				} else {
					C20.m27(E0.E0A);
				}
			};
		}
		C20.m27(({ var v236 = (Std.parseInt("x,y,z") ?? 0); E0.E0A; }));
		return E0.E0A;
	}
}

class C34 extends C30 implements I5 {
	public function new(a35:Int, a36:Array<Int>) {
		super();
	}
	override public function m6(a7:E1):Int {
		H.tick();
		if (C30.f31) {
			function lf237(n238:Int):Int {
				H.tick();
				return n238 <= 0 ? (K4.K4A : Int) : (lf237(n238 - 1) + ([true, false, true]).indexOf(false));
			}
			H.out("lf237 " + lf237(2));
			final v239:Int = this.f21;
		}
		var v240:Array<Int> = [for (i241 in [234, 0xD3F3]) if ((([] : Array<Int>)).contains(136)) (K4.K4B : Int)];
		switch (E1.E1A) {
			case E1A: {
				(new C43(E0.E0A, (-2147483647))).m50((new A3(0x8369)).get(), 192);
			};
			case _: {
				if (false) {
					a7 = H.id(a7);
					H.out("o242 " + Std.string((K4.K4C : Int)));
				}
				H.out("o243 " + Std.string(255));
			};
		}
		if ((75 >= 253)) {
			m33();
			Main.fn55(36, C37.f38, 209);
		}
		H.out("o244 " + Std.string((0x39CB >>> ((-1557580759) & 31))));
		return (-1841498066);
	}
	override public function m24():Int {
		H.tick();
		final v245 = H.at(([] : Array<Int>), 0xD8CC, 0);
		C37.f38 = (new C43(E0.E0A, v245)).m6(E1.E1B(v245));
		C37.f38 &= (v245 - 0x80000000);
		var v246:Int = v245;
		if ((true && false)) {
			var v247:Array<Bool> = [true];
			H.out("o248 " + Std.string(0x7FFFFFFF));
			var v249:E0 = E0.E0A;
		}
		var v250:Int = (([v245]).length >>> (Type.enumIndex(E0.E0A) & 31));
		return v250;
	}
	override public function m33():E0 {
		H.tick();
		C30.f31 = (false && (Std.downcast((new C30() : C20), C37) != null));
		switch (E1.E1B(this.f22)) {
			case E1A: {
				H.out("o251 " + Std.string(1430287301));
			};
			case E1B(c252): {
				final lf253:(Int) -> Void = function(p254:Int):Void {
					H.tick();
					var v255:Bool = false;
					C20.m25(c252);
					H.out("o256 " + Std.string(p254));
				};
				var v257:Bool = true;
			};
		}
		H.out("o258 " + Std.string((new A3(this.f21) : Int)));
		if (true) {
			C20.m25(190);
		}
		return E0.E0A;
	}
	override public function m8(a9:Bool, a10:Int):Int {
		H.tick();
		var v259 = (switch (E1.E1A) {
			case E1A: Lambda.fold([a10, a10, (-148807813)], (v260:Int, v261:Int) -> 192, 0);
			case E1B(c262): a10;
		});
		var v263:K4 = K4.K4B;
		if ((false || false)) {
			(new C11()).m17();
		} else {
			H.out("o264 " + Std.string((K4.K4A : Int)));
			H.out("o265 " + Std.string(172));
		}
		H.out("o266 " + Std.string((0x80000000 * a10)));
		return (cast (this.f21) : Int);
	}
}
