import H;
import p.M1;

enum E0 {
	E0A;
}

enum E1 {
	E1A;
	E1B(a2:Int);
}

enum abstract K4(Int) to Int {
	var K4A = 1;
	var K4B = 4;
	var K4C = 7;
}

class C37 extends C34 implements I5 {
	public static var f38:Int = 67;
	public var f39:Int;
	var _f40:Bool;

	public var f40(get, set):Bool;

	function get_f40():Bool
		return _f40;

	function set_f40(v:Bool):Bool
		return _f40 = v;
	public function new(a41:Bool, a42:Bool) {
		super(181, ([] : Array<Int>));
		this.f39 = (-396206502);
		this._f40 = true;
	}
	override public function m6(a7:E1):Int {
		H.tick();
		try {
			if (false) {
				this.f39 = (-535599068);
			}
			if (this.f40) throw new Err((H.at(([] : Array<Int>), 0xE536, 0) - this.f21));
		} catch (ex267:String) {
			H.out("caught String " + ex267);
			var v268:Array<Int> = ([] : Array<Int>);
		} catch (ex269:Int) {
			H.out("caught Int " + ex269);
			var v270:Int = 44;
		} catch (ex271:Err) {
			H.out("caught Err " + ex271.errCode);
			var v272:Int = (Std.parseInt(Std.string(21)) ?? 0);
		} catch (ex273:Dynamic) {
			H.out("caught " + H.exn(ex273));
			final v274:Array<Bool> = [false, false];
		}
		this.f39 |= 246;
		H.out("o275 " + Std.string((Type.enumIndex(E1.E1B(0xFFFFFFFF)) ^ this.f22)));
		switch (a7) {
			case E1A: {
				final v276:(Int) -> Int = (p277:Int) -> p277;
				var v278 = this.f39;
			};
			case E1B(c279): {
				var v280 = (-6);
			};
			case _: {
				C20.m27(E0A);
			};
		}
		{
			H.out("o281 " + Std.string(42));
			switch (E1.E1A) {
				case E1A: {
					var v282:Array<Int> = [194, 292];
				};
				case E1B(_): {
					var v283 = false;
					final v284:Array<Int> = [35];
				};
				case _: {
					H.out("o285 " + Std.string(0x1FD0));
				};
			}
			var v286:Bool = false;
		}
		if (true) {
			var v287:Array<E0> = ([E0A, E0A, E0A] : Array<E0>);
			if (C11.f12) {
				Main.fn53(156);
				C37.f38 <<= (285 & 7);
			}
		} else {
			function lf288(n289:Int):Int {
				H.tick();
				return n289 <= 0 ? this.f22 : (lf288(n289 - 1) + 0xF1AE);
			}
			H.out("lf288 " + lf288(1));
		}
		final v290:Array<Int> = ((true ? [43] : ([] : Array<Int>)) : Array<Int>);
		try {
			switch (E0A) {
				case E0A: {
					H.out("o291 " + Std.string(65535));
				};
				case _: {
					var v292:Array<String> = ["\x41\x42", "日本語", "ab"];
				};
			}
			C20.m25(227);
			if (true) {
				H.out("o293 " + Std.string(true));
			} else {
				H.out("o294 " + Std.string(127));
				var v295:Int = 255;
			}
			if ((switch (E1.E1B(116)) {
				case E1A: Std.isOfType(new C43(E0.E0A, 196), C30);
				case E1B(c298): false;
			})) throw new Err(Lambda.fold(([] : Array<Int>), (v296:Int, v297:Int) -> 254, 0));
		} catch (ex299:Dynamic) {
			H.out("caught " + H.exn(ex299));
			if ((Std.downcast((new C30() : I5), C11) != null)) {
				Main.fn53(0xB2C9);
				m33();
			}
		}
		return (C20.m29() + Reflect.compare(this.f39, 272));
	}
	override public function m8(a9:Bool, a10:Int):Int {
		H.tick();
		var v300:K4 = K4.K4B;
		try {
			H.out("o301 " + Std.string(E0.E0A));
			if ((a9 || Std.isOfType(new C20(), C34))) throw "boom";
		} catch (ex302:Err) {
			H.out("caught Err " + ex302.errCode);
			switch (a10) {
				case 0: {
					this.f39 = a10;
				};
				case 1 | 6: {
					H.out("o303 " + Std.string((new A3(53) : Int)));
				};
				case _: {
					C37.f38 = a10;
					var v304:Int = a10;
				};
			}
		} catch (ex305:haxe.Exception) {
			H.out("caught " + H.exn(ex305));
			var v306:Bool = a9;
			C20.m27(E0A);
		}
		var v307:Bool = false;
		H.out("o308 " + Std.string(([] : Array<C30>)));
		Main.fn53((H.at([28, a10, (-16)], 49, 0) & 0xC02A));
		if (a9) return (new C11()).m17();
		{
			if (C30.f31) {
				this.f22 &= a10;
				(new C30()).m33();
			} else {
				var v309:C43 = new C43(E0A, a10);
			}
			Main.fn63();
			H.out("o310 " + Std.string([a10, a10, a10]));
		}
		var v311:Array<Array<C37>> = ([([new C37(true, a9), new C37(v307, a9), new C37(a9, a9)] : Array<C37>), ([new C37(a9, v307), new C37(a9, true)] : Array<C37>)] : Array<Array<C37>>);
		return C37.f38;
	}
}

class C43 extends C34 {
	public var f44:Array<Int>;
	public final f45:Bool;
	public var cb46:(Int) -> Int;
	public function new(a47:E0, a48:Int) {
		super(228, [a48]);
		this.f44 = [(-1181102513), a48, a48];
		this.f45 = true;
		this.cb46 = (p312:Int) -> 170;
	}
	override public function m6(a7:E1):Int {
		H.tick();
		if (this.f45) {
			H.out("o313 " + Std.string((new A3(241)).get()));
			var v314:Array<Int> = [0x7876, 0x7FFFFFFF];
			final v315:(Int) -> Bool = function(p316:Int):Bool {
				H.tick();
				this.m50(p316, p316);
				return false;
			};
		}
		this.f22 = ((Std.parseInt("a\rb") ?? 0) >> (H.at([0xDA96, 0x7CBC, 0x8857], 0x7FFF, 0) & 31));
		Main.fn53((185 % H.nz(0x255A)));
		C20.m25((201 | this.f22));
		H.out("o317 " + Std.string((C37.f38 % H.nz((new A3(251)).get()))));
		if ((136 < Type.enumIndex(E1B(162)))) {
			if (true) return Reflect.compare(36, 81);
			final v318:Int = (K4.K4B : Int);
			var v319:A3 = new A3(v318);
		} else {
			switch (Lambda.fold([0x7E63, 98], (v320:Int, v321:Int) -> Reflect.compare(v320, v320), 0)) {
				case 0: {
					H.out("o322 " + Std.string(new C11()));
					C30.f31 = false;
				};
				case 1 | 4: {
					final v323:() -> Void = function():Void {
						H.tick();
						Main.fn53(22);
						Main.fn55(22, 15, 0x80000000);
						H.out("o324 " + Std.string(([E1.E1B(623717714), E1.E1A] : Array<E1>)));
					};
				};
				case _: {
					var v325:Int = 69;
					this.f22 = v325;
				};
			}
			var v326 = false;
		}
		final v327 = Main.fn59(true, new C37(true, false), C37.f38);
		switch (E0.E0A) {
			case E0A: {
				C20.m29();
			};
		}
		H.out("o328 " + Std.string(Main.fn53(0x9026)));
		return (((switch (758797265) {
			case 0: [v327];
			case 1 | 6: [v327, false];
			case _: [false, v327];
		}) : Array<Bool>)).indexOf((switch (E0.E0A) {
			case E0A: true;
		}));
	}
	public function m49():Void {
		H.tick();
		if (((new A3((-19))).get() < this.f22)) {
			try {
				if (C30.f31) throw 40;
				H.out("o329 " + Std.string(90));
			} catch (ex330:Err) {
				H.out("caught Err " + ex330.errCode);
				var v331 = 235;
				var v332:E1 = E1A;
			} catch (ex333:haxe.Exception) {
				H.out("caught " + H.exn(ex333));
				C11.m14(0x565C);
				final v334:C20 = new C37(false, false);
			}
			H.out("o335 " + Std.string(new C30()));
		}
		try {
			if ((([232]).contains(67) && Std.isOfType(new C11(), I5))) throw ({ var v336 = Lambda.count([103, 34], v337 -> false); (["\n", "日本語"]).join(" "); });
			final v338:E1 = E1.E1B((-7));
		} catch (ex339:Dynamic) {
			H.out("caught " + H.exn(ex339));
			H.out("o340 " + Std.string(65535));
			H.out("o341 " + Std.string(new C37(false, false)));
		}
		H.out("o342 " + Std.string(true));
		final v343:Bool = C11.m14((Std.parseInt(Std.string(35)) ?? 0));
	}
	public function m50(a51:Int, a52:Int):Int {
		H.tick();
		final lf344:() -> Void = function():Void {
			H.tick();
			this.f22 += C37.f38;
			var v345:Int = Type.enumIndex(E0A);
			H.out("o346 " + Std.string(([a51, 124]).contains(a51)));
		};
		H.out("o347 " + Std.string(E1.E1B((-2063882650))));
		final v348:(Int, Int) -> Bool = function(p349:Int, p350:Int):Bool {
			H.tick();
			final v351:(Int) -> Bool = (p352:Int) -> true;
			final v353:E1 = E1.E1A;
			var v354 = a51;
			return true;
		};
		final lf355:() -> Void = function():Void {
			H.tick();
			var v356:Array<Bool> = [true];
			H.out("o357 " + Std.string(E1B(159)));
		};
		return (C20.m25(252) >>> ((a52 - a51) & 31));
	}
}

class Main {
	public static function fn53(a54:Int):Int {
		H.tick();
		if ((C11.f12 || C11.f12)) return a54;
		var v358:Bool = false;
		var v359:Int = a54;
		H.out("o360 " + Std.string(((K4.K4B : Int) ^ C37.f38)));
		final v361:Int = C20.m25(247);
		final v362:Array<Int> = (cast ([51, v361]) : Array<Int>);
		if (v358) {
			var v363:E1 = E1A;
			(new C43(E0.E0A, 65535)).m50(65535, 39);
			switch (K4.K4A) {
				case K4.K4A: {
					(new C11()).m17();
				};
				case K4.K4B: {
					H.out("o364 " + Std.string(v359));
				};
				case K4.K4C: {
					var v365:C43 = new C43(E0.E0A, v359);
					v359 &= a54;
				};
			}
		} else {
			a54--;
			v362.push(C37.f38);
		}
		if (v358) return (true ? v361 : a54);
		if (v358) {
			H.out("o366 " + Std.string((new A3(a54) : Int)));
			var v367 = v361;
			a54 = C37.f38;
		} else {
			if (v362.length > 0) v362[H.ix(Reflect.compare(v359, v359), v362.length)] = 526675702;
			v359--;
		}
		return (0x7FFFFFFF << ((new A3(43)).get() & 31));
	}
	public static inline function fn55(a56:Int, a57:Int, a58:Int):Int {
		H.tick();
		H.out("o368 " + Std.string(C20.m29()));
		switch (E0A) {
			case E0A: {
				switch (K4.K4B) {
					case K4.K4A: {
						C20.m27(E0A);
					};
					case K4.K4B: {
						var v369 = true;
					};
					case K4.K4C: {
						H.out("o370 " + Std.string(true));
						var v371:C11 = new C11();
					};
				}
				a56 *= (Std.parseInt("42") ?? 0);
			};
			case _: {
				if ((([] : Array<Int>)).contains(a57)) {
					var v372 = a56;
				} else {
					C37.f38 &= a58;
					var v373:Array<Int> = ([] : Array<Int>);
				}
			};
		}
		H.out("o374 " + Std.string((K4.K4A : Int)));
		final v375:Array<(Int, Bool) -> Int> = (([function(p377:Int, p378:Bool):Int {
			H.tick();
			H.out("o379 " + Std.string(a58));
			var v380:Bool = p378;
			final v381:() -> Bool = () -> p378;
			return 0xFFFFFFFF;
		}] : Array<(Int, Bool) -> Int>)).filter(v376 -> false);
		C30.f31 = (false || true);
		var v382:K4 = ({ var v383 = false; K4.K4B; });
		final v384:C11 = new C11();
		var v385 = C20.m29();
		H.out("o386 " + Std.string((new A3((new A3(v385)).get()) : Int)));
		return ((50 <= 181) ? H.at([v385], a57, 0) : (switch (E0A) {
			case E0A: a56;
		}));
	}
	public static function fn59(a60:Bool, a61:C37, ...r62:Int):Bool {
		H.tick();
		H.out("o387 " + Std.string(128));
		H.out("o388 " + Std.string(([(-2147483647), 0x80000000]).map((v389:Int) -> (new A3(v389) : A3))));
		switch (E1.E1B(Reflect.compare((-15), 0x7FFFFFFF))) {
			case E1A: {
				final lf390:(Int, Bool) -> Int = (p391:Int, p392:Bool) -> C37.f38;
				C37.f38 += (r62.toArray()).indexOf(161);
			};
			case E1B(_): {
				H.out("o393 " + Std.string(([new A3(222)] : Array<A3>)));
				var v394:Int = 74;
			};
		}
		final v395:Bool = (switch (E1.E1A) {
			case E1A: a60;
			case E1B(_): true;
		});
		return a60;
	}
	public static function fn63(...r64:Int):Int {
		H.tick();
		{
			final v396:A3 = new A3(0xA147);
		}
		var v397:Int = C20.m29();
		var v398:E1 = ((switch (Std.isOfType(new C37(false, false), C30)) {
			case true: E1B(v397);
			case false: E1B(v397);
		}) : E1);
		var v399:C37 = new C37(true, false);
		return (v397 * 4);
	}
	public static function fn65(a66:Int):Bool {
		H.tick();
		if (false) {
			var v400:A3 = (a66 : A3);
		} else {
			fn63();
		}
		var v401:C20 = new C43(E0.E0A, (Std.parseInt("Haxe") ?? 0));
		final v402 = (cast (a66) : Int);
		var v403:A3 = (-new A3(a66));
		return (((switch (69) {
			case 0: [253, v402, 257];
			case 2 | 5: [v402, v402];
			case _: [v402, a66, a66];
		}) : Array<Int>)).contains(C37.f38);
	}
	public static function fn67(a68:Bool):Bool {
		H.tick();
		var v404:C43 = new C43(E0.E0A, (-9));
		H.out("o405 " + Std.string(([0x35FE, 148, 43]).filter(v406 -> (([] : Array<Int>)).contains(v406))));
		final v407:C34 = ({ var v408 = 187; v404; });
		if (a68) {
			final lf409:(String, Int) -> Bool = function(p410:String, p411:Int):Bool {
				H.tick();
				var v412 = p411;
				return false;
			};
			var v413:Bool = a68;
			if (a68) {
				(new C11()).m6(E1A);
			}
		}
		H.out("o414 " + Std.string(C37.f38));
		C37.f38++;
		C37.f38 = (([125, 219]).indexOf((-20)) + 107);
		return Std.isOfType(((false ? new C37(a68, a68) : new C37(false, true)) : C37), C20);
	}
	public static function fn69():Int {
		H.tick();
		var v415:Int = (C37.f38 & Lambda.count([162, 202377700, (-13)], v416 -> Std.isOfType(new C20(), C20)));
		v415 ^= v415;
		H.out("o417 " + Std.string((switch (E1.E1B(v415)) {
			case E1A: C30.f31;
			case _: false;
		})));
		H.out("o418 " + Std.string(new C37(false, ([v415]).contains(v415))));
		H.out("o419 " + Std.string((-([v415, v415]).length)));
		H.out("o420 " + Std.string([for (i421 in 0...1) (K4.K4C : Int)]));
		return v415;
	}
	public static function fn70():Int {
		H.tick();
		final lf422:(Int, Bool) -> Void = function(p423:Int, p424:Bool):Void {
			H.tick();
			final v425:Bool = false;
			switch (E1B(p423)) {
				case E1A: {
					var v426:E0 = E0.E0A;
				};
				case E1B(c427): {
					H.out("o428 " + Std.string(266));
				};
			}
		};
		fn69();
		C20.m29();
		H.out("o429 " + Std.string([true]));
		H.out("o430 " + Std.string((([82]).contains(0x7FFFFFFF) ? (([] : Array<Int>)).contains(0xFFFFFFFF) : true)));
		if ((false || true)) return (-5);
		return 1181211388;
	}
	public static function section0():Void {
		H.tick();
		switch (([228]).indexOf(0xFFFFFFFF)) {
			case 0: {
				var v431:Int = (([] : Array<Int>)).indexOf(177);
				if (true) {
					H.out("o432 " + Std.string(v431));
				}
			};
			case 1 | 5: {
				H.out("o433 " + Std.string(Type.enumIndex(E1B(100))));
			};
			case _: {
				H.out("o434 " + Std.string(E1.E1A));
			};
		}
		var v435:C37 = new C37(false, Std.isOfType(new C37(true, true), C37));
		C37.f38 = (C37.f38 ^ 173);
		final v436 = (202 << (H.at([1671593889], 119, 0) & 31));
		C37.f38--;
		var v437 = (switch ((Std.parseInt(Std.string(0xFFFFFFFF)) ?? 0)) {
			case 0: C37.f38;
			case 2 | 4: C37.f38;
			case _: v436;
		});
		var v438 = 17;
		Main.fn63((v438 * 0x334F), v437);
		var v439:Int = 26;
	}
	public static function section1():Void {
		H.tick();
		C11.f12 = ({ var v440 = Lambda.count([116, 790196203, (-2147483647)], v441 -> true); C11.f12; });
		final v442:C20 = new C34(14, ([] : Array<Int>));
		C37.f38 = (Std.parseInt((["\u{1F600}"]).join("|")) ?? 0);
		final lf443:(String, Int) -> Bool = (p444:String, p445:Int) -> ((-2147483647) > p445);
		H.out("o446 " + Std.string(H.at([173], 283, 0)));
		if (false) {
			final v447 = C37.f38;
			try {
				if (C30.f31) throw new Err(v447);
				H.out("o448 " + Std.string(v447));
				C37.f38 = 295;
				C37.f38 &= v447;
			} catch (ex449:Dynamic) {
				H.out("caught " + H.exn(ex449));
				var v450:Int = v447;
				var v451:Int = v450;
			}
		} else {
			function lf452(n453:Int):Int {
				H.tick();
				return n453 <= 0 ? ([n453]).length : (lf452(n453 - 1) + n453);
			}
			H.out("lf452 " + lf452(2));
		}
		H.out("o454 " + Std.string(new C37(false, C11.f12)));
		try {
			if ((291 >= (new A3(184)).twice)) throw 67;
			function lf455(n456:Int):Int {
				H.tick();
				return n456 <= 0 ? n456 : (lf455(n456 - 1) + 99);
			}
			H.out("lf455 " + lf455(5));
			final v457:() -> Bool = function():Bool {
				H.tick();
				H.out("o458 " + Std.string(15));
				H.out("o459 " + Std.string([252, 255]));
				return false;
			};
			H.out("o460 " + Std.string((([] : Array<Int>)).contains(276)));
		} catch (ex461:Err) {
			H.out("caught Err " + ex461.errCode);
			if (true) {
				(new C11()).m17();
				H.out("o462 " + Std.string(new C37(false, true)));
				C37.f38 = 14;
			} else {
				H.out("o463 " + Std.string(0xE934));
				var v464:Array<() -> Int> = ([] : Array<() -> Int>);
			}
		} catch (ex465:haxe.Exception) {
			H.out("caught " + H.exn(ex465));
			C37.f38 = (Std.parseInt(Std.string(65)) ?? 0);
		}
		H.out("o466 " + Std.string([(K4.K4B : Int)]));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
