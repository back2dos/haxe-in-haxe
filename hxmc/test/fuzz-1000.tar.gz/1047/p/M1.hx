package p;

import Main;
import H;
import p.M1;

class M1 {}

enum E3 {
	E3A;
	E3B(a6:E3, a7:Int);
	E3C(a8:Int, a9:E3);
}

interface I19 {
	function m20(a21:Bool, a22:Bool):String;
}
