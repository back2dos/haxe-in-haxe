import H;
import p.M1;

enum E0 {
	E0A;
	E0B(a1:String, a2:E0);
}

enum E10 {
	E10A;
	E10B(a12:E10);
	E10C(a13:Int);
}

typedef S14 = {x15:Int, x16:String, x17:Int};

enum abstract K18(Int) to Int {
	var K18A = 1;
	var K18B = 4;
	var K18C = 7;
}

class C23 implements I19 {
	public var cb24:(Int) -> Int;
	public function new(a25:Int, a26:Bool) {
		this.cb24 = (p54:Int) -> a25;
	}
	public function m20(a21:Bool, a22:Bool):String {
		H.tick();
		H.out("o55 " + Std.string(149));
		var v56:Int = 275;
		v56 ^= ((("x,y,z").charCodeAt(v56) ?? -1) ^ v56);
		{
			switch (a21) {
				case true: {
					var v57:Array<Int> = [v56, v56, (-13)];
				};
				case false: {
					var v58 = "abc";
					var v59:Array<Int> = [0x6AC7];
				};
			}
		}
		{
			H.out("o60 " + Std.string(new C23((-1744970722), a21)));
			if (false) {
				var v61 = v56;
			} else {
				v56 = H.id(v56);
				v56 = H.id(v56);
			}
		}
		try {
			H.out("o62 " + Std.string(E10C(v56)));
			var v63:E10 = E10.E10C(v56);
			switch (E0A) {
				case E0A: {
					var v64:C23 = new C29();
				};
				case E0B(c65, c66): {
					var v67:Int = v56;
				};
			}
			if (true) throw new Err((a22 ? v56 : v56));
		} catch (ex68:String) {
			H.out("caught String " + ex68);
			var v69:E0 = E0.E0A;
		} catch (ex70:Int) {
			H.out("caught Int " + ex70);
			H.out("o71 " + Std.string((([-3 => v56, 4 => v56, 11 => ex70] : Map<Int, Int>)).exists(11)));
			try {
				if (true) throw 60;
				var v72 = v56;
				final v73:Map<String, String> = new Map<String, String>();
				v72 <<= (v72 & 7);
			} catch (ex74:Err) {
				H.out("caught Err " + ex74.errCode);
				H.out("o75 " + Std.string(E0A));
				var v76:Box<Map<String, Int>> = new Box<Map<String, Int>>((["k0" => v56] : Map<String, Int>));
			} catch (ex77:haxe.Exception) {
				H.out("caught " + H.exn(ex77));
				var v78:S14 = ({x15: ex70, x16: "\n", x17: v56} : S14);
			}
		} catch (ex79:Err) {
			H.out("caught Err " + ex79.errCode);
			var v80:Bool = (E0A).match(E0B(_, _));
			{
				var v81:I19 = new C29();
			}
		} catch (ex82:Dynamic) {
			H.out("caught " + H.exn(ex82));
			if (false) {
				v56 = 168;
			}
			var v83:Array<Box<Int>> = ([new Box((-10)), new Box<Int>(0x80000000), new Box(v56)] : Array<Box<Int>>);
		}
		if (a22) {
			H.out("o84 " + "-7");
			v56 &= 82;
			if (a21) {
				H.out("o85 " + Std.string(new C29()));
				H.out("o86 " + Std.string((K18.K18A : Int)));
			}
		} else {
			if (([296, v56]).contains(140)) {
				var v87:Null<Int> = v56;
				v56 = H.id(v56);
				var v88:Array<Bool> = [false, a21];
			} else {
				H.out("o89 " + Std.string(v56));
				var v90:C29 = new C29();
			}
			var v91 = a22;
		}
		final v92 = a21;
		v56 |= (K18.K18A : Int);
		return ((("abc").toLowerCase() + Std.string(E10C(v56))) + false);
	}
	public static function m27(?a28:Null<Bool>):Int {
		H.tick();
		try {
			if (Std.isOfType(new C29(), I19)) throw 91;
			H.out("o93 " + Std.string(219));
		} catch (ex94:Err) {
			H.out("caught Err " + ex94.errCode);
			var v95:K18 = K18.K18B;
			var v96:S14 = ({x16: "ab", x15: 41, x17: (-1850981159)} : S14);
		} catch (ex97:haxe.Exception) {
			H.out("caught " + H.exn(ex97));
			if ((([] : Array<Int>)).contains(4)) {
				var v98:Int = 187;
				(new C23(v98, true)).m20(false, false);
				H.out("o99 " + Std.string(v98));
			}
			(new C29()).m20(true, Std.isOfType(new C23(132, false), C29));
		}
		try {
			if (false) throw "boom";
			if (true) {
				H.out("o100 " + Std.string(129));
				H.out("o101 " + "a");
			}
		} catch (ex102:String) {
			H.out("caught String " + ex102);
			{ var dyn103:Dynamic = ({x15: 0x68CD, x16: "a", x17: 108} : S14); H.out("dyn " + Std.string(dyn103.x15) + " " + Std.string(Reflect.field(dyn103, "x15"))); }
		} catch (ex104:Int) {
			H.out("caught Int " + ex104);
			if ((Std.downcast((new C23(ex104, false) : C23), C29) != null)) return ('$$').indexOf("\"q\"");
			if (true) {
				var v105:S14 = ({x16: "\t", x17: ex104, x15: ex104} : S14);
				final v106:Array<String> = ["ab", "A-B-C", "0"];
			} else {
				var v107:E10 = E10.E10C(118);
			}
		} catch (ex108:Err) {
			H.out("caught Err " + ex108.errCode);
			H.out("o109 " + Std.string(0x648B));
			(new C29()).m20(false, Std.isOfType(new C23(91, true), C29));
		} catch (ex110:Dynamic) {
			H.out("caught " + H.exn(ex110));
			H.out("o111 " + Std.string(Std.isOfType(new C29(), C29)));
			(new C29()).m33("ab");
		}
		H.out("o112 " + Std.string(new Box(StringTools.replace("zz", "a", "A-B-C"))));
		return 0x7FFFFFFF;
	}
}

class C29 extends C23 implements I19 {
	public var f30:Int;
	public function new() {
		super((K18.K18C : Int), true);
		this.f30 = ("hello world").indexOf("0");
	}
	override public function m20(a21:Bool, a22:Bool):String {
		H.tick();
		var v113:Bool = a21;
		this.f30 = (~(({x15: 71, x17: (-4), x16: "\n"} : S14)).x15);
		H.out("o114 " + Std.string((66 & 150)));
		this.f30 = (switch (E10.E10C(86)) {
			case E10A: 1989001417;
			case E10B(E10B(_)): Type.enumIndex(E10C(87));
			case E10C(c115): ("\t").indexOf("\"q\"");
			case _: this.f30;
		});
		var v116:C29 = new C29();
		return "\\";
	}
	public function m31(a32:String):Int {
		H.tick();
		var v117 = (new C23(231, true)).m20(StringTools.startsWith("-7", a32), false);
		var v118:Array<Bool> = ([] : Array<Bool>);
		final v119:Null<Int> = ((switch (a32) {
			case "a" | "b": null;
			case "Haxe": null;
			case "": 6;
			case _: 1305107061;
		}) : Null<Int>);
		if (H.apply((new Map<String, E3>()).exists("k1"), (v120:Bool) -> true)) {
			if (v118.length > 0) v118[H.ix(("zz").indexOf(a32), v118.length)] = true;
		}
		this.f30 ^= ({ var v121 = "\t"; Type.enumIndex(E0A); });
		final v122:(Int) -> Int = function(p123:Int):Int {
			H.tick();
			Main.fn35(true);
			this.f30 = p123;
			var v124 = "a";
			return 0x3347;
		};
		H.out("o125 " + Std.string(new C29()));
		return Lambda.count([(({x17: 0x2192, x15: 0x2AE1, x16: a32} : S14)).x17], v126 -> (v126 == 294));
	}
	public function m33(a34:String):Int {
		H.tick();
		H.out("o127 " + Std.string((2064093706 & 60)));
		final v128 = String.fromCharCode(65 + ((184) & 15));
		this.f30 = (switch (("0").length) {
			case 0: Type.enumIndex(E0.E0A);
			case 2 | 4: ((([-3 => 134, 4 => 285] : Map<Int, Int>)).get(0xFFFFFFFF) ?? 0);
			case _: ([v128]).indexOf(v128);
		});
		H.out("o129 " + "q");
		if ((([] : Array<Int>)).contains(0x96A4)) {
			this.f30 = (-17);
			if (false) {
				var v130 = 28;
			} else {
				H.out("o131 " + Std.string(79));
				var v132:Int = 277;
			}
			(new C29()).m20(([0xDB46, 259, (-2147483647)]).contains(129), ([(-4)]).contains(0x7DB));
		}
		var v133:E10 = E10C(this.f30);
		var v134 = (a34).charAt(2);
		m20((switch (Std.string(85)) {
			case "a" | "b": ((["k0" => 32, "k1" => 13] : Map<String, Int>)).exists("k1");
			case "Haxe": Std.isOfType(new C29(), I19);
			case _: Std.isOfType(new C29(), C29);
		}), Std.isOfType(new C29(), C29));
		return ({ var v135 = (([false, false, false]).indexOf(true) * (-483078780)); ((a34).charCodeAt((v134).indexOf(v134)) ?? -1); });
	}
}

class Main {
	public static function fn35(a36:Bool):Int {
		H.tick();
		try {
			var v136:Map<String, Int> = (["k0" => 143] : Map<String, Int>);
			(new C29()).m20(a36, a36);
			if ((("").toUpperCase() < "q")) throw "boom";
		} catch (ex137:Dynamic) {
			H.out("caught " + H.exn(ex137));
			{ var dyn138:Dynamic = ({x17: 35, x15: 132, x16: "A-B-C"} : S14); H.out("dyn " + Std.string(dyn138.x15) + " " + Std.string(Reflect.field(dyn138, "x15"))); }
		}
		(new C29()).m20(a36, (StringTools.replace("  pad  ", "a", "abc") < StringTools.trim("\"q\"")));
		var v139:Map<String, Int> = H.apply("-7", (v140:String) -> (["k0" => 157] : Map<String, Int>));
		final v141:String = ("x,y,z").toLowerCase();
		H.out("o142 " + Std.string(({x16: v141, x17: 135, x15: Type.enumIndex(E3.E3A)} : S14)));
		H.out("o143 " + Std.string(("\"q\"").indexOf("ab")));
		if (([253]).contains(((v141).charCodeAt(866674107) ?? -1))) {
			var v144:Array<String> = [v141, "\n", v141];
			final v145:Int = H.at(([] : Array<Int>), 0xED6B, 0);
			final v146:I19 = new C23(v145, a36);
		} else {
			final v147:Array<C23> = ([] : Array<C23>);
			final v148 = true;
		}
		switch (E3.E3C(0xC057, E3.E3A)) {
			case E3A: {
				H.out("o149 " + Std.string(((([-3 => 186, 4 => 16] : Map<Int, Int>)).get(18) ?? 0)));
				H.out("o150 " + Std.string(E3.E3A));
			};
			case E3B(_, _): {
				switch ((-11)) {
					case 0: {
						final v151 = 12;
						var v152 = v141;
					};
					case 3 | 5: {
						H.out("o153 " + Std.string(a36));
						var v154:Int = 209;
					};
					case _: {
						var v155 = 26;
					};
				}
			};
			case E3C(_, _): {
				if (a36) {
					var v156 = (-12);
					var v157:Map<String, Int> = v139;
					H.out("o158 " + Std.string(({x15: 137, x16: "hello world", x17: 177} : S14)));
				}
				H.out("o159 " + v141);
			};
			case _: {
				var v160:C29 = new C29();
				var v161:Int = (([] : Array<Int>)).length;
			};
		}
		if ((a36 || a36)) return 0xEF12;
		return (K18.K18B : Int);
	}
	public static function fn37(a38:Int = 9):String {
		H.tick();
		H.out("o162 " + Std.string(a38));
		a38 = ((Std.parseInt("hello world") ?? 0) | ([a38]).indexOf(94));
		try {
			if (({ var v163 = true; true; })) throw StringTools.lpad("a", "*", (107 & 7));
			final v164:Map<Int, Int> = ([-3 => a38, 4 => a38, 11 => a38] : Map<Int, Int>);
			fn35((new Map<String, String>()).exists("k1"));
			final v165:Box<Int> = new Box<Int>(164);
		} catch (ex166:String) {
			H.out("caught String " + ex166);
			var v167 = a38;
			H.out("o168 " + ex166);
		} catch (ex169:Int) {
			H.out("caught Int " + ex169);
			H.out("o170 " + Std.string((K18.K18A : Int)));
		} catch (ex171:Err) {
			H.out("caught Err " + ex171.errCode);
			final v172:Null<Int> = null;
		} catch (ex173:Dynamic) {
			H.out("caught " + H.exn(ex173));
			H.out("o174 " + Std.string(H.at([0x3597], a38, 0)));
			H.out("o175 " + Std.string(([a38, a38]).contains(a38)));
		}
		switch (E10C(Lambda.count(([] : Array<Int>), v176 -> (E3.E3A).match(E3A)))) {
			case E10A: {
				try {
					if (false) throw StringTools.trim("0");
					var v177:Int = 293;
				} catch (ex178:Dynamic) {
					H.out("caught " + H.exn(ex178));
					final v179:Bool = true;
					H.out("o180 " + Std.string((-12)));
				}
				switch (K18.K18A) {
					case K18.K18A: {
						var v181:Map<String, Bool> = new Map<String, Bool>();
					};
					case K18.K18B: {
						final v182:Int = 1493436843;
						a38 &= v182;
					};
					case K18.K18C: {
						var v183:Map<String, Bool> = new Map<String, Bool>();
						final v184 = true;
					};
				}
			};
			case E10C(c185) if (c185 > 3): {
				var v186:Int = (-2019006786);
			};
			case _: {
				try {
					if (true) throw "boom";
					H.out("o187 " + Std.string(new C23((-2147483647), false)));
					var v188 = false;
				} catch (ex189:Dynamic) {
					H.out("caught " + H.exn(ex189));
					var v190:Int = a38;
				}
			};
		}
		final v191:Array<Int> = [0x15EE, ("hello world").indexOf("A-B-C"), 165];
		switch (E10B(E10.E10C(a38))) {
			case E10A: {
				H.out("o192 " + Std.string((new Map<String, Int>()).exists("\"q\"")));
			};
			case E10B(_): {
				switch (a38) {
					case 0: {
						H.out("o193 " + "Haxe");
					};
					case 2 | 5: {
						a38++;
					};
					case _: {
						a38 |= a38;
					};
				}
				v191.sort((x, y) -> x - y);
			};
			case E10C(c194) if (c194 > 2): {
				var v195:Bool = false;
			};
			case _: {
				switch (a38) {
					case 0: {
						H.out("o196 " + Std.string(a38));
					};
					case 3 | 5: {
						(new C29()).m20(false, true);
					};
					case _: {
						final v197:Map<String, S14> = (["k0" => ({x15: a38, x16: "A-B-C", x17: 208} : S14), "k1" => ({x17: a38, x16: "ab", x15: a38} : S14), "k2" => ({x15: a38, x16: "-7", x17: a38} : S14)] : Map<String, S14>);
					};
				}
			};
		}
		(new C29()).m33("\\");
		H.out("o198 " + Std.string(new Box<String>("0")));
		return "\n";
	}
	public static function fn39(a40:Int, a41:E10, a42:String = "d"):String {
		H.tick();
		switch (a42) {
			case "a" | "b": {
				final v199:Bool = (E3.E3A).match(E3C(_, _));
				final v200 = ("a").length;
			};
			case "Haxe": {
				var v201 = a42;
			};
			case _: {
				final v202:E0 = E0A;
			};
		}
		var v203 = ((a42).toUpperCase() > (a42).toUpperCase());
		a41 = ({ var v204 = false; a41; });
		return a42;
	}
	public static function fn43(a44:Bool, ?a45:Null<Int>):E0 {
		H.tick();
		Main.fn37();
		switch (StringTools.trim('$$')) {
			case "a" | "b": {
				try {
					var v205:String = "abc";
					if ((new Map<String, Int>()).exists(v205)) throw new Err(773513276);
				} catch (ex206:Err) {
					H.out("caught Err " + ex206.errCode);
					var v207:Map<String, Int> = (["k0" => 0x7B4E, "k1" => 215] : Map<String, Int>);
				} catch (ex208:haxe.Exception) {
					H.out("caught " + H.exn(ex208));
					var v209:Array<Int> = [0x5E88];
				}
				var v210 = 0x888;
			};
			case "Haxe": {
				var v211:Array<Null<Int>> = ([] : Array<Null<Int>>);
			};
			case _: {
				(new C29()).m20(true, true);
				switch (E3.E3A) {
					case E3A: {
						var v212:Int = 0xB5D9;
						var v213:Array<String> = ["zz", "42", "ab"];
					};
					case _: {
						var v214:Array<E10> = ([E10.E10A, E10A] : Array<E10>);
						final v215:(Bool) -> Bool = function(p216:Bool):Bool {
							H.tick();
							final v217:Map<String, Int> = new Map<String, Int>();
							H.out("o218 " + "ab");
							var v219:Array<Array<Int>> = ([] : Array<Array<Int>>);
							return false;
						};
					};
				}
			};
		}
		if ((Lambda.count([0x7FFFFFFF], v220 -> true) > (Std.parseInt(Std.string(195)) ?? 0))) {
			switch (K18.K18B) {
				case K18.K18A: {
					final v221:Int = 184;
					var v222:Array<Array<Int>> = ([([] : Array<Int>), [v221, v221, v221]] : Array<Array<Int>>);
				};
				case K18.K18B: {
					H.out("o223 " + Std.string((K18.K18A : Int)));
					Main.fn39((-1344015083), E10.E10C(152), "");
				};
				case K18.K18C: {
					var v224:Array<E0> = ([E0.E0A, E0.E0A] : Array<E0>);
				};
			}
			var v225:Bool = true;
			var v226:Array<Array<String>> = ([["A-B-C", "\t"]] : Array<Array<String>>);
		}
		var v227:Int = 84;
		return E0.E0B(StringTools.trim("a"), E0.E0B(Std.string(v227), E0.E0A));
	}
	public static function fn46():Int {
		H.tick();
		var v228 = "abc";
		if ((switch (171) {
			case 0: (E3.E3A).match(E3C(_, _));
			case 3 | 6: (new Map<String, String>()).exists(v228);
			case c229 if (c229 > 10): false;
			case _: false;
		})) {
			var v230:Box<K18> = new Box<K18>(K18.K18C);
			var v231:Map<Int, Map<Int, E0>> = new Map<Int, Map<Int, E0>>();
			var v232 = ([(-18)]).length;
		} else {
			if (StringTools.contains(v228, "zz")) {
				(new C29()).m20(true, true);
				var v233:Int = 209;
			} else {
				final v234:(String, Int) -> Bool = (p235:String, p236:Int) -> false;
				H.out("o237 " + Std.string(245));
			}
			H.out("o238 " + Std.string(true));
		}
		H.out("o239 " + Std.string((Reflect.compare(0x2565, 78) & Reflect.compare(0xD300, 224))));
		var v240:Int = (switch (H.id([269])) {
			case []: 222;
			case [c241]: c241;
			case [_, c242]: c242;
			case _: 0x53CB;
		});
		var v243:S14 = ({x15: ((([-3 => (-244683304)] : Map<Int, Int>)).get(-3) ?? 0), x16: ([false, false]).join(","), x17: v240} : S14);
		H.out("o244 " + Std.string(false));
		if (((({x15: 126, x16: "hello world", x17: 66} : S14)).x15 == 0x3F30)) return ((v228).length >>> (v240 & 31));
		return (new C29()).m31((StringTools.trim(v228)).substring(1, 4));
	}
	public static function fn47(a48:Array<K18>):Void {
		H.tick();
		var v245:K18 = K18.K18A;
		var v246:Array<Int> = ([] : Array<Int>);
		if (false) {
			var v247:Map<String, String> = (["k0" => "\t", "k1" => "", "k2" => ""] : Map<String, String>);
		} else {
			if ((new Map<String, String>()).exists("k3")) {
				Main.fn35(true);
				var v248:E10 = E10.E10C(208);
			} else {
				H.out("o249 " + "-7");
				H.out("o250 " + Std.string(39));
			}
			var v251:Map<Int, Int> = new Map<Int, Int>();
		}
	}
	public static function fn49():String {
		H.tick();
		H.out("o252 " + Std.string(E0.E0A));
		var v253:Bool = (StringTools.contains("42", "") && StringTools.contains("A-B-C", "  pad  "));
		H.out("o254 " + Std.string((switch (E3.E3A) {
			case E3A: v253;
			case E3B(c255, c256): StringTools.endsWith("-7", "a");
			case E3C(c257, E3C(_, _)) if (c257 > 3): false;
			case _: (E3.E3A).match(E3A);
		})));
		H.out("o258 " + Std.string(new C29()));
		var v259:Int = (~152);
		var v260:String = (("A-B-C").toUpperCase() + "\n");
		H.out("o261 " + Std.string(v253));
		H.out("o262 " + Std.string(v259));
		return '$$';
	}
	public static function fn50(a51:Int, a52:Bool, a53:Array<Int>):E3 {
		H.tick();
		var v263:Array<Int> = [a51, a51];
		var v264:Map<String, Int> = new Map<String, Int>();
		if ((true ? a52 : (a53).contains(a51))) {
			var v265:Map<Int, String> = new Map<Int, String>();
			H.out("o266 " + Std.string(({x15: 29, x16: "x,y,z", x17: 3} : S14)));
			if (((["k0" => new C29(), "k1" => new C23(a51, false)] : Map<String, C23>)).exists("k3")) {
				var v267:S14 = ({x15: a51, x17: a51, x16: "q"} : S14);
				H.out("o268 " + Std.string(a51));
			} else {
				var v269:Map<Int, Int> = new Map<Int, Int>();
				final v270:K18 = K18.K18B;
			}
		} else {
			var v271 = ("42").length;
		}
		return E3.E3C((("  pad  ").charCodeAt(189) ?? -1), E3.E3B(E3.E3A, a51));
	}
	public static function section0():Void {
		H.tick();
		C23.m27(((new Map<Int, String>()).exists(18) ? true : ([12, 0xE7CD]).contains(290)));
		H.out("o272 " + StringTools.lpad("abc", "*", ((({x16: "zz", x17: 218, x15: 190} : S14)).x17 & 7)));
		var v273:String = (new C29()).m20((([-3 => 130, 4 => 182, 11 => 26] : Map<Int, Int>)).exists(11), ([192]).contains(17));
		if (StringTools.contains("\n", (v273).toUpperCase())) {
			H.out("o274 " + v273);
		}
		var v275:K18 = K18.K18A;
		var v276:Map<String, String> = (["k0" => (v273).toUpperCase(), "k1" => "\t"] : Map<String, String>);
		var v277:E0 = fn43(StringTools.contains(v273, v273));
		Main.fn50((194 >>> (Lambda.fold(([] : Array<Int>), (v278:Int, v279:Int) -> (Std.parseInt(Std.string(v278)) ?? 0), 0) & 31)), (168 <= 65535), ([] : Array<Int>));
		(new C29()).m20((Std.string(0x7FFFFFFF) == v273), (v273 == Std.string(true)));
	}
	public static function section1():Void {
		H.tick();
		var v280:Array<Bool> = ([] : Array<Bool>);
		try {
			if (false) {
				H.out("o281 " + "q");
				H.out("o282 " + Std.string(0x80000000));
			}
			var v283 = 0xDF69;
			if ((StringTools.startsWith("Haxe", "x,y,z") ? StringTools.startsWith("", "\n") : ([v283]).contains(v283))) throw new Err((Type.enumIndex(E10C(743472552)) % H.nz(v283)));
		} catch (ex284:Err) {
			H.out("caught Err " + ex284.errCode);
			var v285:Box<Int> = new Box(959714078);
			var v286:Null<Int> = 66;
		} catch (ex287:haxe.Exception) {
			H.out("caught " + H.exn(ex287));
			var v288:S14 = ({x15: 772413976, x16: "a", x17: 142} : S14);
		}
		final v289:String = ("42" + Std.string(true));
		var v290:I19 = new C29();
		H.out("o291 " + Std.string(H.id(191)));
		try {
			final v292:Map<String, String> = new Map<String, String>();
			if ((StringTools.contains(v289, v289) ? Std.isOfType(new C29(), C29) : (([-3 => true, 4 => false, 11 => false] : Map<Int, Bool>)).exists(18))) throw new Err((220 % H.nz(210)));
		} catch (ex293:Dynamic) {
			H.out("caught " + H.exn(ex293));
			var v294:String = v289;
		}
		try {
			if ((((v289).charCodeAt(138) ?? -1) != ([233, 8]).length)) throw (v289 + Std.string(0x7ADB));
			var v295:Array<(Int, String) -> Int> = ([(p296:Int, p297:String) -> p296, (p298:Int, p299:String) -> 248, function(p300:Int, p301:String):Int {
				H.tick();
				var v302:Map<Int, Int> = ([-3 => 0x7FFFFFFF, 4 => p300] : Map<Int, Int>);
				return 119;
			}] : Array<(Int, String) -> Int>);
			H.out("o303 " + Std.string(((([-3 => 300] : Map<Int, Int>)).get(0xB098) ?? 0)));
		} catch (ex304:Dynamic) {
			H.out("caught " + H.exn(ex304));
			var v305 = StringTools.hex((65535) & 0xFFFF, 4);
		}
		final v306:String = (new C29()).m20(([192]).contains(33), ([299]).contains(528596228));
	}
	public static function section2():Void {
		H.tick();
		if (((["k0" => 149] : Map<String, Int>)).exists("k3")) {
			H.out("o307 " + Std.string([65535, 45]));
			final v308:E3 = E3.E3A;
			var v309:C29 = new C29();
		} else {
			var v310 = Type.enumIndex(E3.E3A);
			var v311:Map<Int, Int> = ([-3 => 157] : Map<Int, Int>);
		}
		var v312 = ("  pad  ").lastIndexOf(Std.string(true));
		try {
			if ((true ? StringTools.startsWith("\\", "q") : false)) throw new Err(H.apply(Lambda.fold(([] : Array<Int>), (v314:Int, v315:Int) -> ("q").length, 0), (v313:Int) -> (("q").charCodeAt(v312) ?? -1)));
			(new C29()).m20(([v312, v312, v312]).contains(v312), false);
			{ var dyn316:Dynamic = ({x16: "a", x17: v312, x15: v312} : S14); H.out("dyn " + Std.string(dyn316.x15) + " " + Std.string(Reflect.field(dyn316, "x15"))); }
			var v317:Map<String, String> = new Map<String, String>();
		} catch (ex318:String) {
			H.out("caught String " + ex318);
			var v319:Int = 125;
		} catch (ex320:Int) {
			H.out("caught Int " + ex320);
			v312 = (({x15: ex320, x17: ex320, x16: "\\"} : S14)).x15;
			var v321:Array<Int> = [35];
		} catch (ex322:Err) {
			H.out("caught Err " + ex322.errCode);
			v312 += H.at([v312, v312], v312, 0);
		} catch (ex323:Dynamic) {
			H.out("caught " + H.exn(ex323));
			if (([v312]).contains(v312)) {
				var v324:Array<Int> = [171, v312, v312];
			} else {
				H.out("o325 " + Std.string(283));
				v312--;
			}
			var v326:Map<String, String> = (["k0" => "\\"] : Map<String, String>);
		}
		var v327:Array<Int> = (((E3.E3A).match(E3A) ? ([] : Array<Int>) : [148, v312]) : Array<Int>);
		Main.fn39(v312, H.id(E10.E10C(101)));
		final v328:Array<String> = ([82, v312]).map((v329:Int) -> Std.string(v312));
		final v330:(String) -> String = (p331:String) -> p331;
		var v332:E10 = E10B(E10A);
	}
	public static function section3():Void {
		H.tick();
		var v333:String = (false ? StringTools.replace("x,y,z", "a", "\t") : "-7");
		H.out("o334 " + Std.string((new Map<Int, S14>()).exists(11)));
		var v335:String = (v333 + 44);
		var v336:Array<Int> = (([] : Array<Int>)).concat([90, (-2133555443), 97]);
		final v337:Int = 0x7FFFFFFF;
		(new C29()).m20((251 > v337), (new Map<String, S14>()).exists("k2"));
		var v338:Bool = (v337 != v337);
		switch (v337) {
			case 0: {
				if (StringTools.contains(v335, v333)) {
					Main.fn37(v337);
					H.out("o339 " + Std.string((K18.K18B : Int)));
					var v340:Array<Bool> = [false];
				}
			};
			case 1 | 5: {
				H.out("o341 " + Std.string(new C29()));
				v338 = true;
			};
			case c342 if (c342 > 10): {
				var v343 = c342;
			};
			case _: {
				var v344:Array<C23> = ([new C29(), new C23(74, v338), new C29()] : Array<C23>);
				Main.fn49();
			};
		}
		H.out("o345 " + Std.string(new C29()));
	}
	public static function section4():Void {
		H.tick();
		H.out("o346 " + Std.string(E10B(E10C(955016805))));
		var v347:S14 = ({x15: 74, x16: "Haxe", x17: 273} : S14);
		var v348:Array<Int> = ([0xF1E0, 58]).map((v349:Int) -> v349);
		var v350 = ((-1899471333) % H.nz((v347).x15));
		if ((true ? true : (([-3 => v350, 4 => v350] : Map<Int, Int>)).exists(18))) {
			if (true) {
				final v351 = v350;
			} else {
				var v352:String = "q";
			}
			var v353:Array<(String) -> Int> = ([(p354:String) -> v350] : Array<(String) -> Int>);
			v348.unshift((("0").charCodeAt(0x8E0E) ?? -1));
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
