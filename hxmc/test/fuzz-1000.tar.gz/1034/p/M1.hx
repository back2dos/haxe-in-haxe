package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
	E0B(a1:String);
	E0C;
}

interface I7 {
	function m8():String;
	function m9(a10:Bool):Float;
}

class C16 implements I11 {
	public final f17:String;
	public static var f18:String = "ab";
	public var cb19:(Int) -> Int;
	public function new() {
		this.f17 = "x,y,z";
		this.cb19 = function(p56:Int):Int {
			H.tick();
			var v57:Array<String> = ["A-B-C"];
			H.out("o58 " + Std.string(["q", "ab"]));
			var v59 = p56;
			return v59;
		};
	}
	public function m12():Int {
		H.tick();
		H.out("o60 " + Std.string((Math.PI - 100.75)));
		switch ((0x50F << (2109554516 & 31))) {
			case 0: {
				H.out("o61 " + Std.string(247));
			};
			case 2 | 4: {
				H.out("o62 " + Std.string(176));
			};
			case _: {
				var v63:I11 = new C27(0xB6A8);
			};
		}
		H.out("o64 " + Std.string(65535));
		H.out("o65 " + "\n");
		var v66 = Math.ceil(Std.parseFloat("12.5"));
		var v67:Array<Null<Int>> = ([v66, v66, v66] : Array<Null<Int>>);
		var v68:Array<String> = (("a\rb").split("a")).map((v69:String) -> Std.string(v66));
		H.out("o70 " + Std.string((cast (((([-3 => v66, 4 => v66] : Map<Int, Int>)).get(v66) ?? 0)) : Int)));
		final lf71:(String, Int) -> Void = function(p72:String, p73:Int):Void {
			H.tick();
			try {
				v66 = H.id(v66);
				v66 = 0x4C12;
				if (StringTools.startsWith(p72, "-7")) throw 21;
			} catch (ex74:String) {
				H.out("caught String " + ex74);
				var v75 = p73;
			} catch (ex76:Int) {
				H.out("caught Int " + ex76);
				var v77:Map<String, Bool> = new Map<String, Bool>();
				H.out("o78 " + Std.string(p73));
			} catch (ex79:Err) {
				H.out("caught Err " + ex79.errCode);
				var v80 = p72;
				v66 = H.id(v66);
			} catch (ex81:Dynamic) {
				H.out("caught " + H.exn(ex81));
				H.out("o82 " + Std.string(new C27(299)));
			}
			if (true) {
				final v83:Map<String, Int> = (["k0" => 0xF827] : Map<String, Int>);
				H.out("o84 " + Std.string(v66));
				v83.set("k2", p73);
			} else {
				H.out("o85 " + Std.string(v66));
				v66++;
			}
		};
		return ((new Map<String, Int>()).get("k3") ?? 0);
	}
	public function m13(a14:Float, a15:E0):Int {
		H.tick();
		final v86:S2 = ({x3: 98, x4: ("  pad  ").toLowerCase(), x5: (new A6(117)).get()} : S2);
		var v87:Array<Int> = ([] : Array<Int>);
		if ((100.75 != Std.parseFloat("q"))) return 84;
		return (([(-17), 107, 91]).filter(v88 -> (E0.E0A).match(E0A))).length;
	}
	public function m20(a21:Int = -1):Int {
		H.tick();
		switch (85) {
			case 0: {
				switch (E0.E0C) {
					case E0A: {
						m12();
					};
					case E0B(c89): {
						H.out("o90 " + "abc");
						a21 = H.id(a21);
					};
					case E0C: {
						final v91:Int = 0x4735;
						a21 |= 0xC662;
					};
					case _: {
						var v92 = 166;
						H.out("o93 " + Std.string(0x2269));
					};
				}
			};
			case 2 | 4: {
				var v94:Map<String, Int> = new Map<String, Int>();
				H.out("o95 " + Std.string((new A6(a21) : Int)));
			};
			case _: {
				final v96:Array<I11> = ([new C27(20), new C27(106)] : Array<I11>);
			};
		}
		H.out("o97 " + Std.string(((switch ((new A6(a21) : Int)) {
			case 0: ({x3: 37, x4: "\x41\x42", x5: a21} : S2);
			case 3 | 4: ({x3: a21, x4: "abc", x5: 33} : S2);
			case _: ({x3: 300368525, x4: "\"q\"", x5: a21} : S2);
		}) : S2)));
		H.out("o98 " + Std.string(a21));
		var v99:Bool = (switch (E0.E0B("abc")) {
			case E0A: true;
			case E0B(c100): ([a21, a21]).contains(a21);
			case E0C: ([2026840269, 0xFFFFFFFF, a21]).contains(a21);
			case _: true;
		});
		var v101 = Lambda.count([80, a21], v102 -> true);
		return ((new C16()).m12() - (v101 ^ Math.floor(v101)));
	}
	public function m22(a23:Int):Int {
		H.tick();
		var v103:I11 = new C16();
		H.out("o104 " + Std.string(Main.fn35(({x5: 0xE09E, x4: "  pad  ", x3: a23} : S2), (Std.downcast((new C27(24) : C27), C27) != null))));
		H.out("o105 " + Std.string(true));
		return ((((160 : A6)).get() <= (("\"q\"").charCodeAt(a23) ?? -1)) ? a23 : a23);
	}
	public function m24():Int {
		H.tick();
		var v106:String = ((Std.downcast((null : I7), I7) != null) + C16.f18);
		function lf107(n108:Int):Int {
			H.tick();
			return n108 <= 0 ? Reflect.compare("ünï", (v106).toLowerCase()) : (lf107(n108 - 1) + 9);
		}
		H.out("lf107 " + lf107(5));
		H.out("o109 " + Std.string((133 != 273)));
		C16.f18 = H.cap("\u{1F600}");
		v106 = H.cap(({ var v110 = StringTools.trim("0"); (v106).toUpperCase(); }));
		H.out("o111 " + Std.string(new C16()));
		return m12();
	}
	public static function m25(a26:String):Int {
		H.tick();
		if (true) {
			(new C16()).m13(3.0, E0B(a26));
		} else {
			final v112:Int = Std.int(1.25);
			var v113:A6 = new A6(209);
		}
		final v114:() -> Void = function():Void {
			H.tick();
			Main.fn39(([278] : Array<Null<Int>>), 1e3);
			var v115:Float = 100.75;
			H.out("o116 " + Std.string(([] : Array<Bool>)));
		};
		var v117:String = (true + a26);
		H.out("o118 " + Std.string(true));
		final lf119:() -> Bool = () -> false;
		H.out("o120 " + Std.string((182 - 37)));
		H.out("o121 " + Std.string((Reflect.compare("\"q\"", v117)).ext55(Type.enumIndex(E0B(a26)))));
		Main.fn39(((switch ((({x5: 0xFFFFFFFF, x4: a26, x3: 281} : S2)).x5) {
			case 0: ([224] : Array<Null<Int>>);
			case 3 | 6: ([287, 0x80000000] : Array<Null<Int>>);
			case _: ([262, 1335974887, null] : Array<Null<Int>>);
		}) : Array<Null<Int>>), 0.1);
		return 18;
	}
}

class C27 extends C16 {
	var _f28:Int;

	public var f28(get, set):Int;

	function get_f28():Int
		return _f28;

	function set_f28(v:Int):Int
		return _f28 = v;
	var _f29:Int;

	public var f29(get, set):Int;

	function get_f29():Int
		return _f29;

	function set_f29(v:Int):Int
		return _f29 = v;
	public function new(a30:Int) {
		super();
		this._f28 = (("").charCodeAt(a30) ?? -1);
		this._f29 = (Std.parseInt(Std.string(291)) ?? 0);
	}
	override public function m24():Int {
		H.tick();
		m12();
		H.out("o122 " + Std.string((E0A).match(E0B(_))));
		this.m12();
		this.f29 |= (true ? 3 : this.f28);
		try {
			if ((false ? true : (E0.E0A).match(E0B(_)))) throw "boom";
			var v123:S2 = ({x5: 30, x4: "zz", x3: 92} : S2);
			switch (E0.E0C) {
				case E0A: {
					final v124:String = "0";
				};
				case E0B(_): {
					this.f29 = 106;
				};
				case E0C: {
					var v125:Int = 282;
					v125 = H.id(v125);
				};
			}
		} catch (ex126:String) {
			H.out("caught String " + ex126);
			var v127:Int = Std.int(1e3);
			if ((E0.E0C).match(E0C)) {
				var v128:Box<Int> = new Box<Int>(v127);
				var v129:Array<Int> = [v127, v127];
			}
		} catch (ex130:Int) {
			H.out("caught Int " + ex130);
			try {
				this.m12();
				this.m12();
				H.out("o131 " + Std.string(ex130));
				if (StringTools.endsWith("\n", "zz")) throw 68;
			} catch (ex132:Dynamic) {
				H.out("caught " + H.exn(ex132));
				H.out("o133 " + "\"q\"");
			}
			var v134:Float = 1.7976931348623157e308;
		} catch (ex135:Err) {
			H.out("caught Err " + ex135.errCode);
			switch (Lambda.fold([34], (v136:Int, v137:Int) -> (("ünï").charCodeAt((-2147483647)) ?? -1), 0)) {
				case 0: {
					var v138 = 140;
					var v139:Int = v138;
				};
				case 2 | 4: {
					H.out("o140 " + Std.string(new Box<E0>(E0.E0C)));
					H.out("o141 " + Std.string(100.75));
				};
				case _: {
					H.out("o142 " + Std.string([183]));
					m12();
				};
			}
			var v143:Int = 149;
		} catch (ex144:Dynamic) {
			H.out("caught " + H.exn(ex144));
			H.out("o145 " + Std.string((({x3: 107, x4: "x,y,z", x5: 91} : S2)).x5));
		}
		H.out("o146 " + Std.string((false ? ((181 : A6)).twice : 145)));
		return 60;
	}
	public function m31(a32:Int, a33:Int, ...r34:Int):Void {
		H.tick();
		final v147:Box<String> = ({ var v148 = (r34.toArray()).length; new Box("x,y,z"); });
		var v149:C16 = new C27(a33);
		final v150 = true;
	}
}
