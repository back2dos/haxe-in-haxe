package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext52(a50:Int, a51:C27):Int {
		H.tick();
		if (true) return ({ var v242 = (("\x41\x42").charCodeAt(0x5FFF) ?? -1); 264; });
		(a51).m20();
		var v243:Map<String, Int> = (new Box<Map<String, Int>>(new Map<String, Int>())).get();
		try {
			if ((Math.isNaN(1.25) || true)) throw "ünï";
			switch (Lambda.fold([a50, a50], (v244:Int, v245:Int) -> 129, 0)) {
				case 0: {
					H.out("o246 " + Std.string([a50]));
				};
				case 3 | 6: {
					a50 = (-340543751);
					Main.fn42();
				};
				case _: {
					H.out("o247 " + "ünï");
				};
			}
		} catch (ex248:Dynamic) {
			H.out("caught " + H.exn(ex248));
			a50 -= 41;
		}
		H.out("o249 " + Std.string(([false, false, false]).map((v250:Bool) -> (("\n").charCodeAt(a50) ?? -1))));
		return a50;
	}
	public static function ext55(a53:Int, a54:Int):Bool {
		H.tick();
		var v251:String = "a\rb";
		var v252:Array<Int> = [110];
		var v253:String = ((E0.E0A).match(E0A) ? v251 : "x,y,z");
		H.out("o254 " + Std.string(new C16()));
		var v255:A6 = (-(a54 : A6));
		return true;
	}
}
