import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

typedef S2 = {x3:Int, x4:String, x5:Int};

interface I11 {
	function m12():Int;
	function m13(a14:Float, a15:E0):Int;
}

class Main {
	public static function fn35(a36:S2, a37:Bool, ?a38:Null<Int>):Bool {
		H.tick();
		H.out("o151 " + Std.string(3.0));
		H.out("o152 " + Std.string((1403226007 + Lambda.count([107, (-696373028), 45], v153 -> true))));
		H.out("o154 " + Std.string(({ var v155 = (-1219850997); a37; })));
		if (a37) return ("\x41\x42" < "q");
		H.out("o156 " + Std.string(Math.max(1e3, 19)));
		H.out("o157 " + Std.string(new C27(("ünï").length)));
		switch (270) {
			case 0: {
				final v158 = Math.floor(1.7976931348623157e308);
			};
			case 2 | 6: {
				if (true) return true;
			};
			case c159 if (c159 > 10): {
				var v160 = "\"q\"";
			};
			case _: {
				if ((new Map<String, String>()).exists("k0")) {
					H.out("o161 " + Std.string(E0.E0C));
					H.out("o162 " + Std.string(a37));
					final v163:String = "-7";
				}
			};
		}
		((new Box<I11>(new C27(110))).get()).m12();
		var v164:Int = (Lambda.count([0xFFFFFFFF, 181, 30], v165 -> (E0.E0C).match(E0C)) * Math.round(5e-324));
		return ({ var v166 = (([v164]).contains(v164) && true); (switch (E0.E0A) {
			case E0A: true;
			case E0B(c167): true;
			case E0C: a37;
			case _: ((["k0" => ({x3: 176, x4: "a\rb", x5: v164} : S2), "k1" => a36] : Map<String, S2>)).exists("k0");
		}); });
	}
	public static inline function fn39(a40:Array<Null<Int>>, a41:Float):Bool {
		H.tick();
		H.out("o168 " + Std.string(((-new A6(210)) : Int)));
		var v169:Box<Int> = (((E0.E0A).match(E0B(_)) ? new Box<Int>(58) : new Box<Int>(124)) : Box<Int>);
		(new C27((Std.parseInt("Haxe") ?? 0))).m31(((("q").charCodeAt(247) ?? -1) * 150), 0xB387, (({x3: 21, x4: "ünï", x5: 284} : S2)).x3, (("é").substring((65535 & 7), 4)).indexOf(Std.string(E0.E0C)));
		var v170:C16 = (((([] : Array<Int>)).contains(135) ? new C27((-1713014550)) : new C27(66)) : C16);
		var v171:String = (switch (E0.E0C) {
			case E0A: Std.string(79);
			case E0B(_): ("日本語").charAt(((-314208992) & 7));
			case E0C: ("ünï").replace("a", "b");
		});
		H.out("o172 " + Std.string((v170).m20(2121436449)));
		try {
			if (fn35(({x3: 170, x5: 253, x4: v171} : S2), false, 40)) throw "boom";
			var v173:Float = 210;
			H.out("o174 " + Std.string(194));
			H.out("o175 " + Std.string(E0.E0C));
		} catch (ex176:Err) {
			H.out("caught Err " + ex176.errCode);
			(new C27(0x20FD)).m12();
		} catch (ex177:haxe.Exception) {
			H.out("caught " + H.exn(ex177));
			if (StringTools.contains(v171, "-7")) {
				final v178:() -> Float = () -> a41;
				H.out("o179 " + Std.string(([] : Array<Int>)));
				H.out("o180 " + Std.string(172));
			}
			final v181:Array<String> = (v171).split(" ");
		}
		return (new Map<Int, Bool>()).exists(18);
	}
	public static function fn42(?a43:Null<Int>):Void {
		H.tick();
		var v182 = ((-14) << (Reflect.compare("\u{1F600}", "ab") & 31));
		fn35(({x5: Lambda.fold([v182], (v183:Int, v184:Int) -> Math.floor(v182), 0), x4: ("Haxe").replace("a", "b"), x3: (("\\").charCodeAt(72) ?? -1)} : S2), H.id(true), 53);
		H.out("o185 " + Std.string((("ünï").charCodeAt((["ünï", "  pad  ", "abc"]).length) ?? -1)));
		if ((false ? false : true)) {
			var v186:Array<Int> = [149, v182];
			final v187:(Bool, String) -> Float = function(p188:Bool, p189:String):Float {
				H.tick();
				var v190:Array<Bool> = [p188, p188, p188];
				var v191 = p188;
				return v182;
			};
			try {
				if (false) throw "boom";
				(new C27(205)).m31(v182, v182, 141);
				(new C27(v182)).m12();
			} catch (ex192:String) {
				H.out("caught String " + ex192);
				H.out("o193 " + Std.string(v182));
				v182 = 55;
			} catch (ex194:Int) {
				H.out("caught Int " + ex194);
				H.out("o195 " + Std.string(ex194));
			} catch (ex196:Err) {
				H.out("caught Err " + ex196.errCode);
				++v182;
			} catch (ex197:Dynamic) {
				H.out("caught " + H.exn(ex197));
				var v198:Int = v182;
			}
		}
		var v199:Bool = ({ var v200 = (["a\rb", "  pad  "]).join(""); false; });
		try {
			try {
				final v201 = 195632201;
				var v202:String = "";
				(new C27(201)).m24();
				if (v199) throw 95;
			} catch (ex203:Err) {
				H.out("caught Err " + ex203.errCode);
				(new C27(265)).m20();
			} catch (ex204:haxe.Exception) {
				H.out("caught " + H.exn(ex204));
				H.out("o205 " + Std.string(v182));
				var v206:Array<Array<Int>> = ([([] : Array<Int>), [v182, v182]] : Array<Array<Int>>);
			}
			if ((Reflect.compare(v182, v182) <= (Std.parseInt(Std.string(v182)) ?? 0))) throw (("A-B-C").charAt((v182 & 7)) + v199);
		} catch (ex207:String) {
			H.out("caught String " + ex207);
			var v208:Int = (ex207).indexOf("q");
		} catch (ex209:Int) {
			H.out("caught Int " + ex209);
			final v210:Int = ("\x41\x42").length;
		} catch (ex211:Err) {
			H.out("caught Err " + ex211.errCode);
			var v212:String = "  pad  ";
		} catch (ex213:Dynamic) {
			H.out("caught " + H.exn(ex213));
			H.out("o214 " + Std.string(E0.E0A));
			H.out("o215 " + Std.string(StringTools.contains("\\", "\n")));
		}
		final v216:S2 = ({x3: 0x5459, x4: "ab", x5: v182} : S2);
		final v217:(Int, Int) -> Void = function(p218:Int, p219:Int):Void {
			H.tick();
			H.out("o220 " + Std.string(v182));
			final v221:Map<Int, String> = new Map<Int, String>();
		};
	}
	public static function fn44(a45:Bool, a46:Int, a47:Int):E0 {
		H.tick();
		H.out("o222 " + Std.string(a47));
		final v223:Float = (new C27(1467675231)).m12();
		var v224 = 'x${Std.string(Math.round(a46))}';
		var v225:A6 = (new A6(a47) + new A6(89));
		(new C16()).m12();
		var v226:String = ("Haxe" + (([-3 => v224] : Map<Int, String>)).exists(18));
		final v227:Array<Bool> = [a45, StringTools.contains("\\", v226), (([] : Array<Int>)).contains(a46)];
		if (a45) {
			var v228:Array<String> = [v224];
		} else {
			(new C27(a46)).m31(H.at([229, 118, a47], a46, 0), a47, a47);
		}
		return E0.E0A;
	}
	public static function fn48(a49:Int):Int {
		H.tick();
		var v229 = true;
		((switch (56) {
			case 0: a49;
			case 1 | 6: (((["k0" => a49, "k1" => 224, "k2" => 0x992B] : Map<String, Int>)).get("k1") ?? 0);
			case c230 if (c230 > 10): 223;
			case _: Type.enumIndex(E0.E0A);
		})).ext55((switch (E0.E0C) {
			case E0A: a49;
			case E0C: 109;
			case _: a49;
		}));
		final lf231:(Int) -> String = function(p232:Int):String {
			H.tick();
			var v233:Map<String, Int> = new Map<String, Int>();
			function lf234(n235:Int):Int {
				H.tick();
				return n235 <= 0 ? (([] : Array<String>)).length : (lf234(n235 - 1) + a49);
			}
			H.out("lf234 " + lf234(2));
			return (Std.string(E0.E0B("0")) + Std.string(v229));
		};
		if ((1651992263 > (({x5: a49, x4: "x,y,z", x3: a49} : S2)).x5)) {
			var v236:E0 = E0.E0B("a\rb");
			if ((v236).match(E0A)) {
				H.out("o237 " + Std.string(v229));
				H.out("o238 " + Std.string([a49, a49]));
				H.out("o239 " + "x,y,z");
			}
			var v240 = (Std.parseInt("ünï") ?? 0);
		}
		final v241:Int = (new C27(a49)).m24();
		return (new C27(65535)).m22(a49);
	}
	public static function section0():Void {
		H.tick();
		fn48((new C16()).m13(3.0, E0.E0A));
		H.out("o256 " + Std.string((111 - 3.0)));
		var v257:Map<String, Bool> = (["k0" => true, "k1" => true] : Map<String, Bool>);
		var v258:Int = ((E0.E0C).match(E0B(_)) ? (Std.parseInt("\t") ?? 0) : 17);
		var v259:Array<String> = ["\u{1F600}"];
		v259.remove(((E0.E0B("\"q\"")).match(E0B(_)) + "\"q\""));
		Ext.ext55(("zz").length, 156);
		(((switch ("q") {
			case "a" | "b": new C27(22);
			case "Haxe": new C27(v258);
			case "": new C16();
			case _: new C16();
		}) : C16)).m20();
	}
	public static function section1():Void {
		H.tick();
		var v260:Map<Int, Int> = new Map<Int, Int>();
		Main.fn39((([] : Array<Null<Int>>)).filter(v261 -> StringTools.contains("42", "ab")), Math.PI);
		if ((StringTools.contains("zz", "é") ? true : true)) {
			final lf262:() -> Int = () -> ("\x41\x42").indexOf("ab");
		}
		final lf263:() -> Int = function():Int {
			H.tick();
			var v264:C16 = new C16();
			if (true) return 36;
			var v265:S2 = ({x4: "\"q\"", x3: 116, x5: 58} : S2);
			return (~(("zz").charCodeAt(51) ?? -1));
		};
		H.out("o266 " + Std.string((136 % H.nz(0xFFFFFFFF))));
	}
	public static function section2():Void {
		H.tick();
		var v267:E0 = fn44(StringTools.contains("zz", "\n"), (Std.parseInt("A-B-C") ?? 0), ("Haxe").lastIndexOf("hello world"));
		H.out("o268 " + Std.string(((switch (252) {
			case 0: new Box<Float>(1.7976931348623157e308);
			case 3 | 5: new Box<Float>(1e21);
			case _: new Box<Float>(0.5);
		}) : Box<Float>)));
		H.out("o269 " + Std.string(Math.max(7.0, 7.0)));
	}
	public static function section3():Void {
		H.tick();
		var v270:Box<A6> = new Box<A6>(new A6(276));
		var v271:String = Std.string(E0.E0B("\"q\""));
		H.out("o272 " + Std.string(53));
		var v273:E0 = E0.E0B("ünï");
		var v274:Array<Array<Int>> = ([[65535]] : Array<Array<Int>>);
		(({ var v275 = (E0.E0A).match(E0B(_)); new C27(194); })).m12();
		H.out("o276 " + Std.string(((true ? new C27(25) : new C27(217)) : C16)));
		var v277 = (Lambda.count([(-2147483647), 0x77AB, 907313192], v278 -> Math.isNaN(v278)) >> ((("a").charCodeAt(87) ?? -1) & 31));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
