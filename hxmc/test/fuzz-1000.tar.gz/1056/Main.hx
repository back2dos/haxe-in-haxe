import H;
import p.M1;

enum E1 {
	E1A;
	E1B;
}

enum E2 {
	E2A;
}

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

class C6 {
	public var f7:Bool;
	var _f8:String;

	public var f8(get, set):String;

	function get_f8():String
		return _f8;

	function set_f8(v:String):String
		return _f8 = v;
	public function new(a9:String, a10:Bool) {
		this.f7 = a10;
		this._f8 = StringTools.replace("日本語", " ", a9);
	}
}

class C11 extends C6 {
	var _f12:String;

	public var f12(get, set):String;

	function get_f12():String
		return _f12;

	function set_f12(v:String):String
		return _f12 = v;
	public final f13:Int;
	public var f14:Int;
	public var cb15:(Int) -> Int;
	public function new(a16:String) {
		super(Std.string(65535), true);
		this._f12 = a16;
		this.f13 = ([127, 0xDFF8, 0x80000000]).indexOf(18);
		this.f14 = (Std.parseInt(Std.string(884583601)) ?? 0);
		this.cb15 = function(p51:Int):Int {
			H.tick();
			var v52:Box<Map<Int, String>> = new Box<Map<Int, String>>(([-3 => a16, 4 => "0"] : Map<Int, String>));
			var v53:Array<String> = ["\t", a16];
			var v54:C21 = null;
			return p51;
		};
	}
	public function m17():C11 {
		H.tick();
		try {
			var v55:E0 = E0.E0A;
			var v56 = ((([-3 => 54, 4 => 212] : Map<Int, Int>)).get(57) ?? 0);
			if (true) throw new Err((v56 >>> ((v56 = 5) & 31)));
		} catch (ex57:String) {
			H.out("caught String " + ex57);
			for (i58 in 0...H.lim(0xFFFFFFFF)) {
				H.tick();
				var v59:Int = i58;
				v59 = i58;
				var v60 = 162;
			}
			var v61:Map<String, String> = (["k0" => "\n", "k1" => "ünï", "k2" => ex57] : Map<String, String>);
		} catch (ex62:Int) {
			H.out("caught Int " + ex62);
			{ var dyn63:Dynamic = this.f13; H.out("dyn " + Std.string(dyn63 + 1)); }
		} catch (ex64:Err) {
			H.out("caught Err " + ex64.errCode);
			{ var dyn65:Dynamic = ("\t").length; H.out("dyn " + Std.string(dyn65 + 1)); }
		} catch (ex66:Dynamic) {
			H.out("caught " + H.exn(ex66));
			var v67 = Type.enumIndex(E2.E2A);
			for (k68 => v69 in (["k0" => v67, "k1" => 191, "k2" => v67] : Map<String, Int>)) {
				H.tick();
				var v70:Int = v69;
				v67 = v70;
				var v71:C21 = new C21(true, [true, true, true]);
			}
		}
		H.out("o72 " + Std.string(new Box<C6>(new C11("A-B-C"))));
		var v73:Int = ("\x41\x42").lastIndexOf("42");
		v73 ^= v73;
		H.out("o74 " + Std.string((new Box<Array<String>>(([] : Array<String>))).value));
		var v75:Map<String, () -> Bool> = new Map<String, () -> Bool>();
		return new C11((String.fromCharCode(65 + ((v73) & 15))).charAt(3));
	}
	public function m18():Int {
		H.tick();
		var v76 = ((E2.E2A).match(E2A) ? 259 : this.f13);
		var v77:String = (new Box("zz")).value;
		var v78:Array<String> = [for (i79 in 0...3) "q"];
		H.out("o80 " + Std.string(new C21(([v76, v76, v76]).contains(v76), [false, true])));
		H.out("o81 " + Std.string(v76));
		for (i82 in 0...0) {
			H.tick();
			for (x83 in v78) {
				H.tick();
				var v84:Int = 110;
				var v85:C21 = new C21(true, [true, true, true]);
			}
			var v86 = v76;
			for (k87 => v88 in (["k0" => v76, "k1" => v86, "k2" => v76] : Map<String, Int>)) {
				H.tick();
				v76++;
				var v89:A5 = new A5(v86);
				var v90:Box<Int> = new Box<Int>(v88);
			}
		}
		v77 = H.cap((v77 + "日本語"));
		return v76;
	}
	public function m19():Int {
		H.tick();
		var v91:Map<Int, Bool> = new Map<Int, Bool>();
		this.m17();
		H.out("o92 " + Std.string(("42").length));
		return (if ((new Map<String, Bool>()).exists("q")) ((([] : Array<String>)).indexOf("0") - this.f14) else (true ? ("hello world").lastIndexOf("hello world") : H.at([(-11)], 242, 0)));
	}
	public function m20():Bool {
		H.tick();
		if (false) {
			var v93:Box<Map<String, C11>> = new Box<Map<String, C11>>((["k0" => new C21(true, [false])] : Map<String, C11>));
		} else {
			H.out("o94 " + Std.string((new Map<String, C6>()).exists("k0")));
		}
		H.out("o95 " + Std.string((this.f7 ? (["\x41\x42", "ünï"]).indexOf("  pad  ") : 238)));
		function lf96(n97:Int):Int {
			H.tick();
			return n97 <= 0 ? n97 : (lf96(n97 - 1) + this.f14);
		}
		H.out("lf96 " + lf96(3));
		for (i98 in 0...2) {
			H.tick();
			if (false) {
				final v99:C6 = new C6("a", false);
			} else {
				final v100:E0 = E0.E0A;
			}
		}
		this.f14 += (([] : Array<Bool>)).length;
		(new C21((Std.downcast((new C11("x,y,z") : C11), C21) != null), ([] : Array<Bool>))).m18();
		var v101 = (248 | this.f13);
		H.out("o102 " + Std.string(((new Map<String, Int>()).get("k2") ?? 0)));
		return (v101 <= Main.fn37(Lambda.count([v101, v101, v101], v103 -> false), ([v101, v101]).contains(136), new A5(v101)));
	}
}

class C21 extends C11 {
	public var f22:Int;
	public final f23:Box<Int>;
	public function new(a24:Bool, a25:Array<Bool>) {
		super(Std.string(295));
		this.f22 = ("Haxe").indexOf("ab");
		this.f23 = new Box(64);
	}
	override public function m18():Int {
		H.tick();
		final v104:() -> Bool = () -> false;
		this.m17();
		if (StringTools.endsWith(StringTools.replace("", "a", "a"), StringTools.hex((65535) & 0xFFFF, 4))) {
			this.f14 &= (("-7").charCodeAt(182) ?? -1);
			this.m17();
		}
		H.out("o105 " + Std.string(false));
		var w106 = 0;
while (w106 < 1 && !true) {
			w106++;
			H.tick();
			if (false) break;
			var v107:E0 = E0.E0A;
			(new C11("\u{1F600}")).m17();
		}
		return Reflect.compare((["A-B-C", "\t"]).join("|"), ("q").substr((("a").lastIndexOf("zz") & 7), 4));
	}
	override public function m20():Bool {
		H.tick();
		if ((false || (Std.downcast((new C11("abc") : C6), C6) != null))) {
			final lf108:(Int, Int) -> Void = function(p109:Int, p110:Int):Void {
				H.tick();
				var v111 = 165;
				H.out("o112 " + Std.string(E2.E2A));
				var v113 = p110;
			};
		} else {
			var v114:Array<Int> = [0x9CC0, 204, 181];
		}
		var v115 = (["日本語"]).join(" ");
		m18();
		H.out("o116 " + Std.string(E1.E1B));
		H.out("o117 " + Std.string(({ var v118 = Std.isOfType(new C6("\"q\"", false), C6); E0.E0A; })));
		this.f14 |= (282 >>> ((v115).length & 31));
		return false;
	}
	public function m26(a27:Bool):Void {
		H.tick();
		{
			var v119:Map<String, Bool> = new Map<String, Bool>();
			this.f8 = H.cap(StringTools.lpad("ab", "*", -2));
			H.out("o120 " + ("").substring((122 & 7), 1));
		}
		H.out("o121 " + Std.string([for (i122 in 0...3) i122]));
		H.out("o123 " + '${"ünï"} = ${Std.string(this.f13)}');
		final v124 = 291;
		var v125:Box<Bool> = ((a27 ? new Box(a27) : new Box(a27)) : Box<Bool>);
		this.f14 *= this.f13;
		var v126:Int = this.f13;
	}
	public function m28(a29:Int, a30:Int):E2 {
		H.tick();
		function lf127(n128:Int):Int {
			H.tick();
			return n128 <= 0 ? (("é").indexOf("ünï") >> (this.f13 & 31)) : (lf127(n128 - 1) + (4 % H.nz((a29 += 3))));
		}
		H.out("lf127 " + lf127(2));
		var v129:E1 = E1.E1B;
		{ var dyn130:Dynamic = a29; H.out("dyn " + Std.string(dyn130 + 1)); }
		return E2A;
	}
}

class Main {
	public static function fn31(a32:Int, a33:Array<Bool>):Int {
		H.tick();
		var w131 = 0;
while (w131 < 1 && ((new A5(a32)).get() < (((["k0" => a32, "k1" => a32] : Map<String, Int>)).get("\"q\"") ?? 0))) {
			w131++;
			H.tick();
			(new C11("  pad  ")).m18();
			H.out("o132 " + Std.string(new C11("a\rb")));
			H.out("o133 " + Std.string(a32));
		}
		a32 -= 0x7FFFFFFF;
		if ((215 < 0xF063)) {
			H.out("o134 " + Std.string((a33).indexOf(true)));
		}
		var v135:Int = Reflect.compare("a", "x,y,z");
		if (false) {
			if (true) {
				var v136 = true;
				var v137:Array<String> = ([] : Array<String>);
				final v138:Array<() -> Bool> = ([() -> v136, function():Bool {
					H.tick();
					var v139:Bool = v136;
					return v136;
				}, function():Bool {
					H.tick();
					var v140:Bool = v136;
					v135 = H.id(v135);
					var v141:A5 = (a32 : A5);
					return v136;
				}] : Array<() -> Bool>);
			} else {
				v135 -= 19;
			}
		}
		for (i142 in 0...H.lim(a32)) {
			H.tick();
			for (x143 in ([] : Array<Int>)) {
				H.tick();
				var v144 = 45;
				H.out("o145 " + Std.string(new C11("q")));
			}
			for (i146 in 0...4) {
				H.tick();
				var v147:Array<String> = ["zz", "  pad  ", "\x41\x42"];
				var v148:C11 = new C21(true, a33);
				var v149:Int = a32;
			}
			final v150:C6 = new C21(true, a33);
		}
		return a32;
	}
	public static function fn34(a35:Int, a36:Bool):Int {
		H.tick();
		H.out("o151 " + Std.string(76));
		for (i152 in 0...0) {
			H.tick();
			var v153:Array<Int> = [a35, i152];
			var v154 = a36;
			H.out("o155 " + Std.string(146));
		}
		(new C21(false, [a36])).m18();
		if ((StringTools.contains("zz", "") && a36)) {
			if (a36) return (a35++);
		}
		a35 = (a35 += 3);
		try {
			if (false) throw (("a\rb").substring(-2, (a35 & 7))).substr(-1, 6);
			if (false) {
				H.out("o156 " + Std.string(a35));
			} else {
				var v157:E1 = E1A;
				a35 = 32;
			}
			var v158 = "abc";
		} catch (ex159:String) {
			H.out("caught String " + ex159);
			a36 = (E0.E0A).match(E0A);
			if ((E2.E2A).match(E2A)) {
				a35++;
			}
		} catch (ex160:Int) {
			H.out("caught Int " + ex160);
			for (x161 in [0xDC60]) {
				H.tick();
				H.out("o162 " + "\x41\x42");
				var v163:C11 = new C21(a36, [a36, a36]);
			}
			for (i164 in 0...4) {
				H.tick();
				(new C11("-7")).m18();
			}
		} catch (ex165:Err) {
			H.out("caught Err " + ex165.errCode);
			H.out("o166 " + StringTools.lpad("\t", "*", 0));
			for (x167 in ([] : Array<Int>)) {
				H.tick();
				Main.fn31(a35, [true]);
				var v168:Int = a35;
			}
		} catch (ex169:Dynamic) {
			H.out("caught " + H.exn(ex169));
			final v170:E0 = E0.E0A;
		}
		return H.at([a35], a35, 0);
	}
	public static function fn37(a38:Int, a39:Bool, a40:A5):Int {
		H.tick();
		var v171:Box<Int> = new Box(1631513635);
		for (k173 => x172 in [(("  pad  ").charCodeAt(a38) ?? -1)]) {
			H.tick();
			if (StringTools.contains("hello world", "ab")) continue;
			for (k175 => x174 in [a38, 95]) {
				H.tick();
				var v176 = "\x41\x42";
				a38 = x174;
			}
		}
		try {
			if (a39) {
				a39 = H.id(a39);
				(new C11("abc")).m18();
				H.out("o177 " + Std.string(a38));
			}
			if (StringTools.startsWith(StringTools.trim("abc"), "  pad  ")) throw "boom";
		} catch (ex178:Err) {
			H.out("caught Err " + ex178.errCode);
			var v179:Int = a38;
		} catch (ex180:haxe.Exception) {
			H.out("caught " + H.exn(ex180));
			var v181:Array<Int> = [a38, 260];
		}
		return ("a").indexOf("日本語");
	}
	public static function fn41(a42:Bool, a43:Int, a44:Int):String {
		H.tick();
		final v182:Array<Int> = (new Box<Array<Int>>(([] : Array<Int>))).get();
		function lf183(n184:Int):Int {
			H.tick();
			return n184 <= 0 ? a44 : (lf183(n184 - 1) + Main.fn37(282, false, new A5(a43)));
		}
		H.out("lf183 " + lf183(1));
		var v185:E0 = E0.E0A;
		if (true) {
			var w186 = 0;
while (w186 < 5 && StringTools.contains("", "hello world")) {
				w186++;
				H.tick();
				var v187 = false;
				H.out("o188 " + Std.string(new C21(true, [a42])));
				(new C21(false, ([] : Array<Bool>))).m18();
			}
			(new C11("0")).m17();
			final v189:C11 = new C21(a42, [false]);
		}
		return ("  pad  " + '-${Std.string((v182).contains(a43))}');
	}
	public static function fn45(a46:Int = 7):String {
		H.tick();
		final v190:Map<String, Bool> = (["k0" => ([a46, a46]).contains(a46), "k1" => (E1B).match(E1A)] : Map<String, Bool>);
		a46 = ((("hello world").charCodeAt(40) ?? -1) ^ Lambda.fold([a46, a46], (v191:Int, v192:Int) -> 30, 0));
		try {
			if ((new Map<Int, String>()).exists(18)) {
				var v193:Int = a46;
				final v194:Bool = false;
				var v195:A5 = new A5(v193);
			} else {
				var v196 = 222;
				var v197:Int = v196;
			}
			for (x198 in ([] : Array<Int>)) {
				H.tick();
				a46 ^= x198;
				Main.fn31((-2147483647), [false, false, false]);
			}
			if (((("ab").charCodeAt(196) ?? -1) > ([a46, 300]).indexOf(a46))) throw new Err((if (([224, a46, a46]).contains(a46)) (Std.parseInt(Std.string(a46)) ?? 0) else Type.enumIndex(E1B)));
		} catch (ex199:Dynamic) {
			H.out("caught " + H.exn(ex199));
			var v200:Array<String> = ["42", "42", ""];
			final v201:Box<Int> = new Box(a46);
		}
		var v202:Int = a46;
		for (x203 in (([] : Array<String>)).copy()) {
			H.tick();
			var v204:Array<Int> = [v202, v202];
			H.out("o205 " + Std.string(39));
		}
		H.out("o206 " + Std.string(([new C11("0")] : Array<C11>)));
		final v207:(Int, Int) -> Bool = (p208:Int, p209:Int) -> StringTools.startsWith("q", "\"q\"");
		final v210:(Int, Bool) -> Int = function(p211:Int, p212:Bool):Int {
			H.tick();
			final v213:(String, Int) -> String = function(p214:String, p215:Int):String {
				H.tick();
				a46 |= (-1563238257);
				return p214;
			};
			Main.fn31(190, [false]);
			return (Std.parseInt("zz") ?? 0);
		};
		return '${Std.string(a46)}<${Std.string(a46)}';
	}
	public static function fn47(a48:Int, a49:String = "d"):Array<Int> {
		H.tick();
		for (i216 in 0...H.lim(a48)) {
			H.tick();
			fn34(a48, ([i216, 241, i216]).contains(i216));
			for (x217 in ([] : Array<Int>)) {
				H.tick();
				var v218:Bool = true;
				a48 -= x217;
			}
			for (x219 in [a48, i216, 62]) {
				H.tick();
				if (true) continue;
				a48 -= x219;
				var v220 = 4;
			}
		}
		H.out("o221 " + Std.string(new Box<Int>(Lambda.fold([0xFFFFFFFF, 174], (v222:Int, v223:Int) -> Type.enumIndex(E1A), 0))));
		a48 = H.id(a48);
		var v224:Array<Int> = ((true ? [185, 235] : [a48, a48, a48]) : Array<Int>);
		var v225:Array<String> = [for (i226 in ["\u{1F600}"]) if ((v224).contains(0x7FFFFFFF)) StringTools.trim("zz")];
		H.out("o227 " + Std.string(new C6(StringTools.lpad("a", "*", -2), Std.isOfType(new C21(false, [false, false, true]), C11))));
		for (i228 in 0...0) {
			H.tick();
			H.out("o229 " + Std.string(E0.E0A));
			var v230:A5 = new A5(i228);
			a48 = (-1139780150);
		}
		for (x231 in ([true, true]).filter(v232 -> false)) {
			H.tick();
			{
				H.out("o233 " + Std.string(v224));
				a48 *= a48;
			}
			if (StringTools.startsWith(a49, "hello world")) {
				(new C21(x231, [x231])).m18();
				a48 &= a48;
				final v234:Int = 14;
			}
		}
		var v235:Int = a48;
		return ((true ? ([""]).map((v236:String) -> (new A5(0x1130)).twice) : (cast (v224) : Array<Int>)) : Array<Int>);
	}
	public static function fn50():Int {
		H.tick();
		H.out("o237 " + Std.string(("0").indexOf(StringTools.trim("a"))));
		var v238:Map<String, Int> = new Map<String, Int>();
		var v239 = (256 & 1937748926);
		return ((new C21(false, ([] : Array<Bool>))).m20() ? v239 : 267);
	}
	public static function section0():Void {
		H.tick();
		fn34((195 << ((-12) & 31)), (new C21(true, [false, false, false])).m20());
		H.out("o240 " + Std.string(65535));
		var v241:C6 = (new C21(false, ([] : Array<Bool>))).m17();
	}
	public static function section1():Void {
		H.tick();
		var v242 = 241;
		var v243:Int = v242;
		var w244 = 0;
while (w244 < 1 && (new C11("\n")).m20()) {
			w244++;
			H.tick();
			H.out("o245 " + Std.string(new C6("q", true)));
			for (k247 => x246 in ["\x41\x42", "\\", "42"]) {
				H.tick();
				(new C21(false, [false, true, false])).m28((-552984769), v243);
				var v248:String = x246;
				H.out("o249 " + Std.string(true));
			}
		}
		final v250:String = H.apply(("42").charAt(3), (v251:String) -> Std.string(22));
		for (k253 => x252 in fn47((v242--))) {
			H.tick();
			final lf254:(Int) -> Int = function(p255:Int):Int {
				H.tick();
				var v256:Array<String> = (v250).split("a");
				v242 <<= (k253 & 7);
				var v257:Map<Int, String> = new Map<Int, String>();
				return x252;
			};
		}
		H.out("o258 " + Std.string(new C21(([v243]).contains(v242), ([] : Array<Bool>))));
	}
	public static function section2():Void {
		H.tick();
		(((([226, 1]).contains(179) ? new C21(false, [false]) : new C21(true, [false, false])) : C11)).m18();
		var v259 = Main.fn41(false, 149, ("42").indexOf("-7"));
		var v260:Bool = ({ var v261 = false; StringTools.contains(v259, v259); });
	}
	public static function section3():Void {
		H.tick();
		final lf262:(Bool) -> String = (p263:Bool) -> (p263 ? (["a", "\"q\""]).join(",") : ("").toUpperCase());
		H.out("o264 " + Std.string((new C21(true, [false, false, true])).m19()));
		var v265 = false;
		var v266:Map<String, Int> = new Map<String, Int>();
		if (v265) {
			H.out("o267 " + ("zz").toUpperCase());
		}
		v265 = true;
		H.out("o268 " + Std.string((((v265 ? new A5(235) : new A5(91)) : A5) : Int)));
		var v269:Box<A5> = new Box<A5>(new A5(197));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
