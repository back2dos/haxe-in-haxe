package p;

import Main;
import H;
import p.M1;
using p.Ext;

class M1 {}

enum E0 {
	E0A;
}

enum E6 {
	E6A;
}

typedef S7 = {x8:Int, x9:Bool};

typedef S10 = {x11:Float, x12:Int};

abstract A13(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A13, b:A13):A13
		return new A13(a.get() + b.get());

	@:op(A * B) public static function mul(a:A13, b:A13):A13
		return new A13(a.get() * b.get());

	@:op(-A) public static function neg(a:A13):A13
		return new A13(-a.get());
}

enum abstract K14(Int) to Int {
	var K14A = 1;
	var K14B = 4;
}

abstract class C15 {
	public var f16:Int;
	public var f17:Int;
	public static var f18:Float = (-2.5);
	public function new(a19:Float) {
		this.f16 = 249;
		this.f17 = ((55 : A13)).get();
	}
	abstract public function m20():(Int) -> Bool;
}

class C27 {
	public var cb28:(Int) -> Int;
	public function new() {
		this.cb28 = function(p114:Int):Int {
			H.tick();
			final v115:() -> Bool = function():Bool {
				H.tick();
				final v116:S10 = ({x11: p114, x12: p114} : S10);
				var v117 = p114;
				final v118:Map<String, Float> = new Map<String, Float>();
				return false;
			};
			return p114;
		};
	}
	public function m29(a30:Int):Int {
		H.tick();
		if ((Type.enumIndex(E0.E0A) < a30)) {
			var v119 = a30;
		} else {
			try {
				if (true) throw new Err(82);
				var v120:Int = a30;
				Main.fn48();
				H.out("o121 " + Std.string(0xFFFFFFFF));
			} catch (ex122:Dynamic) {
				H.out("caught " + H.exn(ex122));
				var v123:E1 = E1.E1A;
				var v124:Int = a30;
			}
		}
		H.out("o125 " + Std.string(a30));
		for (i126 in 2...3) {
			H.tick();
			if (true) {
				var v127 = 54;
			} else {
				final v128:Map<String, C15> = new Map<String, C15>();
				var v129:Map<Int, Float> = new Map<Int, Float>();
			}
			if (true) {
				var v130:Float = i126;
			} else {
				final v131 = true;
				H.out("o132 " + Std.string((new A13(246) : Int)));
			}
			var v133:Int = (({x9: false, x8: a30} : S7)).x8;
		}
		switch ((0.1 == (-2.5))) {
			case true: {
				H.out("o134 " + Std.string(298419404));
			};
			case false: {
				final v135:S10 = ({x11: a30, x12: 112} : S10);
			};
		}
		var v136:Bool = (true || ((["k0" => a30, "k1" => 0x7FFFFFFF, "k2" => a30] : Map<String, Int>)).exists("k2"));
		final v137 = v136;
		Main.fn49(new C21(false, a30), ((switch ((K14.K14B : Int)) {
			case 0: a30;
			case 2 | 4: null;
			case _: 0xB209;
		}) : Null<Int>), 273);
		try {
			if (((Std.parseInt("é") ?? 0) >= a30)) throw "boom";
			a30 = (new A13(103) : Int);
			H.out("o138 " + Std.string(Std.isOfType(new C21(v137, a30), C15)));
			a30 <<= ((Std.parseInt("\\") ?? 0) & 7);
		} catch (ex139:String) {
			H.out("caught String " + ex139);
			var v140 = (({x8: a30, x9: true} : S7)).x8;
		} catch (ex141:Int) {
			H.out("caught Int " + ex141);
			(new C21(true, 1e3)).m20();
		} catch (ex142:Err) {
			H.out("caught Err " + ex142.errCode);
			var v143:Map<String, Int> = new Map<String, Int>();
		} catch (ex144:Dynamic) {
			H.out("caught " + H.exn(ex144));
			H.out("o145 " + Std.string(v137));
		}
		return Reflect.compare(Main.fn53(7.0), a30);
	}
	public function m31(a32:String):Int {
		H.tick();
		var v146 = 242;
		(new C21(false, v146)).m20();
		var v147:Null<Int> = ((switch (E1.E1B((-2147483647), v146)) {
			case E1A: v146;
			case E1C(_, c148): v146;
			case E1D: null;
			case _: v146;
		}) : Null<Int>);
		if (true) {
			final lf149:(Bool, Bool) -> Int = (p150:Bool, p151:Bool) -> 184;
			var v152:Map<Int, Int> = new Map<Int, Int>();
		}
		var v153:C21 = ((((["k0" => v146, "k1" => v146, "k2" => v146] : Map<String, Int>)).exists("") ? new C21(true, 1.7976931348623157e308) : new C21(false, 0.5)) : C21);
		final v154:Int = v146;
		var v155:Int = (false ? Reflect.compare(v154, v154) : (-949510972));
		H.out("o156 " + Std.string(({x8: v155, x9: true} : S7)));
		H.out("o157 " + Std.string((((false ? K14.K14A : K14.K14B) : K14) : Int)));
		return (109 >>> (122 & 31));
	}
	public function m33(a34:A13):Int {
		H.tick();
		var v158:Int = 65535;
		var v159:A13 = ((switch (E6A) {
			case E6A: a34;
		}) : A13);
		for (i160 in 0...H.lim(m31("0"))) {
			H.tick();
			{ var dyn161:Dynamic = ({x11: v158, x12: i160} : S10); H.out("dyn " + Std.string(dyn161.x11) + " " + Std.string(Reflect.field(dyn161, "x11"))); }
			v158 = 82;
			v158 &= 295;
		}
		return 0x7FFFFFFF;
	}
}

abstract class C35 {
	public static var f36:Float = 1e3;
	public var cb37:(Int) -> Int;
	public function new(a38:Float, a39:Bool) {
		this.cb37 = (p162:Int) -> p162;
	}
	abstract public function m40(a41:Int):C27;
}
