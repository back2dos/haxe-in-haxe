package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext73(a71:Int, a72:Int):Bool {
		H.tick();
		var v258 = ((-2.5) > 1e-7);
		for (i259 in 0...H.lim(253)) {
			H.tick();
			a72--;
			H.out("o260 " + Std.string(a71));
		}
		try {
			var w261 = 0;
while (w261 < 4 && v258) {
				w261++;
				H.tick();
				var v262:Float = a71;
				final v263:Int = 0xC5C6;
			}
			v258 = false;
			final lf264:(Float, String) -> Int = (p265:Float, p266:String) -> a71;
			if (v258) throw "boom";
		} catch (ex267:String) {
			H.out("caught String " + ex267);
			var v268:Bool = true;
			H.out("o269 " + Std.string(v268));
		} catch (ex270:Int) {
			H.out("caught Int " + ex270);
			for (i271 in 0...H.lim((Std.parseInt(Std.string(a72)) ?? 0))) {
				H.tick();
				a71 = a72;
			}
		} catch (ex272:Err) {
			H.out("caught Err " + ex272.errCode);
			var v273:Int = (-1906893181);
		} catch (ex274:Dynamic) {
			H.out("caught " + H.exn(ex274));
			var v275:E6 = E6.E6A;
			switch (E1.E1A) {
				case E1A: {
					var v276:Float = 2.5e-3;
					a71 <<= (a72 & 7);
				};
				case E1C(c277, c278): {
					final v279:Null<Int> = a71;
					var v280:E0 = E0.E0A;
				};
				case _: {
					H.out("o281 " + Std.string(a71));
				};
			}
		}
		switch (E1.E1C(a71, a71)) {
			case E1A: {
				a72 = (a71--);
				if (v258) return Math.isNaN(a71);
			};
			case E1B(c282, c283): {
				for (i284 in 0...0) {
					H.tick();
					var v285:Map<String, Int> = (["k0" => c282, "k1" => a72] : Map<String, Int>);
				}
			};
			case E1C(c286, c287): {
				final lf288:(Int) -> Void = function(p289:Int):Void {
					H.tick();
					H.out("o290 " + Std.string(p289));
				};
			};
			case E1D: {
				final v291:Float = 1.25;
			};
			case _: {
				var v292 = a72;
			};
		}
		H.out("o293 " + Std.string(E1.E1C(a71, 130)));
		a72 &= (Std.int(1e-7) % H.nz((({x8: 43, x9: v258} : S7)).x8));
		var v294 = (v258 ? 216 : (++a71));
		return (Reflect.compare(v294, v294) < v294);
	}
	public static function ext76(a74:Int, a75:Int):Int {
		H.tick();
		var v295:E6 = E6.E6A;
		var v296 = ((a75 = 5) - (Std.parseInt(Std.string(a74)) ?? 0));
		var v297:Int = (a74 << (a75 & 31));
		switch ((cast (a75) : Int)) {
			case 0: {
				var v298:Int = a74;
				a75 = 228;
			};
			case 2 | 5: {
				var v299:Float = 2.5e-3;
				H.out("o300 " + Std.string(v296));
			};
			case _: {
				{
					H.out("o301 " + Std.string(253));
				}
			};
		}
		switch (((Std.parseInt(Std.string(a74)) ?? 0) - 233)) {
			case 0: {
				final v302:() -> Int = function():Int {
					H.tick();
					var v303 = false;
					var v304:Int = a75;
					final v305:(Int, String) -> Void = function(p306:Int, p307:String):Void {
						H.tick();
						var v308:Int = a75;
						var v309:Float = v304;
					};
					return 233;
				};
			};
			case 3 | 5: {
				try {
					if (Std.isOfType(new C21(false, 123456.789), C21)) throw Std.string(v297);
					var v310 = v297;
				} catch (ex311:Dynamic) {
					H.out("caught " + H.exn(ex311));
					var v312:Float = a75;
				}
				Main.fn48();
			};
			case _: {
				H.out("o313 " + Std.string(a74));
				a74++;
			};
		}
		final v314:(Bool) -> Bool = function(p315:Bool):Bool {
			H.tick();
			var v316:Int = v296;
			return p315;
		};
		return (-1487986211);
	}
}
