import H;
import p.M1;
using p.Ext;

enum E1 {
	E1A;
	E1B(a2:Int, a3:Int);
	E1C(a4:Int, a5:Float);
	E1D;
}

class C21 extends C15 {
	public var f22:Int;
	public final f23:Float;
	public function new(a24:Bool, a25:Float) {
		super((-1757693395));
		this.f22 = (-514615669);
		this.f23 = 1e100;
	}
	public function m20():(Int) -> Bool {
		H.tick();
		var v77:Float = ({ var v78 = 39; this.f23; });
		try {
			H.out("o79 " + Std.string((Std.parseInt("") ?? 0)));
			if (false) throw 15;
		} catch (ex80:Err) {
			H.out("caught Err " + ex80.errCode);
			H.out("o81 " + Std.string(false));
		} catch (ex82:haxe.Exception) {
			H.out("caught " + H.exn(ex82));
			var v83:Map<String, Int> = (["k0" => 158] : Map<String, Int>);
		}
		var w84 = 0;
while (w84 < 2 && (Std.downcast((new C21(true, v77) : C15), C15) != null)) {
			w84++;
			H.tick();
			var v85:Map<Int, Int> = ([-3 => 253] : Map<Int, Int>);
			if (false) continue;
		}
		final v86 = ({ var v87 = (([-3 => v77, 4 => v77] : Map<Int, Float>)).exists(4); 8467025; });
		var v88:Int = 265;
		return ({ var v89 = (true && true); (((([-3 => (83 : A13)] : Map<Int, A13>)).exists(11) ? (p90:Int) -> v89 : (p91:Int) -> v89) : (Int) -> Bool); });
	}
	public function m26():Int {
		H.tick();
		for (i92 in 2...5) {
			H.tick();
			for (i93 in 0...4) {
				H.tick();
				var v94 = 194;
				var v95:Map<String, String> = new Map<String, String>();
				var v96:Null<Int> = i92;
			}
			(new C21(false, 1.25)).m20();
		}
		Ext.ext76(((K14.K14B : Int) | 0x8BDE), (177 - 298));
		for (i97 in 0...2) {
			H.tick();
			H.out("o98 " + Std.string(((i97 : A13) : Int)));
		}
		H.out("o99 " + Std.string(new C21((Std.downcast((new C21(false, 1.7976931348623157e308) : C15), C15) != null), 1e-7)));
		try {
			if (((["k0" => 146] : Map<String, Int>)).exists("k0")) {
				Main.fn53(123456.789);
				H.out("o100 " + Std.string(230));
				this.f17 *= 25;
			}
			if ((Std.isOfType(new C21(true, 2.5e-3), C21) || true)) throw ("\t" + "hello world");
		} catch (ex101:String) {
			H.out("caught String " + ex101);
			if (false) return (({x9: false, x8: 0x4184} : S7)).x8;
		} catch (ex102:Int) {
			H.out("caught Int " + ex102);
			Main.fn48();
		} catch (ex103:Err) {
			H.out("caught Err " + ex103.errCode);
			H.out("o104 " + Std.string(Std.parseFloat("\x41\x42")));
			if (false) {
				this.f17 *= 0xD092;
				var v105:E1 = E1D;
				H.out("o106 " + Std.string(({x8: 250, x9: false} : S7)));
			}
		} catch (ex107:Dynamic) {
			H.out("caught " + H.exn(ex107));
			H.out("o108 " + Std.string(true));
			this.f16 = (({x8: 114, x9: false} : S7)).x8;
		}
		H.out("o109 " + Std.string(this.f16));
		final v110:Float = 123456.789;
		return (switch (({ var v111 = Lambda.fold([102], (v112:Int, v113:Int) -> 213, 0); K14.K14B; })) {
			case K14.K14A: ((Std.parseInt(Std.string(158)) ?? 0) & Type.enumIndex(E6.E6A));
			case K14.K14B: (new C27()).m31("\u{1F600}");
		});
	}
}

class Main {
	public static inline function fn42(a43:Int = 8):Float {
		H.tick();
		switch ((((([-3 => new A13(a43), 4 => (a43 : A13)] : Map<Int, A13>)).exists(-3) ? K14.K14B : K14.K14A) : K14)) {
			case K14.K14A: {
				function lf163(n164:Int):Int {
					H.tick();
					return n164 <= 0 ? 251 : (lf163(n164 - 1) + 0xCE2B);
				}
				H.out("lf163 " + lf163(2));
			};
			case K14.K14B: {
				H.out("o165 " + Std.string(E1.E1A));
			};
		}
		(((true ? new C21(true, (-2.5)) : new C21(true, a43)) : C15)).m20();
		var v166:Null<Int> = null;
		return a43;
	}
	public static inline function fn44(a45:Int, a46:Bool, a47:String):String {
		H.tick();
		Main.fn42();
		var v167:Bool = ((["k0" => E0.E0A, "k1" => E0.E0A] : Map<String, E0>)).exists("k1");
		var v168:Bool = (1e3 > a45);
		var v169 = a45;
		for (k170 => v171 in ((switch (v169) {
			case 0: new Map<String, Int>();
			case 2 | 6: (["k0" => a45, "k1" => v169, "k2" => v169] : Map<String, Int>);
			case _: new Map<String, Int>();
		}) : Map<String, Int>)) {
			H.tick();
			v169 = H.id(v169);
		}
		H.out("o172 " + Std.string((new C27()).m31("\"q\"")));
		return "42";
	}
	public static inline function fn48():E0 {
		H.tick();
		var v173:Int = (154 - 0x7B35);
		H.out("o174 " + Std.string((new A13(76) : Int)));
		fn42(v173);
		return (((v173 <= v173) ? ((Std.isOfType(new C27(), C27) ? E0.E0A : E0.E0A) : E0) : E0.E0A) : E0);
	}
	public static function fn49(a50:C21, a51:Null<Int>, a52:Int = 8):Bool {
		H.tick();
		H.out("o175 " + Std.string(Lambda.fold(([] : Array<Int>), (v176:Int, v177:Int) -> ((([-3 => 291, 4 => v176, 11 => v177] : Map<Int, Int>)).get(11) ?? 0), 0)));
		for (i178 in 2...6) {
			H.tick();
			a52--;
		}
		for (i179 in 0...2) {
			H.tick();
			var w180 = 0;
do {
				w180++;
				H.tick();
				H.out("o181 " + Std.string(({x8: 0x43C0, x9: false} : S7)));
				var v182 = 0x4ECD;
			} while (w180 < 3 && false);
		}
		final v183:A13 = new A13(185);
		function lf184(n185:Int):Int {
			H.tick();
			return n185 <= 0 ? n185 : (lf184(n185 - 1) + (if (false) (({x12: n185, x11: a52} : S10)).x12 else Math.ceil(n185)));
		}
		H.out("lf184 " + lf184(2));
		return !true;
	}
	public static inline function fn53(a54:Float):Int {
		H.tick();
		switch ((switch ((-1809040349)) {
			case 0: 206;
			case 1 | 4: Std.int(a54);
			case _: (Std.parseInt("\x41\x42") ?? 0);
		})) {
			case 0: {
				switch (((new Map<String, Int>()).get("x,y,z") ?? 0)) {
					case 0: {
						var v186:Int = 245;
						(new C21(false, 2.5e-3)).m20();
					};
					case 2 | 6: {
						var v187:Int = 244;
					};
					case _: {
						H.out("o188 " + Std.string(null));
						var v189:A13 = new A13((-84480049));
					};
				}
			};
			case 3 | 5: {
				H.out("o190 " + Std.string(({x8: (-1905052527), x9: true} : S7)));
			};
			case _: {
				var v191:A13 = (65535 : A13);
				switch (E6.E6A) {
					case E6A: {
						var v192 = 0x7FFFFFFF;
					};
				}
			};
		}
		Main.fn44((true ? Math.floor(a54) : 29), (false || false), "x,y,z");
		switch (E0.E0A) {
			case E0A: {
				var v193:C27 = new C27();
			};
			case _: {
				if (false) {
					H.out("o194 " + Std.string(179));
					var v195:E6 = E6.E6A;
					final v196:() -> Float = () -> a54;
				} else {
					(new C21(false, a54)).m20();
					var v197:C15 = new C21(true, a54);
				}
				H.out("o198 " + Std.string(0x92AE));
			};
		}
		return ((((new Map<Int, E0>()).exists(-3) ? new C27() : new C27()) : C27)).m31("x,y,z");
	}
	public static function fn55(a56:Int, a57:Bool):Int {
		H.tick();
		if ((23 == a56)) {
			final lf199:(Bool) -> Int = (p200:Bool) -> a56;
			H.out("o201 " + Std.string(a56));
		} else {
			a56 = Type.enumIndex(E1D);
			switch (0xB099) {
				case 0: {
					var v202:Float = 0.5;
					H.out("o203 " + Std.string(a57));
				};
				case 3 | 5: {
					(new C27()).m33(new A13(a56));
				};
				case _: {
					a56 = H.id(a56);
				};
			}
		}
		if (a57) {
			var v204:E1 = E1.E1C(a56, a56);
		}
		var v205:C15 = new C21(a57, a56);
		(new C27()).m33((-(a56 : A13)));
		var v206:C27 = new C27();
		return 266;
	}
	public static function fn58(a59:Float):E1 {
		H.tick();
		var v207:Int = 423819367;
		var v208:Int = (Reflect.compare(v207, v207) % H.nz(34));
		if ((true || false)) return E1.E1A;
		try {
			if (((({x12: v208, x11: 0.1} : S10)).x12 < v208)) throw "boom";
			var v209 = Math.round(v208);
			fn48();
		} catch (ex210:Dynamic) {
			H.out("caught " + H.exn(ex210));
			H.out("o211 " + Std.string(v208));
		}
		{ var dyn212:Dynamic = ({x12: (((["k0" => v208, "k1" => v208, "k2" => 96] : Map<String, Int>)).get("k2") ?? 0), x11: Math.pow(v208, 2)} : S10); H.out("dyn " + Std.string(dyn212.x11) + " " + Std.string(Reflect.field(dyn212, "x11"))); }
		final v213:(Int) -> Int = function(p214:Int):Int {
			H.tick();
			H.out("o215 " + Std.string(true));
			return ((new Map<Int, Int>()).get(88) ?? 0);
		};
		return E1C(120, Std.parseFloat(Std.string(true)));
	}
	public static function fn60(a61:Int, a62:String, a63:Int):Int {
		H.tick();
		var v216:C21 = new C21(((["k0" => E1.E1D, "k1" => E1.E1A] : Map<String, E1>)).exists("k2"), a63);
		var v217 = a63;
		try {
			if (Ext.ext73(Math.round(v217), (a61 += 3))) throw "boom";
			var w218 = 0;
while (w218 < 5 && Math.isNaN(0.30000000000000004)) {
				w218++;
				H.tick();
				(new C27()).m29(4);
				H.out("o219 " + Std.string(v216));
				(new C27()).m33(new A13(a63));
			}
			H.out("o220 " + Std.string(Type.enumIndex(E1D)));
			final v221:Null<Int> = v217;
		} catch (ex222:Err) {
			H.out("caught Err " + ex222.errCode);
			Main.fn42();
		} catch (ex223:haxe.Exception) {
			H.out("caught " + H.exn(ex223));
			Ext.ext73(a61, 152);
			H.out("o224 " + Std.string(true));
		}
		var v225:Map<String, Int> = new Map<String, Int>();
		var v226 = (v217 & a63);
		fn55((new C21(true, a61)).m26(), (true && Std.isOfType(v216, C21)));
		return ((switch (K14.K14B) {
			case K14.K14A: a63;
			case K14.K14B: (({x8: a61, x9: false} : S7)).x8;
			case _: (Std.parseInt(Std.string(259)) ?? 0);
		}) >> ((a61 = 5) & 31));
	}
	public static function fn64(a65:Float, a66:String, a67:Bool):String {
		H.tick();
		var v227:Float = (a65 * a65);
		var v228:Int = 238;
		Main.fn55((v228 ^ (new A13(57)).twice), Std.isOfType(new C27(), C27));
		H.out("o229 " + Std.string(v228));
		H.out("o230 " + Std.string((v228 = 5)));
		final v231:S7 = ({x8: Math.ceil(100.75), x9: a67} : S7);
		v228 -= (a67 ? v228 : Lambda.fold([v228, v228], (v232:Int, v233:Int) -> (new A13(v228) : Int), 0));
		var v234:Int = Std.int(v228);
		return (a67 ? "hello world" : "ab");
	}
	public static function fn68(a69:Int):Void {
		H.tick();
		H.out("o235 " + Std.string(a69));
		final v236:(Float, Float) -> Int = (p237:Float, p238:Float) -> 29;
		if ((181 == (Std.parseInt(Std.string(a69)) ?? 0))) {
			a69 *= a69;
			var v239:Int = Type.enumIndex(E1A);
		}
		fn49(((switch (101) {
			case 0: new C21(true, a69);
			case 3 | 5: new C21(false, a69);
			case _: new C21(true, a69);
		}) : C21), ({ var v240 = (a69 -= 1); 78; }), a69);
		var v241:S7 = ({x9: (new Map<String, K14>()).exists("k1"), x8: (({x9: true, x8: 179} : S7)).x8} : S7);
		if ((true ? ((["k0" => new A13(a69)] : Map<String, A13>)).exists("k1") : true)) {
			Main.fn42(a69);
			function lf242(n243:Int):Int {
				H.tick();
				return n243 <= 0 ? (v241).x8 : (lf242(n243 - 1) + (a69 = 5));
			}
			H.out("lf242 " + lf242(4));
			(new C27()).m31("Haxe");
		} else {
			H.out("o244 " + Std.string(({x12: a69, x11: a69} : S10)));
		}
	}
	public static function fn70():(Int, Int) -> Bool {
		H.tick();
		H.out("o245 " + Std.string(127));
		H.out("o246 " + Std.string(((Std.parseInt(Std.string(0x80000000)) ?? 0) ^ 0xFFFFFFFF)));
		if ((Reflect.compare((-1899855103), 40)).ext73((Std.parseInt(Std.string(2083962052)) ?? 0))) {
			final v247:E1 = E1.E1A;
		} else {
			var v248:Int = 214;
			function lf249(n250:Int):Int {
				H.tick();
				return n250 <= 0 ? n250 : (lf249(n250 - 1) + 154);
			}
			H.out("lf249 " + lf249(2));
		}
		final v251:Map<String, Float> = (["k0" => 1.25, "k1" => 0.1] : Map<String, Float>);
		final v252:A13 = (new A13(140) + new A13((-9)));
		H.out("o253 " + Std.string((230 <= C15.f18)));
		return function(p254:Int, p255:Int):Bool {
			H.tick();
			var v256:Float = Std.parseFloat("-0.25");
			var v257:S10 = ({x11: v256, x12: p255} : S10);
			return Math.isNaN(p255);
		};
	}
	public static function section0():Void {
		H.tick();
		switch (E6.E6A) {
			case E6A: {
				var v317:Int = (({x11: 0.5, x12: 280} : S10)).x12;
			};
		}
		var v318:E0 = E0.E0A;
		switch (K14.K14A) {
			case K14.K14A: {
				final v319:E0 = E0.E0A;
				H.out("o320 " + Std.string(({x11: 1e3, x12: 131} : S10)));
			};
			case K14.K14B: {
				Ext.ext73(Math.floor((-2.5)), (({x11: 123456.789, x12: 159} : S10)).x12);
			};
		}
		for (i321 in 0...4) {
			H.tick();
			fn68(i321);
			final v322:(Int, String) -> Float = (p323:Int, p324:String) -> p323;
			var v325 = i321;
		}
		var v326:S7 = ({x8: Reflect.compare(259, 100), x9: (new Map<String, C21>()).exists("k3")} : S7);
		var v327:K14 = K14.K14A;
		H.out("o328 " + Std.string(Ext.ext73(261, 147)));
		for (k329 => v330 in (["k0" => 51] : Map<String, Int>)) {
			H.tick();
			for (i331 in 0...0) {
				H.tick();
				H.out("o332 " + Std.string(i331));
			}
			var w333 = 0;
while (w333 < 3 && true) {
				w333++;
				H.tick();
				Main.fn70();
				var v334:Map<Int, String> = new Map<Int, String>();
			}
			final v335:() -> Bool = () -> true;
		}
	}
	public static function section1():Void {
		H.tick();
		var v336:E0 = ({ var v337 = false; E0.E0A; });
		(((({x8: (-2147483647), x9: true} : S7)).x8 >> ((-20) & 31))).ext73(0x817D);
		(new C21(false, C35.f36)).m20();
		H.out("o338 " + Std.string((new C27()).m33(new A13(117))));
		function lf339(n340:Int):Int {
			H.tick();
			return n340 <= 0 ? (740121699 << (Math.floor(2.5e-3) & 31)) : (lf339(n340 - 1) + (180 * (Std.parseInt("\x41\x42") ?? 0)));
		}
		H.out("lf339 " + lf339(1));
	}
	public static function section2():Void {
		H.tick();
		var v341:Bool = (cast (false) : Bool);
		final v342:Int = (259 ^ 231);
		switch ((K14.K14A : Int)) {
			case 0: {
				final v343:Int = v342;
				for (i344 in 0...H.lim(0x430A)) {
					H.tick();
					var v345:Int = v342;
					H.out("o346 " + Std.string(0x80000000));
					var v347:Map<String, Int> = (["k0" => i344, "k1" => 119] : Map<String, Int>);
				}
			};
			case 1 | 6: {
				var v348:Float = (-2.5);
				switch (E1D) {
					case E1A: {
						var v349 = false;
					};
					case E1B(c350, c351): {
						Main.fn68(v342);
					};
					case E1D: {
						var v352 = v342;
						(new C27()).m29(v342);
					};
					case _: {
						var v353:C27 = new C27();
						var v354 = v342;
					};
				}
			};
			case _: {
				var v355 = v342;
				H.out("o356 " + Std.string(E1D));
			};
		}
		H.out("o357 " + Std.string((true ? v342 : v342)));
		var v358:Map<Int, Int> = ([-3 => Lambda.count([v342], v359 -> true)] : Map<Int, Int>);
		Main.fn70();
		var v360:C27 = new C27();
	}
	public static function section3():Void {
		H.tick();
		Main.fn48();
		for (i361 in 0...3) {
			H.tick();
			var v362:C15 = new C21(true, 1e3);
		}
		var v363:C15 = new C21((([-3 => true, 4 => true, 11 => false] : Map<Int, Bool>)).exists(18), 3.0);
		var v364:S7 = ({x8: 215, x9: false} : S7);
		try {
			H.out("o365 " + Std.string((Std.parseInt(Std.string(0xF0F6)) ?? 0)));
			if (((new A13(191)).get() > Reflect.compare(65535, 0x9499))) throw new Err(165);
		} catch (ex366:String) {
			H.out("caught String " + ex366);
			try {
				Main.fn58(0.30000000000000004);
				var v367:Bool = false;
				if (true) throw "0";
			} catch (ex368:String) {
				H.out("caught String " + ex368);
				H.out("o369 " + Std.string(282));
				var v370:S10 = ({x11: 2.5e-3, x12: 194} : S10);
			} catch (ex371:Int) {
				H.out("caught Int " + ex371);
				var v372:A13 = new A13(62);
			} catch (ex373:Err) {
				H.out("caught Err " + ex373.errCode);
				var v374 = 289;
				(v374).ext76(81);
			} catch (ex375:Dynamic) {
				H.out("caught " + H.exn(ex375));
				H.out("o376 " + Std.string(v364));
				var v377:Float = 0.5;
			}
			var v378 = Math.round(1e-7);
		} catch (ex379:Int) {
			H.out("caught Int " + ex379);
			try {
				H.out("o380 " + Std.string(ex379));
				var v381:Map<String, Float> = (["k0" => 1e3] : Map<String, Float>);
				if (false) throw "\t";
			} catch (ex382:Dynamic) {
				H.out("caught " + H.exn(ex382));
				var v383:Int = ex379;
				H.out("o384 " + Std.string(ex379));
			}
		} catch (ex385:Err) {
			H.out("caught Err " + ex385.errCode);
			var v386 = (((["k0" => 61] : Map<String, Int>)).get("k2") ?? 0);
		} catch (ex387:Dynamic) {
			H.out("caught " + H.exn(ex387));
			H.out("o388 " + Std.string((Std.downcast((new C27() : C27), C27) != null)));
			Main.fn70();
		}
		var v389 = (new C27()).m33((0x8421 : A13));
	}
	public static function section4():Void {
		H.tick();
		fn68(((new A13(275)).get() >> ((-15) & 31)));
		if (false) {
			H.out("o390 " + Std.string((({x8: 65535, x9: false} : S7)).x8));
			H.out("o391 " + Std.string(237));
			var v392:Int = (Std.parseInt("日本語") ?? 0);
		}
		var v393:K14 = K14.K14B;
		var v394:A13 = (-(0x4CA8 : A13));
		try {
			H.out("o395 " + Std.string(1e-7));
			if (false) throw "\t";
		} catch (ex396:String) {
			H.out("caught String " + ex396);
			try {
				if (false) throw new Err(1491817554);
				var v397:C27 = new C27();
				var v398:A13 = v394;
				H.out("o399 " + Std.string(117));
			} catch (ex400:Dynamic) {
				H.out("caught " + H.exn(ex400));
				var v401:K14 = v393;
			}
		} catch (ex402:Int) {
			H.out("caught Int " + ex402);
			H.out("o403 " + Std.string(139));
		} catch (ex404:Err) {
			H.out("caught Err " + ex404.errCode);
			final v405:S7 = ({x8: 260, x9: true} : S7);
			var v406:Float = C35.f36;
		} catch (ex407:Dynamic) {
			H.out("caught " + H.exn(ex407));
			if (false) {
				var v408:Null<Int> = 18;
				var v409 = 0x80000000;
				var v410:Float = v409;
			}
			var v411:Float = (-2.5);
		}
		if ((Std.int((-2.5)) != Lambda.count([0x80000000, 16, 277], v412 -> false))) {
			for (i413 in 0...0) {
				H.tick();
				if (true) continue;
				final v414:S7 = ({x8: i413, x9: true} : S7);
				Main.fn55(116, false);
			}
		} else {
			if (false) {
				var v415:Int = 166;
				var v416 = v415;
			}
		}
		for (i417 in 0...1) {
			H.tick();
			var v418:E0 = E0.E0A;
			var v419:Float = i417;
		}
		var v420:E0 = E0.E0A;
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
