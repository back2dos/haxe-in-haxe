import H;
import p.M1;

typedef S0 = {x1:Int, x2:Float, x3:Bool};

typedef S4 = {x5:String};

class Main {
	public static function fn7():Int {
		H.tick();
		var v28:Bool = ((([] : Array<Int>)).length < 299);
		try {
			switch (Std.int(123456.789)) {
				case 0: {
					H.out("o29 " + Std.string(0xBEEA));
				};
				case 2 | 4: {
					H.out("o30 " + Std.string((K6.K6A : Int)));
				};
				case _: {
					var v31:Int = 0x7FFFFFFF;
					final v32:String = "ab";
				};
			}
			if (false) {
				var v33:Bool = v28;
				final v34:Null<Int> = 22;
			} else {
				H.out("o35 " + Std.string(99));
				var v36:Array<Int> = [(-1386269952), 146, 142];
			}
			if ((Math.isNaN(100.75) ? false : v28)) throw ("abc").substring(((-17) & 7), (1367274665 & 7));
		} catch (ex37:Err) {
			H.out("caught Err " + ex37.errCode);
			for (i38 in 0...H.lim(35)) {
				H.tick();
				H.out("o39 " + Std.string(v28));
				H.out("o40 " + Std.string(i38));
			}
			var v41:Map<String, Int> = (["k0" => 154, "k1" => 84] : Map<String, Int>);
		} catch (ex42:haxe.Exception) {
			H.out("caught " + H.exn(ex42));
			H.out("o43 " + Std.string(0.30000000000000004));
			var v44:Int = (([] : Array<Int>)).length;
		}
		H.out("o45 " + Std.string(155));
		for (k46 => v47 in new Map<String, Int>()) {
			H.tick();
			if (true) {
				var v48:Float = v47;
				var v49 = k46;
				var v50:Map<String, String> = new Map<String, String>();
			}
			for (i51 in 0...2) {
				H.tick();
				final v52:String = "hello world";
				var v53:Box<Bool> = new Box<Bool>(v28);
				if (v28) continue;
			}
		}
		var v54 = 195;
		for (k56 => x55 in ([6, 247]).slice((v54 & 7), -2)) {
			H.tick();
			H.out("o57 " + "x,y,z");
			v54 = 239;
			H.out("o58 " + Std.string(k56));
		}
		var v59:Array<Int> = [("abc").indexOf("A-B-C")];
		return (217 >>> (v54 & 31));
	}
	public static function fn8(a9:Int, a10:Int):Bool {
		H.tick();
		final v60 = a10;
		Main.fn7();
		if (("q" >= "\n")) return (((["k0" => a10, "k1" => a9] : Map<String, Int>)).exists("") ? true : StringTools.endsWith("q", "abc"));
		var v61:Box<Float> = new Box<Float>((-2.5));
		a9 = v60;
		var v62 = (("zz").toUpperCase()).toUpperCase();
		var v63:Map<Int, String> = new Map<Int, String>();
		final v64 = false;
		return false;
	}
	public static function fn11(a12:Bool, a13:String):String {
		H.tick();
		var v65 = (280 * Math.round((-2.5)));
		for (i66 in 0...H.lim(v65)) {
			H.tick();
			if (true) {
				Main.fn8(76, i66);
				final v67:Array<String> = ("hello world").split("-");
			}
		}
		for (x68 in [a13]) {
			H.tick();
			{
				a12 = false;
				final v69:String = "  pad  ";
				fn8(v65, 229);
			}
			fn8(39, (a13).lastIndexOf(x68));
		}
		var v70 = 284;
		return a13;
	}
	public static function fn14():Array<Float> {
		H.tick();
		final v71 = !true;
		H.out("o72 " + Std.string(3.0));
		for (i73 in 0...H.lim((H.at([16, 1475619074], 143, 0) ^ 16))) {
			H.tick();
			H.out("o74 " + Std.string(100.75));
			switch (("\t").lastIndexOf("-7")) {
				case 0: {
					var v75:Float = 1.7976931348623157e308;
					H.out("o76 " + Std.string(i73));
				};
				case 3 | 5: {
					H.out("o77 " + "ab");
				};
				case _: {
					H.out("o78 " + Std.string(i73));
					H.out("o79 " + "Haxe");
				};
			}
		}
		return (([for (i80 in 0...1) i80] : Array<Float>)).slice(3, -1);
	}
	public static function fn15():Array<String> {
		H.tick();
		var v81 = 138;
		var v82:Array<String> = ((false ? ["Haxe", ""] : ["Haxe"]) : Array<String>);
		var v83:S0 = ({x1: H.at([v81, v81, v81], v81, 0), x2: v81, x3: StringTools.contains("hello world", "\"q\"")} : S0);
		try {
			H.out("o84 " + "");
			for (x85 in [278, v81]) {
				H.tick();
				Main.fn8(v81, 0xD016);
				H.out("o86 " + Std.string(57));
				H.out("o87 " + "\"q\"");
			}
			fn14();
			if (true) throw 51;
		} catch (ex88:String) {
			H.out("caught String " + ex88);
			v81 = (-781908055);
			v81 = Reflect.compare(241, v81);
		} catch (ex89:Int) {
			H.out("caught Int " + ex89);
			v81 ^= v81;
		} catch (ex90:Err) {
			H.out("caught Err " + ex90.errCode);
			var v91:Int = Std.int(1e-7);
			H.out("o92 " + Std.string(v91));
		} catch (ex93:Dynamic) {
			H.out("caught " + H.exn(ex93));
			switch (("A-B-C").substring(-2, 4)) {
				case "a" | "b": {
					H.out("o94 " + Std.string(v81));
				};
				case "Haxe": {
					v81 = H.id(v81);
					Main.fn7();
				};
				case "": {
					fn7();
				};
				case _: {
					v81++;
				};
			}
		}
		for (i95 in 0...H.lim((StringTools.replace("hello world", "a", "A-B-C")).indexOf((v82).join(",")))) {
			H.tick();
			var v96:Array<Float> = ([v81, i95, 2.5e-3] : Array<Float>);
			var v97:Int = (v81++);
		}
		return (Std.string(v81)).split(" ");
	}
	public static function fn16(a17:Bool, a18:Int, ?a19:Null<String>):Bool {
		H.tick();
		var v98 = ({ var sb99 = new StringBuf(); sb99.add(Std.string(false)); sb99.add(Std.string(Reflect.compare("\n", "a"))); sb99.add(Std.string(false)); sb99.addChar(71); sb99.toString(); });
		var v100 = (new Box(v98)).get();
		for (k103 => x101 in [for (i102 in ([7.0] : Array<Float>)) if (true) 166]) {
			H.tick();
			for (i104 in 0...H.lim(x101)) {
				H.tick();
				var v105 = v100;
			}
		}
		fn11((a17 && false), v100);
		return StringTools.startsWith((cast (v100) : String), Main.fn11(false, (v100).toUpperCase()));
	}
	public static function fn20(a21:Int, a22:Int, a23:Int):String {
		H.tick();
		function lf106(n107:Int):Int {
			H.tick();
			return n107 <= 0 ? (cast (a22) : Int) : (lf106(n107 - 1) + fn7());
		}
		H.out("lf106 " + lf106(4));
		for (x108 in ([a21] : Array<Float>)) {
			H.tick();
			for (x109 in ([x108, a22, a23] : Array<Float>)) {
				H.tick();
				fn16(false, a21, "42");
				var v110 = a22;
				var v111 = v110;
			}
			final v112 = (K6.K6B : Int);
		}
		a23--;
		{
			if (true) return Std.string(a21);
			a22 = H.id(a22);
			var v113:Array<String> = ["0", "a", "\n"];
		}
		if ((([a23, a21]).join("") <= String.fromCharCode(65 + ((a22) & 15)))) return "Haxe";
		return (StringTools.replace("0", ",", StringTools.replace("\\", ",", "A-B-C"))).toLowerCase();
	}
	public static function fn24():String {
		H.tick();
		function lf114(n115:Int):Int {
			H.tick();
			return n115 <= 0 ? (switch (({x1: n115, x2: n115, x3: false} : S0)) {
			case {x1: 1 | 2}: (((["k0" => n115, "k1" => n115, "k2" => n115] : Map<String, Int>)).get("k2") ?? 0);
			case {x1: c116}: n115;
		}) : (lf114(n115 - 1) + (switch (n115) {
			case 0: n115;
			case 2 | 6: 0x8C16;
			case _: n115;
		}));
		}
		H.out("lf114 " + lf114(0));
		var v117:Map<String, Bool> = new Map<String, Bool>();
		final v118 = 170;
		if ((cast (false) : Bool)) {
			var w119 = 0;
while (w119 < 4 && StringTools.endsWith("a", "\\")) {
				w119++;
				H.tick();
				final v120:Float = v118;
			}
		}
		for (i121 in 1...4) {
			H.tick();
			if (StringTools.contains("  pad  ", "-7")) {
				var v122 = 143;
				v122 = 177;
			}
		}
		if (({ var v123 = Std.parseFloat("-0.25"); true; })) {
			var v124 = (("\n").charCodeAt(183) ?? -1);
			v124 = H.id(v124);
			final v125:Float = 123456.789;
		}
		return "x,y,z";
	}
	public static function fn25(a26:Float, a27:Map<String, Int>):Float {
		H.tick();
		if (Main.fn16(StringTools.endsWith("\n", "ab"), Reflect.compare("  pad  ", '$$'), ("Haxe").substr((250 & 7), (0x1194 & 7)))) {
			var v126:S4 = ({x5: "0"} : S4);
		} else {
			H.out("o127 " + String.fromCharCode(65 + ((195) & 15)));
			try {
				if (true) throw "boom";
				H.out("o128 " + "");
				H.out("o129 " + Std.string(1933524963));
			} catch (ex130:String) {
				H.out("caught String " + ex130);
				var v131:String = "hello world";
				var v132:Array<Int> = [277, 299, 0xCF19];
			} catch (ex133:Int) {
				H.out("caught Int " + ex133);
				H.out("o134 " + Std.string(131));
			} catch (ex135:Err) {
				H.out("caught Err " + ex135.errCode);
				var v136:Map<String, Map<String, Int>> = new Map<String, Map<String, Int>>();
				Main.fn11(true, "q");
			} catch (ex137:Dynamic) {
				H.out("caught " + H.exn(ex137));
				var v138:Array<Bool> = ([] : Array<Bool>);
			}
		}
		a27.set("k1", (["\"q\""]).length);
		H.out("o139 " + Main.fn20(266, 234, 0xD66));
		return 100.75;
	}
	public static function section0():Void {
		H.tick();
		var v140:Map<Int, Int> = H.id(new Map<Int, Int>());
		final v141 = ((("zz").charCodeAt(0x7FFFFFFF) ?? -1) * 0x19E3);
		try {
			if ((("A-B-C").indexOf("\t") > 196)) throw Main.fn20(("a").length, ([v141]).length, ([v141]).indexOf(v141));
			var v142:Int = ("Haxe").indexOf("\t");
			{ var dyn143:Dynamic = ({x5: "A-B-C"} : S4); H.out("dyn " + Std.string(dyn143.x5) + " " + Std.string(Reflect.field(dyn143, "x5"))); }
			var w144 = 0;
while (w144 < 5 && false) {
				w144++;
				H.tick();
				v142 += 237;
				H.out("o145 " + Std.string(v142));
			}
		} catch (ex146:Dynamic) {
			H.out("caught " + H.exn(ex146));
			for (k148 => x147 in [false]) {
				H.tick();
				var v149:Int = k148;
			}
		}
		for (i150 in 0...H.lim(([v141, 182, v141]).indexOf(v141))) {
			H.tick();
			var v151 = Std.string(v141);
			if ((([] : Array<Int>)).contains(v141)) continue;
			var v152:String = v151;
		}
	}
	public static function section1():Void {
		H.tick();
		for (x153 in ([] : Array<String>)) {
			H.tick();
			if (Math.isNaN((-2.5))) break;
		}
		var v154:Array<Int> = ([45, 16]).slice(-1, -2);
		for (x155 in [for (i156 in 0...3) "q"]) {
			H.tick();
			for (k157 => v158 in new Map<String, Int>()) {
				H.tick();
				H.out("o159 " + Std.string(([100.75, v158, v158] : Array<Float>)));
			}
			final v160:S4 = ({x5: x155} : S4);
			var v161:Float = Std.parseFloat("3");
		}
		if (("\"q\"" < Std.string(false))) {
			H.out("o162 " + Std.string(("x,y,z").split(" ")));
		}
	}
	public static function section2():Void {
		H.tick();
		var w163 = 0;
do {
			w163++;
			H.tick();
			try {
				if (StringTools.startsWith("\"q\"", "-7")) throw new Err(78);
				H.out("o164 " + Std.string(true));
				H.out("o165 " + Std.string((K6.K6A : Int)));
			} catch (ex166:Dynamic) {
				H.out("caught " + H.exn(ex166));
				var v167:S0 = ({x3: true, x2: 2.5e-3, x1: 495835924} : S0);
				if (true) break;
			}
			var v168 = "hello world";
			H.out("o169 " + Std.string(new Box("zz")));
		} while (w163 < 4 && ((-1) > 13));
		var w170 = 0;
while (w170 < 3 && !false) {
			w170++;
			H.tick();
			if ((new Map<Int, Int>()).exists(4)) break;
		}
		H.out("o171 " + Std.string(("  pad  ").indexOf("-7")));
		try {
			if (Main.fn8(("zz").lastIndexOf("\"q\""), H.at([272, 124, 174], 195, 0))) throw new Err((~(-9)));
			var v172:String = "q";
			var v173:Map<String, Bool> = new Map<String, Bool>();
			var v174:Int = 13;
		} catch (ex175:Err) {
			H.out("caught Err " + ex175.errCode);
			if (false) {
				var v176:String = "";
				var v177:Map<String, Bool> = new Map<String, Bool>();
				final v178:Bool = false;
			} else {
				var v179 = '$$';
			}
			final v180 = ((new Map<Int, Int>()).get(225) ?? 0);
		} catch (ex181:haxe.Exception) {
			H.out("caught " + H.exn(ex181));
			H.out("o182 " + Std.string(false));
			var v183:Array<Int> = [176];
		}
		for (x184 in ((true ? ([100.75] : Array<Float>) : ([1.25, 100.75, 100.75] : Array<Float>)) : Array<Float>)) {
			H.tick();
			var v185:Int = ((new Map<Int, Int>()).get(18) ?? 0);
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
