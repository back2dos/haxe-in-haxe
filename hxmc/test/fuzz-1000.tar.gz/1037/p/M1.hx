package p;

import Main;
import H;
import p.M1;

class M1 {}

enum abstract K6(Int) to Int {
	var K6A = 1;
	var K6B = 4;
	var K6C = 7;
}
