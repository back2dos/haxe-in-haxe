package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

enum E3 {
	E3A;
	E3B(a4:E3, a5:Int);
	E3C(a6:Bool);
	E3D(a7:String);
}

enum abstract K10(Int) to Int {
	var K10A = 1;
	var K10B = 4;
}
