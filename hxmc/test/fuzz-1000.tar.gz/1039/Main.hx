import H;
import p.M1;
import p.q.M2;

typedef S8 = {x9:Int};

class Main {
	public static function fn11(a12:String, a13:Int):Int {
		H.tick();
		switch (E3.E3C((E3.E3A).match(E3A))) {
			case E3A: {
				var v28:String = "\u{1F600}";
				var v29:Array<String> = [a12, "Haxe"];
			};
			case E3B(E3D(_), c30): {
				a13 = H.id(a13);
			};
			case E3C(_): {
				H.out("o31 " + Std.string(a13));
				var v32:Map<Int, String> = ([-3 => a12, 4 => a12, 11 => a12] : Map<Int, String>);
			};
			case E3D(c33): {
				if ((E0.E0A).match(E0A)) {
					var v34:Array<Int> = ([] : Array<Int>);
					var v35 = a13;
				} else {
					H.out("o36 " + Std.string(a13));
				}
			};
			case _: {
				var v37:Int = 162;
			};
		}
		a13++;
		a13 = (a13 % H.nz(a13));
		return (a13 + a13);
	}
	public static inline function fn14():Int {
		H.tick();
		var v38 = "Haxe";
		var v39:String = '<${Std.string((-300732145))}';
		var v40:Null<Int> = (K10.K10A : Int);
		final v41 = ((new Map<String, Int>()).get("k1") ?? 0);
		return v41;
	}
	public static function fn15(a16:Int, a17:String):Int {
		H.tick();
		var v42:Int = a16;
		H.out("o43 " + Std.string(Main.fn14()));
		fn11(((([] : Array<Int>)).join("|")).substring((a16 & 7), 4), v42);
		try {
			var v44:Map<Int, Int> = ([-3 => a16, 4 => 136] : Map<Int, Int>);
			H.out("o45 " + Std.string((Std.parseInt(a17) ?? 0)));
			var v46:Bool = StringTools.endsWith("\n", "a\rb");
			if ((v46 && (v44).exists(11))) throw 90;
		} catch (ex47:Dynamic) {
			H.out("caught " + H.exn(ex47));
			if (false) {
				H.out("o48 " + Std.string(v42));
				Main.fn11(a17, a16);
				final v49 = a17;
			}
		}
		fn11(a17, fn14());
		Main.fn11("\"q\"", a16);
		switch (E0.E0B) {
			case E0A: {
				v42 += ([a17, a17]).indexOf(a17);
				switch (("q").lastIndexOf(a17)) {
					case 0: {
						var v50:E0 = E0.E0B;
					};
					case 3 | 5: {
						H.out("o51 " + Std.string(v42));
						v42 -= a16;
					};
					case _: {
						final v52 = a16;
						var v53 = a16;
					};
				}
			};
			case E0B: {
				a16 = (++a16);
			};
			case E0C(c54, _): {
				fn14();
				if ((E3.E3A).match(E3D(_))) return a16;
			};
		}
		++a16;
		try {
			var v55:Array<Int> = [v42, v42];
			try {
				var v56:String = a17;
				H.out("o57 " + Std.string(([E0.E0C(v42, a16), E0.E0B, E0.E0B] : Array<E0>)));
				if (true) throw new Err((K10.K10B : Int));
			} catch (ex58:String) {
				H.out("caught String " + ex58);
				var v59 = v42;
			} catch (ex60:Int) {
				H.out("caught Int " + ex60);
				final v61:Array<Bool> = [true, true];
				var v62:Map<Int, Bool> = new Map<Int, Bool>();
			} catch (ex63:Err) {
				H.out("caught Err " + ex63.errCode);
				Main.fn14();
				H.out("o64 " + "q");
			} catch (ex65:Dynamic) {
				H.out("caught " + H.exn(ex65));
				v42 = 207;
			}
			if ((a16 == (Std.parseInt(Std.string((-10))) ?? 0))) throw "ünï";
		} catch (ex66:Err) {
			H.out("caught Err " + ex66.errCode);
			switch (0x7FFFFFFF) {
				case 0: {
					var v67 = a17;
					H.out("o68 " + Std.string(({x9: a16} : S8)));
				};
				case 2 | 4: {
					H.out("o69 " + Std.string(v42));
					var v70 = a16;
				};
				case _: {
					Main.fn11(a17, v42);
				};
			}
			v42 = H.id(v42);
		} catch (ex71:haxe.Exception) {
			H.out("caught " + H.exn(ex71));
			v42 = 1947162107;
			v42 = (([] : Array<String>)).length;
		}
		return ((v42 % H.nz(("\"q\"").length)) - Reflect.compare((a16--), a16));
	}
	public static function fn18():String {
		H.tick();
		final v72:Bool = false;
		var v73:Int = (switch ("abc") {
			case "a" | "b": (([] : Array<Int>)).indexOf((-1967788572));
			case "Haxe": ("\u{1F600}").indexOf("0");
			case _: 0xFFFFFFFF;
		});
		var v74:String = "\"q\"";
		var v75:Map<String, Map<Int, String>> = new Map<String, Map<Int, String>>();
		var v76:Map<String, Int> = (cast (new Map<String, Int>()) : Map<String, Int>);
		var v77 = (-(([] : Array<Bool>)).length);
		var v78:Map<Int, Int> = new Map<Int, Int>();
		var v79:Int = v73;
		return "a\rb";
	}
	public static function fn19(a20:Int, a21:String):Void {
		H.tick();
		{ var dyn80:Dynamic = ({x9: (({x9: a20} : S8)).x9} : S8); H.out("dyn " + Std.string(dyn80.x9) + " " + Std.string(Reflect.field(dyn80, "x9"))); }
		switch (E0.E0C((-848669239), a20)) {
			case E0A: {
				if ((E0.E0A).match(E0A)) {
					fn18();
				} else {
					var v81:Null<Int> = a20;
				}
				fn15(a20, "zz");
			};
			case E0B: {
				H.out("o82 " + Std.string(a20));
			};
			case E0C(c83, c84) if (c83 > 3): {
				fn18();
			};
			case _: {
				var v85:S8 = ({x9: a20} : S8);
			};
		}
		final v86:Map<Int, Bool> = (cast (([-3 => true] : Map<Int, Bool>)) : Map<Int, Bool>);
		var v87:Array<Int> = ([] : Array<Int>);
		H.out("o88 " + Std.string(([({x9: 28} : S8)] : Array<S8>)));
	}
	public static function fn22(a23:Null<Int>, a24:Bool):Map<String, Int> {
		H.tick();
		final v89 = Main.fn14();
		if ((E3.E3D("\u{1F600}")).match(E3C(_))) {
			a24 = true;
			{
				H.out("o90 " + Std.string(a24));
			}
			var v91:E0 = E0.E0C(125, v89);
		} else {
			fn19(v89, "0");
		}
		if ((v89 >= (-7))) {
			if ((new Map<String, Int>()).exists("\t")) {
				var v92 = v89;
			}
			var v93:E3 = E3.E3A;
		}
		fn19((false ? 261 : 2109355697), "abc");
		return (["k0" => 0x2C3F, "k1" => v89] : Map<String, Int>);
	}
	public static function fn25():Int {
		H.tick();
		var v94:String = (switch ((Std.parseInt("q") ?? 0)) {
			case 0: "x,y,z";
			case 3 | 6: Std.string(245);
			case c95 if (c95 > 10): "\\";
			case _: ("abc").toLowerCase();
		});
		var v96:Int = Main.fn14();
		var v97:Map<Int, Bool> = ([-3 => StringTools.endsWith(v94, ""), 4 => ([v96, v96, v96]).contains(v96)] : Map<Int, Bool>);
		return v96;
	}
	public static function fn26(a27:Bool):E3 {
		H.tick();
		if (a27) {
			try {
				H.out("o98 " + Std.string(([E0.E0B] : Array<E0>)));
				if (a27) throw "boom";
			} catch (ex99:Err) {
				H.out("caught Err " + ex99.errCode);
				var v100:String = "a";
				final v101:Array<Int> = [243, 0xD8B5];
			} catch (ex102:haxe.Exception) {
				H.out("caught " + H.exn(ex102));
				var v103 = 0xFED2;
			}
			var v104:Map<String, Int> = new Map<String, Int>();
			var v105:Int = (-8);
		}
		var v106:Int = (("é").charCodeAt(Reflect.compare("\u{1F600}", "ab")) ?? -1);
		var v107 = (false && StringTools.contains("\"q\"", "zz"));
		switch (E0.E0B) {
			case E0A: {
				var v108 = "A-B-C";
				Main.fn18();
			};
			case _: {
				final v109:Int = v106;
			};
		}
		H.out("o110 " + Std.string(({ var v111 = Std.string(v106); 187; })));
		var v112:Array<String> = ((switch (E3.E3C(true)) {
			case E3A: ["é"];
			case E3C(_): ([] : Array<String>);
			case _: ["\u{1F600}", "\\"];
		}) : Array<String>);
		return ((v107 ? E3.E3A : (((E3.E3C(v107)).match(E3C(_)) ? E3.E3A : E3.E3A) : E3)) : E3);
	}
	public static function section0():Void {
		H.tick();
		final v113:Array<Array<String>> = ([["42", "é", "zz"], ["a\rb"], ["0", "\x41\x42"]] : Array<Array<String>>);
		var v114:E0 = E0.E0C(([124]).length, (("Haxe").charCodeAt(65535) ?? -1));
		var v115 = (4 - 0x972A);
		switch (E0.E0B) {
			case E0A: {
				final v116:E0 = E0.E0A;
			};
			case E0C(c117, _) if (c117 > 3): {
				var v118 = (Std.parseInt("\u{1F600}") ?? 0);
			};
			case _: {
				var v119:Array<E3> = ([E3.E3D("q"), E3.E3A, E3.E3A] : Array<E3>);
				Main.fn15(H.at([v115, 65535, v115], v115, 0), "");
			};
		}
		var v120:Map<Int, String> = ({ var v121 = "é"; new Map<Int, String>(); });
		var v122:S8 = ({x9: v115} : S8);
		final v123:Map<String, String> = ((false ? (["k0" => "x,y,z", "k1" => "\\", "k2" => ""] : Map<String, String>) : (["k0" => "42"] : Map<String, String>)) : Map<String, String>);
		H.out("o124 " + Std.string(({x9: 237} : S8)));
		v115 = fn25();
	}
	public static function section1():Void {
		H.tick();
		H.out("o125 " + Std.string(([142]).indexOf(Type.enumIndex(E0.E0B))));
		H.out("o126 " + StringTools.hex((136) & 0xFFFF, 4));
		fn14();
		var v127:Map<String, Int> = fn22(69, true);
		final v128:Array<Int> = ([] : Array<Int>);
		try {
			var v129:Int = ("  pad  ").length;
			H.out("o130 " + ("hello world").substr(5, 2));
			H.out("o131 " + Std.string(false));
			if ((cast (false) : Bool)) throw "boom";
		} catch (ex132:String) {
			H.out("caught String " + ex132);
			try {
				H.out("o133 " + Std.string(245));
				final v134:Int = 293;
				if (false) throw "boom";
			} catch (ex135:Dynamic) {
				H.out("caught " + H.exn(ex135));
				v127.set("k3", 0xF7B1);
				var v136:Array<Int> = v128;
			}
			H.out("o137 " + Std.string(Type.enumIndex(E3.E3D("zz"))));
		} catch (ex138:Int) {
			H.out("caught Int " + ex138);
			var v139 = Type.enumIndex(E0.E0A);
			var v140:Array<String> = ([] : Array<String>);
		} catch (ex141:Err) {
			H.out("caught Err " + ex141.errCode);
			if (false) {
				var v142:K10 = K10.K10B;
			}
			final v143:Array<Bool> = [true, false, false];
		} catch (ex144:Dynamic) {
			H.out("caught " + H.exn(ex144));
			final v145:Array<Int> = [33, 2031742998];
		}
		final v146:Null<Int> = ((switch (E0.E0B) {
			case E0A: 175;
			case E0B: 128;
			case E0C(c147, c148) if (c147 > 3): null;
			case _: null;
		}) : Null<Int>);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
