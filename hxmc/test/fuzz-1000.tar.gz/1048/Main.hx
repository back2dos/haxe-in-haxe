import H;

enum E0 {
	E0A;
	E0B;
	E0C;
	E0D;
}

enum E1 {
	E1A;
	E1B(a2:String);
	E1C(a3:Int, a4:Float);
}

enum E5 {
	E5A;
	E5B(a8:Bool, a9:Int);
	E5C;
}

typedef S10 = {x11:Int};

abstract A12(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A12, b:A12):A12
		return new A12(a.get() + b.get());

	@:op(A * B) public static function mul(a:A12, b:A12):A12
		return new A12(a.get() * b.get());

	@:op(-A) public static function neg(a:A12):A12
		return new A12(-a.get());
}

enum abstract K13(Int) to Int {
	var K13A = 1;
	var K13B = 4;
	var K13C = 7;
}

abstract class C14 {
	public final f15:Array<Int>;
	public function new(a16:Int, a17:Bool) {
		this.f15 = [292, a16];
	}
}

class C18 {
	public var f19:String;
	public final f20:String;
	public function new(a21:Int) {
		this.f19 = "x,y,z";
		this.f20 = "-7";
	}
	public function m22(a23:String):Void {
		H.tick();
		var v85 = ("-7" + (E1.E1B(a23)).match(E1A));
		var v86:Int = ({ var v87 = this.f19; 0x80000000; });
		v86 |= (switch (StringTools.contains(a23, a23)) {
			case true: 200;
			case false: 270;
		});
	}
	public function m24(a25:Box<Bool>, a26:String = "d"):Int {
		H.tick();
		H.out("o88 " + a26);
		if (((E0.E0A).match(E0A) && (([] : Array<Int>)).contains(90))) {
			var v89 = 128;
			var v90:K13 = K13.K13A;
		} else {
			Main.fn52(StringTools.hex((0x38D1) & 0xFFFF, 4));
			var v91:Array<String> = (a26).split("a");
		}
		for (i92 in 0...1) {
			H.tick();
			final v93:Map<Int, Int> = new Map<Int, Int>();
		}
		if (H.apply(Math.ceil(7.0), (v94:Int) -> ([v94]).contains(v94))) {
			for (i95 in 0...2) {
				H.tick();
				var v96:E1 = E1.E1C(i95, i95);
				var v97:Int = i95;
			}
		} else {
			Main.fn52(a26);
		}
		for (x98 in ([] : Array<String>)) {
			H.tick();
			var v99:Bool = false;
			var v100:Int = 1072872601;
			v100 = ((([-3 => v100, 4 => v100] : Map<Int, Int>)).get(11) ?? 0);
		}
		var v101:String = (a26).substring(-2, (Type.enumIndex(E5.E5B(false, 111)) & 7));
		return ((123456.789 <= Std.parseFloat(v101)) ? (switch (E1B(v101)) {
			case E1A: (([] : Array<Bool>)).indexOf(true);
			case E1B(_): (-2147483647);
			case E1C(2 | 4, _): (new A12(245)).twice;
			case _: ((([-3 => (-2147483647)] : Map<Int, Int>)).get(187) ?? 0);
		}) : (new C30(true)).m39(73));
	}
	public function m27(a28:E5):Bool {
		H.tick();
		for (k103 => x102 in (([2.5e-3, (-2.5)] : Array<Float>)).concat(([] : Array<Float>))) {
			H.tick();
			var v104:Array<String> = ["a", "A-B-C"];
			for (k106 => x105 in ([] : Array<Int>)) {
				H.tick();
				H.out("o107 " + Std.string(E0.E0B));
				var v108:Map<String, String> = (["k0" => "  pad  "] : Map<String, String>);
				H.out("o109 " + "42");
			}
			var v110:Map<String, String> = new Map<String, String>();
		}
		if (((E1C(179, 1e-7)).match(E1B(_)) && (new Map<Int, Int>()).exists(11))) return (switch (({x11: 10} : S10)) {
			case {x11: 1 | 2}: true;
			case {x11: c111}: true;
		});
		var v112:Bool = (Reflect.compare(155, 132) != 21);
		H.out("o113 " + Std.string(E1C(Math.round(2.5e-3), 178)));
		H.out("o114 " + Std.string(E5.E5B((a28).match(E5A), H.at([213, 159], 1679162657, 0))));
		return (E5B(v112, (([5e-324, 0.30000000000000004] : Array<Float>)).length)).match(E5C);
	}
	public function m29():Bool {
		H.tick();
		var v115:E1 = E1.E1C((["\t", ""]).indexOf("abc"), Math.PI);
		final v116:Array<Bool> = H.apply((Std.parseInt("42") ?? 0), (v117:Int) -> [true, true, true]);
		Main.fn67(0x6B4F);
		switch (E5.E5A) {
			case E5A: {
				function lf118(n119:Int):Int {
					H.tick();
					return n119 <= 0 ? n119 : (lf118(n119 - 1) + ((new Map<String, Int>()).get("k1") ?? 0));
				}
				H.out("lf118 " + lf118(3));
				for (x120 in [65535, 0x7FFFFFFF]) {
					H.tick();
					H.out("o121 " + Std.string(new Box(183)));
					var v122:E1 = v115;
					Main.fn67(x120);
				}
			};
			case E5C: {
				H.out("o123 " + Std.string(new C30(false)));
				var v124:E5 = E5B(true, 115);
			};
			case _: {
				for (i125 in 2...4) {
					H.tick();
					H.out("o126 " + Std.string(({x11: i125} : S10)));
					var v127:S10 = ({x11: 0x7FFFFFFF} : S10);
					if (true) continue;
				}
			};
		}
		final v128 = (["a"]).join(" ");
		H.out("o129 " + Std.string((({ var v130 = ("a").toLowerCase(); new A12(281); }) : Int)));
		return (true ? ((["k0" => new C30(false), "k1" => new C30(true), "k2" => new C30(false)] : Map<String, C30>)).exists(Std.string(174)) : !true);
	}
}

class C30 {
	public var f31:Int;
	public var f32:Array<Float>;
	public function new(a33:Bool) {
		this.f31 = 218;
		this.f32 = ([] : Array<Float>);
	}
	public function m34():Void {
		H.tick();
		if (Std.isOfType(new C49(), C49)) {
			H.out("o131 " + ("\"q\"").substr(6, 0));
			for (i132 in 0...H.lim(171)) {
				H.tick();
				H.out("o133 " + Std.string(i132));
			}
			var v134:String = Std.string(false);
		}
		this.f31 = H.id(this.f31);
		H.out("o135 " + Std.string(((E5B(true, 65535)).match(E5B(_, _)) && (E0D).match(E0C))));
		(new C30(true)).m39(Main.fn52(StringTools.replace("\t", "a", "\t")));
		H.out("o136 " + Std.string(((false ? E0A : E0D) : E0)));
	}
	public function m35(a36:String, a37:E0, ...r38:Int):Void {
		H.tick();
		H.out("o137 " + Std.string(({ var v138 = 171; v138; })));
		(H.id(new C18(0xEDE8))).m27((((Std.downcast((new C44(true) : C44), C44) != null) ? E5C : E5B(false, 227)) : E5));
		var v139 = (Std.string(E5.E5C) + 134);
		final v140 = (65535 + H.at(r38.toArray(), 285170851, 0));
		var w141 = 0;
while (w141 < 2 && true) {
			w141++;
			H.tick();
			var v142 = (("A-B-C").charCodeAt(v140) ?? -1);
		}
		for (k143 => v144 in new Map<String, Int>()) {
			H.tick();
			this.f31 = v140;
		}
	}
	public function m39(a40:Int):Int {
		H.tick();
		for (i145 in 1...4) {
			H.tick();
			H.out("o146 " + Std.string(false));
		}
		final v147:Map<String, Int> = new Map<String, Int>();
		switch (E5.E5C) {
			case E5A: {
				var v148:S10 = ({x11: 268} : S10);
				H.out("o149 " + Std.string(true));
			};
			case E5B(c150, _): {
				for (i151 in 0...H.lim(a40)) {
					H.tick();
					v147.set("k3", a40);
					(new C18(i151)).m27(E5B(c150, i151));
					var v152:Map<String, A12> = (["k0" => new A12(i151), "k1" => new A12(i151)] : Map<String, A12>);
				}
				var v153:Map<String, String> = new Map<String, String>();
			};
			case _: {
				if (true) {
					var v154 = false;
					var v155:E0 = E0C;
					(new C18(a40)).m27(E5.E5A);
				} else {
					this.f31 &= a40;
					this.f31 = 72;
				}
			};
		}
		final v156:Float = (a40 - a40);
		var v157:Float = a40;
		var v158:C18 = new C18(this.f31);
		v147.remove("k2");
		return ((("42").charCodeAt(Type.enumIndex(E1.E1B("A-B-C"))) ?? -1) & (a40 ^ (('$$').charCodeAt(a40) ?? -1)));
	}
	public function m41(a42:Int, a43:Int):String {
		H.tick();
		(new C18((new A12(264)).twice)).m29();
		(new C18(295)).m22(Std.string((K13.K13C : Int)));
		for (x159 in ([Std.parseFloat("3"), a42] : Array<Float>)) {
			H.tick();
			H.out("o160 " + Std.string((({x11: a42} : S10)).x11));
			function lf161(n162:Int):Int {
				H.tick();
				return n162 <= 0 ? n162 : (lf161(n162 - 1) + a42);
			}
			H.out("lf161 " + lf161(2));
		}
		for (x163 in (((E0D).match(E0A) ? [214, 145] : [a42, 176, 146]) : Array<Int>)) {
			H.tick();
			H.out("o164 " + Std.string((new A12(158) : Int)));
		}
		return "\"q\"";
	}
}

class C44 {
	public function new(a45:Bool) {}
	public function m46(a47:String, a48:Array<Int>):Float {
		H.tick();
		var v165:Map<Int, String> = ({ var v166 = (a47).substr(5, (138 & 7)); new Map<Int, String>(); });
		var v167 = (K13.K13A : Int);
		var v168 = (Std.string(E0.E0A)).toLowerCase();
		var v169 = (switch (v168) {
			case "a" | "b": (a47).indexOf(v168);
			case "Haxe": (a47).length;
			case _: v167;
		});
		for (i170 in 2...H.lim((v167 ^ ((v168).charCodeAt(65535) ?? -1)))) {
			H.tick();
			switch (a47) {
				case "a" | "b": {
					var v171:A12 = (i170 : A12);
					var v172:Int = 67;
				};
				case "Haxe": {
					var v173:Float = v169;
					var v174:String = "0";
				};
				case _: {
					v169 = (-1018513590);
				};
			}
		}
		H.out("o175 " + Std.string(({x11: (a48).indexOf(260)} : S10)));
		return Math.sqrt(Math.abs(((v168).indexOf("") + v167)));
	}
}

class C49 {
	public var f50:A12;
	public var f51:String;
	public function new() {
		this.f50 = new A12((-937220031));
		this.f51 = "0";
	}
}

class Main {
	public static function fn52(a53:String, ?a54:Null<Int>):Int {
		H.tick();
		var v176:E0 = E0.E0D;
		var v177:S10 = ({x11: ((a53).charCodeAt(524849500) ?? -1)} : S10);
		var v178:Array<Int> = (((E1A).match(E1A) ? [812998862, 0x69FF, 128] : [(-823053967), 50, (-3)]) : Array<Int>);
		return Reflect.compare(("" + StringTools.replace("\n", " ", a53)), a53);
	}
	public static inline function fn55(a56:String, a57:Array<Int>, a58:E1):Bool {
		H.tick();
		var v179:Float = Math.max(220, 7.0);
		var v180:Float = (3.0 * v179);
		if (((["k0" => new A12(0x80000000), "k1" => (0xD1EB : A12)] : Map<String, A12>)).exists(Std.string(v179))) {
			H.out("o181 " + Std.string(new C44(false)));
			(new C18(95)).m27(E5.E5A);
		} else {
			var v182:Map<Int, String> = ([-3 => "q", 4 => "zz"] : Map<Int, String>);
		}
		return false;
	}
	public static function fn59(a60:Int, a61:String, a62:Bool):Bool {
		H.tick();
		switch (E0D) {
			case E0A: {
				var v183:Array<Int> = [a60];
			};
			case E0B: {
				switch ((--a60)) {
					case 0: {
						H.out("o184 " + Std.string(1e100));
						var v185:Array<Float> = ([a60, a60, 2.5e-3] : Array<Float>);
					};
					case 2 | 6: {
						final v186:String = "abc";
						var v187 = 118;
					};
					case _: {
						H.out("o188 " + a61);
					};
				}
				a60 <<= (a60 & 7);
			};
			case _: {
				a60 ^= a60;
			};
		}
		a60 = H.id(a60);
		switch (E5B(a62, 65)) {
			case E5A: {
				a60 &= a60;
				var v189:String = a61;
			};
			case E5B(c190, 2 | 4): {
				a60 *= ((a60 : A12)).get();
			};
			case _: {
				var v191:Array<Bool> = [false, true];
				final v192:Array<Map<Int, E1>> = ([new Map<Int, E1>()] : Array<Map<Int, E1>>);
			};
		}
		if (a62) return a62;
		Main.fn52(H.id(Std.string(E1B(a61))));
		a60 = (new C30(a62)).m39(a60);
		if (a62) return (100.75 > a60);
		return (({ var v193 = ([a60, 125, 289]).contains(a60); false; }) || !a62);
	}
	public static inline function fn63(a64:Int, a65:Int, a66:Bool = true):Bool {
		H.tick();
		H.out("o194 " + Std.string(E5.E5A));
		final lf195:(Bool) -> Void = function(p196:Bool):Void {
			H.tick();
			var w197 = 0;
do {
				w197++;
				H.tick();
				H.out("o198 " + Std.string(a64));
			} while (w197 < 4 && true);
			var w199 = 0;
while (w199 < 3 && (E5.E5C).match(E5C)) {
				w199++;
				H.tick();
				final v200:Array<Float> = ([] : Array<Float>);
				H.out("o201 " + "hello world");
			}
		};
		for (i202 in 0...H.lim(fn52("\n"))) {
			H.tick();
			a64 = Math.floor(a64);
		}
		final v203:Map<Int, Bool> = new Map<Int, Bool>();
		final v204:Array<Int> = [a64, (K13.K13C : Int), (--a65)];
		return fn59((K13.K13B : Int), (Std.string(a65)).toUpperCase(), !a66);
	}
	public static function fn67(a68:Int):Bool {
		H.tick();
		H.out("o205 " + Std.string(new C18((new A12(113)).twice)));
		var v206:S10 = ((switch (E1A) {
			case E1A: ({x11: a68} : S10);
			case E1B(c207): ({x11: 0x4827} : S10);
			case E1C(_, c208): ({x11: a68} : S10);
			case _: ({x11: a68} : S10);
		}) : S10);
		for (i209 in 0...H.lim((([true]).indexOf(true) % H.nz((("\n").charCodeAt(a68) ?? -1))))) {
			H.tick();
			var v210:Map<String, C49> = (["k0" => new C49(), "k1" => new C49()] : Map<String, C49>);
			if (true) {
				H.out("o211 " + Std.string(a68));
				a68 |= a68;
			}
			var v212:Array<String> = ["\n", "42", '$$'];
		}
		for (x213 in (([] : Array<Bool>)).concat(([] : Array<Bool>))) {
			H.tick();
			if (true) {
				H.out("o214 " + Std.string(v206));
				var v215 = 0xAD31;
			} else {
				var v216:Array<Float> = ([3.0, a68, a68] : Array<Float>);
			}
			final lf217:() -> Void = function():Void {
				H.tick();
				a68 ^= a68;
			};
		}
		a68 += a68;
		{
			var v218:Array<String> = ["A-B-C", "42", "\t"];
			final v219:S10 = ({x11: 290} : S10);
		}
		if (({ var v220 = (([] : Array<Int>)).indexOf(a68); false; })) {
			switch (E0.E0C) {
				case E0A: {
					H.out("o221 " + Std.string(0x7FFFFFFF));
					H.out("o222 " + Std.string(([K13.K13B, K13.K13C] : Array<K13>)));
				};
				case E0B: {
					var v223:String = "zz";
				};
				case E0C: {
					a68 = 0x7FFFFFFF;
					a68 |= 65535;
				};
				case _: {
					H.out("o224 " + Std.string(a68));
					var v225:Int = 65535;
				};
			}
			var v226:A12 = new A12(0xAEC4);
			a68 *= (("abc").charCodeAt(262) ?? -1);
		}
		var w227 = 0;
do {
			w227++;
			H.tick();
			if ((([-3 => 239, 4 => a68] : Map<Int, Int>)).exists(4)) {
				var v228:Map<String, Array<String>> = (["k0" => ["abc"]] : Map<String, Array<String>>);
			} else {
				final v229:Array<Int> = [a68];
				var v230:E0 = E0A;
			}
			if (true) {
				var v231:Int = 41;
			}
		} while (w227 < 2 && (true && (E0D).match(E0A)));
		return true;
	}
	public static function fn69():Bool {
		H.tick();
		var v232:Float = 123456.789;
		if (([199, 124, 132]).contains((([] : Array<Int>)).indexOf(201))) {
			Main.fn59(H.at(([] : Array<Int>), 93, 0), StringTools.replace("q", ",", "0"), false);
		}
		var v233:Float = 0x3487;
		for (i234 in 0...4) {
			H.tick();
			var v235:E0 = E0C;
			for (k236 => v237 in (["k0" => i234, "k1" => i234] : Map<String, Int>)) {
				H.tick();
				var v238:E1 = E1A;
				H.out("o239 " + Std.string(E5C));
			}
		}
		if ((new C18(82)).m29()) {
			var v240:Map<Int, Int> = new Map<Int, Int>();
			H.out("o241 " + Std.string(21));
		}
		return StringTools.endsWith("q", "-7");
	}
	public static function fn70(a71:K13, a72:Int):Int {
		H.tick();
		(new C18(67)).m24((((([-3 => new A12(a72)] : Map<Int, A12>)).exists(18) ? new Box(false) : new Box(false)) : Box<Bool>));
		for (i242 in 2...H.lim(74)) {
			H.tick();
			a72 <<= (a72 & 7);
			var v243 = i242;
			final lf244:() -> Int = () -> 79;
		}
		for (i245 in 0...3) {
			H.tick();
			a72 = ((new Map<Int, Int>()).get(11) ?? 0);
			H.out("o246 " + Std.string(("\n").indexOf("abc")));
			a72 |= i245;
		}
		var v247:C49 = new C49();
		var v248:S10 = ({x11: (Std.parseInt(Std.string(a72)) ?? 0)} : S10);
		return a72;
	}
	public static function fn73():Int {
		H.tick();
		{
			final lf249:() -> Int = () -> (new A12(0x8468)).twice;
			if (false) {
				var v250:C44 = new C44(true);
			}
			var v251:Int = Reflect.compare("0", "\n");
		}
		final v252:Float = fn70(K13.K13A, (-396963544));
		(new C18(((0x80000000 : A12)).get())).m27(E5.E5B(true, Type.enumIndex(E1A)));
		var v253:Array<Box<S10>> = ([for (i254 in [106, 210]) if (StringTools.endsWith("A-B-C", "\\")) new Box<S10>(({x11: 12} : S10))] : Array<Box<S10>>);
		var v255 = (new C30(false)).m41((Std.parseInt("0") ?? 0), Math.floor(v252));
		return 5;
	}
	public static function fn74(a75:String, a76:String, a77:Int):Float {
		H.tick();
		a77 = H.id(a77);
		Main.fn55(a75, [for (i256 in 0...2) a77], E1.E1A);
		switch ((a77 + a77)) {
			case 0: {
				if (true) {
					a77 *= a77;
					H.out("o257 " + "\\");
				}
			};
			case 1 | 6: {
				var v258:S10 = ({x11: a77} : S10);
			};
			case c259 if (c259 > 10): {
				Main.fn59((a75).lastIndexOf("a"), (a75).toLowerCase(), StringTools.endsWith(a76, a75));
				var v260:Array<String> = ([] : Array<String>);
			};
			case _: {
				final v261:Box<String> = new Box("Haxe");
			};
		}
		H.out("o262 " + Std.string(true));
		var v263:Bool = (a77 < a77);
		return ((Main.fn55(a76, [204, a77], E1C(a77, a77)) ? (2.5e-3 / a77) : a77) : Float);
	}
	public static function fn78(?a79:Null<Int>):Int {
		H.tick();
		if ((switch (H.id(([] : Array<Int>))) {
			case []: false;
			case [c264]: (E5.E5B(true, c264)).match(E5A);
			case [_, c265]: false;
			case _: false;
		})) {
			H.out("o266 " + String.fromCharCode(65 + ((129) & 15)));
			final v267:Array<Int> = ([] : Array<Int>);
		}
		H.out("o268 " + Std.string((Std.string(3.0) == ([89]).join(" "))));
		var v269:Box<C18> = new Box<C18>(new C18(0x7FFFFFFF));
		for (i270 in 1...5) {
			H.tick();
			if ((E1.E1B("\t")).match(E1A)) {
				(new C18(i270)).m22("zz");
				var v271:Map<Int, C30> = new Map<Int, C30>();
				var v272:Int = i270;
			} else {
				H.out("o273 " + Std.string(i270));
			}
			fn69();
		}
		var v274:Float = (0x984E / Std.parseFloat("3"));
		fn73();
		if (fn55("a", [192], E1B("\t"))) {
			if (false) {
				var v275:E5 = E5.E5C;
			} else {
				var v276:Float = (-2.5);
				var v277 = 0x80000000;
			}
			for (i278 in 2...H.lim(H.at(([] : Array<Int>), 77, 0))) {
				H.tick();
				fn59(i278, "abc", false);
				var v279:Array<Int> = ([] : Array<Int>);
				var v280:Float = i278;
			}
			for (i281 in 0...2) {
				H.tick();
				final v282:Float = (-2.5);
			}
		}
		Main.fn67((226 ^ ("x,y,z").lastIndexOf("\n")));
		return 23;
	}
	public static function fn80(a81:Int):Bool {
		H.tick();
		var v283:Array<Float> = ((StringTools.startsWith("", "0") ? ([1e100, a81] : Array<Float>) : ([a81] : Array<Float>)) : Array<Float>);
		if (Std.isOfType(new C18(a81), C18)) {
			(new C18(a81)).m27(E5B(true, a81));
			switch (E1B("42")) {
				case E1A: {
					var v284:Float = 0.1;
				};
				case E1B(c285): {
					fn78();
					a81 = H.id(a81);
				};
				case E1C(c286, c287): {
					H.out("o288 " + Std.string((K13.K13B : Int)));
					var v289:E0 = E0.E0A;
				};
			}
		} else {
			var v290:Box<Int> = new Box(35);
			(new C30(false)).m34();
		}
		var v291 = StringTools.trim("\n");
		switch (E0.E0A) {
			case E0A: {
				var v292:Map<String, Int> = (["k0" => a81] : Map<String, Int>);
			};
			case E0B: {
				switch (E5.E5A) {
					case E5A: {
						(new C18(a81)).m29();
					};
					case E5C: {
						a81 ^= a81;
					};
					case _: {
						(new C30(false)).m34();
					};
				}
				var v293:Map<Int, Int> = ([-3 => a81, 4 => a81] : Map<Int, Int>);
			};
			case E0C: {
				H.out("o294 " + String.fromCharCode(65 + ((135) & 15)));
			};
			case E0D: {
				switch (K13.K13C) {
					case K13.K13A: {
						var v295:Array<String> = [v291, v291];
					};
					case K13.K13B: {
						var v296:Map<String, Int> = new Map<String, Int>();
						Main.fn78();
					};
					case K13.K13C: {
						H.out("o297 " + Std.string([a81, 0x80000000, 263]));
						(new C30(true)).m39(a81);
					};
				}
				H.out("o298 " + Std.string(new Box<K13>(K13.K13B)));
			};
		}
		v283.push((new C30(true)).m39(((a81 : A12) : Int)));
		if (false) {
			function lf299(n300:Int):Int {
				H.tick();
				return n300 <= 0 ? 215 : (lf299(n300 - 1) + Type.enumIndex(E0A));
			}
			H.out("lf299 " + lf299(3));
			var v301 = Math.round(123456.789);
		}
		if ((Math.PI < 65535)) {
			final v302:C30 = new C30(true);
		}
		var v303 = Main.fn73();
		var w304 = 0;
while (w304 < 4 && H.id(true)) {
			w304++;
			H.tick();
			var w305 = 0;
while (w305 < 1 && ([a81]).contains(v303)) {
				w305++;
				H.tick();
				H.out("o306 " + Std.string(a81));
				H.out("o307 " + Std.string(a81));
				final v308 = 94;
			}
			var v309:String = ("abc").substr((a81 & 7), (v303 & 7));
		}
		return StringTools.startsWith("hello world", (new C30(true)).m41(v303, a81));
	}
	public static function fn82(a83:Bool, a84:Bool):Int {
		H.tick();
		var v310:Int = (new C18(0x5005)).m24(new Box(true), "  pad  ");
		final v311 = (295 >= v310);
		var v312 = (new C30(a83)).m41(("ab").length, (v310 = 5));
		var v313:Bool = (a83 && false);
		final v314:Float = 100.75;
		H.out("o315 " + v312);
		var v316 = Std.string(Math.ceil(v314));
		return ((([v310, 2.5e-3, 123456.789] : Array<Float>)).length * (v310 - v310));
	}
	public static function section0():Void {
		H.tick();
		switch ((String.fromCharCode(65 + ((8) & 15))).toUpperCase()) {
			case "a" | "b": {
				var v317:S10 = ({x11: 42} : S10);
			};
			case "Haxe": {
				(new C30(true)).m34();
				(new C18(79)).m22(("zz").substring((25 & 7), (14 & 7)));
			};
			case "": {
				var v318:E5 = E5B(true, 0x80000000);
				{ var dyn319:Dynamic = ({x11: 290} : S10); H.out("dyn " + Std.string(dyn319.x11) + " " + Std.string(Reflect.field(dyn319, "x11"))); }
			};
			case _: {
				final v320:Int = (["a", "x,y,z"]).indexOf("\n");
				var v321:C18 = new C18(v320);
			};
		}
		var v322 = "0";
		for (i323 in 0...H.lim((new Box<Int>(14)).get())) {
			H.tick();
			var v324 = v322;
			if (([(-1189288988)]).contains(i323)) {
				H.out("o325 " + Std.string([v324, "\\", v324]));
			} else {
				var v326:Array<Int> = [i323];
			}
			switch ((-643377025)) {
				case 0: {
					var v327:String = v324;
					Main.fn73();
				};
				case 1 | 5: {
					(new C18(i323)).m29();
				};
				case _: {
					final v328:Bool = false;
				};
			}
		}
		var v329:K13 = K13.K13B;
		var v330 = Std.string(E1A);
		var v331:C44 = new C44(true);
		final v332:Array<Int> = [((v330).split("a")).indexOf("a"), 210, ("  pad  ").indexOf(v322)];
		var v333:C44 = ((false ? v331 : new C44(true)) : C44);
		H.out("o334 " + Std.string(0xD90B));
	}
	public static function section1():Void {
		H.tick();
		H.out("o335 " + Std.string(0.30000000000000004));
		for (i336 in 0...1) {
			H.tick();
			for (i337 in 1...5) {
				H.tick();
				H.out("o338 " + "a");
				final v339:Float = 2.5e-3;
				var v340:S10 = ({x11: i336} : S10);
			}
		}
		var v341 = (Reflect.compare(77, 222) >> (208 & 31));
		for (k343 => x342 in ["42"]) {
			H.tick();
			v341 = Math.ceil(v341);
		}
		Main.fn74(("hello world").charAt(4), (switch (({x11: 272} : S10)) {
			case {x11: 1 | 2}: StringTools.lpad("0", "*", (v341 & 7));
			case {x11: c344}: ("hello world").toUpperCase();
		}), ({ var v345 = (-2.5); ((new Map<Int, Int>()).get(v341) ?? 0); }));
	}
	public static function section2():Void {
		H.tick();
		var w346 = 0;
while (w346 < 5 && ((([-3 => 27] : Map<Int, Int>)).exists(18) ? StringTools.startsWith("", "\"q\"") : ([202]).contains(285))) {
			w346++;
			H.tick();
			var v347 = ([9]).indexOf(70);
			v347 = H.id(v347);
			if ((new Map<Int, String>()).exists(4)) {
				final v348:String = "a";
				fn59(v347, v348, false);
				var v349:E1 = E1B(v348);
			}
		}
		final v350:Float = 1.25;
		var v351 = (new C18(219)).m24(new Box(true), Std.string(0xB38A));
		var v352:Bool = (v351 >= 7.0);
		var v353:Array<String> = ((false ? ("a").split("a") : ("-7").split(",")) : Array<String>);
	}
	public static function section3():Void {
		H.tick();
		final v354:C44 = new C44(false);
		var v355:Int = 253;
		{
			v355 = ([true, false, true]).indexOf(false);
		}
		for (i356 in 0...H.lim(v355)) {
			H.tick();
			var v357:String = StringTools.replace("\t", ",", "ab");
			if (Std.isOfType(new C49(), C49)) {
				H.out("o358 " + Std.string(true));
			} else {
				H.out("o359 " + Std.string(v355));
				H.out("o360 " + Std.string(v355));
			}
			for (i361 in 0...H.lim((({x11: i356} : S10)).x11)) {
				H.tick();
				var v362 = (-1);
				H.out("o363 " + Std.string(v362));
				v355 = v362;
			}
		}
		H.out("o364 " + Std.string(((["k0" => v355, "k1" => (-2.5), "k2" => v355] : Map<String, Float>)).exists("k3")));
		H.out("o365 " + Std.string(E0B));
		H.out("o366 " + Std.string(((v355 : A12) : Int)));
		var v367 = (switch (Type.enumIndex(E1.E1B("a"))) {
			case 0: Std.string(E5A);
			case 3 | 6: ('$$').toLowerCase();
			case _: StringTools.trim("A-B-C");
		});
		v355 = H.id(v355);
	}
	public static function section4():Void {
		H.tick();
		var v368 = Std.string(E0.E0A);
		for (i369 in 0...4) {
			H.tick();
			var w370 = 0;
while (w370 < 5 && (Std.downcast((null : C14), C14) != null)) {
				w370++;
				H.tick();
				(new C18(i369)).m24(new Box<Bool>(true));
				H.out("o371 " + Std.string(i369));
			}
			switch (E1B(v368)) {
				case E1A: {
					(new C18(i369)).m29();
					Main.fn73();
				};
				case E1B(c372): {
					var v373:C30 = new C30(false);
				};
				case _: {
					fn63(i369, (-2), false);
				};
			}
			H.out("o374 " + Std.string(E5A));
		}
		var w375 = 0;
do {
			w375++;
			H.tick();
			var v376:Array<String> = ["-7", v368];
		} while (w375 < 1 && true);
		H.out("o377 " + Std.string(240));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
