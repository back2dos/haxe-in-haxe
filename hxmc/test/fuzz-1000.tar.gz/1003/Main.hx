import H;
import p.M1;
using p.Ext;

typedef S3 = {x4:Float};

class C15 implements I7 {
	var _f16:Int;

	public var f16(get, set):Int;

	function get_f16():Int
		return _f16;

	function set_f16(v:Int):Int
		return _f16 = v;
	public function new() {
		this._f16 = Lambda.fold(([] : Array<Int>), (v119:Int, v120:Int) -> Lambda.fold(([] : Array<Int>), (v121:Int, v122:Int) -> ((47 : A5) : Int), 0), 0);
	}
	public function m8():Float {
		H.tick();
		if ((1e3 <= this.f16)) {
			H.out("o123 " + Std.string((K6.K6B : Int)));
			for (i124 in 0...2) {
				H.tick();
				(new C9()).m12(i124);
				this.f16--;
				this.f16 = i124;
			}
			H.out("o125 " + Std.string(this.f16));
		} else {
			var v126:K6 = K6.K6A;
			Ext.ext54(Math.round((-2.5)));
		}
		(new C9()).m11();
		final lf127:(Int) -> Int = (p128:Int) -> Ext.ext57(this.f16, 150);
		var v129:I7 = new C9();
		if (Main.fn17(this.f16, v129, 255, 293)) {
			final lf130:(Int) -> Int = function(p131:Int):Int {
				H.tick();
				Main.fn29(K6.K6B, true, p131);
				final v132:C15 = new C15();
				return p131;
			};
			if (Math.isNaN(0.5)) {
				v129 = H.id(v129);
				var v133:S0 = ({x1: 62, x2: (-1273344482)} : S0);
				this.f16 *= 282;
			} else {
				this.f16 *= 0x80000000;
				var v134:K6 = K6.K6B;
			}
			var v135:Int = 231;
		} else {
			if (true) {
				var v136:Box<Float> = new Box<Float>(7.0);
				this.f16 = (-16);
				this.f16 *= 549259560;
			} else {
				var v137:Int = 0x7FFFFFFF;
			}
		}
		var v138:C15 = new C15();
		if (Main.fn17(288, new C15(), (new A5(108)).get(), (new A5(106)).get())) {
			switch (0x86F9) {
				case 0: {
					(new C9()).m11();
				};
				case 3 | 6: {
					final v139:(Int) -> Void = function(p140:Int):Void {
						H.tick();
						var v141:S0 = ({x1: p140, x2: p140} : S0);
					};
				};
				case _: {
					var v142 = (-2097161614);
					(new C9()).m12(v142);
				};
			}
			++this.f16;
		} else {
			var v143 = 138;
			final lf144:(Int) -> Float = function(p145:Int):Float {
				H.tick();
				H.out("o146 " + Std.string(p145));
				H.out("o147 " + Std.string(({x1: 138279745, x2: p145} : S0)));
				return (-10);
			};
		}
		return Math.min((1e21 * 0x4512), 1012383825);
	}
}

class Main {
	public static function fn17(a18:Int, a19:I7, a20:Int, ...r21:Int):Bool {
		H.tick();
		var v148:Null<Int> = a20;
		var w149 = 0;
while (w149 < 4 && (Math.isNaN(a20) ? true : Math.isNaN(a20))) {
			w149++;
			H.tick();
			final v150:Float = 123456.789;
		}
		var v151:K6 = K6.K6A;
		a18 *= 185;
		var v152:Int = (new C9()).m11();
		v152 *= Math.round(0.5);
		if (true) return (true ? false : true);
		(new C9()).m11();
		if (false) {
			final v153:Int = a20;
		}
		return ((true ? 52 : a18) < v152);
	}
	public static function fn22(a23:Int, a24:A5, a25:Bool):Void {
		H.tick();
		H.out("o154 " + Std.string((new Box<Bool>(a25)).get()));
		final v155 = a23;
		try {
			switch (v155) {
				case 0: {
					final v156:S0 = ({x1: 65535, x2: v155} : S0);
					var v157:A5 = new A5(0x21D6);
				};
				case 2 | 4: {
					H.out("o158 " + Std.string(58));
				};
				case _: {
					fn17(a23, new C9(), 0x3C3E, v155);
				};
			}
			var v159:C15 = new C15();
			if (false) {
				a23 += 0x6136;
				(new C9()).m12(0x9B43);
			}
			if ((false || a25)) throw new Err(0x8066);
		} catch (ex160:Dynamic) {
			H.out("caught " + H.exn(ex160));
			H.out("o161 " + Std.string(a23));
			H.out("o162 " + Std.string(v155));
		}
		var w163 = 0;
do {
			w163++;
			H.tick();
			H.out("o164 " + Std.string((new A5(a23) : Int)));
		} while (w163 < 2 && ((Std.parseInt(Std.string(a23)) ?? 0) >= (({x1: v155, x2: a23} : S0)).x1));
		var v165 = (-v155);
		a23 -= (switch (K6.K6D) {
			case K6.K6A: v155;
			case K6.K6B: a23;
			case K6.K6C: (new A5((-9))).twice;
			case K6.K6D: v165;
		});
		Main.fn17(v165, H.apply(Std.string(2.5e-3), (v166:String) -> new C15()), (-685543586), 157);
		var v167 = 20;
	}
	public static inline function fn26(a27:Float, a28:Int):Void {
		H.tick();
		a28 -= a28;
		final lf168:(Int) -> Int = (p169:Int) -> (-1426618433);
		if (!true) {
			final v170 = (-9);
		} else {
			H.out("o171 " + Std.string(({x4: a28} : S3)));
		}
		var v172:Bool = Math.isNaN(a28);
	}
	public static inline function fn29(a30:K6, a31:Bool, a32:Float):Int {
		H.tick();
		H.out("o173 " + Std.string(a32));
		var w174 = 0;
while (w174 < 1 && (237 < Reflect.compare(139, 252))) {
			w174++;
			H.tick();
			(new C9()).m11();
		}
		switch ((false || a31)) {
			case true: {
				var v175 = Std.int(a32);
			};
			case false: {
				final v176:() -> Bool = () -> false;
				if (Std.isOfType(new C9(), I7)) {
					final v177:S0 = ({x1: 90, x2: 0x6BDB} : S0);
					var v178 = 109;
					H.out("o179 " + Std.string(new C15()));
				}
			};
		}
		var v180:S0 = ({x1: Math.round(a32), x2: Reflect.compare(251, 197)} : S0);
		fn22((switch ((new A5(0xABA1) : Int)) {
			case 0: 49;
			case 3 | 5: (Std.parseInt(Std.string(145)) ?? 0);
			case _: Math.ceil(a32);
		}), ((false ? new A5(55) : (239 : A5)) : A5), fn17((-67413527), new C9(), (v180).x2, (new A5((-522199438)) : Int)));
		H.out("o181 " + Std.string(Math.min(0.1, Math.PI)));
		return (-525823692);
	}
	public static function fn33(...r34:Int):Float {
		H.tick();
		var v182 = false;
		fn26(3.0, Math.round(1e21));
		H.out("o183 " + Std.string(Main.fn29(K6.K6C, Std.isOfType(new C15(), C15), Math.PI)));
		H.out("o184 " + Std.string(v182));
		var v185:Bool = (cast (true) : Bool);
		final v186:K6 = K6.K6B;
		H.out("o187 " + Std.string((v185 && v182)));
		var v188:A5 = new A5(Lambda.count(r34.toArray(), v189 -> (Std.downcast((new C15() : C15), C15) != null)));
		function lf190(n191:Int):Int {
			H.tick();
			return n191 <= 0 ? (236 * n191) : (lf190(n191 - 1) + 110);
		}
		H.out("lf190 " + lf190(3));
		return Math.PI;
	}
	public static function fn35():Float {
		H.tick();
		for (i192 in 0...H.lim((if (Std.isOfType(new C9(), I7)) Math.ceil(3.0) else 0xFFFFFFFF))) {
			H.tick();
			var v193:A5 = new A5(i192);
			H.out("o194 " + Std.string(Lambda.count([i192], v195 -> false)));
		}
		var w196 = 0;
while (w196 < 4 && (true && false)) {
			w196++;
			H.tick();
			Ext.ext54(83);
			for (i197 in 0...4) {
				H.tick();
				var v198 = 65535;
				v198 *= (-1604454177);
			}
		}
		(new C9()).m8();
		function lf199(n200:Int):Int {
			H.tick();
			return n200 <= 0 ? (false ? (({x1: n200, x2: n200} : S0)).x2 : n200) : (lf199(n200 - 1) + ({ var v201 = 174; Math.floor(v201); }));
		}
		H.out("lf199 " + lf199(4));
		var v202:Bool = (cast (true) : Bool);
		for (i203 in 1...1) {
			H.tick();
			var v204 = Reflect.compare(i203, i203);
		}
		Main.fn17(153, new C15(), 253);
		H.out("o205 " + Std.string((K6.K6B : Int)));
		return 1e3;
	}
	public static function fn36(a37:Float, a38:Int):Int {
		H.tick();
		H.out("o206 " + Std.string((false ? 0x835F : Lambda.fold([a38, a38], (v207:Int, v208:Int) -> ((624358822 : A5) : Int), 0))));
		var v209:A5 = new A5(a38);
		for (i210 in 0...0) {
			H.tick();
			var v211 = 299;
			H.out("o212 " + Std.string(i210));
		}
		(((false ? new C15() : new C15()) : C15)).m8();
		return (a38 * a38);
	}
	public static function fn39(a40:String, a41:Int):Bool {
		H.tick();
		for (i213 in 1...5) {
			H.tick();
			for (i214 in 0...H.lim(Math.round(i213))) {
				H.tick();
				final v215 = i213;
			}
		}
		try {
			if (Ext.ext54((new A5(a41)).get())) throw 45;
			var v216:A5 = new A5(a41);
			final lf217:(Int, Bool) -> Void = function(p218:Int, p219:Bool):Void {
				H.tick();
				H.out("o220 " + Std.string(p218));
				var v221:K6 = K6.K6C;
				var v222:Bool = p219;
			};
			H.out("o223 " + Std.string(new C15()));
		} catch (ex224:String) {
			H.out("caught String " + ex224);
			H.out("o225 " + Std.string(new C9()));
		} catch (ex226:Int) {
			H.out("caught Int " + ex226);
			final v227:(Bool, Float) -> Int = (p228:Bool, p229:Float) -> ex226;
			var w230 = 0;
while (w230 < 2 && false) {
				w230++;
				H.tick();
				var v231:I7 = new C15();
			}
		} catch (ex232:Err) {
			H.out("caught Err " + ex232.errCode);
			var v233:Float = a41;
			var v234:Box<Int> = new Box<Int>(a41);
		} catch (ex235:Dynamic) {
			H.out("caught " + H.exn(ex235));
			var v236:Int = (Std.parseInt(Std.string(a41)) ?? 0);
		}
		if ((Lambda.fold([70, a41, 181], (v237:Int, v238:Int) -> (new A5(a41)).twice, 0) <= a41)) {
			try {
				var v239 = true;
				var v240:Int = a41;
				a41 = 0x80000000;
				if (v239) throw a40;
			} catch (ex241:String) {
				H.out("caught String " + ex241);
				H.out("o242 " + Std.string(a41));
				a41++;
			} catch (ex243:Int) {
				H.out("caught Int " + ex243);
				final v244 = ex243;
				a41 = ex243;
			} catch (ex245:Err) {
				H.out("caught Err " + ex245.errCode);
				a41 = H.id(a41);
				var v246:Bool = false;
			} catch (ex247:Dynamic) {
				H.out("caught " + H.exn(ex247));
				var v248:A5 = new A5(92);
				final v249:C9 = new C9();
			}
		} else {
			final v250 = a41;
			H.out("o251 " + Std.string(({x2: 65535, x1: 0xCF6A} : S0)));
		}
		final v252:C9 = ({ var v253 = (({x1: a41, x2: 239} : S0)).x2; new C9(); });
		var v254 = (85 != (K6.K6A : Int));
		final lf255:(Int, Int) -> Bool = function(p256:Int, p257:Int):Bool {
			H.tick();
			H.out("o258 " + Std.string(({x1: 102, x2: p256} : S0)));
			return v254;
		};
		H.out("o259 " + Std.string(({ var v260 = v254; new C15(); })));
		var v261:A5 = new A5(0x7FFFFFFF);
		return fn17(Reflect.compare((-665038500), a41), v252, a41, (127 * 181), ((({x1: 186, x2: a41} : S0)).x2 % H.nz(a41)));
	}
	public static function fn42(a43:Float, a44:Int, a45:Bool):Bool {
		H.tick();
		a43 = (123456.789 * a44);
		H.out("o262 " + Std.string((a44 % H.nz(a44))));
		H.out("o263 " + Std.string(((new A5(a44) + new A5(194)) : Int)));
		(new C15()).m8();
		a44 = (Std.parseInt(Std.string(a44)) ?? 0);
		try {
			H.out("o264 " + Std.string(new C15()));
			(new C15()).m8();
			a44 = H.id(a44);
			if (Main.fn17(a44, new C15(), 0x80000000, (({x1: a44, x2: 231} : S0)).x1, 143)) throw 23;
		} catch (ex265:Dynamic) {
			H.out("caught " + H.exn(ex265));
			H.out("o266 " + Std.string((K6.K6D : Int)));
		}
		a45 = H.id(a45);
		var v267:S3 = ({x4: 0.5} : S3);
		final v268:() -> Int = function():Int {
			H.tick();
			a44 -= 106;
			var v269:S0 = ({x1: a44, x2: a44} : S0);
			final v270:(Int) -> Int = function(p271:Int):Int {
				H.tick();
				H.out("o272 " + Std.string(new C9()));
				(p271).ext54();
				return 210;
			};
			return (new A5(a44)).get();
		};
		return Main.fn39(({ var v273 = false; Std.string(false); }), Lambda.count([186, a44], v274 -> true));
	}
	public static function fn46():Bool {
		H.tick();
		var v275 = (214 * 246);
		switch (true) {
			case true: {
				final lf276:(Int) -> Int = (p277:Int) -> v275;
			};
			case false: {
				var v278:Int = (({x1: v275, x2: v275} : S0)).x1;
			};
		}
		final v279:Int = (false ? (-20) : Math.floor(0.5));
		return (0x853E == v275);
	}
	public static function fn47(a48:Int, a49:Float, a50:Null<Int>):Int {
		H.tick();
		a48 = 118;
		Main.fn46();
		final v280:(Bool) -> String = function(p281:Bool):String {
			H.tick();
			a48 = H.id(a48);
			fn22(a48, new A5(a48), true);
			return "q";
		};
		a48 -= ((new A5(a48)).twice).ext57(a48);
		H.out("o282 " + Std.string(((switch (a48) {
			case 0: new C15();
			case 2 | 4: new C9();
			case _: new C9();
		}) : I7)));
		var v283 = 13;
		var v284 = ((K6.K6C : Int) - 129);
		(new C9()).m11();
		return v283;
	}
	public static function section0():Void {
		H.tick();
		final v315:Int = (new C9()).m12(0x1D7);
		H.out("o316 " + Std.string(new Box<C9>(new C9())));
		var v317 = Main.fn42(1.25, v315, false);
		switch (K6.K6B) {
			case K6.K6A: {
				(new C9()).m14();
			};
			case K6.K6B: {
				for (i318 in 0...4) {
					H.tick();
					var v319 = v315;
					Main.fn46();
					v319++;
				}
			};
			case K6.K6C: {
				H.out("o320 " + Std.string(new C9()));
				var v321:C15 = new C15();
			};
			case K6.K6D: {
				(new C15()).m8();
			};
		}
		var v322:Int = v315;
		var v323 = v317;
		H.out("o324 " + Std.string(({ var v325 = "zz"; ({x1: v315, x2: v322} : S0); })));
		if (v323) {
			if (Std.isOfType(new C15(), C9)) {
				H.out("o326 " + Std.string(new C9()));
				v322 += v315;
			}
			v317 = H.id(v317);
			if (false) {
				var v327:C15 = new C15();
				var v328:Box<Int> = new Box<Int>(v315);
				H.out("o329 " + Std.string(v315));
			}
		} else {
			try {
				if (v323) throw "\x41\x42";
				Ext.ext54(v315);
			} catch (ex330:Dynamic) {
				H.out("caught " + H.exn(ex330));
				H.out("o331 " + Std.string(0x7FFFFFFF));
			}
		}
		H.out("o332 " + Std.string(v315));
	}
	public static function section1():Void {
		H.tick();
		fn26(Std.parseFloat("3"), (false ? (-7) : 99));
		var v333:S0 = ({x1: (Std.parseInt("abc") ?? 0), x2: (({x1: 13, x2: 65535} : S0)).x2} : S0);
		for (i334 in 1...2) {
			H.tick();
			var v335:Box<Null<Int>> = new Box<Null<Int>>(i334);
			H.out("o336 " + Std.string(267));
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
