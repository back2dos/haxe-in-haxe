package p;

import Main;
import H;
import p.M1;

class Ext {
	public static function ext52(a51:String):Float {
		H.tick();
		var v285:Bool = (true && Math.isNaN(1e21));
		final v286:Int = 212;
		H.out("o287 " + Std.string(v285));
		H.out("o288 " + Std.string((v285 ? false : v285)));
		if (v285) {
			if (true) return 1e3;
			Main.fn26(v286, v286);
		}
		v285 = (false && v285);
		return v286;
	}
	public static function ext54(a53:Int):Bool {
		H.tick();
		switch (({ var v289 = 184; Math.floor(a53); })) {
			case 0: {
				for (i290 in 0...1) {
					H.tick();
					var v291:Int = i290;
					H.out("o292 " + Std.string((K6.K6B : Int)));
					var v293:Int = 678079073;
				}
			};
			case 3 | 4: {
				{
					final v294 = a53;
					var v295 = true;
				}
			};
			case _: {
				H.out("o296 " + Std.string(({x1: (-1033510945), x2: a53} : S0)));
			};
		}
		function lf297(n298:Int):Int {
			H.tick();
			return n298 <= 0 ? a53 : (lf297(n298 - 1) + (Math.round(7.0) + Reflect.compare(n298, a53)));
		}
		H.out("lf297 " + lf297(4));
		(new C9()).m11();
		{
			a53 += 65535;
			final lf299:() -> Int = () -> (K6.K6D : Int);
			a53 = 204;
		}
		var v300 = !Std.isOfType(new C15(), I7);
		return v300;
	}
	public static function ext57(a55:Int, a56:Int):Int {
		H.tick();
		(new C9()).m11();
		if (false) {
			var v301:Bool = true;
			var v302 = Reflect.compare(a55, 235);
			switch (a55) {
				case 0: {
					H.out("o303 " + Std.string((K6.K6D : Int)));
				};
				case 2 | 4: {
					H.out("o304 " + Std.string(a56));
					H.out("o305 " + Std.string(168));
				};
				case _: {
					v302 = 0xB696;
				};
			}
		} else {
			a56 -= Lambda.count([a56, a55], v306 -> (Std.downcast((new C9() : I7), C9) != null));
			H.out("o307 " + Std.string((K6.K6C : Int)));
		}
		Ext.ext52((switch (a55) {
			case 0: "Haxe";
			case 2 | 6: Std.string(a56);
			case _: Std.string(a56);
		}));
		final v308:K6 = K6.K6A;
		var v309:C15 = new C15();
		switch ((cast (Lambda.fold([a56, 38, a55], (v310:Int, v311:Int) -> 0xE26C, 0)) : Int)) {
			case 0: {
				Ext.ext52("ünï");
				for (i312 in 0...H.lim(a56)) {
					H.tick();
					Main.fn29(K6.K6D, true, i312);
				}
			};
			case 2 | 4: {
				a55 -= 206;
				H.out("o313 " + Std.string(new C9()));
			};
			case _: {
				a56 = Math.floor(2.5e-3);
				var v314 = a56;
			};
		}
		{
			Main.fn22(a55, new A5(a56), true);
		}
		return (cast (a56) : Int);
	}
}
