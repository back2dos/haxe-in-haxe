package p;

import Main;
import H;
import p.M1;
using p.Ext;

class M1 {}

typedef S0 = {x1:Int, x2:Int};

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

enum abstract K6(Int) to Int {
	var K6A = 1;
	var K6B = 4;
	var K6C = 7;
	var K6D = 10;
}

interface I7 {
	function m8():Float;
}

class C9 implements I7 {
	public var cb10:(Int) -> Int;
	public function new() {
		this.cb10 = (p58:Int) -> p58;
	}
	public function m8():Float {
		H.tick();
		var v59:I7 = new C15();
		var v60:Bool = false;
		var v61:Int = ((-2147483647) - 825868218);
		final v62:(Bool) -> Int = function(p63:Bool):Int {
			H.tick();
			var v64 = false;
			v61 = H.id(v61);
			this.m11();
			return (Std.parseInt(Std.string(215)) ?? 0);
		};
		Main.fn29(K6.K6B, (v61 == v61), Math.max(1e3, 0.1));
		var v65 = (switch (K6.K6A) {
			case K6.K6A: (-851359050);
			case K6.K6B: (Std.parseInt(Std.string(183)) ?? 0);
			case K6.K6C: 277;
			case K6.K6D: 718274537;
		});
		return (Main.fn33(v65) + ((-552277745) / (({x2: v65, x1: v65} : S0)).x1));
	}
	public function m11():Int {
		H.tick();
		final v66:Float = 0.1;
		H.out("o67 " + Std.string((192 + 102)));
		final lf68:(Bool) -> Int = (p69:Bool) -> (Std.isOfType(new C15(), C15) ? (({x1: (-2147483647), x2: 96} : S0)).x1 : Reflect.compare(290, 260));
		return (switch (K6.K6B) {
			case K6.K6A: ((Std.parseInt("42") ?? 0) * (({x1: 238, x2: 249} : S0)).x2);
			case K6.K6B: (switch (Reflect.compare(216, (-2147483647))) {
				case 0: 69;
				case 3 | 5: (K6.K6B : Int);
				case _: (K6.K6C : Int);
			});
			case K6.K6C: 256;
			case K6.K6D: (Std.int(v66) - 232);
		});
	}
	public function m12(a13:Int):Int {
		H.tick();
		H.out("o70 " + Std.string(Reflect.compare(Reflect.compare(a13, a13), a13)));
		for (i71 in 1...2) {
			H.tick();
			var v72:A5 = new A5(a13);
		}
		this.m11();
		final v73:(Int) -> Void = function(p74:Int):Void {
			H.tick();
			H.out("o75 " + Std.string(119));
			var v76 = p74;
		};
		return ({ var v77 = 1e-7; (true ? (new A5(a13)).twice : (K6.K6D : Int)); });
	}
	public function m14():Int {
		H.tick();
		var v78:K6 = K6.K6D;
		switch (v78) {
			case K6.K6A: {
				final v79:Int = 231;
				{
					H.out("o80 " + Std.string(v79));
					H.out("o81 " + Std.string(new C15()));
					final v82:(Int, Int) -> Int = (p83:Int, p84:Int) -> v79;
				}
			};
			case K6.K6B: {
				switch (276) {
					case 0: {
						H.out("o85 " + Std.string(0xE847));
					};
					case 1 | 4: {
						var v86:Bool = false;
					};
					case _: {
						var v87:Int = 284;
					};
				}
				final lf88:() -> Int = () -> Reflect.compare(0x4336, 0x8F14);
			};
			case K6.K6C: {
				final lf89:(Float, Int) -> Bool = function(p90:Float, p91:Int):Bool {
					H.tick();
					H.out("o92 " + Std.string(false));
					var v93:S3 = ({x4: 1e100} : S3);
					Main.fn26((-2.5), 64);
					return true;
				};
			};
			case K6.K6D: {
				final v94:(Float) -> Bool = function(p95:Float):Bool {
					H.tick();
					var v96:C9 = new C9();
					H.out("o97 " + Std.string((-646789541)));
					return true;
				};
			};
		}
		var v98:Float = 7.0;
		try {
			var v99:Float = (-2.5);
			H.out("o100 " + Std.string(new C9()));
			if ((0.5 >= 1.25)) throw new Err((switch ((v78 : Int)) {
				case 0: (Std.parseInt("ünï") ?? 0);
				case 2 | 5: Math.ceil(0.5);
				case _: 103;
			}));
		} catch (ex101:Err) {
			H.out("caught Err " + ex101.errCode);
			for (i102 in 0...H.lim(Math.round(1.25))) {
				H.tick();
				this.m8();
				H.out("o103 " + Std.string(new Box(i102)));
				var v104:Bool = true;
			}
			var v105:C9 = new C9();
		} catch (ex106:haxe.Exception) {
			H.out("caught " + H.exn(ex106));
			H.out("o107 " + Std.string(v98));
		}
		switch (Main.fn29(v78, true, v98)) {
			case 0: {
				final v108:C9 = new C9();
				final v109:(Bool, Int) -> Float = (p110:Bool, p111:Int) -> p111;
			};
			case 1 | 5: {
				for (i112 in 1...5) {
					H.tick();
					H.out("o113 " + Std.string(45));
					H.out("o114 " + Std.string(new C15()));
				}
				H.out("o115 " + Std.string((Std.parseInt(Std.string(248)) ?? 0)));
			};
			case _: {
				final v116:() -> Int = function():Int {
					H.tick();
					final v117:Int = 0x3CD1;
					Main.fn26(v117, v117);
					H.out("o118 " + Std.string(v98));
					return v117;
				};
			};
		}
		return m11();
	}
}
