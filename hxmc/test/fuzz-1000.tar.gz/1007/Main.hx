import H;
import p.M1;
import p.q.M2;

enum E5 {
	E5A;
	E5B(a6:String);
}

class C20 extends C10 {
	public final f21:String;
	public static var f22:String = "日本語";
	public function new(a23:Int, a24:Float) {
		super(false, 281);
		this.f21 = "\t";
	}
	override public function m17(a18:Float, a19:Box<Int>):E1 {
		H.tick();
		C27.f28 = ((E1.E1C).match(E1A) ? Math.round(a18) : ("ünï").length);
		C27.f28 = (114 ^ ("0").length);
		if (false) return this.f12;
		{
			H.out("o78 " + ("\"q\"").substr(((-2147483647) & 7), (31 & 7)));
			(new C27(false)).m15();
		}
		H.out("o79 " + Std.string(281));
		for (i80 in 0...0) {
			H.tick();
			H.out("o81 " + Std.string(i80));
		}
		(new C27(true)).m15();
		C27.f28 += ({ var v82 = StringTools.trim("ünï"); Reflect.compare(0xBCA6, 93); });
		final v83:C20 = (cast (new C20(73, 0.5)) : C20);
		return this.f12;
	}
	public function m25(a26:C10):String {
		H.tick();
		var v84:C10 = new C10(true, (("x,y,z").charCodeAt(156) ?? -1));
		var w85 = 0;
do {
			w85++;
			H.tick();
			if (false) {
				H.out("o86 " + Std.string(0x5D36));
				C27.f28 <<= ((-736736544) & 7);
				H.out("o87 " + Std.string(E0.E0A));
			}
			var v88:Float = 3.0;
			for (i89 in 0...3) {
				H.tick();
				var v90 = true;
				C27.f28 = i89;
			}
		} while (w85 < 3 && (StringTools.contains("abc", "A-B-C") && false));
		C27.f28 &= ((new A9(0x32AB)).twice & (-1916983316));
		return (new C49(69, 197)).m54();
	}
}

class C27 extends C10 {
	public static var f28:Int = 11;
	public function new(a29:Bool) {
		super(a29, (("\x41\x42").charCodeAt(89) ?? -1));
	}
	override public function m15():Int {
		H.tick();
		if ((Std.string(1.25) > "q")) {
			for (i91 in 0...H.lim(291)) {
				H.tick();
				var v92:E0 = E0.E0A;
				var v93 = (-19);
			}
			H.out("o94 " + Std.string(E1.E1B(17, 121)));
		} else {
			var v95:A9 = new A9(133);
			final v96 = StringTools.trim("\x41\x42");
		}
		H.out("o97 " + Std.string(E0.E0A));
		var v98 = false;
		var v99:C20 = new C20(Math.round(1e-7), 126);
		C27.f28 = (if ((E5.E5A).match(E5B(_))) (-2) else Math.ceil(1e100));
		C27.f28 = ((Std.string(v98)).charCodeAt((Std.parseInt("日本語") ?? 0)) ?? -1);
		var w100 = 0;
while (w100 < 1 && StringTools.endsWith(StringTools.replace("", " ", ""), StringTools.lpad("日本語", "*", -1))) {
			w100++;
			H.tick();
			final v101:(Int) -> Int = function(p102:Int):Int {
				H.tick();
				C27.f28 = p102;
				return p102;
			};
		}
		C27.f28 *= (206 * C27.f28);
		var v103:E1 = E1.E1B((-399151002), Math.ceil(7.0));
		return ((("x,y,z").toLowerCase()).charCodeAt(((StringTools.trim("a")).charCodeAt(C27.f28) ?? -1)) ?? -1);
	}
	public static function m30():Bool {
		H.tick();
		if ((StringTools.hex((264) & 0xFFFF, 4) != C20.f22)) {
			final v104:String = "é";
		}
		(new C27(false)).m15();
		(new C10((E5B("\x41\x42")).match(E5A), 164)).m15();
		for (i105 in 0...H.lim((StringTools.hex((282) & 0xFFFF, 4)).indexOf(Std.string(1e3)))) {
			H.tick();
			C27.f28 = i105;
			H.out("o106 " + Std.string(new Box<Bool>(true)));
			(new C27(false)).m17(1e3, new Box<Int>(i105));
		}
		for (i107 in 0...3) {
			H.tick();
			(new C10(false, 147)).m17(i107, new Box(5));
			H.out("o108 " + Std.string(i107));
			var v109:Bool = StringTools.startsWith("\t", "日本語");
		}
		{
			H.out("o110 " + Std.string(StringTools.contains("ab", "ünï")));
			if (true) return false;
		}
		return ("日本語" < "\x41\x42");
	}
	public static function m31(a32:Bool, a33:E1):Int {
		H.tick();
		C27.f28 = (StringTools.replace("Haxe", ",", "\"q\"")).lastIndexOf(("0").toLowerCase());
		var v111:String = ("é").toLowerCase();
		var w112 = 0;
while (w112 < 1 && a32) {
			w112++;
			H.tick();
			var v113:Int = 272;
		}
		var v114 = (StringTools.contains(v111, "\n") && a32);
		if (v114) return Lambda.count(([] : Array<Int>), v115 -> (Std.downcast((new C27(true) : C27), C27) != null));
		var v116 = (Std.string(v114) + C20.f22);
		C27.f28 |= Reflect.compare(C20.f22, (v116).toUpperCase());
		if ((Std.isOfType(new C27(v114), C27) && (E5.E5A).match(E5A))) {
			{
				(new C49(203, 0x9A26)).m55();
				++C27.f28;
			}
			var w117 = 0;
do {
				w117++;
				H.tick();
				(new C27(a32)).m37(v111);
			} while (w117 < 4 && Math.isNaN(7.0));
			H.out("o118 " + Std.string(E1.E1A));
		} else {
			var w119 = 0;
do {
				w119++;
				H.tick();
				H.out("o120 " + Std.string(true));
				final v121:Int = 4;
				H.out("o122 " + Std.string(v121));
			} while (w119 < 2 && true);
		}
		return ((Type.enumIndex(E0.E0A) >> ((new A9(137) : Int) & 31)) + 294);
	}
	public function m34(a35:String, a36:C10):String {
		H.tick();
		for (i123 in 0...H.lim(Main.fn58(Math.ceil(2.5e-3), 196))) {
			H.tick();
			var v124 = Std.string(E1.E1B(i123, 65535));
			final v125 = "a";
		}
		C27.f28 = 192;
		var v126:C10 = a36;
		if ((StringTools.endsWith("ünï", "ünï") || true)) return StringTools.trim("q");
		return a35;
	}
	public function m37(a38:String):Void {
		H.tick();
		var v127:S7 = H.apply((a38).indexOf("q"), (v128:Int) -> ({x8: v128} : S7));
		C27.m30();
		H.out("o129 " + Std.string(((true ? new C20(183, 123456.789) : new C20(120, 0.1)) : C20)));
	}
}

class Main {
	public static inline function fn56():Bool {
		H.tick();
		C20.f22 = H.cap(Std.string(0xE57D));
		C27.f28 -= 0x1EF6;
		H.out("o164 " + Std.string(Lambda.fold(([] : Array<Int>), (v165:Int, v166:Int) -> Math.ceil(v166), 0)));
		return ((2007453524 > ("-7").length) ? (cast (StringTools.endsWith("-7", "\u{1F600}")) : Bool) : !StringTools.startsWith("\x41\x42", "ab"));
	}
	public static inline function fn57():Int {
		H.tick();
		final lf167:(Bool) -> String = function(p168:Bool):String {
			H.tick();
			H.out("o169 " + Std.string(new C49((-2147483647), 30)));
			return (new C49(196, 138)).m54();
		};
		H.out("o170 " + Std.string(true));
		H.out("o171 " + Std.string(new Box<Bool>(false)));
		(new C27(true)).m15();
		H.out("o172 " + Std.string((new A9(85) : Int)));
		H.out("o173 " + Std.string(new Box<Bool>(false)));
		{ var dyn174:Dynamic = ({x8: 109} : S7); H.out("dyn " + Std.string(dyn174.x8) + " " + Std.string(Reflect.field(dyn174, "x8"))); }
		return (String.fromCharCode(65 + ((("\x41\x42").lastIndexOf("hello world")) & 15))).lastIndexOf(("-7" + ("0").toLowerCase()));
	}
	public static inline function fn58(a59:Int, a60:Int):Int {
		H.tick();
		(new C27(Std.isOfType(new C39(), C10))).m15();
		if (StringTools.startsWith("é", "zz")) {
			a59 ^= a60;
			if (true) {
				H.out("o175 " + Std.string(a60));
			}
		} else {
			var v176 = Std.string(false);
		}
		var v177:C39 = ((false ? new C39() : new C39()) : C39);
		H.out("o178 " + Std.string(((new A9(a59) * new A9(a60)) : Int)));
		var v179:C27 = new C27((E1.E1B(a60, a59)).match(E1B(_, _)));
		H.out("o180 " + Std.string(E5B(C20.f22)));
		final lf181:() -> Int = () -> a60;
		var v182 = (new C49(a59, a60)).m54();
		return (-a60);
	}
	public static function fn61():Bool {
		H.tick();
		C27.m30();
		var v183 = C39.m45();
		C27.m31((StringTools.startsWith("zz", "") ? (E1.E1B(v183, v183)).match(E1A) : true), E1.E1C);
		var v184:E5 = E5A;
		var v185 = (new A9(v183)).twice;
		var v186:Box<Int> = new Box(286);
		if ((("é").charAt(3) > StringTools.lpad("Haxe", "*", ((-17) & 7)))) {
			var v187 = v185;
			var w188 = 0;
while (w188 < 4 && false) {
				w188++;
				H.tick();
				final v189:Float = 5e-324;
				var v190:Float = v189;
			}
			for (i191 in 0...1) {
				H.tick();
				H.out("o192 " + Std.string(156));
				C27.f28 = 0x4FA6;
				H.out("o193 " + Std.string(({x8: v183} : S7)));
			}
		} else {
			v183 -= 108;
		}
		if ((v183 != v183)) {
			H.out("o194 " + Std.string(v183));
		}
		for (i195 in 0...0) {
			H.tick();
			H.out("o196 " + Std.string(i195));
			H.out("o197 " + Std.string(v184));
		}
		return Main.fn56();
	}
	public static function fn62():Int {
		H.tick();
		C27.f28 = C39.m45();
		C27.f28 *= 159;
		function lf198(n199:Int):Int {
			H.tick();
			return n199 <= 0 ? n199 : (lf198(n199 - 1) + n199);
		}
		H.out("lf198 " + lf198(1));
		var v200 = C27.f28;
		C27.f28 = v200;
		return v200;
	}
	public static function fn63():Float {
		H.tick();
		H.out("o201 " + Std.string((8 | 26)));
		var v202 = (-1694634546);
		final v203 = (true ? StringTools.lpad("hello world", "*", (v202 & 7)) : Std.string(E0.E0A));
		C20.f22 = H.cap("\x41\x42");
		if (false) {
			C27.f28 = v202;
		} else {
			if (false) {
				final v204:(Int, Int) -> String = (p205:Int, p206:Int) -> v203;
				var v207:C20 = new C20(v202, v202);
				C39.m45();
			}
			for (i208 in 0...H.lim((Std.parseInt(Std.string(v202)) ?? 0))) {
				H.tick();
				H.out("o209 " + Std.string(v202));
				var v210:S7 = ({x8: i208} : S7);
				H.out("o211 " + Std.string(new C20(i208, 2.5e-3)));
			}
		}
		var v212:Float = (new C39()).m43(E5B(v203));
		return Math.abs(((-2.5) * 2.5e-3));
	}
	public static function fn64(a65:E5):Float {
		H.tick();
		var w213 = 0;
while (w213 < 3 && Std.isOfType(new C39(), C39)) {
			w213++;
			H.tick();
			var v214 = (({x8: 227} : S7)).x8;
		}
		H.out("o215 " + Std.string(1e3));
		var v216:C27 = new C27(true);
		H.out("o217 " + Std.string(v216));
		return C49.f51;
	}
	public static function section0():Void {
		H.tick();
		var v218:Bool = !true;
		for (i219 in 1...1) {
			H.tick();
			fn63();
		}
		final v220 = ({ var v221 = "\x41\x42"; StringTools.trim("zz"); });
		H.out("o222 " + Std.string(new C39()));
		var v223:E1 = E1.E1A;
		var v224:S7 = ({x8: 0xBF0C} : S7);
		var v225:Box<C10> = new Box<C10>(new C20(38, 1e-7));
		if (v218) {
			var v226:Float = 55;
			(new C39()).m46((v224).x8, (v220).lastIndexOf("0"));
		}
	}
	public static function section1():Void {
		H.tick();
		H.out("o227 " + Std.string(({x8: (((-15) : A9) : Int)} : S7)));
		Main.fn58((false ? (-1090719555) : 154), ((StringTools.hex((229) & 0xFFFF, 4)).charCodeAt(C27.f28) ?? -1));
		H.out("o228 " + Std.string(C27.m31(Std.isOfType(new C27(true), C39), E1.E1A)));
		H.out("o229 " + Std.string(new C10((E0.E0A).match(E0A), (Std.parseInt("") ?? 0))));
		H.out("o230 " + (new C20(0xFCA4, 3.0)).m25(new C27(true)));
		var v231:Int = Main.fn62();
		var w232 = 0;
while (w232 < 3 && (v231 == v231)) {
			w232++;
			H.tick();
			(new C10(true, v231)).m15();
			var v233 = true;
		}
		for (i234 in 0...4) {
			H.tick();
			var v235:Float = 100.75;
			var v236:Int = Lambda.count(([] : Array<Int>), v237 -> Std.isOfType(new C20(v231, v231), C20));
			C27.m31((E1.E1A).match(E1B(_, _)), E1.E1A);
		}
		{
			H.out("o238 " + Std.string(false));
			C20.f22 = H.cap(C20.f22 + ("  pad  ").toUpperCase());
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
