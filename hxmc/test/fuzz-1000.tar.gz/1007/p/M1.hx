package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

enum E1 {
	E1A;
	E1B(a3:Int, a4:Int);
	E1C;
}

class C10 {
	public var f11:Float;
	public var f12:E1;
	public function new(a13:Bool, a14:Int) {
		this.f11 = a14;
		this.f12 = E1.E1A;
	}
	public function m15():Int {
		H.tick();
		var v66 = (Std.parseInt(Std.string(Type.enumIndex(E0.E0A))) ?? 0);
		var v67 = C27.f28;
		H.out("o68 " + Std.string(((true ? ({x8: v67} : S7) : ({x8: v67} : S7)) : S7)));
		return v67;
	}
	public static function m16():Void {
		H.tick();
		var v69 = H.id(Math.ceil(2.5e-3));
		var v70 = (new C49(v69, (-309789816))).m54();
		var v71:S7 = (((E5.E5A).match(E5A) ? ({x8: v69} : S7) : ({x8: v69} : S7)) : S7);
		v69 = Main.fn57();
		var w72 = 0;
while (w72 < 3 && (v69 >= (--v69))) {
			w72++;
			H.tick();
			v69 = H.id(v69);
			H.out("o73 " + Std.string(E5.E5B("\t")));
			var v74:Float = C27.f28;
		}
	}
	public function m17(a18:Float, a19:Box<Int>):E1 {
		H.tick();
		C27.f28 = (65535 >> (C27.f28 & 31));
		var v75 = 'x${Std.string((("A-B-C").charCodeAt(55) ?? -1))}x${Std.string(false)}x${Std.string((E1A).match(E1C))}';
		H.out("o76 " + v75);
		H.out("o77 " + Std.string((11 | (Std.parseInt("42") ?? 0))));
		return E1C;
	}
}
