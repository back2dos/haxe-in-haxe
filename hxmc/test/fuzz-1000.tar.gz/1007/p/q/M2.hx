package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

enum E0 {
	E0A;
}

typedef S7 = {x8:Int};

abstract A9(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A9, b:A9):A9
		return new A9(a.get() + b.get());

	@:op(A * B) public static function mul(a:A9, b:A9):A9
		return new A9(a.get() * b.get());

	@:op(-A) public static function neg(a:A9):A9
		return new A9(-a.get());
}

class C39 extends C10 {
	public var f40:Int;
	public var f41:Int;
	public var f42:E0;
	public function new() {
		super((E0A).match(E0A), 288);
		this.f40 = Type.enumIndex(E0.E0A);
		this.f41 = Math.round((-2.5));
		this.f42 = E0A;
	}
	public function m43(a44:E5):Int {
		H.tick();
		this.f40 = (false ? C27.f28 : 242);
		H.out("o130 " + Std.string(1.7976931348623157e308));
		(new C27(StringTools.endsWith("hello world", "-7"))).m37((true ? "\t" : Std.string(1e-7)));
		var v131 = this.m15();
		return ({ var v132 = v131; (C20.f22).indexOf(StringTools.lpad("\t", "*", 4)); });
	}
	public static function m45():Int {
		H.tick();
		if (StringTools.startsWith(StringTools.lpad("a", "*", 3), "A-B-C")) return 105;
		var v133:S7 = ({x8: (-4)} : S7);
		var v134 = !false;
		var v135:E1 = E1.E1A;
		return (v134 ? Math.ceil(Std.parseFloat("12.5")) : Std.int(0.1));
	}
	public function m46(a47:Int, a48:Int):E1 {
		H.tick();
		a47 = ((("").charCodeAt(a48) ?? -1) ^ this.f40);
		var v136 = a47;
		var v137:C20 = new C20(175, a48);
		return (new C20(this.f40, 110)).m17((a47 / v136), new Box(this.f40));
	}
}

class C49 {
	public var f50:String;
	public static var f51:Float = 1.25;
	public function new(a52:Int, a53:Int) {
		this.f50 = "0";
	}
	public function m54():String {
		H.tick();
		if ((Math.isNaN(0.5) ? false : StringTools.endsWith("日本語", "Haxe"))) {
			final v138 = Lambda.fold(([] : Array<Int>), (v139:Int, v140:Int) -> Math.round(v140), 0);
			var v141 = (-8);
			final lf142:(Float) -> String = (p143:Float) -> "ünï";
		} else {
			C27.f28 *= C27.f28;
			{
				H.out("o144 " + Std.string(new C49(0x80000000, 775499177)));
				var v145:Box<String> = new Box<String>("\t");
			}
		}
		var w146 = 0;
while (w146 < 4 && true) {
			w146++;
			H.tick();
			if ((E1.E1B(0x7FFFFFFF, 97)).match(E1B(_, _))) return Std.string(7.0);
			var v147 = Std.string(0x4C96);
		}
		H.out("o148 " + Std.string(H.apply((({x8: 211} : S7)).x8, (v149:Int) -> ({x8: 79} : S7))));
		return (true ? '-${"-7"}' : "q");
	}
	public function m55():Float {
		H.tick();
		H.out("o150 " + Std.string(((false ? new C49(160, 67) : new C49(1617736623, 11)) : C49)));
		var v151:String = Std.string(E1.E1A);
		var v152:Bool = (true || true);
		final lf153:(String) -> Void = function(p154:String):Void {
			H.tick();
			final lf155:(Int) -> Float = function(p156:Int):Float {
				H.tick();
				var v157:A9 = (p156 : A9);
				var v158:Float = p156;
				return p156;
			};
		};
		H.out("o159 " + Std.string((42 >>> ((v151).lastIndexOf(v151) & 31))));
		var v160:Box<Box<String>> = new Box<Box<String>>(new Box(v151));
		C27.f28 = (false ? Reflect.compare(2, 135) : C27.f28);
		(new C39()).m17(((StringTools.startsWith(v151, v151) ? 100.75 : 223) : Float), new Box(127));
		for (i161 in 1...4) {
			H.tick();
			final v162 = 0x9671;
			C27.f28 = H.id(C27.f28);
			var v163:Box<String> = new Box(v151);
		}
		return 0.1;
	}
}
