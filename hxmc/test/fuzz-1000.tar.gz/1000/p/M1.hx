package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
}

typedef S2 = {x3:Float, x4:Int};

class C12 {
	var _f13:Int;

	public var f13(get, set):Int;

	function get_f13():Int
		return _f13;

	function set_f13(v:Int):Int
		return _f13 = v;
	public final f14:Int;
	public var f15:Float;
	public function new(a16:String, a17:Int) {
		this._f13 = (a16).lastIndexOf("A-B-C");
		this.f14 = a17;
		this.f15 = a17;
	}
	public function m18(a19:Int, a20:Float):Int {
		H.tick();
		var w53 = 0;
do {
			w53++;
			H.tick();
			var v54:Array<Bool> = [true, true, true];
			if (([a19, a19]).contains(a19)) return (new A5(a19)).get();
			H.out("o55 " + Std.string(({x3: a20, x4: a19} : S2)));
		} while (w53 < 3 && StringTools.startsWith(StringTools.replace("zz", "b", "0"), "\n"));
		Main.fn27(new Box(199), (("x,y,z").toLowerCase()).substr(5, -2));
		H.out("o56 " + Std.string(a19));
		H.out("o57 " + Std.string((13 + a19)));
		final lf58:(Int) -> Float = (p59:Int) -> Math.sqrt(Math.abs(a20));
		final v60 = 1131521144;
		return a19;
	}
	public function m21(a22:Float, a23:Bool):Void {
		H.tick();
		var v61:Float = ("\n").indexOf("zz");
		var v62 = a23;
		{
			this.f13 |= ([147735792]).indexOf((-396513041));
		}
	}
}

class C24 {
	public final f25:String;
	public var f26:Float;
	public function new() {
		this.f25 = "";
		this.f26 = 1.25;
	}
}
