package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext49(a48:Array<Int>):Int {
		H.tick();
		Main.fn35((Reflect.compare(182, 260) - Reflect.compare("\n", "A-B-C")), 1317696646);
		if ((Std.parseFloat("0") != 0.1)) {
			if ((a48).contains(101)) {
				H.out("o147 " + Std.string(239));
				var v148:Bool = true;
			}
			var v149:String = "zz";
		} else {
			H.out("o150 " + Std.string(StringTools.endsWith("\t", "-7")));
		}
		H.out("o151 " + Std.string((true ? 243 : Std.int(0.5))));
		final v152 = ("q").substr(-1, 5);
		for (x153 in [for (i154 in a48) if (true) "zz"]) {
			H.tick();
			H.out("o155 " + Std.string(({x3: (-2.5), x4: 221} : S2)));
			var v156:Float = 2.5e-3;
			var v157:Bool = true;
		}
		var w158 = 0;
while (w158 < 3 && ([(-2147483647)]).contains(Reflect.compare(294, 0x7FFFFFFF))) {
			w158++;
			H.tick();
			switch (E0.E0A) {
				case E0A: {
					H.out("o159 " + Std.string(0.30000000000000004));
					var v160:E1 = E1.E1A;
				};
			}
		}
		return 296;
	}
	public static function ext52(a50:Array<Int>, a51:Int):String {
		H.tick();
		a51 |= (Lambda.fold(a50, (v161:Int, v162:Int) -> ((a51 : A5)).twice, 0) ^ a51);
		var v163:Array<Int> = a50;
		H.out("o164 " + Std.string(((true ? ({x3: a51, x4: a51} : S2) : ({x3: 1.25, x4: a51} : S2)) : S2)));
		final v165:Array<Array<Int>> = ([a51, a51]).map((v166:Int) -> ([v166, v166, a51] : Array<Int>));
		for (x167 in [(-837308726)]) {
			H.tick();
			if (false) {
				a51 |= 0x75B;
				Main.fn32("abc", a51);
			} else {
				a51 = H.id(a51);
				var v168:E1 = E1.E1A;
			}
		}
		var v169 = (-16);
		return "abc";
	}
}
