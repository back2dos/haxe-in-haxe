import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

interface I6 {
	function m7(a8:Int):Bool;
	function m9(a10:String, a11:Bool):Bool;
}

class Main {
	public static inline function fn27(a28:Box<Int>, a29:String):Float {
		H.tick();
		var v63:Array<String> = ([a29, a29]).filter(v64 -> false);
		final v65:Int = ((("a\rb").charCodeAt((-1631120110)) ?? -1) * ((a29).charCodeAt(0xD13B) ?? -1));
		var v66:Array<Int> = [Type.enumIndex(E0.E0A), Lambda.count([284, v65, v65], v67 -> Std.isOfType(null, I6))];
		for (i68 in 0...H.lim(Math.floor(v65))) {
			H.tick();
			H.out("o69 " + Std.string(1e21));
			var v70:Int = 65535;
			var v71 = Math.isNaN((-2.5));
		}
		v66.remove(v65);
		H.out("o72 " + Std.string(E1.E1A));
		var v73:E0 = E0.E0A;
		H.out("o74 " + (v63).join("|"));
		var v75:Int = (false ? v65 : 192);
		return Std.parseFloat("12.5");
	}
	public static function fn30(a31:(Int, Bool) -> Int):String {
		H.tick();
		switch (0x7FFFFFFF) {
			case 0: {
				var v76:E0 = E0.E0A;
			};
			case 2 | 5: {
				Main.fn27(new Box(24), "  pad  ");
				H.out("o77 " + ("  pad  ").charAt(4));
			};
			case _: {
				var v78:Array<Bool> = [true];
			};
		}
		for (i79 in 0...H.lim(28)) {
			H.tick();
			switch (E1.E1A) {
				case E1A: {
					var v80:Array<Int> = ([] : Array<Int>);
				};
			}
		}
		H.out("o81 " + Std.string((116 >> (84 & 31))));
		var v82:Array<Bool> = (cast (([] : Array<Bool>)) : Array<Bool>);
		var v83:String = "q";
		final v84:(String) -> Bool = (p85:String) -> true;
		var w86 = 0;
while (w86 < 2 && (234 == 100.75)) {
			w86++;
			H.tick();
			H.out("o87 " + Std.string((new A5(242) : Int)));
			var v88:S2 = ({x4: 76, x3: 1e-7} : S2);
		}
		return "zz";
	}
	public static function fn32(a33:String, a34:Int):E0 {
		H.tick();
		final v89:() -> Int = () -> a34;
		final v90:Int = (Reflect.compare(a34, a34) - (([] : Array<Int>)).length);
		H.out("o91 " + Std.string(true));
		return E0.E0A;
	}
	public static inline function fn35(a36:Int, a37:Int):Void {
		H.tick();
		if ((new Box(true)).get()) {
			for (x92 in [15, 0x55ED, 153]) {
				H.tick();
				var v93:Array<String> = ("").split("a");
				H.out("o94 " + Std.string(E1.E1A));
				final v95:Array<Int> = [283];
			}
		} else {
			if (StringTools.endsWith("", "\t")) {
				a37 -= a37;
				var v96:A5 = new A5(a37);
			}
			var v97 = "  pad  ";
		}
		fn30(function(p98:Int, p99:Bool):Int {
			H.tick();
			fn27(new Box(37), "zz");
			Main.fn32("a\rb", a37);
			var v100:Int = (-825953398);
			return v100;
		});
		for (k102 => x101 in ([] : Array<Bool>)) {
			H.tick();
			for (i103 in 1...1) {
				H.tick();
				H.out("o104 " + Std.string(a37));
				H.out("o105 " + "x,y,z");
			}
			H.out("o106 " + Std.string([a36]));
			final v107 = Math.round(a37);
		}
	}
	public static function fn38(a39:E1, a40:Float):Float {
		H.tick();
		if ((Std.string(E1.E1A) < "\x41\x42")) {
			if (true) {
				final v108:Int = (-2147483647);
				final v109 = 0xFFFFFFFF;
				H.out("o110 " + Std.string(a40));
			} else {
				H.out("o111 " + Std.string(268));
			}
		} else {
			final v112:String = StringTools.trim("\\");
		}
		if ((Std.isOfType(new C24(), C24) || false)) {
			var v113:Float = a40;
			final lf114:(String) -> Int = function(p115:String):Int {
				H.tick();
				var v116:A5 = (420453685 : A5);
				H.out("o117 " + p115);
				return ([false]).indexOf(true);
			};
			var v118 = ("  pad  ").replace("a", "b");
		}
		(new C12(StringTools.lpad("\x41\x42", "*", 3), (Std.parseInt("  pad  ") ?? 0))).m18(13, a40);
		var w119 = 0;
while (w119 < 5 && false) {
			w119++;
			H.tick();
			(new C12("é", (-2147483647))).m21(Math.sin(a40), StringTools.contains("a", "\u{1F600}"));
			var v120:Array<Int> = [136, 170];
			var v121:Bool = (E0.E0A).match(E0A);
		}
		return a40;
	}
	public static function fn41(a42:Bool, a43:E0):Array<Int> {
		H.tick();
		final v122:() -> Bool = function():Bool {
			H.tick();
			var v123:String = "\n";
			var v124:Float = 0.1;
			return Math.isNaN(v124);
		};
		if (("A-B-C" >= "Haxe")) return ((false ? [0xFFFFFFFF, 127, 0x7FFFFFFF] : [298, 69]) : Array<Int>);
		final v125:String = (("\x41\x42").split(" ")).join(",");
		switch (({x3: 295, x4: 154} : S2)) {
			case {x3: c126}: {
				function lf127(n128:Int):Int {
					H.tick();
					return n128 <= 0 ? (Std.parseInt(Std.string(n128)) ?? 0) : (lf127(n128 - 1) + n128);
				}
				H.out("lf127 " + lf127(1));
			};
		}
		final v129:Array<Int> = [2081724235];
		var w130 = 0;
while (w130 < 5 && (cast (a42) : Bool)) {
			w130++;
			H.tick();
			switch (StringTools.lpad("Haxe", "*", (287 & 7))) {
				case "a" | "b": {
					H.out("o131 " + Std.string(0x80000000));
				};
				case "Haxe": {
					H.out("o132 " + Std.string(new Box<E0>(a43)));
				};
				case "": {
					H.out("o133 " + Std.string(E1.E1A));
					H.out("o134 " + v125);
				};
				case _: {
					(new C12(v125, 153)).m18((-13), 3.0);
					var v135:C12 = new C12(v125, 24);
				};
			}
			for (i136 in 1...H.lim(720385176)) {
				H.tick();
				final v137:() -> String = Main.fn30.bind((p138:Int, p139:Bool) -> 198);
				final v140:Null<Int> = i136;
				H.out("o141 " + Std.string(i136));
			}
			var v142:Array<Int> = ([] : Array<Int>);
		}
		return (((true && (v129).contains(43)) ? v129 : ([] : Array<Int>)) : Array<Int>);
	}
	public static function fn44(a45:Bool, a46:String, a47:Int):Int {
		H.tick();
		++a47;
		final lf143:() -> String = () -> a46;
		var v144:Array<Float> = (([] : Array<Float>)).slice((a47 & 7), (a47 & 7));
		var v145 = (false ? 239 : a47);
		v145 -= (([a47, v145, 63]).contains(a47) ? (a46).lastIndexOf("a\rb") : (a47 += 3));
		H.out("o146 " + StringTools.hex((([a47]).length) & 0xFFFF, 4));
		return a47;
	}
	public static function section0():Void {
		H.tick();
		var v170:Int = ((({x3: 1e100, x4: (-2147483647)} : S2)).x4 - Reflect.compare("a", "\"q\""));
		H.out("o171 " + Std.string((Std.parseInt(Std.string(v170)) ?? 0)));
		H.out("o172 " + Std.string(47));
		final v173:() -> Void = function():Void {
			H.tick();
			final v174:() -> Int = function():Int {
				H.tick();
				var v175:Int = v170;
				var v176:Array<Int> = ([] : Array<Int>);
				return v170;
			};
		};
		Main.fn30((p177:Int, p178:Bool) -> v170);
		var v179:E1 = E1.E1A;
		final v180:Array<String> = [("é").substr((v170 & 7), (v170 & 7))];
		H.out("o181 " + Std.string(v170));
		var w182 = 0;
do {
			w182++;
			H.tick();
			fn38(v179, v170);
			var v183 = H.at([v170, 2, v170], v170, 0);
			(new C12("x,y,z", v170)).m18(v183, 2.5e-3);
		} while (w182 < 1 && false);
	}
	public static function section1():Void {
		H.tick();
		var v184 = false;
		H.out("o185 " + Std.string((({x4: 0x44B4, x3: 123456.789} : S2)).x4));
		for (x186 in ((false ? [v184] : [v184]) : Array<Bool>)) {
			H.tick();
			{
				var v187 = 177;
				var v188 = "abc";
			}
			var v189:Float = 1e3;
			for (x190 in ([] : Array<String>)) {
				H.tick();
				final v191 = 108;
				H.out("o192 " + Std.string(new C24()));
				var v193 = v191;
			}
		}
		for (i194 in 0...0) {
			H.tick();
			var v195 = "\x41\x42";
			if (v184) {
				var v196:Box<Int> = new Box(201);
				var v197 = v195;
				final v198 = v197;
			} else {
				final v199:() -> String = function():String {
					H.tick();
					H.out("o200 " + v195);
					return v195;
				};
			}
		}
		final v201:C24 = new C24();
		H.out("o202 " + Std.string((Reflect.compare(289, 15) >>> (283 & 31))));
		H.out("o203 " + Std.string(([] : Array<Int>)));
		var v204:Int = (new A5(76)).twice;
		if (v184) {
			H.out("o205 " + Std.string(E0.E0A));
		} else {
			H.out("o206 " + Std.string(H.at(([] : Array<Int>), v204, 0)));
			if (v184) {
				var v207:Float = v204;
				v184 = H.id(v184);
				v204 ^= v204;
			} else {
				H.out("o208 " + Std.string([v204, v204, v204]));
				final v209 = v204;
			}
		}
	}
	public static function section2():Void {
		H.tick();
		var v210:Array<Bool> = [false];
		var v211:Array<Int> = (["日本語", "日本語", "hello world"]).map((v212:String) -> ([false, true]).indexOf(false));
		var v213:Int = (({x4: 63, x3: 1e-7} : S2)).x4;
		var v214:Float = Std.parseFloat("3");
		H.out("o215 " + Std.string((["0"]).length));
		var v216:Int = v213;
		switch (({x3: Math.sin(7.0), x4: (v213 -= 1)} : S2)) {
			case {x3: c217}: {
				v216 = H.at(v211, 10, 0);
				H.out("o218 " + Std.string(v213));
			};
		}
	}
	public static function section3():Void {
		H.tick();
		var v219:Array<Int> = [108, Reflect.compare("abc", "abc"), (Std.parseInt(Std.string(0xFFFFFFFF)) ?? 0)];
		if (((({x3: 0.1, x4: 1473225334} : S2)).x4 == (new A5(156)).twice)) {
			final v220:Int = (("ünï").charCodeAt(0x48FF) ?? -1);
			for (i221 in 0...0) {
				H.tick();
				var v222 = i221;
			}
		} else {
			var v223:E1 = E1.E1A;
		}
		H.out("o224 " + ([true, false]).join(" "));
		var v225:Int = (Reflect.compare((-2147483647), 207) - 116);
		var v226:Int = ((("a\rb").charCodeAt(182) ?? -1) * v225);
		for (x227 in ((switch (E1.E1A) {
			case E1A: ([] : Array<Float>);
			case _: ([v225, v226, v226] : Array<Float>);
		}) : Array<Float>)) {
			H.tick();
			var w228 = 0;
while (w228 < 5 && Std.isOfType(null, I6)) {
				w228++;
				H.tick();
				(v219).ext49();
				(new C12("\n", 26)).m21(x227, false);
				var v229:Array<Float> = ([v226, v225] : Array<Float>);
			}
			if ((v219).contains(v225)) continue;
		}
		for (i230 in 0...H.lim((switch (("\\").length) {
			case 0: (++v226);
			case 3 | 4: (v226++);
			case _: (["zz"]).indexOf("\"q\"");
		}))) {
			H.tick();
			H.out("o231 " + Std.string(([] : Array<Int>)));
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
