package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

typedef S0 = {x1:Int, x2:Float};

abstract A6(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A6, b:A6):A6
		return new A6(a.get() + b.get());

	@:op(A * B) public static function mul(a:A6, b:A6):A6
		return new A6(a.get() * b.get());

	@:op(-A) public static function neg(a:A6):A6
		return new A6(-a.get());
}

class C8 {
	public var f9:String;
	public var f10:String;
	public function new(a11:String, a12:Float) {
		this.f9 = Std.string(false);
		this.f10 = Std.string(false);
	}
	public function m13(a14:Int):Array<String> {
		H.tick();
		H.out("o51 " + Std.string(a14));
		var v52 = (0x823D - a14);
		H.out("o53 " + Std.string(a14));
		return [for (i54 in ((Math.isNaN(123456.789) ? ([123456.789, v52] : Array<Float>) : ([a14] : Array<Float>)) : Array<Float>)) if ((0x7FFFFFFF == (({x2: i54, x1: v52} : S0)).x1)) ("  pad  " + ([a14]).indexOf(a14))];
	}
	public function m15():String {
		H.tick();
		var v55:Array<String> = ["日本語", this.f10, ([185, (-378051791)]).join("")];
		this.m13(323163167);
		var v56 = ([91, 170, 0x1B61]).indexOf((v55).indexOf("Haxe"));
		v56--;
		H.out("o57 " + Std.string(({x1: Math.round(v56), x2: 0.5} : S0)));
		for (i58 in 0...H.lim(v56)) {
			H.tick();
			for (i59 in 0...4) {
				H.tick();
				var v60:Int = i59;
			}
			try {
				if (true) throw new Err(196);
				final v61:Map<Int, String> = ([-3 => "abc", 4 => "\t"] : Map<Int, String>);
				final v62 = v56;
				var v63:Int = v62;
			} catch (ex64:Dynamic) {
				H.out("caught " + H.exn(ex64));
				var v65:A6 = new A6(i58);
			}
		}
		return (Std.string((("日本語").split(" ")).indexOf("\u{1F600}"))).substring((v56 & 7), ((("zz").length >>> ((Std.parseInt("hello world") ?? 0) & 31)) & 7));
	}
	public function m16(a17:S3):Float {
		H.tick();
		var v66:Int = (-1709741398);
		final v67:String = m15();
		for (x68 in ([] : Array<Int>)) {
			H.tick();
			var v69:Array<Int> = ([] : Array<Int>);
			H.out("o70 " + Std.string(true));
			var v71:String = Std.string(x68);
		}
		final v72:Array<Bool> = [([v66, v66]).contains(v66), false];
		final v73:Float = Math.max(v66, 0.1);
		var v74:String = String.fromCharCode(65 + ((3) & 15));
		v66 = (K7.K7B : Int);
		return v73;
	}
}
