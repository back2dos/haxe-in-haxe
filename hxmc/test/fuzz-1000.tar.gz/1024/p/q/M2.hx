package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

typedef S3 = {x4:Int, x5:Int};

enum abstract K7(Int) to Int {
	var K7A = 1;
	var K7B = 4;
	var K7C = 7;
	var K7D = 10;
}

class C18 {
	public var f19:String;
	public var f20:Float;
	public function new(a21:Int, a22:Int) {
		this.f19 = ("ünï").replace("a", "b");
		this.f20 = a22;
	}
	public function m23(a24:Int):K7 {
		H.tick();
		a24 <<= (((this.f19).charCodeAt(Math.round(a24)) ?? -1) & 7);
		for (i75 in 0...3) {
			H.tick();
			try {
				if (([1084217448, 0xAE53]).contains((-601533211))) throw this.f19;
				final v76:Bool = true;
				(new C8("ab", i75)).m15();
				a24 = 898401056;
			} catch (ex77:String) {
				H.out("caught String " + ex77);
				H.out("o78 " + Std.string(i75));
				final v79:String = ex77;
			} catch (ex80:Int) {
				H.out("caught Int " + ex80);
				var v81:Array<String> = ([] : Array<String>);
				H.out("o82 " + Std.string(i75));
			} catch (ex83:Err) {
				H.out("caught Err " + ex83.errCode);
				var v84:Array<Float> = ([] : Array<Float>);
			} catch (ex85:Dynamic) {
				H.out("caught " + H.exn(ex85));
				a24 *= a24;
				final v86 = i75;
			}
		}
		if ((207 <= ("42").lastIndexOf("a"))) {
			H.out("o87 " + "\n");
			if (StringTools.startsWith("é", "42")) return K7.K7C;
		}
		for (i88 in 0...3) {
			H.tick();
			if (true) {
				var v89 = "é";
				var v90:Float = i88;
			} else {
				final v91:C8 = new C8("hello world", i88);
				this.f20 = a24;
			}
			var v92:Float = 1e3;
		}
		a24 += a24;
		for (x93 in ([] : Array<Int>)) {
			H.tick();
			for (i94 in 0...H.lim(30)) {
				H.tick();
				var v95 = true;
				a24 = x93;
				var v96:Bool = false;
			}
			(new C8("Haxe", a24)).m15();
			H.out("o97 " + Std.string(([] : Array<Int>)));
		}
		var v98:String = ("q" + (K7.K7B : Int));
		return K7.K7D;
	}
	public function m25():Int {
		H.tick();
		H.out("o99 " + Std.string((Std.parseInt(("Haxe").toLowerCase()) ?? 0)));
		for (k100 => v101 in new Map<String, Int>()) {
			H.tick();
			if (false) break;
			if (([v101, v101]).contains(v101)) {
				final v102:Array<Int> = [v101];
				this.f19 = H.cap(k100);
				var v103:Int = 288;
			} else {
				var v104:Int = v101;
				v104 = v101;
			}
			var v105 = (K7.K7A : Int);
		}
		H.out("o106 " + Std.string((1e100 + 175)));
		if (false) {
			H.out("o107 " + Std.string(["é", "zz"]));
			var v108:Map<Int, Float> = new Map<Int, Float>();
		} else {
			try {
				if (StringTools.endsWith("日本語", "日本語")) throw this.f19;
				var v109:Float = (-2.5);
			} catch (ex110:Err) {
				H.out("caught Err " + ex110.errCode);
				H.out("o111 " + Std.string(157));
				var v112:Null<Int> = 281;
			} catch (ex113:haxe.Exception) {
				H.out("caught " + H.exn(ex113));
				var v114:Map<String, Float> = (["k0" => 123456.789] : Map<String, Float>);
				(new C8("abc", 1e3)).m16(({x5: 0xFFFFFFFF, x4: 0xC844} : S3));
			}
			if (Math.isNaN(1e3)) return 0x7FFFFFFF;
		}
		if ((false || true)) {
			H.out("o115 " + Std.string((K7.K7B : Int)));
		} else {
			if (false) {
				final v116 = 1464904657;
			} else {
				(new C8("A-B-C", 1.25)).m13(0xF432);
			}
			(new C8("42", 0.1)).m15();
		}
		H.out("o117 " + Std.string(("\u{1F600}" != Std.string(false))));
		var v118 = (Lambda.count(([] : Array<Int>), v119 -> StringTools.startsWith("0", "é")) >>> (((([-3 => (-2147483647), 4 => 165, 11 => 37] : Map<Int, Int>)).get(18) ?? 0) & 31));
		return (Std.parseInt(Std.string(({ var v120 = ("-7").substr((47 & 7), 3); v118; }))) ?? 0);
	}
	public function m26(a27:Int):Int {
		H.tick();
		a27 += a27;
		H.out("o121 " + Std.string((([a27, 8, a27]).indexOf(a27) - H.at([a27, a27], a27, 0))));
		var v122:K7 = K7.K7D;
		if ((("\x41\x42").charAt((a27 & 7)) <= "Haxe")) {
			if (true) {
				H.out("o123 " + Std.string(0xDF0E));
				var v124 = "hello world";
			} else {
				var v125:Array<String> = ["\u{1F600}", "-7"];
			}
		} else {
			var w126 = 0;
do {
				w126++;
				H.tick();
				a27 |= a27;
				var v127 = "42";
			} while (w126 < 3 && true);
		}
		return a27;
	}
}
