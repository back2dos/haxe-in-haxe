package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext50(a49:Int):Int {
		H.tick();
		H.out("o241 " + Std.string((Std.parseInt("zz") ?? 0)));
		a49 -= Math.round(123456.789);
		var v242:Int = (~75);
		var v243:Int = ((("").charCodeAt(a49) ?? -1) >>> (H.at(([] : Array<Int>), v242, 0) & 31));
		try {
			H.out("o244 " + Std.string(true));
			if ((a49 >= v242)) throw new Err(243);
		} catch (ex245:Dynamic) {
			H.out("caught " + H.exn(ex245));
			var v246 = ((new Map<Int, Int>()).get(v242) ?? 0);
			H.out("o247 " + Std.string((new A6((-18)) : Int)));
		}
		final v248:Int = v242;
		for (i249 in 0...2) {
			H.tick();
			for (k251 => x250 in ["ünï"]) {
				H.tick();
				var v252:Null<Int> = v242;
			}
			var v253:Array<Int> = ([] : Array<Int>);
			var v254:Int = Math.floor(a49);
		}
		final v255:String = ("A-B-C" + "é");
		var v256:Int = v243;
		return v256;
	}
}
