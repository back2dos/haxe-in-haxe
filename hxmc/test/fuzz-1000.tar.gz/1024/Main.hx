import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class Main {
	public static function fn28(a29:S0):Void {
		H.tick();
		var v128:S3 = ({x4: (K7.K7C : Int), x5: 0x7FFFFFFF} : S3);
		for (i129 in 1...H.lim(80)) {
			H.tick();
			var v130:C8 = new C8("ab", i129);
			var w131 = 0;
while (w131 < 2 && false) {
				w131++;
				H.tick();
				(new C18(i129, i129)).m25();
			}
		}
		var v132:String = (StringTools.replace("\t", "a", "ab")).charAt(1);
		final v133:Array<String> = (new C8("é", 2.5e-3)).m13((("日本語").charCodeAt(225) ?? -1));
		try {
			H.out("o134 " + Std.string([258, 28, 75]));
			if (StringTools.endsWith(v132, v132)) throw 52;
		} catch (ex135:Dynamic) {
			H.out("caught " + H.exn(ex135));
			H.out("o136 " + Std.string(([123456.789, 0.5] : Array<Float>)));
			v133.sort(Reflect.compare);
		}
		v132 = H.cap(v132 + '-${Std.string(false)} = ${Std.string(StringTools.startsWith(v132, "日本語"))}');
		final v137:Array<Bool> = ([] : Array<Bool>);
		var v138:Map<String, Map<Int, Int>> = (["k0" => new Map<Int, Int>(), "k1" => new Map<Int, Int>(), "k2" => ([-3 => 193, 4 => (-10)] : Map<Int, Int>)] : Map<String, Map<Int, Int>>);
	}
	public static function fn30(a31:Int, a32:Int, ...r33:Int):Bool {
		H.tick();
		if ((1e-7 <= 1.7976931348623157e308)) return !StringTools.startsWith("0", "\"q\"");
		(new C8(("").charAt(((-513441314) & 7)), a32)).m15();
		for (x139 in r33.toArray()) {
			H.tick();
			final v140:S0 = ({x1: x139, x2: 0.5} : S0);
			if ((r33.toArray()).contains(x139)) {
				var v141:String = "  pad  ";
			}
		}
		for (i142 in 0...1) {
			H.tick();
			H.out("o143 " + Std.string(({x1: i142, x2: a31} : S0)));
			var v144:Array<Array<Int>> = ([] : Array<Array<Int>>);
		}
		if (StringTools.contains("ünï", "-7")) {
			for (i145 in 0...H.lim(Math.floor(100.75))) {
				H.tick();
				var v146:String = "42";
				var v147:Null<Int> = a32;
				var v148:C18 = new C18(13, a31);
			}
		} else {
			final v149:Map<Int, Int> = ([-3 => 17, 4 => a31] : Map<Int, Int>);
		}
		return true;
	}
	public static function fn34(a35:Int, a36:Int):String {
		H.tick();
		for (x150 in ([a35] : Array<Float>)) {
			H.tick();
			a35 = 190;
		}
		if ((0xFF64 == a36)) {
			(new C18(a35, 206)).m25();
			var v151:A6 = new A6(1850219999);
		} else {
			var v152:Map<String, Int> = new Map<String, Int>();
		}
		var v153:Bool = (a36 > 285);
		if (v153) {
			(new C8("A-B-C", a36)).m15();
			var v154 = ("Haxe").charAt(1);
		}
		var w155 = 0;
do {
			w155++;
			H.tick();
			if ((([] : Array<Int>)).contains(a35)) {
				var v156:Int = a36;
				(new C18(0x73B3, (-1822023038))).m25();
				v156 ^= a35;
			} else {
				var v157:Map<String, String> = (["k0" => "x,y,z"] : Map<String, String>);
			}
			final v158:Float = Std.parseFloat("3");
		} while (w155 < 2 && ({ var v159 = "hello world"; false; }));
		if ((a36 <= 7.0)) {
			a35 <<= (a36 & 7);
			final v160 = "\u{1F600}";
		} else {
			var v161:Map<String, Int> = (["k0" => a36, "k1" => (-1003639405)] : Map<String, Int>);
		}
		if (v153) {
			a35 = H.id(a35);
			var v162 = Std.string(v153);
			(new C18(a36, a36)).m23(0x2425);
		} else {
			var v163:Int = (["abc", "a", "\u{1F600}"]).indexOf("\n");
		}
		return ((213 > 1e-7) ? '${Std.string(true)}' : (("hello world").replace("a", "b") + "\"q\""));
	}
	public static function fn37():Bool {
		H.tick();
		for (x164 in [for (i165 in 0...3) (({x1: i165, x2: i165} : S0)).x1]) {
			H.tick();
			try {
				var v166:Array<Int> = [x164, 0xD84F, x164];
				if (false) continue;
				var v167:Array<Int> = v166;
				if (true) throw "boom";
			} catch (ex168:Err) {
				H.out("caught Err " + ex168.errCode);
				var v169:Array<Int> = [x164, 0x80000000, x164];
			} catch (ex170:haxe.Exception) {
				H.out("caught " + H.exn(ex170));
				var v171:Array<C18> = ([new C18(118, 250)] : Array<C18>);
				var v172 = "0";
			}
			for (k174 => x173 in ["\"q\"", "\t", "a\rb"]) {
				H.tick();
				Main.fn30(x164, k174);
				fn34(x164, 214);
				H.out("o175 " + "  pad  ");
			}
		}
		H.out("o176 " + ((([-3 => 3.0, 4 => 1e21] : Map<Int, Float>)).exists(11) + String.fromCharCode(65 + ((81) & 15))));
		final v177:A6 = (-new A6(0x7FFFFFFF));
		final v178:(Int) -> Int = (p179:Int) -> p179;
		final v180 = false;
		for (i181 in 0...0) {
			H.tick();
			for (i182 in 0...1) {
				H.tick();
				final v183 = "zz";
			}
			H.out("o184 " + Std.string(false));
			var v185:Null<Int> = i181;
		}
		for (x186 in (["zz"]).slice(-2, -1)) {
			H.tick();
			var w187 = 0;
do {
				w187++;
				H.tick();
				fn34(31, 1251810401);
			} while (w187 < 2 && false);
		}
		return (fn30(((new Map<String, Int>()).get("k2") ?? 0), Math.round(2.5e-3)) ? ((["k0" => v180, "k1" => v180, "k2" => v180] : Map<String, Bool>)).exists("k1") : v180);
	}
	public static function fn38(a39:Null<Int>, a40:Int):S3 {
		H.tick();
		var v188:Array<C18> = ([new C18(252, 197), new C18(a40, a40), new C18(a40, a40)] : Array<C18>);
		try {
			if (StringTools.contains(StringTools.replace("a\rb", "b", "\\"), String.fromCharCode(65 + ((260) & 15)))) throw 60;
			a40 = 288;
			var v189:S0 = ({x1: 204, x2: a40} : S0);
		} catch (ex190:Dynamic) {
			H.out("caught " + H.exn(ex190));
			var v191:A6 = (280 : A6);
			H.out("o192 " + Std.string(Std.parseFloat("3")));
		}
		var v193 = StringTools.replace(("abc").substring(0, (116 & 7)), " ", Std.string(a40));
		if (Main.fn37()) return ({x5: Std.int(a40), x4: a40} : S3);
		{
			H.out("o194 " + ("a").charAt(0));
			var w195 = 0;
while (w195 < 1 && StringTools.endsWith(v193, v193)) {
				w195++;
				H.tick();
				Main.fn30(a40, 117);
				if (true) break;
				if (true) break;
			}
			if (StringTools.endsWith("zz", v193)) {
				var v196:Array<Int> = [a40];
				H.out("o197 " + "0");
				a40 = H.id(a40);
			}
		}
		{
			try {
				if (true) throw new Err(44);
				H.out("o198 " + Std.string((new A6(208) : Int)));
				final v199:Int = a40;
			} catch (ex200:Err) {
				H.out("caught Err " + ex200.errCode);
				var v201 = 133;
			} catch (ex202:haxe.Exception) {
				H.out("caught " + H.exn(ex202));
				(new C18(a40, a40)).m23(a40);
			}
			Main.fn34(132, (([] : Array<Float>)).length);
		}
		return ({x4: (a40 & (v193).indexOf("a")), x5: H.at(([] : Array<Int>), 232, 0)} : S3);
	}
	public static function fn41(a42:Int, a43:Int):Void {
		H.tick();
		a43++;
		var w203 = 0;
while (w203 < 5 && (133 <= (new A6(a43) : Int))) {
			w203++;
			H.tick();
			var v204:Array<String> = ["42", "\"q\"", "ab"];
			H.out("o205 " + Std.string((new A6(a43) : Int)));
		}
		var v206:Map<String, Array<Bool>> = (["k0" => [false, true, true], "k1" => [false, true], "k2" => [false]] : Map<String, Array<Bool>>);
		a43 |= a43;
		(new C8(Std.string(a43), 2.5e-3)).m13((("x,y,z").replace("a", "b")).length);
	}
	public static function fn44(?a45:Null<Int>):Int {
		H.tick();
		var v207 = 186;
		for (x208 in ([v207] : Array<Float>)) {
			H.tick();
			var v209 = (("\x41\x42").charCodeAt(46) ?? -1);
		}
		final v210:Map<String, Float> = (["k0" => 1.25, "k1" => v207] : Map<String, Float>);
		{
			Main.fn30(v207, (Std.parseInt("42") ?? 0), (({x1: 65535, x2: v207} : S0)).x1, (K7.K7C : Int));
			var v211:C8 = new C8("\\", (-2.5));
			a45 = null;
		}
		v207 = (Std.parseInt("\t") ?? 0);
		Main.fn37();
		return v207;
	}
	public static function fn46():Array<String> {
		H.tick();
		try {
			if ((115 <= Reflect.compare(65535, 271))) throw "boom";
			H.out("o212 " + Std.string(({x4: 146, x5: 219} : S3)));
			H.out("o213 " + "é");
			H.out("o214 " + "\x41\x42");
		} catch (ex215:Err) {
			H.out("caught Err " + ex215.errCode);
			{
				var v216 = 0x80000000;
				v216 += 0x44;
				v216 = H.id(v216);
			}
			for (i217 in 0...H.lim((Std.parseInt("é") ?? 0))) {
				H.tick();
				var v218:Array<Int> = [i217, 162, 97];
				H.out("o219 " + Std.string(65535));
			}
		} catch (ex220:haxe.Exception) {
			H.out("caught " + H.exn(ex220));
			var v221:String = "x,y,z";
		}
		H.out("o222 " + Std.string(({x4: ((([-3 => 154, 4 => 107] : Map<Int, Int>)).get(-3) ?? 0), x5: H.at([92, 31, 1215209911], 106, 0)} : S3)));
		for (i223 in 0...0) {
			H.tick();
			var v224:C18 = new C18(48, i223);
			final v225:S0 = ({x1: i223, x2: i223} : S0);
			var v226:String = ([true, true]).join("|");
		}
		var v227 = true;
		{
			for (i228 in 0...H.lim((Std.parseInt(Std.string((-7))) ?? 0))) {
				H.tick();
				(new C8("Haxe", i228)).m13(i228);
				(new C18(48, i228)).m23(i228);
			}
		}
		Main.fn41(207, (-1144958305));
		var v229:Array<Float> = (([0.5, 100.75, 0.1] : Array<Float>)).copy();
		return [for (i230 in 0...3) "日本語"];
	}
	public static function fn47(a48:Float):() -> Void {
		H.tick();
		var v231:Map<String, Bool> = new Map<String, Bool>();
		fn44(((((["k0" => 0xD18, "k1" => 52] : Map<String, Int>)).get("\n") ?? 0) & (Std.parseInt("\x41\x42") ?? 0)));
		for (k232 => v233 in new Map<String, Int>()) {
			H.tick();
			final v234:Int = 133;
			if (false) {
				var v235:String = k232;
				Main.fn41(0x7FFFFFFF, v234);
				final v236 = false;
			} else {
				var v237:Bool = false;
				(new C8("ab", 3.0)).m16(({x4: v233, x5: v233} : S3));
			}
		}
		return function():Void {
			H.tick();
			var v238:C18 = new C18(68, 165);
			H.out("o239 " + Std.string([282, 0x5C90]));
			H.out("o240 " + StringTools.lpad("42", "*", (1104500606 & 7)));
		};
	}
	public static function section0():Void {
		H.tick();
		H.out("o257 " + Std.string(((new Map<String, S0>()).exists("k2") ? 71 : ([""]).indexOf("\"q\""))));
		H.out("o258 " + Std.string((new C18(15, (-16))).m26(Math.ceil(1.25))));
		H.out("o259 " + Std.string((K7.K7A : Int)));
	}
	public static function section1():Void {
		H.tick();
		var v260:K7 = K7.K7C;
		if (([65535]).contains(Lambda.count([133], v261 -> ([v261]).contains(108)))) {
			var v262 = ([690088675]).length;
		}
		var v263:C18 = new C18(189, (({x4: (-3), x5: 88} : S3)).x4);
		final v264:String = "ab";
		var v265 = (([] : Array<Int>)).contains(0x80000000);
		var v266:Array<Int> = [for (i267 in ([] : Array<Int>)) if (false) 269];
		for (k269 => x268 in ([1e3] : Array<Float>)) {
			H.tick();
			var v270:String = Std.string(true);
		}
		var v271 = v265;
	}
	public static function section2():Void {
		H.tick();
		for (i272 in 0...0) {
			H.tick();
			var v273:Bool = StringTools.contains("hello world", "hello world");
		}
		final v274 = ({ var sb275 = new StringBuf(); sb275.add(Std.string(0x80000000)); sb275.add(String.fromCharCode(65 + ((102) & 15))); sb275.add(Std.string(0x80000000)); sb275.addChar(75); sb275.toString(); });
		for (i276 in 0...4) {
			H.tick();
			var v277:S0 = ({x1: 104, x2: i276} : S0);
			var w278 = 0;
do {
				w278++;
				H.tick();
				var v279:Map<String, Array<C18>> = new Map<String, Array<C18>>();
			} while (w278 < 1 && false);
			(new C8(v274, 100.75)).m16(({x5: i276, x4: 54} : S3));
		}
		var v280:Float = 0.1;
		var v281:Array<Null<Int>> = ([for (i282 in 0...2) i282] : Array<Null<Int>>);
		var v283:C8 = new C8(v274, 223);
		H.out("o284 " + Std.string(new C18(("").indexOf("q"), ((new Map<Int, Int>()).get(18) ?? 0))));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
