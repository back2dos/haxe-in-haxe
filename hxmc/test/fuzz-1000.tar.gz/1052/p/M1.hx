package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
	E0B(a2:String, a3:Int);
	E0C;
	E0D(a4:Int);
}

typedef S5 = {x6:String, x7:Int};

interface I13 {
	function m14():Void;
	function m15(a16:Int, a17:Array<Int>):Int;
}

class C18 implements I13 {
	public var f19:String;
	public function new(a20:Bool, a21:String) {
		this.f19 = "a";
	}
	public function m14():Void {
		H.tick();
		function lf75(n76:Int):Int {
			H.tick();
			return n76 <= 0 ? n76 : (lf75(n76 - 1) + n76);
		}
		H.out("lf75 " + lf75(3));
		if ((176 < Type.enumIndex(E0A))) {
			H.out("o77 " + Std.string(("ünï").indexOf("abc")));
		} else {
			var v78:String = Std.string(253);
		}
		C22.f24 = (this.f19).indexOf("\t");
		var v79 = Reflect.compare(C22.f24, 0xFFFFFFFF);
		final v80:Map<Int, A8> = ([-3 => new A8(v79), 4 => new A8(v79), 11 => new A8(v79)] : Map<Int, A8>);
		for (i81 in 2...H.lim(((({x6: "ünï", x7: v79} : S5)).x7 * 177))) {
			H.tick();
			var v82:Map<Int, Bool> = ([-3 => true] : Map<Int, Bool>);
			H.out("o83 " + Std.string(new C22(v79, i81)));
		}
		try {
			if (((((["k0" => v79, "k1" => v79] : Map<String, Int>)).get("k3") ?? 0) < (({x6: "\t", x7: 178} : S5)).x7)) throw "boom";
			{
				v79 = H.id(v79);
				C22.f24 = 291;
			}
			var v84:S5 = ({x6: "\n", x7: 271} : S5);
			final v85:Array<Bool> = [true, false, false];
		} catch (ex86:Dynamic) {
			H.out("caught " + H.exn(ex86));
			H.out("o87 " + Std.string(([new C40([v79, 220, 1840928166], false), new C40(([] : Array<Int>), false)] : Array<C40>)));
		}
		var v88:String = "a\rb";
	}
	public function m15(a16:Int, a17:Array<Int>):Int {
		H.tick();
		H.out("o89 " + (false ? "-7" : StringTools.lpad("A-B-C", "*", (a16 & 7))));
		if (((a17).contains(a16) || false)) {
			switch (E0.E0D(a16)) {
				case E0A: {
					H.out("o90 " + "ünï");
				};
				case E0B(c91, _): {
					a16 = H.id(a16);
					H.out("o92 " + Std.string(new C22(a16, a16)));
				};
				case E0C: {
					var v93:Array<Bool> = [true];
				};
				case E0D(2 | 4): {
					final v94:E0 = E0.E0C;
				};
				case _: {
					var v95:Bool = true;
					(a17).ext71(a16);
				};
			}
			for (i96 in 0...0) {
				H.tick();
				m14();
			}
			H.out("o97 " + this.f19);
		}
		for (i98 in 0...1) {
			H.tick();
			var v99:S5 = ({x7: i98, x6: "\x41\x42"} : S5);
			if (true) {
				H.out("o100 " + "日本語");
				a16 <<= (i98 & 7);
			}
			var v101:String = "q";
		}
		a16 &= ((a17).contains(a16) ? a16 : a16);
		var v102:Array<S5> = ([] : Array<S5>);
		for (i103 in 2...4) {
			H.tick();
			var v104:Int = 65535;
		}
		if ((274 != C22.f24)) {
			for (i105 in 0...2) {
				H.tick();
				var v106:A8 = new A8(190);
			}
			for (i107 in 0...2) {
				H.tick();
				a17 = H.capa([a16]);
			}
			var v108:Int = 83;
		}
		final lf109:(String, String) -> String = function(p110:String, p111:String):String {
			H.tick();
			for (i112 in 0...H.lim(a16)) {
				H.tick();
				var v113:Map<Int, String> = ([-3 => "a"] : Map<Int, String>);
			}
			return p111;
		};
		var w114 = 0;
do {
			w114++;
			H.tick();
			var v115:Map<String, Int> = (["k0" => a16] : Map<String, Int>);
			a16 = C22.f24;
		} while (w114 < 2 && C33.f35);
		return ((C22.f24 != (Std.parseInt("a") ?? 0)) ? (a16 % H.nz(a16)) : a16);
	}
}

class C22 extends C18 {
	public var f23:String;
	public static var f24:Int = 19;
	public function new(a25:Int, a26:Int) {
		super(C33.f35, ("").substring((12 & 7), 1));
		this.f23 = String.fromCharCode(65 + ((198) & 15));
	}
	public function m27(a28:String, a29:Int):String {
		H.tick();
		H.out("o116 " + "Haxe");
		m15(247, [for (i117 in 0...1) (a28).indexOf("0")]);
		C33.m36(a29, 65535, a29);
		var v118:Int = (a29 >>> ((({x6: "Haxe", x7: a29} : S5)).x7 & 31));
		var v119 = StringTools.contains(a28, Std.string(E0B("-7", v118)));
		return Std.string((v119 && (([] : Array<Int>)).contains(a29)));
	}
	public function m30(a31:Bool):Void {
		H.tick();
		switch (StringTools.trim(("A-B-C").substr(4, -2))) {
			case "a" | "b": {
				var v120:A8 = new A8(121);
				(new C33()).m39();
			};
			case "Haxe": {
				(new C33()).m39();
			};
			case _: {
				var v121:String = ("abc").toUpperCase();
			};
		}
		var w122 = 0;
while (w122 < 1 && C33.f35) {
			w122++;
			H.tick();
			C22.f24 *= H.at([268], 87, 0);
			switch (("\\").indexOf("\n")) {
				case 0: {
					var v123:Map<String, String> = (["k0" => "a", "k1" => "\"q\"", "k2" => "abc"] : Map<String, String>);
					([135, (-10)]).ext74(a31);
				};
				case 1 | 6: {
					H.out("o124 " + Std.string(a31));
					H.out("o125 " + Std.string(0x5480));
				};
				case _: {
					H.out("o126 " + Std.string(224));
				};
			}
			var v127:Array<String> = ([] : Array<String>);
		}
		{
			C22.f24 = (new A8(170) : Int);
			try {
				if (true) throw "x,y,z";
				(new C40([31, 298], a31)).m14();
				var v128:Int = 9;
			} catch (ex129:String) {
				H.out("caught String " + ex129);
				H.out("o130 " + Std.string(33));
			} catch (ex131:Int) {
				H.out("caught Int " + ex131);
				var v132:Int = ex131;
				C22.f24 = v132;
			} catch (ex133:Err) {
				H.out("caught Err " + ex133.errCode);
				var v134:String = "\t";
				var v135:A8 = new A8(9);
			} catch (ex136:Dynamic) {
				H.out("caught " + H.exn(ex136));
				C22.f24 <<= (65 & 7);
			}
		}
		function lf137(n138:Int):Int {
			H.tick();
			return n138 <= 0 ? n138 : (lf137(n138 - 1) + n138);
		}
		H.out("lf137 " + lf137(5));
	}
	public function m32():Array<String> {
		H.tick();
		C33.m36(C22.f24);
		final v139:Map<Int, A8> = ([-3 => new A8(1330764954)] : Map<Int, A8>);
		m14();
		return [for (i140 in ([291, 182, 50]).copy()) if (true) (("\"q\"").substr(2, (i140 & 7))).toUpperCase()];
	}
}

class C40 implements I13 {
	public var f41:String;
	public var f42:E0;
	public var f43:Int;
	public function new(a44:Array<Int>, a45:Bool) {
		this.f41 = StringTools.lpad("x,y,z", "*", -2);
		this.f42 = E0.E0B("\n", 245);
		this.f43 = ("\u{1F600}").indexOf("A-B-C");
	}
	public function m14():Void {
		H.tick();
		var v152:S5 = ({x6: ("a\rb").replace("a", "b"), x7: ("  pad  ").lastIndexOf("日本語")} : S5);
		v152 = H.id(v152);
		var v153:Int = (77 << ((("a").charCodeAt(0) ?? -1) & 31));
		var v154:A8 = (new A8(v153) * new A8(v153));
		for (x155 in [for (i156 in 0...1) Std.string(v153)]) {
			H.tick();
			this.f43++;
			final v157:Map<String, Bool> = new Map<String, Bool>();
		}
		try {
			if ((E0.E0D(659628467)).match(E0C)) throw 39;
			if (true) {
				var v158:Int = 664533362;
				H.out("o159 " + Std.string(E0.E0C));
			} else {
				this.f43 -= 52;
				H.out("o160 " + "a");
			}
		} catch (ex161:Dynamic) {
			H.out("caught " + H.exn(ex161));
			for (i162 in 2...5) {
				H.tick();
				if (true) break;
				final v163:Array<Int> = [0x94E8, v153];
			}
		}
		H.out("o164 " + Std.string(v153));
		H.out("o165 " + Std.string(v152));
	}
	public function m15(a16:Int, a17:Array<Int>):Int {
		H.tick();
		var v166:String = ((([-3 => "abc", 4 => "\u{1F600}"] : Map<Int, String>)).exists(a16) + this.f41);
		var v167 = ((new A8(a16)).twice == ((new Map<Int, Int>()).get(-3) ?? 0));
		var v168:Array<Bool> = ((switch (E0.E0D(a16)) {
			case E0A: [v167];
			case E0B(c169, _): ([] : Array<Bool>);
			case E0C: [v167, v167, v167];
			case E0D(c170): [v167, v167, v167];
			case _: [v167, v167, v167];
		}) : Array<Bool>);
		var w171 = 0;
while (w171 < 5 && false) {
			w171++;
			H.tick();
			Main.fn52(E0.E0A, this.f42);
			var v172:Bool = v167;
		}
		v168.push(v167);
		var v173 = 'x${v166}<${Std.string(120)}-${StringTools.trim(v166)}';
		H.out("o174 " + Std.string(({x7: (v166).length, x6: this.f41} : S5)));
		try {
			for (x175 in [v167, true]) {
				H.tick();
				Main.fn49();
			}
			if (false) throw new Err(a16);
		} catch (ex176:Dynamic) {
			H.out("caught " + H.exn(ex176));
			if (false) {
				var v177:S5 = ({x6: v173, x7: 159} : S5);
				if (a17.length > 0) a17[H.ix(a16, a17.length)] = (-3);
			} else {
				a16 = H.id(a16);
				C33.m36(a16);
			}
			this.f43 &= 281;
		}
		return ((("ünï").charCodeAt(a16) ?? -1) & (switch (E0C) {
			case E0A: (a17).indexOf(a16);
			case E0B(c178, _): a16;
			case E0C: 0x242;
			case E0D(c179): a16;
		}));
	}
	public function m46(a47:Bool, a48:String):Bool {
		H.tick();
		if (true) {
			H.out("o180 " + Std.string(a47));
			var v181:Array<String> = [a48];
			var v182:E0 = this.f42;
		} else {
			C22.f24++;
			Main.fn49();
		}
		this.f42 = E0.E0C;
		try {
			{ var dyn183:Dynamic = ({x6: a48, x7: 123} : S5); H.out("dyn " + Std.string(dyn183.x6) + " " + Std.string(Reflect.field(dyn183, "x6"))); }
			if (a47) throw "boom";
		} catch (ex184:String) {
			H.out("caught String " + ex184);
			var v185 = Type.enumIndex(E0.E0A);
		} catch (ex186:Int) {
			H.out("caught Int " + ex186);
			H.out("o187 " + Std.string(ex186));
			var v188 = ex186;
		} catch (ex189:Err) {
			H.out("caught Err " + ex189.errCode);
			try {
				if (false) throw "q";
				this.f43 = 75;
			} catch (ex190:String) {
				H.out("caught String " + ex190);
				var v191 = true;
				H.out("o192 " + ex190);
			} catch (ex193:Int) {
				H.out("caught Int " + ex193);
				this.f43 -= ex193;
				var v194:S5 = ({x6: a48, x7: ex193} : S5);
			} catch (ex195:Err) {
				H.out("caught Err " + ex195.errCode);
				var v196 = true;
				var v197:Array<Int> = [185];
			} catch (ex198:Dynamic) {
				H.out("caught " + H.exn(ex198));
				C22.f24 |= 206;
			}
		} catch (ex199:Dynamic) {
			H.out("caught " + H.exn(ex199));
			switch (E0C) {
				case E0A: {
					Ext.ext71([35, (-16)], 188);
				};
				case E0B(c200, 0 | 5): {
					var v201:E0 = E0C;
					var v202:Array<String> = [c200, c200, c200];
				};
				case E0C: {
					final v203:Int = (-14);
				};
				case E0D(c204): {
					var v205:Array<Bool> = ([] : Array<Bool>);
				};
				case _: {
					final v206 = (-6);
					C22.f24 |= 223989673;
				};
			}
		}
		H.out("o207 " + Std.string(((new A8(180) : Int) ^ 291)));
		this.f43 = (new A8(51) : Int);
		try {
			if ((switch (E0C) {
				case E0A: a47;
				case E0B(c208, c209): false;
				case E0C: false;
				case E0D(1 | 3): true;
				case _: false;
			})) throw (Std.string(E0.E0C)).replace("a", "b");
			if (false) {
				H.out("o210 " + a48);
			}
			final v211:Map<String, Int> = (["k0" => 242, "k1" => 0x773D, "k2" => (-12)] : Map<String, Int>);
		} catch (ex212:String) {
			H.out("caught String " + ex212);
			final v213:Array<String> = [a48, ex212];
		} catch (ex214:Int) {
			H.out("caught Int " + ex214);
			var v215:Array<String> = ("\n").split(",");
			var v216:I13 = new C40([ex214, 88], true);
		} catch (ex217:Err) {
			H.out("caught Err " + ex217.errCode);
			C22.f24 = (("a").charCodeAt(0x2F7) ?? -1);
			([245, 200, (-4)]).ext74(([240, 173]).contains(141));
		} catch (ex218:Dynamic) {
			H.out("caught " + H.exn(ex218));
			var v219:Bool = (Std.downcast((null : I9), I9) != null);
			(new C22(10, 2051937890)).m30(false);
		}
		var v220:Array<String> = ((a47 ? [a48] : ["\x41\x42"]) : Array<String>);
		switch (E0.E0A) {
			case E0A: {
				var v221 = a48;
				var v222:Map<String, Int> = (["k0" => 75, "k1" => (-2147483647)] : Map<String, Int>);
			};
			case E0B(c223, 1 | 4): {
				H.out("o224 " + Std.string(C33.f35));
				var v225:E0 = E0B(a48, 222);
			};
			case E0C: {
				(new C22(65535, 20)).m27(a48, (-73802146));
			};
			case E0D(c226) if (c226 > 2): {
				var v227:Int = c226;
				for (k229 => x228 in v220) {
					H.tick();
					H.out("o230 " + a48);
				}
			};
			case _: {
				this.f43 += (new A8(56)).get();
			};
		}
		return false;
	}
}
