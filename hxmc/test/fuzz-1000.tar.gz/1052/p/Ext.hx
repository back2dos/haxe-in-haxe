package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext71(a69:Array<Int>, a70:Int):String {
		H.tick();
		C22.f24 = a70;
		switch (E0.E0B(Std.string(a70), (("zz").charCodeAt(194) ?? -1))) {
			case E0A: {
				a70 -= ("q").indexOf("日本語");
			};
			case E0B(c350, c351): {
				function lf352(n353:Int):Int {
					H.tick();
					return n353 <= 0 ? ([c350, "\u{1F600}"]).length : (lf352(n353 - 1) + ((([-3 => c351] : Map<Int, Int>)).get(11) ?? 0));
				}
				H.out("lf352 " + lf352(5));
				H.out("o354 " + Std.string((E0.E0A).match(E0D(_))));
			};
			case E0C: {
				for (x355 in [false, true]) {
					H.tick();
					H.out("o356 " + Std.string(a70));
					var v357 = a70;
					H.out("o358 " + Std.string(({x7: a70, x6: "Haxe"} : S5)));
				}
				{
					a70 <<= (170 & 7);
					final v359:S5 = ({x6: "", x7: a70} : S5);
				}
			};
			case E0D(c360): {
				C22.f24 = c360;
				var v361 = 251;
			};
			case _: {
				for (k363 => x362 in a69) {
					H.tick();
					var v364:Map<String, String> = new Map<String, String>();
					var v365:E0 = E0.E0A;
				}
				if (Std.isOfType(new C18(false, "42"), I13)) {
					var v366 = a70;
					var v367 = a70;
				}
			};
		}
		var v368:Int = a70;
		H.out("o369 " + Std.string(E0.E0B((["\"q\"", "é", "  pad  "]).join(","), 286)));
		H.out("o370 " + Std.string(24));
		if (StringTools.endsWith("42", StringTools.replace("\u{1F600}", ",", "zz"))) {
			try {
				if (Std.isOfType(new C33(), C33)) throw Std.string(true);
				H.out("o371 " + Std.string(false));
				var v372 = 0x80000000;
			} catch (ex373:Dynamic) {
				H.out("caught " + H.exn(ex373));
				H.out("o374 " + Std.string([false, false, true]));
			}
			H.out("o375 " + Std.string(new C40(a69, false)));
		}
		H.out("o376 " + Std.string(true));
		var v377:Map<String, String> = (["k0" => Std.string(E0.E0A), "k1" => ("q").toUpperCase(), "k2" => "Haxe"] : Map<String, String>);
		return (switch (E0.E0C) {
			case E0A: (Std.isOfType(null, I9) + "é");
			case E0C: ("A-B-C").substring((C22.f24 & 7), (192 & 7));
			case E0D(c378): (("A-B-C").substr(6, (379465329 & 7))).replace("a", "b");
			case _: '-${Std.string((([-3 => 222] : Map<Int, Int>)).exists(v368))}<${Std.string(Std.isOfType(new C22(a70, 28), I13))}x${StringTools.hex((259) & 0xFFFF, 4)}';
		});
	}
	public static function ext74(a72:Array<Int>, a73:Bool):Int {
		H.tick();
		H.out("o379 " + Std.string(true));
		C33.f35 = a73;
		Main.fn50(new C22((new A8(112)).twice, 0xBD99));
		return (new C33()).m39();
	}
}
