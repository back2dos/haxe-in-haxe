import H;
import p.M1;
using p.Ext;
using StringTools;

abstract A8(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A8, b:A8):A8
		return new A8(a.get() + b.get());

	@:op(A * B) public static function mul(a:A8, b:A8):A8
		return new A8(a.get() * b.get());

	@:op(-A) public static function neg(a:A8):A8
		return new A8(-a.get());
}

interface I9 {
	function m10():Void;
	function m11(a12:Int):Bool;
}

class C33 {
	var _f34:E0;

	public var f34(get, set):E0;

	function get_f34():E0
		return _f34;

	function set_f34(v:E0):E0
		return _f34 = v;
	public static var f35:Bool = false;
	public function new() {
		this._f34 = E0.E0C;
	}
	public static function m36(a37:Int, ...r38:Int):Int {
		H.tick();
		(new C40(([] : Array<Int>), false)).m14();
		for (x141 in r38.toArray()) {
			H.tick();
			var v142:Map<Int, Int> = ([-3 => x141, 4 => 189] : Map<Int, Int>);
		}
		var v143:Map<String, Int> = new Map<String, Int>();
		C22.f24 |= a37;
		var v144:Int = a37;
		if ((Std.string(a37) != Std.string(a37))) {
			(new C40(r38.toArray(), false)).m14();
			a37 = 97;
		} else {
			H.out("o145 " + Std.string((-2147483647)));
		}
		return ((new A8(v144) : Int) ^ C22.f24);
	}
	public function m39():Int {
		H.tick();
		final v146 = (new A8(283) : Int);
		H.out("o147 " + Std.string(({x6: Std.string(239), x7: v146} : S5)));
		H.out("o148 " + Std.string(2004919478));
		final v149:S5 = ((switch (E0.E0C) {
			case E0A: ({x6: "abc", x7: v146} : S5);
			case E0B(c150, c151): ({x7: c151, x6: c150} : S5);
			case E0C: ({x6: "q", x7: 0x135E} : S5);
			case E0D(_): ({x6: "  pad  ", x7: v146} : S5);
		}) : S5);
		return (C33.m36(("é").length, 220) >> ((switch (false) {
			case true: v146;
			case false: v146;
		}) & 31));
	}
}

class Main {
	public static function fn49():S5 {
		H.tick();
		var v231:Array<String> = ((false ? ["\"q\"", "0"] : ([] : Array<String>)) : Array<String>);
		if (false) {
			C33.m36(Type.enumIndex(E0.E0C), (-311558187), 200);
			try {
				final v232:Map<String, Int> = new Map<String, Int>();
				var v233 = (-2147483647);
				H.out("o234 " + Std.string(false));
				if (([v233, v233]).contains(v233)) throw new Err(((v232).get("k1") ?? 0));
			} catch (ex235:Dynamic) {
				H.out("caught " + H.exn(ex235));
				(new C22(235, 256)).m14();
			}
		} else {
			(new C33()).m39();
		}
		var v236 = (([0xFFFFFFFF, 222]).contains(94) ? 42 : 43);
		switch (({x6: "x,y,z", x7: (([] : Array<Int>)).length} : S5)) {
			case {x6: c237}: {
				var v238 = C22.f24;
				v231.push((c237).toLowerCase());
			};
		}
		v231.push("");
		if ((StringTools.replace("-7", "a", "A-B-C") == ("ünï").replace("a", "b"))) {
			(new C18(true, "A-B-C")).m14();
			H.out("o239 " + Std.string(v236));
			if (false) {
				var v240 = v236;
				C33.m36(0x1C35);
				var v241:A8 = (v236 : A8);
			} else {
				final v242:A8 = (0xFFFFFFFF : A8);
			}
		}
		return ({x6: "ab", x7: (if (false) (Std.parseInt("-7") ?? 0) else C22.f24)} : S5);
	}
	public static inline function fn50(a51:C22):Bool {
		H.tick();
		(new C18(false, "x,y,z")).m14();
		C22.f24 -= 1099103148;
		final lf243:() -> String = function():String {
			H.tick();
			H.out("o244 " + Std.string(([] : Array<String>)));
			return ({ var v245 = ([44, 261, 142]).contains(159); "\x41\x42"; });
		};
		var v246 = (new C33()).m39();
		H.out("o247 " + Std.string(C33.f35));
		return (v246 <= (Std.parseInt(([false, true]).join(",")) ?? 0));
	}
	public static function fn52(a53:E0, a54:E0):Bool {
		H.tick();
		if ((true && true)) return ((("hello world").charCodeAt(206) ?? -1) < Reflect.compare("", "\t"));
		var v248 = (120 & 65535);
		switch (C33.m36(v248, v248)) {
			case 0: {
				final v249:Array<C22> = ([new C22(v248, v248), new C22(v248, v248)] : Array<C22>);
			};
			case 2 | 5: {
				H.out("o250 " + Std.string(StringTools.contains("42", "0")));
				C33.m36(H.at([0xFFFFFFFF], v248, 0), 242, v248);
			};
			case _: {
				H.out("o251 " + Std.string((("q").charCodeAt(v248) ?? -1)));
			};
		}
		var v252:Bool = (C33.f35 || StringTools.startsWith("0", "\"q\""));
		var v253:Map<Int, Int> = ([-3 => v248, 4 => ([v248, v248]).indexOf(v248)] : Map<Int, Int>);
		fn50(new C22(262, C22.f24));
		H.out("o254 " + Std.string(v248));
		return C33.f35;
	}
	public static function fn55(a56:Int, a57:Int, a58:Bool):Void {
		H.tick();
		var w255 = 0;
while (w255 < 1 && false) {
			w255++;
			H.tick();
			H.out("o256 " + ([a57, a57]).join(" "));
			var v257 = Type.enumIndex(E0.E0B("日本語", a56));
			final v258:Array<String> = ["zz", "ab", "é"];
		}
		final v259:Array<String> = ((switch (E0.E0D(a57)) {
			case E0A: ("a\rb").split("-");
			case E0B(c260, 2 | 5): [c260];
			case E0C: ([] : Array<String>);
			case E0D(0 | 4): ["é", ""];
			case _: ("a\rb").split(" ");
		}) : Array<String>);
		final v261:Array<Bool> = [a58, a58];
		for (x262 in v259) {
			H.tick();
			var v263:String = Std.string(E0.E0D(a56));
			H.out("o264 " + Std.string(156));
		}
		if ((switch (H.at(([] : Array<Int>), 0x115D, 0)) {
			case 0: StringTools.startsWith("\\", "abc");
			case 3 | 5: true;
			case _: true;
		})) {
			Main.fn49();
		}
		H.out("o265 " + Std.string(Type.enumIndex(E0.E0D(a56))));
		{ var dyn266:Dynamic = ((switch (E0.E0B("\"q\"", a56)) {
			case E0A: ({x6: "é", x7: 268} : S5);
			case E0B(_, c267) if (c267 > 3): ({x6: "\"q\"", x7: a56} : S5);
			case E0C: ({x6: "Haxe", x7: a57} : S5);
			case _: ({x7: 271, x6: "ünï"} : S5);
		}) : S5); H.out("dyn " + Std.string(dyn266.x6) + " " + Std.string(Reflect.field(dyn266, "x6"))); }
		H.out("o268 " + Std.string(a57));
		C22.f24 = C33.m36((-2147483647), (-13), a56);
	}
	public static function fn59(a60:String):String {
		H.tick();
		switch (E0.E0C) {
			case E0A: {
				var v269:Map<Int, String> = new Map<Int, String>();
			};
			case E0B(_, _): {
				var v270:Array<Bool> = [true, false];
				C22.f24 <<= ((new A8(236) : Int) & 7);
			};
			case E0C: {
				var v271:E0 = E0.E0B(a60, 169);
			};
			case E0D(_): {
				C22.f24 = 206;
				final v272:A8 = new A8(183);
			};
		}
		var v273:Array<Int> = ([65535]).concat([96, 0x7FFFFFFF, 251]);
		if ((Reflect.compare(22, (-777920741)) > (Std.parseInt(Std.string(14)) ?? 0))) {
			var v274 = C22.f24;
			final v275:Int = v274;
			try {
				H.out("o276 " + "\\");
				final v277:S5 = ({x6: a60, x7: v274} : S5);
				if ((Std.downcast((new C40(v273, false) : C40), C40) != null)) throw ("\x41\x42").toUpperCase();
			} catch (ex278:String) {
				H.out("caught String " + ex278);
				v273.unshift(36);
				H.out("o279 " + Std.string(new C33()));
			} catch (ex280:Int) {
				H.out("caught Int " + ex280);
				H.out("o281 " + a60);
			} catch (ex282:Err) {
				H.out("caught Err " + ex282.errCode);
				var v283:Bool = true;
			} catch (ex284:Dynamic) {
				H.out("caught " + H.exn(ex284));
				var v285 = 0x96F6;
			}
		}
		for (k286 => v287 in (((v273).contains(204) ? (["k0" => 274, "k1" => 110] : Map<String, Int>) : new Map<String, Int>()) : Map<String, Int>)) {
			H.tick();
			if (true) {
				(new C18(true, "é")).m15(v287, v273);
			} else {
				final v288:Int = v287;
				C33.m36(50, v287);
			}
			C22.f24 |= (({x7: v287, x6: k286} : S5)).x7;
		}
		C22.f24 = (true ? (a60).length : 283);
		return "\t";
	}
	public static function fn61(a62:Int, a63:Bool):Bool {
		H.tick();
		final v289:Map<String, Array<Int>> = (["k0" => [187, a62, a62], "k1" => [a62], "k2" => ([] : Array<Int>)] : Map<String, Array<Int>>);
		H.out("o290 " + (switch (E0.E0A) {
			case E0A: Std.string(a62);
			case E0C: ("0").charAt(6);
			case E0D(_): (([] : Array<String>)).join(" ");
			case _: Std.string(a62);
		}));
		switch (E0.E0B(Std.string(a62), a62)) {
			case E0A: {
				var v291:A8 = new A8(162);
				Main.fn59("Haxe");
			};
			case E0B(c292, c293): {
				{
					C22.f24 |= 21;
					var v294:S5 = ({x7: c293, x6: c292} : S5);
					var v295:Int = 75;
				}
				final v296:Int = (-13);
			};
			case E0C: {
				var v297:Map<String, String> = (["k0" => "A-B-C"] : Map<String, String>);
				if (((["k0" => new C18(a63, "42"), "k1" => new C22((-2147483647), 213)] : Map<String, C18>)).exists("A-B-C")) {
					var v298:C18 = new C22(95, a62);
					a62 = H.id(a62);
				} else {
					final v299:Bool = a63;
				}
			};
			case E0D(c300): {
				final v301:Int = ("\x41\x42").indexOf("abc");
				for (x302 in ["\n"]) {
					H.tick();
					(new C22((-1525217468), a62)).m30(false);
					a62 = 0xDA36;
					var v303:Array<Int> = ([] : Array<Int>);
				}
			};
			case _: {
				final lf304:() -> Bool = () -> StringTools.contains("hello world", "\t");
			};
		}
		var v305:Map<String, Int> = (["k0" => (new A8(a62)).twice] : Map<String, Int>);
		H.out("o306 " + "A-B-C");
		return C33.f35;
	}
	public static function fn64(a65:String):Bool {
		H.tick();
		{
			var v307:Array<String> = [a65];
			for (i308 in 2...H.lim(([33]).length)) {
				H.tick();
				var v309:Int = i308;
			}
		}
		{
			var v310:Array<Int> = ([] : Array<Int>);
		}
		switch (E0.E0C) {
			case E0A: {
				final v311 = a65;
			};
			case E0B(c312, c313): {
				if (true) {
					Main.fn52(E0.E0D(c313), E0.E0C);
				} else {
					var v314:Map<Int, Int> = ([-3 => c313] : Map<Int, Int>);
				}
			};
			case E0C: {
				var v315:Array<Array<Int>> = ([[0x80000000], [190, 110]] : Array<Array<Int>>);
			};
			case E0D(c316) if (c316 > 2): {
				H.out("o317 " + Std.string(0x7FFFFFFF));
			};
			case _: {
				var v318:String = a65;
				try {
					if (C33.f35) throw 69;
					H.out("o319 " + Std.string(0xB70D));
				} catch (ex320:String) {
					H.out("caught String " + ex320);
					H.out("o321 " + Std.string(7));
					H.out("o322 " + Std.string(63));
				} catch (ex323:Int) {
					H.out("caught Int " + ex323);
					H.out("o324 " + Std.string((new A8(64) : Int)));
					(new C33()).m39();
				} catch (ex325:Err) {
					H.out("caught Err " + ex325.errCode);
					H.out("o326 " + Std.string(E0.E0C));
				} catch (ex327:Dynamic) {
					H.out("caught " + H.exn(ex327));
					H.out("o328 " + Std.string(7));
				}
			};
		}
		var v329:Map<Int, String> = new Map<Int, String>();
		var v330:Int = (a65).length;
		v330 &= (~(a65).lastIndexOf(a65));
		var w331 = 0;
while (w331 < 2 && fn52(E0.E0D(90), E0.E0C)) {
			w331++;
			H.tick();
			final v332:Int = (Std.parseInt(a65) ?? 0);
			{ var dyn333:Dynamic = ({x7: v330, x6: "\t"} : S5); H.out("dyn " + Std.string(dyn333.x6) + " " + Std.string(Reflect.field(dyn333, "x6"))); }
		}
		var v334:Map<String, C40> = new Map<String, C40>();
		var w335 = 0;
do {
			w335++;
			H.tick();
			Main.fn52(E0.E0B(a65, 87), E0.E0B(a65, 141));
			H.out("o336 " + Std.string(StringTools.contains(a65, a65)));
			var v337:Array<E0> = ([E0.E0C, E0.E0C] : Array<E0>);
		} while (w335 < 1 && (false || false));
		return fn61(C22.f24, (E0.E0D((-595320502))).match(E0B(_, _)));
	}
	public static function fn66(a67:String, a68:Array<S5>):Void {
		H.tick();
		var v338:String = Std.string(E0.E0B(a67, 219));
		switch (235) {
			case 0: {
				(new C22((-1498092216), 66)).m15(Type.enumIndex(E0.E0D(115107840)), [(-2147483647), 1970729915]);
			};
			case 1 | 4: {
				H.out("o339 " + Std.string(C22.f24));
				H.out("o340 " + Std.string(Type.enumIndex(E0.E0C)));
			};
			case c341 if (c341 > 10): {
				var v342:Map<Int, Int> = ([-3 => c341, 4 => c341, 11 => c341] : Map<Int, Int>);
			};
			case _: {
				H.out("o343 " + (v338).toLowerCase());
			};
		}
		H.out("o344 " + Std.string(((-new A8(109)) : Int)));
		var v345:Array<String> = [Std.string(E0.E0B("q", 132)), ""];
		for (i346 in 1...H.lim(224)) {
			H.tick();
			if (false) {
				v345.push(v338);
			} else {
				var v347:S5 = ({x7: i346, x6: v338} : S5);
			}
			if (true) continue;
			H.out("o348 " + Std.string((new A8(i346)).get()));
		}
		var v349:C22 = new C22(235, (({x6: a67, x7: 0xF3FA} : S5)).x7);
	}
	public static function section0():Void {
		H.tick();
		var v380:Array<Bool> = [false, false];
		(new C18(Std.isOfType(new C40(([] : Array<Int>), false), I13), "q")).m14();
		H.out("o381 " + Std.string(([for (i382 in [88, 130]) if (true) new C22(i382, (-241866554))] : Array<C22>)));
		var v383:String = (Std.string(E0.E0D(290)) + StringTools.trim("\u{1F600}"));
		{ var dyn384:Dynamic = ({x7: (-6), x6: v383} : S5); H.out("dyn " + Std.string(dyn384.x6) + " " + Std.string(Reflect.field(dyn384, "x6"))); }
		var v385 = ([155, 95]).ext74((Std.downcast((new C33() : C33), C33) != null));
		final v386:Map<String, Bool> = new Map<String, Bool>();
	}
	public static function section1():Void {
		H.tick();
		if (((["k0" => 266, "k1" => 0xD8CA, "k2" => 197] : Map<String, Int>)).exists(StringTools.trim("abc"))) {
			final v387:S5 = ({x6: "\"q\"", x7: 66} : S5);
			var w388 = 0;
while (w388 < 2 && StringTools.startsWith("  pad  ", "Haxe")) {
				w388++;
				H.tick();
				C22.f24 -= 51;
				final v389:Map<Int, String> = new Map<Int, String>();
				Ext.ext74([159, 122, 46], false);
			}
		} else {
			C22.f24 &= 194;
			var v390:Map<String, E0> = (["k0" => E0.E0D(1962314402)] : Map<String, E0>);
		}
		{
			H.out("o391 " + Std.string(new C40([191], true)));
		}
		for (i392 in 0...H.lim(35)) {
			H.tick();
			var v393:Array<Int> = [205];
			switch ("q") {
				case "a" | "b": {
					var v394:Int = i392;
					var v395:Int = i392;
				};
				case "Haxe": {
					var v396:Map<Int, Int> = new Map<Int, Int>();
					(new C22(0xD390, i392)).m15(34, v393);
				};
				case _: {
					var v397:Int = i392;
					H.out("o398 " + Std.string([v397]));
				};
			}
			C22.f24 = (("abc").charCodeAt(i392) ?? -1);
		}
		var v399:Map<Int, Int> = new Map<Int, Int>();
		([0xCE60, 283]).ext71(83);
		(new C22(H.at([61, (-18)], 0xFFFFFFFF, 0), 2)).m27(Std.string(C22.f24), (new A8((-465782492))).twice);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
