package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

class C6 {
	public var f7:Int;
	public var cb8:(Int) -> Int;
	public function new() {
		this.f7 = 146;
		this.cb8 = (p62:Int) -> p62;
	}
	public function m9(a10:Int, a11:String, ...r12:Int):E0 {
		H.tick();
		final v63:Float = a10;
		r12.toArray().pop();
		if (true) {
			var v64:Array<Float> = ([a10, a10, 1.25] : Array<Float>);
			a10 -= 129;
		} else {
			H.out("o65 " + Std.string(E0.E0A));
			H.out("o66 " + Std.string(false));
		}
		if (false) {
			var v67:Float = a10;
		}
		r12.toArray().remove(a10);
		this.f7 = 101;
		var v68:C6 = new C6();
		return E0.E0A;
	}
}

class C13 {
	public var cb14:(Int) -> Int;
	public function new(a15:Bool, a16:Bool) {
		this.cb14 = (p69:Int) -> p69;
	}
}
