package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

enum E0 {
	E0A;
}

class C17 extends C13 {
	var _f18:S1;

	public var f18(get, set):S1;

	function get_f18():S1
		return _f18;

	function set_f18(v:S1):S1
		return _f18 = v;
	public function new(a19:Bool) {
		super(a19, a19);
		this._f18 = ({x2: 0, x3: true} : S1);
	}
	public static function m20():Array<Int> {
		H.tick();
		final v70:E0 = (new C6()).m9((-3), Std.string(true), (Std.parseInt(Std.string(300)) ?? 0), 261);
		var v71:Int = 0x3240;
		var v72:Array<Float> = ([v71] : Array<Float>);
		H.out("o73 " + Std.string(v71));
		var v74 = Std.isOfType(new C6(), C6);
		if ((new Box(true)).get()) {
			v71 += (((["k0" => v71] : Map<String, Int>)).get("k1") ?? 0);
			H.out("o75 " + Std.string(Std.isOfType(new C27((-17)), C27)));
			final v76:C17 = new C17(v74);
		}
		var v77:Map<String, Bool> = new Map<String, Bool>();
		H.out("o78 " + Std.string(Math.round(v71)));
		final v79:(Int) -> Float = (p80:Int) -> 1e-7;
		return ([199, 0xFBB, v71]).map((v81:Int) -> ((K5.K5A : Int) * (-1634795112)));
	}
	public static function m21():Bool {
		H.tick();
		var v82 = (({x2: 0x80000000, x3: false} : S1)).x2;
		H.out("o83 " + Std.string(new C6()));
		var v84:E0 = ((false ? E0.E0A : E0A) : E0);
		H.out("o85 " + Std.string(3.0));
		var v86:Int = v82;
		if (true) {
			(new C6()).m9(v82, Std.string(v82), (-723631390));
			final v87:Map<String, String> = (["k0" => "é"] : Map<String, String>);
			if ((E0A).match(E0A)) {
				var v88 = v86;
				H.out("o89 " + Std.string(false));
				final v90:(Float, Int) -> Int = function(p91:Float, p92:Int):Int {
					H.tick();
					var v93:Map<String, Float> = new Map<String, Float>();
					return v82;
				};
			}
		} else {
			H.out("o94 " + Std.string(v86));
			H.out("o95 " + Std.string((K5.K5A : Int)));
		}
		if (true) {
			if (false) {
				v82 = 0x33F0;
				H.out("o96 " + Std.string(([v82, v86, v86] : Array<Null<Int>>)));
				final v97:() -> Int = () -> v86;
			}
			if ((([] : Array<Int>)).contains(v82)) {
				H.out("o98 " + Std.string([true, false]));
				v82 *= v82;
				H.out("o99 " + Std.string(v84));
			} else {
				v82 = H.id(v82);
			}
		} else {
			var v100:Array<C6> = ([new C6()] : Array<C6>);
		}
		return false;
	}
	public function m22(a23:Bool, a24:Float):Void {
		H.tick();
		var v101:C13 = new C13((E0.E0A).match(E0A), a23);
		final v102:(Int, Int) -> String = (p103:Int, p104:Int) -> "  pad  ";
		H.out("o105 " + Std.string((([a24, 0.1] : Array<Float>)).length));
		Main.fn35(new A4((new A4(69)).twice), Main.fn35(new A4(119), 115, 0.5), ({ var v106 = ([173, 190]).indexOf(1799702502); 239; }));
		var v107:Array<Int> = [Lambda.count([183, 29], v108 -> true)];
		Main.fn39((K5.K5B : Int), 251);
	}
	public function m25(a26:String):Array<Int> {
		H.tick();
		Main.fn39(Main.fn35(new A4(110), null, (-2.5)), (Std.parseInt(Std.string((K5.K5C : Int))) ?? 0));
		function lf109(n110:Int):Int {
			H.tick();
			return n110 <= 0 ? n110 : (lf109(n110 - 1) + (-Reflect.compare(217, 0xD411)));
		}
		H.out("lf109 " + lf109(2));
		final lf111:(Int, Float) -> Bool = function(p112:Int, p113:Float):Bool {
			H.tick();
			var v114:Map<Int, Int> = ([-3 => p112, 4 => p112, 11 => p112] : Map<Int, Int>);
			(new C6()).m9(([p112, 122, p112]).length, "A-B-C");
			return (Std.isOfType(new C17(false), C13) || true);
		};
		final v115:Array<Int> = (([1.7976931348623157e308, 123456.789, 7.0] : Array<Float>)).map((v116:Float) -> (-2147483647));
		Main.fn33((-14));
		return (([] : Array<Float>)).map((v117:Float) -> Main.fn35(new A4(10974713), (-3)));
	}
}
