import H;
import p.M1;
import p.q.M2;

typedef S1 = {x2:Int, x3:Bool};

abstract A4(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A4, b:A4):A4
		return new A4(a.get() + b.get());

	@:op(A * B) public static function mul(a:A4, b:A4):A4
		return new A4(a.get() * b.get());

	@:op(-A) public static function neg(a:A4):A4
		return new A4(-a.get());
}

enum abstract K5(Int) to Int {
	var K5A = 1;
	var K5B = 4;
	var K5C = 7;
}

class C27 {
	public var f28:Bool;
	public final f29:Int;
	public final f30:Bool;
	public function new(a31:Int) {
		this.f28 = true;
		this.f29 = a31;
		this.f30 = true;
	}
	public function m32():Int {
		H.tick();
		var v118 = (139 % H.nz(([96]).length));
		var v119:C13 = new C17((new Map<String, Bool>()).exists("k3"));
		var v120:Float = 1e3;
		return ((-(v118 : A4))).twice;
	}
}

class Main {
	public static function fn33(...r34:Int):Void {
		H.tick();
		H.out("o121 " + Std.string((([E0.E0A, E0.E0A] : Array<E0>)).concat(([] : Array<E0>))));
		H.out("o122 " + Std.string(([E0.E0A, E0.E0A, E0.E0A] : Array<E0>)));
		(new C6()).m9(105, ((E0.E0A).match(E0A) + (["q", "ünï", "hello world"]).join(",")), Math.ceil(1.25));
		final v123:Int = (222 + ([false, true]).indexOf(true));
		var v124:Int = 274;
	}
	public static inline function fn35(a36:A4, a37:Null<Int>, ?a38:Null<Float>):Int {
		H.tick();
		var v125:S1 = H.apply(65535, (v126:Float) -> ({x2: 116, x3: true} : S1));
		final v127:Array<Box<Bool>> = ([new Box(true), new Box<Bool>(false), new Box(true)] : Array<Box<Bool>>);
		var v128 = (Lambda.count([130, 57], v129 -> ((["k0" => v129, "k1" => v129, "k2" => v129] : Map<String, Float>)).exists("k2")) % H.nz((v125).x2));
		var v130:C27 = new C27(([0xFB4F, 175]).length);
		var v131:Map<Int, Bool> = new Map<Int, Bool>();
		a37 = v128;
		var v132:Array<Int> = ([false]).map((v133:Bool) -> (-602468886));
		Main.fn33();
		return ((false ? false : (E0.E0A).match(E0A)) ? (-2147483647) : (([(-2.5), v128] : Array<Float>)).length);
	}
	public static function fn39(a40:Int, a41:Int):Array<Float> {
		H.tick();
		var v134:Box<C17> = new Box<C17>(new C17(true));
		var v135:S1 = ({x2: 214, x3: true} : S1);
		if ((new Box<Bool>(true)).value) {
			if ((new Map<String, Int>()).exists("\"q\"")) {
				H.out("o136 " + Std.string(a40));
			}
			var v137:Float = 1e3;
			if ((new Map<Int, Float>()).exists(11)) {
				a40 += a40;
				a40 = a41;
			} else {
				var v138:Int = 123;
			}
		}
		final v139:() -> Bool = function():Bool {
			H.tick();
			var v140:Array<Float> = ([a40, 1e100, 100.75] : Array<Float>);
			Main.fn35(new A4(a40), a40);
			return Math.isNaN(a41);
		};
		H.out("o141 " + Std.string((((270 : A4)).twice == a41)));
		return ([] : Array<Float>);
	}
	public static function fn42():Bool {
		H.tick();
		final v142:Array<Int> = [for (i143 in [24]) if (([1535705598, i143]).contains(i143)) i143];
		{
			var v144:S1 = ({x2: 239, x3: false} : S1);
		}
		{
			H.out("o145 " + "  pad  ");
			var v146:S1 = ({x3: true, x2: (-17)} : S1);
		}
		var v147:Int = (Math.floor(1.7976931348623157e308) * (-777148864));
		var v148:Float = (new Box<Float>(1e100)).get();
		if (false) {
			H.out("o149 " + Std.string(((v147 : A4) : Int)));
			var v150:Int = v147;
			var v151:Map<String, Float> = (["k0" => v150] : Map<String, Float>);
		} else {
			if (true) {
				C17.m20();
				H.out("o152 " + Std.string(v147));
			} else {
				var v153:A4 = new A4(v147);
			}
		}
		if (false) {
			final v154 = (((["k0" => 64, "k1" => v147] : Map<String, Int>)).get("k1") ?? 0);
			final v155 = v147;
			var v156 = v155;
		}
		H.out("o157 " + Std.string(E0.E0A));
		return (true && (false && true));
	}
	public static function fn43(a44:Int, a45:Bool):(Bool) -> Bool {
		H.tick();
		Main.fn33(a44);
		a44 -= a44;
		final v158:E0 = E0.E0A;
		a44 += a44;
		final v159:Array<Int> = [a44];
		return function(p160:Bool):Bool {
			H.tick();
			var v161:Bool = (E0.E0A).match(E0A);
			return true;
		};
	}
	public static function fn46(a47:Int, a48:Float, a49:Bool):Void {
		H.tick();
		var v162:Array<Int> = ([a47, a47]).copy();
		H.out("o163 " + Std.string(((v162).contains(a47) ? 279 : 0xFB0E)));
		if (a49) {
			(new C27(a47)).m32();
			fn39(Std.int(a47), (-878093004));
		} else {
			var v164:E0 = E0.E0A;
			(new C6()).m9(Reflect.compare(a47, a47), Std.string(0.5), (-2147483647));
		}
		C17.m21();
	}
	public static function fn50(a51:Int, a52:String, a53:Int):Float {
		H.tick();
		fn46((cast (a53) : Int), 1.25, (a53 >= a53));
		final lf165:() -> Int = () -> a53;
		H.out("o166 " + Std.string(a53));
		var v167:Int = a53;
		if ((v167 == 7.0)) {
			var v168 = a51;
		} else {
			{
				var v169 = a51;
				var v170:Float = v169;
				H.out("o171 " + Std.string([false, true, false]));
			}
		}
		v167 = (-Lambda.count(([] : Array<Int>), v172 -> true));
		return 1.25;
	}
	public static function fn54(a55:Bool, a56:Array<Int>):Bool {
		H.tick();
		var v173:E0 = E0.E0A;
		var v174:Array<Bool> = [false, true, Std.isOfType(new C27(215), C27)];
		final v175 = ((-3) * (-11));
		var v176:C27 = new C27(v175);
		return Std.isOfType(new C17(a55), C17);
	}
	public static function fn57(a58:Float, ?a59:Null<Int>):Int {
		H.tick();
		var v177:Int = (false ? (Std.parseInt("abc") ?? 0) : 1379427758);
		final v178 = (cast (false) : Bool);
		var v179:C27 = (cast (new C27(223)) : C27);
		H.out("o180 " + Std.string(new C17(([v177, v177, v177]).contains(v177))));
		final v181:C17 = new C17(v178);
		H.out("o182 " + Std.string(([for (i183 in [v177, v177, v177]) if (true) new C6()] : Array<C6>)));
		H.out("o184 " + Std.string(v177));
		return (Std.parseInt(Std.string((if (false) Lambda.count([234, v177], v185 -> true) else (v177--)))) ?? 0);
	}
	public static function fn60(a61:Int):Int {
		H.tick();
		final v186 = ((({x2: 38, x3: true} : S1)).x2 - Math.ceil(a61));
		if (Main.fn42()) {
			H.out("o187 " + Std.string((({x2: a61, x3: false} : S1)).x2));
			var v188:Box<Bool> = new Box(true);
			var v189:Int = (-245974287);
		}
		H.out("o190 " + Std.string((({x2: v186, x3: false} : S1)).x2));
		if (fn42()) {
			a61--;
			H.out("o191 " + Std.string(E0.E0A));
			a61 = 1;
		}
		if ((0x9C95 < (K5.K5C : Int))) {
			if (true) {
				H.out("o192 " + Std.string(v186));
				var v193:Null<Int> = v186;
			}
		} else {
			H.out("o194 " + Std.string(a61));
		}
		H.out("o195 " + Std.string(true));
		fn43(a61, (Std.int(v186) < 33));
		function lf196(n197:Int):Int {
			H.tick();
			return n197 <= 0 ? 28 : (lf196(n197 - 1) + Main.fn35(new A4(v186), n197, v186));
		}
		H.out("lf196 " + lf196(1));
		var v198:C6 = new C6();
		return (Std.parseInt(Std.string((a61 + (new A4(v186) : Int)))) ?? 0);
	}
	public static function section0():Void {
		H.tick();
		{
			var v199:Array<Int> = [0x80000000, 261];
			var v200 = Math.floor(1e3);
		}
		final v201:(Bool) -> Void = ((false ? function(p202:Bool):Void {
			H.tick();
			var v203:C27 = new C27(147);
			var v204:S1 = ({x2: 153, x3: p202} : S1);
		} : function(p205:Bool):Void {
			H.tick();
			H.out("o206 " + Std.string(0xB8A5));
			final v207:Array<E0> = ([E0.E0A, E0.E0A] : Array<E0>);
		}) : (Bool) -> Void);
		{
			var v208:Bool = (new Map<Int, E0>()).exists(4);
			H.out("o209 " + Std.string(true));
			var v210 = (new A4(186) : Int);
		}
		var v211:E0 = E0.E0A;
		var v212:S1 = ({x2: 183, x3: true} : S1);
		H.out("o213 " + Std.string(v211));
		H.out("o214 " + Std.string(({x2: 0xAC4F, x3: ([0xE557, 1398372533, 0x9586]).contains(227)} : S1)));
		H.out("o215 " + Std.string(0x2567));
	}
	public static function section1():Void {
		H.tick();
		var v216:C6 = new C6();
		var v217:Array<Int> = [((new Map<Int, Int>()).get(0x2733) ?? 0)];
		var v218:K5 = (cast (K5.K5B) : K5);
		var v219:C13 = (((E0.E0A).match(E0A) ? new C17(true) : new C13(true, true)) : C13);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
