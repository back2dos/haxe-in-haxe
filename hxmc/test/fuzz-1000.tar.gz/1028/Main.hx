import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

enum E0 {
	E0A;
	E0B(a1:Int, a2:E0);
	E0C(a3:E0, a4:Int);
}

abstract A11(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A11, b:A11):A11
		return new A11(a.get() + b.get());

	@:op(A * B) public static function mul(a:A11, b:A11):A11
		return new A11(a.get() * b.get());

	@:op(-A) public static function neg(a:A11):A11
		return new A11(-a.get());
}

class C23 {
	public var f24:String;
	public var f25:String;
	public function new(a26:String, a27:Bool) {
		this.f24 = ("hello world").replace("a", "b");
		this.f25 = "0";
	}
}

class C28 extends C23 {
	public static var f29:Int = 149;
	public static var f30:String = "a";
	public function new(a31:String, a32:Int) {
		super(C28.f30, false);
	}
	public static function m33(a34:E0):Int {
		H.tick();
		var v138 = (((["k0" => 46] : Map<String, Int>)).get(C28.f30) ?? 0);
		var v139 = ((([-3 => v138] : Map<Int, Int>)).exists(-3) ? C28.f29 : ("\\").length);
		v139 = (-v138);
		final v140:(String) -> Int = (cast ((p141:String) -> v139) : (String) -> Int);
		var v142:Int = 84;
		for (i143 in 2...H.lim(v138)) {
			H.tick();
			H.out("o144 " + ("abc").substring(((-8) & 7), 1));
			var v145 = 0x90DE;
		}
		(new C13()).m20(new Map<Int, Int>());
		return (v139 & ((new A11(274)).twice >>> (("A-B-C").lastIndexOf("\\") & 31)));
	}
	public function m35(a36:Int, ...r37:Int):String {
		H.tick();
		for (i146 in 0...0) {
			H.tick();
			for (k147 => v148 in (["k0" => a36, "k1" => a36, "k2" => i146] : Map<String, Int>)) {
				H.tick();
				(new C40()).m20(new Map<Int, Int>());
				var v149 = true;
				var v150:Int = 65535;
			}
		}
		var v151:Int = ((new A11(226)).twice % H.nz(a36));
		H.out("o152 " + Std.string((new A11(v151)).get()));
		if (Ext.ext72("hello world", 0xE482)) {
			C28.f29 = v151;
		} else {
			var v153:String = String.fromCharCode(65 + ((v151) & 15));
			a36 += (new A11(166) : Int);
		}
		for (k154 => v155 in new Map<String, Int>()) {
			H.tick();
			H.out("o156 " + Std.string(new Box<A11>(new A11(a36))));
			if (false) {
				a36 &= v155;
				H.out("o157 " + Std.string(new C28("", a36)));
				((-2147483647)).ext69();
			} else {
				final v158 = (-14);
				v151 -= a36;
			}
		}
		if (false) return ({ var v159 = Std.isOfType(new C23("q", false), C23); "zz"; });
		return (StringTools.replace("a", ",", ("\n").replace("a", "b"))).substr((v151 & 7), ((a36 ^ v151) & 7));
	}
	public function m38(a39:Int):Int {
		H.tick();
		var v160:Int = (false ? a39 : 62);
		final v161:Int = v160;
		var v162:K12 = K12.K12B;
		H.out("o163 " + Std.string(E7.E7D(v161)));
		return C28.m33(E0.E0B(C28.f29, E0.E0A));
	}
}

class Main {
	public static function fn50(a51:String, a52:String):Int {
		H.tick();
		{
			for (i209 in 0...H.lim(1553389708)) {
				H.tick();
				var v210:K12 = K12.K12A;
				var v211 = false;
			}
		}
		H.out("o212 " + ("\t" + C28.f30));
		var v213:Int = C28.f29;
		for (i214 in 1...2) {
			H.tick();
			var v215:K12 = K12.K12B;
		}
		H.out("o216 " + Std.string(E5.E5A));
		var v217:Int = C28.f29;
		H.out("o218 " + (C28.f30 + (a52).replace("a", "b")));
		var v219 = false;
		return ((([-3 => (new A11(v217) : Int), 4 => 76, 11 => Reflect.compare(a52, a51)] : Map<Int, Int>)).get(-3) ?? 0);
	}
	public static function fn53(a54:Int):Int {
		H.tick();
		final v220:E0 = E0C(E0A, a54);
		final v221:String = ("abc" + Std.string(true));
		if ((true || StringTools.endsWith(v221, v221))) {
			var v222:Int = ((v221).charCodeAt(175) ?? -1);
		} else {
			var v223 = 27;
		}
		return 65535;
	}
	public static function fn55(a56:String, a57:String, a58:Int, ...r59:Int):Int {
		H.tick();
		for (i224 in 0...0) {
			H.tick();
			for (i225 in 1...H.lim(i224)) {
				H.tick();
				var v226:Int = a58;
				C28.f29 <<= (a58 & 7);
				var v227:C23 = new C23("  pad  ", true);
			}
		}
		var v228:C40 = new C40();
		C28.f29 = (false ? (K12.K12A : Int) : 65535);
		var w229 = 0;
while (w229 < 4 && ((new A11(a58) : Int) >= a58)) {
			w229++;
			H.tick();
			a58 += 1859122934;
			++C28.f29;
			for (i230 in 1...H.lim(139)) {
				H.tick();
				var v231 = a56;
				(new C13()).m16((["k0" => E5.E5A, "k1" => E5.E5A] : Map<String, E5>), 211);
			}
		}
		var v232 = (318319624 >> ((new A11(40)).twice & 31));
		return a58;
	}
	public static function fn60(a61:Int, a62:E5):Bool {
		H.tick();
		((new Box<C28>(new C28("42", 241))).get()).m35((a61 + a61));
		H.out("o233 " + Std.string(new Box<Int>(a61)));
		if (Ext.ext72(StringTools.lpad("a", "*", 0), ("  pad  ").indexOf("42"))) {
			var v234 = true;
			if ((([-3 => "\t"] : Map<Int, String>)).exists(211)) {
				var v235:String = "  pad  ";
				C28.f29 = a61;
				var v236:String = v235;
			} else {
				(new C28("\n", a61)).m38(a61);
			}
		} else {
			var v237:Bool = Std.isOfType(new C28("\"q\"", a61), C23);
		}
		for (i238 in 0...4) {
			H.tick();
			var v239:A11 = (a61 : A11);
			H.out("o240 " + Std.string(a61));
			var v241:String = StringTools.trim("q");
		}
		for (k242 => v243 in ((false ? new Map<String, Int>() : (["k0" => a61] : Map<String, Int>)) : Map<String, Int>)) {
			H.tick();
			try {
				if (true) throw "boom";
				final v244 = a61;
				H.out("o245 " + Std.string((new A11(2037357621) : Int)));
				var v246 = a61;
			} catch (ex247:String) {
				H.out("caught String " + ex247);
				(new C40()).m42();
			} catch (ex248:Int) {
				H.out("caught Int " + ex248);
				var v249:Box<Int> = new Box(127);
			} catch (ex250:Err) {
				H.out("caught Err " + ex250.errCode);
				final v251:(Int, String) -> Void = function(p252:Int, p253:String):Void {
					H.tick();
					var v254:Bool = false;
					var v255:Int = v243;
					final v256:C43 = new C43(k242, v255);
				};
				final v257:E5 = a62;
			} catch (ex258:Dynamic) {
				H.out("caught " + H.exn(ex258));
				var v259:A11 = (a61 : A11);
			}
			if (true) {
				C28.f29 += a61;
			}
			C28.f29 = v243;
		}
		{
			final v260 = ("abc").toUpperCase();
			var v261 = Reflect.compare(a61, a61);
		}
		return Ext.ext72((StringTools.trim("-7")).charAt(-1), (cast ((("  pad  ").charCodeAt(a61) ?? -1)) : Int));
	}
	public static function fn63():Bool {
		H.tick();
		final v262:Map<String, E5> = (["k0" => E5.E5A, "k1" => E5.E5A, "k2" => E5.E5A] : Map<String, E5>);
		C28.f29 = ((((["k0" => 601163211] : Map<String, Int>)).get("k0") ?? 0)).ext69();
		for (i263 in 0...H.lim((false ? (K12.K12A : Int) : (((-264949985) : A11) : Int)))) {
			H.tick();
			fn50(("\n").replace("a", "b"), Std.string(170));
			final v264:C43 = new C43('$$', i263);
			var v265:Map<String, Int> = new Map<String, Int>();
		}
		var v266:Map<Int, Int> = (cast (new Map<Int, Int>()) : Map<Int, Int>);
		return ((new C28("a", 261)).m35((K12.K12A : Int), (("0").charCodeAt(6) ?? -1), 157)).ext72(C28.f29);
	}
	public static function fn64(a65:Int):Int {
		H.tick();
		final v267:(Int, Int) -> String = function(p268:Int, p269:Int):String {
			H.tick();
			var v270:Box<Bool> = new Box<Bool>(true);
			C28.f29 = 739107688;
			H.out("o271 " + Std.string(false));
			return "\n";
		};
		a65 <<= ((Type.enumIndex(E0.E0A) & a65) & 7);
		if (Main.fn63()) {
			C28.f29 -= ("\n").lastIndexOf("  pad  ");
			H.out("o272 " + Std.string((new Map<Int, C23>()).exists(4)));
		} else {
			var v273:Map<Int, Int> = ([-3 => a65, 4 => a65] : Map<Int, Int>);
		}
		H.out("o274 " + Std.string((true ? (new A11(a65)).twice : 216)));
		var w275 = 0;
while (w275 < 5 && (false && StringTools.startsWith("\n", "\t"))) {
			w275++;
			H.tick();
			H.out("o276 " + "");
			H.out("o277 " + Std.string(283));
		}
		var v278:Int = a65;
		H.out("o279 " + Std.string((false ? false : false)));
		var v280:C43 = new C43("A-B-C", a65);
		Ext.ext69(Main.fn55(C28.f30, "Haxe", v278, ((new Map<Int, Int>()).get(4) ?? 0), (("ab").charCodeAt(v278) ?? -1)));
		return (({ var v281 = a65; 582265693; }) % H.nz(118));
	}
	public static function fn66():Int {
		H.tick();
		var v282 = Main.fn55("\"q\"", "\n", (-5), 47);
		Main.fn63();
		if (((([-3 => v282, 4 => v282] : Map<Int, Int>)).exists(18) ? (E7.E7C).match(E7A) : false)) {
			H.out("o283 " + Std.string(Type.enumIndex(E7.E7A)));
		}
		for (i284 in 2...6) {
			H.tick();
			v282 = C28.f29;
			for (i285 in 0...H.lim((-2147483647))) {
				H.tick();
				var v286:Bool = true;
				var v287:E7 = E7.E7B(i285);
			}
		}
		final v288:Map<Int, Bool> = new Map<Int, Bool>();
		v282 += C28.f29;
		return (Std.parseInt(StringTools.lpad(("\"q\"").toLowerCase(), "*", 4)) ?? 0);
	}
	public static function fn67():Int {
		H.tick();
		final v289 = (C28.f29 + C28.f30);
		try {
			if ((145 < 202)) throw new Err((-2147483647));
			H.out("o290 " + Std.string(E7.E7A));
			H.out("o291 " + C28.f30);
			var v292:C28 = new C28(v289, 0x80000000);
		} catch (ex293:String) {
			H.out("caught String " + ex293);
			++C28.f29;
		} catch (ex294:Int) {
			H.out("caught Int " + ex294);
			C28.f29 = ex294;
		} catch (ex295:Err) {
			H.out("caught Err " + ex295.errCode);
			final v296:Null<Int> = null;
			var v297:Int = (Std.parseInt(Std.string(77107872)) ?? 0);
		} catch (ex298:Dynamic) {
			H.out("caught " + H.exn(ex298));
			final v299:(String) -> String = (p300:String) -> '$$';
		}
		var v301:K12 = K12.K12B;
		C28.f29++;
		H.out("o302 " + (String.fromCharCode(65 + ((191) & 15)) + v289));
		var v303:String = v289;
		final v304:E7 = E7.E7B(1409430668);
		return (167 * (("x,y,z").charCodeAt((Std.parseInt(v303) ?? 0)) ?? -1));
	}
	public static function section0():Void {
		H.tick();
		var v330:Bool = !(E7.E7D(139)).match(E7B(_));
		H.out("o331 " + Std.string((new Box((-317913655))).get()));
		{
			C28.f29 -= 223;
			var v332:Int = ("").length;
			H.out("o333 " + ("\t").substring(-1, 5));
		}
		final v334:C23 = new C23(Std.string(197), v330);
		H.out("o335 " + Std.string(H.id(new Box(v330))));
		H.out("o336 " + Std.string(fn67()));
	}
	public static function section1():Void {
		H.tick();
		H.out("o337 " + Std.string(new C28(C28.f30, (("q").charCodeAt(31) ?? -1))));
		if (!false) {
			var v338:E0 = E0A;
			H.out("o339 " + Std.string(false));
		}
		var v340:A11 = (new C40()).m20(new Map<Int, Int>());
		if (("42" != C28.f30)) {
			try {
				if (true) throw "ab";
				Main.fn66();
			} catch (ex341:String) {
				H.out("caught String " + ex341);
				var v342 = 111;
			} catch (ex343:Int) {
				H.out("caught Int " + ex343);
				(new C40()).m20(new Map<Int, Int>());
				final v344 = false;
			} catch (ex345:Err) {
				H.out("caught Err " + ex345.errCode);
				C28.f29 *= 88;
				C28.f29 <<= (0xB38B & 7);
			} catch (ex346:Dynamic) {
				H.out("caught " + H.exn(ex346));
				final v347:Map<Int, Int> = new Map<Int, Int>();
			}
		}
		if (false) {
			final v348:Box<K12> = new Box<K12>(K12.K12A);
		} else {
			if (StringTools.endsWith("-7", "42")) {
				C28.f29--;
			}
			(new C40()).m20(([-3 => (-1581255204), 4 => 257, 11 => 61] : Map<Int, Int>));
		}
		var v349:String = "abc";
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
