package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using StringTools;

class Ext {
	public static function ext69(a68:Int):Int {
		H.tick();
		H.out("o305 " + "\"q\"");
		H.out("o306 " + Std.string((cast (new C28("x,y,z", a68)) : C28)));
		var v307:String = Std.string(E5.E5A);
		return a68;
	}
	public static function ext72(a70:String, a71:Int):Bool {
		H.tick();
		for (i308 in 0...4) {
			H.tick();
			if ((E7.E7B(a71)).match(E7C)) {
				H.out("o309 " + Std.string(a71));
				var v310 = a71;
			} else {
				var v311:E5 = E5.E5A;
				H.out("o312 " + Std.string(65535));
			}
		}
		H.out("o313 " + Std.string(E5.E5A));
		H.out("o314 " + Std.string(a71));
		var v315:C40 = new C40();
		Main.fn50((cast (Std.string(a71)) : String), "\\");
		var v316:Bool = true;
		var v317:Null<Int> = ((a70).charCodeAt(a71) ?? -1);
		var v318 = "zz";
		for (i319 in 0...H.lim(a71)) {
			H.tick();
			if (false) continue;
			var w320 = 0;
while (w320 < 1 && (E7.E7B(i319)).match(E7C)) {
				w320++;
				H.tick();
				final v321:E7 = E7.E7C;
				(new C40()).m16((["k0" => E5.E5A] : Map<String, E5>), a71);
				C13.m22();
			}
		}
		return ({ var v322 = C28.m33(E0.E0A); (v316 && false); });
	}
	public static function ext75(a73:Int, a74:Int):String {
		H.tick();
		if (H.apply(168, (v323:Int) -> true)) {
			Ext.ext69(a73);
		}
		var v324:A11 = new A11(("zz").lastIndexOf(""));
		a74 -= a74;
		a74 |= (Reflect.compare("", "zz") + 239);
		for (i325 in 0...H.lim((C28.f29 >>> (a74 & 31)))) {
			H.tick();
			(new C40()).m20(([-3 => a74] : Map<Int, Int>));
			H.out("o326 " + Std.string(null));
			var v327:Int = (K12.K12B : Int);
		}
		final v328:String = "  pad  ";
		final v329:String = C28.f30;
		return v329;
	}
}
