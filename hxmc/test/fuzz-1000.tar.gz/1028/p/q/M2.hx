package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M2 {}

enum abstract K12(Int) to Int {
	var K12A = 1;
	var K12B = 4;
}

class C43 {
	public function new(a44:String, a45:Int) {}
	public function m46(a47:Bool, a48:Int):String {
		H.tick();
		var w193 = 0;
while (w193 < 2 && a47) {
			w193++;
			H.tick();
			H.out("o194 " + Std.string(110));
			a48 = ((new Map<String, Int>()).get("k3") ?? 0);
		}
		H.out("o195 " + Std.string((new A11(65)).get()));
		var v196:C13 = (new C13()).m16(new Map<String, E5>(), C28.f29);
		var v197 = H.apply(171, (v198:Int) -> "x,y,z");
		for (i199 in 2...4) {
			H.tick();
			H.out("o200 " + Std.string(i199));
			C13.m22();
			var v201:E5 = E5.E5A;
		}
		H.out("o202 " + Std.string((new A11(0x1870) : Int)));
		v197 = H.cap(Std.string(C28.f29));
		var v203:Null<Int> = C28.m33(E0.E0A);
		return Std.string(E0.E0A);
	}
	public function m49():E0 {
		H.tick();
		var w204 = 0;
while (w204 < 3 && Ext.ext72("\\", 0x7FFFFFFF)) {
			w204++;
			H.tick();
			if ((new Map<String, Int>()).exists('$$')) {
				C28.f29 ^= (-1946710253);
			}
		}
		if ((Type.enumIndex(E7.E7B(73)) > Lambda.count([1391480817, 0x92DE], v205 -> true))) return E0.E0C(E0.E0A, 0xFFFFFFFF);
		if ((Reflect.compare(252, 0x7FFFFFFF) > Lambda.count(([] : Array<Int>), v206 -> ((["k0" => v206, "k1" => 218] : Map<String, Int>)).exists("k0")))) {
			m46(true, (((["k0" => 249] : Map<String, Int>)).get("k2") ?? 0));
		} else {
			final v207:Int = Type.enumIndex(E5.E5A);
		}
		final v208:Int = ((K12.K12A : Int) - 227);
		C28.f29 ^= v208;
		return E0.E0A;
	}
}
