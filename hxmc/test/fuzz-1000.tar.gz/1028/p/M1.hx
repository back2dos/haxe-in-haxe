package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;
using StringTools;

class M1 {}

enum E5 {
	E5A;
}

enum E7 {
	E7A;
	E7B(a9:Int);
	E7C;
	E7D(a10:Int);
}

class C13 {
	public var f14:String;
	public var f15:Int;
	public function new() {
		this.f14 = '$$';
		this.f15 = ("\\").indexOf("q");
	}
	public function m16(a17:Map<String, E5>, a18:Int):C13 {
		H.tick();
		var v76 = a18;
		var v77 = !(E0.E0A).match(E0B(_, _));
		for (k78 => v79 in ((false ? new Map<String, Int>() : new Map<String, Int>()) : Map<String, Int>)) {
			H.tick();
			H.out("o80 " + Std.string(193));
			H.out("o81 " + Std.string(v79));
		}
		try {
			if ((this.f15 == a18)) throw "boom";
			for (i82 in 0...H.lim(v76)) {
				H.tick();
				H.out("o83 " + Std.string(v76));
				var v84:Int = v76;
			}
		} catch (ex85:String) {
			H.out("caught String " + ex85);
			final v86:A11 = new A11(v76);
		} catch (ex87:Int) {
			H.out("caught Int " + ex87);
			final v88:Map<String, Bool> = new Map<String, Bool>();
		} catch (ex89:Err) {
			H.out("caught Err " + ex89.errCode);
			a18 = 0x80000000;
		} catch (ex90:Dynamic) {
			H.out("caught " + H.exn(ex90));
			final v91:(String) -> String = function(p92:String):String {
				H.tick();
				H.out("o93 " + p92);
				var v94:Int = 20;
				var v95:E7 = E7.E7B(a18);
				return p92;
			};
		}
		for (i96 in 0...H.lim(H.apply(("hello world").length, (v97:Int) -> ("q").lastIndexOf("  pad  ")))) {
			H.tick();
			C28.f29 ^= v76;
		}
		H.out("o98 " + Std.string(this.f15));
		this.f15--;
		try {
			if (false) throw ('$$').toLowerCase();
			var v99:String = "42";
			{
				H.out("o100 " + Std.string(796493437));
				final v101:Bool = v77;
				H.out("o102 " + Std.string(0x80000000));
			}
			var w103 = 0;
do {
				w103++;
				H.tick();
				H.out("o104 " + v99);
				final v105:Box<C13> = new Box<C13>(new C40());
			} while (w103 < 4 && (Std.downcast((new C40() : C13), C13) != null));
		} catch (ex106:Dynamic) {
			H.out("caught " + H.exn(ex106));
			for (i107 in 0...H.lim(("").lastIndexOf("\\"))) {
				H.tick();
				var v108:E7 = E7.E7D(a18);
				var v109:Map<Int, Int> = new Map<Int, Int>();
				H.out("o110 " + Std.string(null));
			}
		}
		return new C40();
	}
	public function m19():Void {
		H.tick();
		final v111 = (false ? StringTools.contains("ab", "ab") : (E7D(823083110)).match(E7B(_)));
		var v112:Int = C28.f29;
		H.out("o113 " + Std.string((C28.f29 >> (v112 & 31))));
		var v114:Map<Int, Int> = new Map<Int, Int>();
		var v115:String = Std.string(E5.E5A);
		var v116:C28 = new C28("hello world", v112);
		var v117 = ({ var v118 = v112; v112; });
	}
	public function m20(a21:Map<Int, Int>):A11 {
		H.tick();
		try {
			var w119 = 0;
while (w119 < 1 && Std.isOfType(new C28("hello world", 81), C28)) {
				w119++;
				H.tick();
				this.f15 = 63;
			}
			H.out("o120 " + Std.string(E5.E5A));
			var v121:C43 = new C43('$$', 253);
			if ((true && false)) throw ((K12.K12B : Int) + ("zz").replace("a", "b"));
		} catch (ex122:Dynamic) {
			H.out("caught " + H.exn(ex122));
			this.f15 = (Std.parseInt(Std.string(49)) ?? 0);
			H.out("o123 " + Std.string(true));
		}
		if (((E7C).match(E7D(_)) ? (E0.E0A).match(E0A) : false)) {
			this.f15 ^= (-3);
			C28.f29 <<= (0x9813 & 7);
			var v124:Bool = true;
		}
		this.m16((["k0" => E5.E5A, "k1" => E5A, "k2" => E5.E5A] : Map<String, E5>), H.apply(("  pad  ").toUpperCase(), (v125:String) -> 169));
		var w126 = 0;
while (w126 < 1 && (false && (E0.E0A).match(E0C(_, _)))) {
			w126++;
			H.tick();
			var v127:Map<String, Int> = new Map<String, Int>();
		}
		C28.f29 ^= 209;
		H.out("o128 " + Std.string(106));
		for (i129 in 0...H.lim((new Box(270)).value)) {
			H.tick();
			var v130 = StringTools.contains("-7", "a");
			H.out("o131 " + Std.string(0x80000000));
			var v132:Int = 151;
		}
		return (cast (({ var v133 = "42"; new A11(268); })) : A11);
	}
	public static function m22():Void {
		H.tick();
		var v134:Map<Int, Bool> = (cast (new Map<Int, Bool>()) : Map<Int, Bool>);
		var v135 = true;
		H.out("o136 " + Std.string((187 >>> (257 & 31))));
		final v137:C28 = new C28("", 272);
	}
}

class C40 extends C13 {
	public var cb41:(Int) -> Int;
	public function new() {
		super();
		this.cb41 = (p164:Int) -> p164;
	}
	override public function m20(a21:Map<Int, Int>):A11 {
		H.tick();
		m16((["k0" => E5A, "k1" => E5.E5A] : Map<String, E5>), ("  pad  ").indexOf(("q").replace("a", "b")));
		(m16((["k0" => E5A, "k1" => E5.E5A] : Map<String, E5>), 14)).m16((["k0" => E5.E5A, "k1" => E5.E5A, "k2" => E5A] : Map<String, E5>), ("-7").indexOf("-7"));
		if ((this.f14 != Std.string(E7C))) {
			var v165:C13 = new C40();
			H.out("o166 " + Std.string(Std.isOfType(new C28("x,y,z", 177), C23)));
		}
		this.f15 = (-717687081);
		this.m16((["k0" => E5.E5A, "k1" => E5A] : Map<String, E5>), ((Std.string(28)).charCodeAt(("  pad  ").length) ?? -1));
		var v167:Int = Reflect.compare(("hello world").replace("a", "b"), ('$$').charAt(0));
		H.out("o168 " + "\"q\"");
		try {
			for (i169 in 0...1) {
				H.tick();
				H.out("o170 " + "\n");
			}
			var v171:String = "\t";
			if ((v167 == 491202401)) throw "boom";
		} catch (ex172:String) {
			H.out("caught String " + ex172);
			for (i173 in 0...H.lim((K12.K12B : Int))) {
				H.tick();
				var v174 = 94;
			}
		} catch (ex175:Int) {
			H.out("caught Int " + ex175);
			this.m16(new Map<String, E5>(), 289);
		} catch (ex176:Err) {
			H.out("caught Err " + ex176.errCode);
			(new C40()).m16(new Map<String, E5>(), (Std.parseInt(Std.string(0xEF65)) ?? 0));
		} catch (ex177:Dynamic) {
			H.out("caught " + H.exn(ex177));
			var w178 = 0;
while (w178 < 4 && ((["k0" => false] : Map<String, Bool>)).exists("k3")) {
				w178++;
				H.tick();
				H.out("o179 " + Std.string((K12.K12B : Int)));
				H.out("o180 " + Std.string(v167));
				this.m16(new Map<String, E5>(), v167);
			}
			var v181:C23 = new C28("A-B-C", v167);
		}
		var v182:C13 = new C13();
		return new A11((("\t").indexOf("hello world") * C28.f29));
	}
	public function m42():Void {
		H.tick();
		this.m16(new Map<String, E5>(), 21);
		try {
			if (true) throw new Err(this.f15);
			var v183 = C28.f29;
			H.out("o184 " + Std.string(0xFFFFFFFF));
		} catch (ex185:Err) {
			H.out("caught Err " + ex185.errCode);
			H.out("o186 " + Std.string(C28.f29));
			var v187:Map<String, Int> = (["k0" => 47, "k1" => 0xD273, "k2" => (-1413222836)] : Map<String, Int>);
		} catch (ex188:haxe.Exception) {
			H.out("caught " + H.exn(ex188));
			H.out("o189 " + Std.string(new Box<K12>(K12.K12B)));
			this.f15 &= 113;
		}
		H.out("o190 " + StringTools.hex((C28.f29) & 0xFFFF, 4));
		H.out("o191 " + Std.string(((true ? new C23("42", true) : new C28("\\", 256)) : C23)));
		H.out("o192 " + (new Box<String>("A-B-C")).get());
	}
}
