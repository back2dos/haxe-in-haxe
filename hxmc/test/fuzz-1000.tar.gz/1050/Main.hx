import H;
import p.M1;
import p.q.M2;
using p.Ext;

typedef S3 = {x4:Int};

class Main {
	public static function fn6(a7:Int, a8:Bool, a9:Array<Bool>):Void {
		H.tick();
		var v37 = a7;
		for (i38 in 0...H.lim((switch (E0.E0B(a7)) {
			case E0A: (({x4: v37} : S3)).x4;
			case E0B(c39): Reflect.compare(84, 0xFFFFFFFF);
			case _: a7;
		}))) {
			H.tick();
			v37 -= (((["k0" => 109, "k1" => i38, "k2" => a7] : Map<String, Int>)).get("a") ?? 0);
			a9.reverse();
			final lf40:(Int) -> Int = function(p41:Int):Int {
				H.tick();
				H.out("o42 " + Std.string((new A5(117) : Int)));
				var v43:Int = p41;
				return 123;
			};
		}
		switch (((-1050297617) ^ (Std.parseInt("hello world") ?? 0))) {
			case 0: {
				for (x44 in ([] : Array<Int>)) {
					H.tick();
					v37 = a7;
					final v45:E0 = E0.E0C(x44);
					H.out("o46 " + Std.string(a7));
				}
			};
			case 3 | 6: {
				H.out("o47 " + "-7");
			};
			case _: {
				var v48:S3 = ({x4: v37} : S3);
			};
		}
		final lf49:() -> Void = function():Void {
			H.tick();
			var v50:Int = a7;
			var v51:Map<String, Int> = new Map<String, Int>();
			var v52:Box<Int> = new Box<Int>(a7);
		};
		for (i53 in 0...4) {
			H.tick();
			H.out("o54 " + Std.string((Std.parseInt(Std.string(a7)) ?? 0)));
			if (([i53]).contains(a7)) {
				var v55:Box<Int> = new Box(v37);
			} else {
				H.out("o56 " + Std.string([i53, v37, i53]));
				final v57:() -> Int = () -> 264;
			}
			for (i58 in 2...H.lim((v37 -= 1))) {
				H.tick();
				var v59 = false;
			}
		}
		var v60 = v37;
		var w61 = 0;
while (w61 < 1 && false) {
			w61++;
			H.tick();
			final v62:E0 = E0.E0B(v60);
			if (true) {
				final v63:Bool = false;
				H.out("o64 " + Std.string(a7));
				var v65:Map<Int, Int> = ([-3 => v37, 4 => a7, 11 => v37] : Map<Int, Int>);
			} else {
				H.out("o66 " + Std.string(([new A5(v37)] : Array<A5>)));
				final v67:() -> Int = () -> v37;
			}
		}
	}
	public static function fn10(a11:A5, a12:A5):Int {
		H.tick();
		var v68 = 19;
		var w69 = 0;
while (w69 < 2 && false) {
			w69++;
			H.tick();
			++v68;
		}
		if (false) {
			H.out("o70 " + Std.string(false));
			switch (E0.E0C(v68)) {
				case E0A: {
					H.out("o71 " + Std.string(126));
					H.out("o72 " + Std.string(({x4: v68} : S3)));
				};
				case E0B(c73): {
					v68 -= v68;
					v68 = H.id(v68);
				};
				case E0C(c74): {
					var v75:E0 = E0.E0A;
					final v76:S3 = ({x4: v68} : S3);
				};
			}
			var v77:A5 = new A5(v68);
		} else {
			v68 *= Reflect.compare(v68, v68);
			for (i78 in 0...H.lim((((["k0" => v68] : Map<String, Int>)).get("hello world") ?? 0))) {
				H.tick();
				var v79 = true;
				H.out("o80 " + Std.string([(-14), v68]));
				var v81:Box<E0> = new Box<E0>(E0.E0B(v68));
			}
		}
		fn6(Type.enumIndex(E0.E0A), ((({x4: v68} : S3)).x4 > 205), ([] : Array<Bool>));
		H.out("o82 " + "\\");
		final v83:Map<String, String> = (["k0" => (([] : Array<Bool>)).join(""), "k1" => Std.string(v68)] : Map<String, String>);
		return (v68 * (-6));
	}
	public static function fn13(a14:Bool):Int {
		H.tick();
		var v84:E0 = E0.E0B(237);
		H.out("o85 " + Std.string(H.apply(154, (v86:Int) -> new Box<S3>(({x4: v86} : S3)))));
		H.out("o87 " + Std.string(({ var v88 = false; true; })));
		if (a14) {
			var v89:Array<Int> = [104, 1609312013, 20];
			try {
				if (a14) throw "boom";
				var v90:Array<Int> = v89;
				final v91:(Int) -> Bool = (p92:Int) -> false;
			} catch (ex93:Dynamic) {
				H.out("caught " + H.exn(ex93));
				final v94 = a14;
				var v95:Map<Int, E0> = ([-3 => v84] : Map<Int, E0>);
			}
			fn6((({x4: 275} : S3)).x4, false, ([] : Array<Bool>));
		}
		var v96:Map<Int, Bool> = new Map<Int, Bool>();
		return (0x4C3D - (([] : Array<Bool>)).length);
	}
	public static function fn15(a16:Int, a17:E0):Int {
		H.tick();
		H.out("o97 " + Std.string(([a16]).contains(((a16 : A5)).get())));
		var v98:Int = a16;
		if (true) {
			var v99:Map<Int, Int> = new Map<Int, Int>();
			var v100:Map<String, Int> = new Map<String, Int>();
			var v101:Array<Int> = ([] : Array<Int>);
		}
		for (i102 in 0...2) {
			H.tick();
			for (i103 in 2...H.lim((({x4: a16} : S3)).x4)) {
				H.tick();
				var v104 = i102;
			}
			var v105 = v98;
			var v106 = 81;
		}
		final lf107:(Int, Bool) -> Bool = function(p108:Int, p109:Bool):Bool {
			H.tick();
			var v110:Box<Array<Int>> = new Box<Array<Int>>([p108]);
			switch (a17) {
				case E0A: {
					H.out("o111 " + Std.string(35));
					v98 ^= v98;
				};
				case E0B(c112): {
					var v113:Map<String, Int> = (["k0" => 0xDFBE] : Map<String, Int>);
					final v114:E0 = a17;
				};
				case E0C(c115): {
					var v116:Map<String, Int> = new Map<String, Int>();
				};
			}
			for (k117 => v118 in new Map<String, Int>()) {
				H.tick();
				var v119:A5 = new A5(a16);
				H.out("o120 " + Std.string(p109));
				fn6(a16, p109, ([] : Array<Bool>));
			}
			return p109;
		};
		var v121:Int = (a16 << ((new A5(v98)).get() & 31));
		try {
			if (false) throw '-${Std.string(a17)}${Std.string(false)}';
			var v122 = 14;
			H.out("o123 " + Std.string(268));
		} catch (ex124:String) {
			H.out("caught String " + ex124);
			var v125:S3 = ({x4: 84} : S3);
		} catch (ex126:Int) {
			H.out("caught Int " + ex126);
			var v127:Box<Bool> = new Box(true);
			var v128:Map<Int, Int> = new Map<Int, Int>();
		} catch (ex129:Err) {
			H.out("caught Err " + ex129.errCode);
			var v130:Int = a16;
		} catch (ex131:Dynamic) {
			H.out("caught " + H.exn(ex131));
			var v132:Int = (((["k0" => a16, "k1" => v98, "k2" => v121] : Map<String, Int>)).get("\"q\"") ?? 0);
			for (i133 in 0...H.lim(a16)) {
				H.tick();
				H.out("o134 " + Std.string(new Box(v121)));
				if (false) break;
				var v135:Bool = true;
			}
		}
		return a16;
	}
	public static function fn18():Box<Int> {
		H.tick();
		H.out("o136 " + Std.string(((113 : A5) : Int)));
		for (k138 => x137 in ((false ? [0x861A, 0x7FFFFFFF, 0x885F] : [0xE052, 205, 0x29FA]) : Array<Int>)) {
			H.tick();
			var v139 = ([k138, 254]).contains(x137);
			var v140:E0 = E0.E0A;
		}
		{
			H.out("o141 " + Std.string((-10)));
			for (i142 in 0...H.lim(1842230193)) {
				H.tick();
				var v143:Map<String, Int> = (["k0" => 0x80000000, "k1" => i142, "k2" => i142] : Map<String, Int>);
				Main.fn13(true);
			}
		}
		{
			{
				final v144:(Int, Int) -> Int = (p145:Int, p146:Int) -> 76;
			}
		}
		var v147 = ((new Map<Int, Int>()).get(Lambda.count([208, 0x8005], v148 -> (([] : Array<Int>)).contains(v148))) ?? 0);
		fn13((true ? (new Map<String, Bool>()).exists("k0") : true));
		if (true) {
			var w149 = 0;
do {
				w149++;
				H.tick();
				var v150:Map<Int, Bool> = new Map<Int, Bool>();
				++v147;
				final v151:Array<String> = ["\"q\""];
			} while (w149 < 4 && true);
			if (true) {
				fn13(true);
			} else {
				var v152:Box<S3> = new Box<S3>(({x4: 144} : S3));
				H.out("o153 " + Std.string(v147));
			}
			H.out("o154 " + Std.string(([28]).indexOf(v147)));
		} else {
			fn15(Lambda.fold([v147, 65535], (v155:Int, v156:Int) -> (Std.parseInt(Std.string(v156)) ?? 0), 0), E0.E0C(v147));
			if (([188, 216, 251]).contains(247)) {
				var v157 = v147;
				H.out("o158 " + Std.string(E0.E0C(v147)));
			} else {
				var v159:Map<String, Int> = new Map<String, Int>();
			}
		}
		return new Box(220);
	}
	public static function fn19():Bool {
		H.tick();
		Main.fn15(fn13(true), E0.E0C(Type.enumIndex(E0.E0B((-1983061837)))));
		var w160 = 0;
while (w160 < 2 && (273 < Lambda.count(([] : Array<Int>), v161 -> false))) {
			w160++;
			H.tick();
			for (i162 in 1...H.lim(([194, 65535]).indexOf(51))) {
				H.tick();
				fn15(243, E0.E0B(0xB5DF));
				var v163:S3 = ({x4: i162} : S3);
			}
			if (((["k0" => false] : Map<String, Bool>)).exists("k0")) {
				var v164:Int = 55;
			}
			H.out("o165 " + Std.string((new A5(2) : Int)));
		}
		var v166:Array<Array<S3>> = ([([({x4: 231} : S3), ({x4: 0x7FFFFFFF} : S3), ({x4: 183} : S3)] : Array<S3>)] : Array<Array<S3>>);
		fn6((~(({x4: (-1568304478)} : S3)).x4), (H.at([0x80000000, 263], 195, 0) != 195), ([false, true, true]).concat([false, true]));
		final v167:() -> Void = function():Void {
			H.tick();
			var v168 = 29;
			H.out("o169 " + Std.string(E0.E0C(v168)));
		};
		for (i170 in 0...H.lim((H.at(([] : Array<Int>), 53, 0) ^ Type.enumIndex(E0.E0C(724441057))))) {
			H.tick();
			var v171:S3 = ({x4: i170} : S3);
		}
		return ({ var v172 = (173 != (new A5(458057845)).get()); (true ? true : v172); });
	}
	public static function fn20(a21:Int, a22:Bool):Bool {
		H.tick();
		if ((a21 != (-13))) {
			H.out("o173 " + Std.string([a22, a22]));
			a21 |= 250;
			for (i174 in 0...2) {
				H.tick();
				var v175:E0 = E0.E0A;
			}
		} else {
			a21 |= (++a21);
			if (true) {
				Main.fn15(a21, E0.E0C(a21));
				final v176:(Int) -> Int = (p177:Int) -> (-2147483647);
			} else {
				Main.fn18();
				H.out("o178 " + Std.string(a21));
			}
		}
		var v179:S3 = ({x4: a21} : S3);
		{
			H.out("o180 " + "abc");
		}
		var w181 = 0;
while (w181 < 4 && !true) {
			w181++;
			H.tick();
			if (a22) continue;
			H.out("o182 " + Std.string(new Box(a21)));
			for (i183 in 0...H.lim((new A5(277) : Int))) {
				H.tick();
				H.out("o184 " + Std.string(E0.E0C((-1))));
				var v185:Map<Int, Bool> = ([-3 => a22] : Map<Int, Bool>);
				H.out("o186 " + Std.string(a21));
			}
		}
		var v187:Int = a21;
		var v188:Map<String, Int> = (["k0" => v187, "k1" => 0xFFFFFFFF, "k2" => v187] : Map<String, Int>);
		return Main.fn19();
	}
	public static function fn23(a24:E0):Void {
		H.tick();
		Main.fn19();
		var v189:Box<Bool> = new Box(false);
		function lf190(n191:Int):Int {
			H.tick();
			return n191 <= 0 ? (n191 * n191) : (lf190(n191 - 1) + Reflect.compare(n191, 1075755069));
		}
		H.out("lf190 " + lf190(1));
		var v192 = (-H.at(([] : Array<Int>), (-2060629734), 0));
		var v193:Array<Int> = (new Box<Array<Int>>([(-15)])).get();
		final v194:A5 = ((switch ((["\"q\"", '$$', "A-B-C"]).indexOf("42")) {
			case 0: (v192 : A5);
			case 2 | 4: new A5(v192);
			case _: new A5(v192);
		}) : A5);
		var v195:Box<Bool> = v189;
		switch (a24) {
			case E0A: {
				if (true) {
					v192 <<= (v192 & 7);
					v192 += v192;
				}
			};
			case E0B(c196): {
				final v197:Int = c196;
			};
			case _: {
				switch (223) {
					case 0: {
						H.out("o198 " + Std.string(75));
						v192 = H.id(v192);
					};
					case 1 | 4: {
						fn18();
						v192 *= v192;
					};
					case _: {
						H.out("o199 " + "A-B-C");
						v193.sort((x, y) -> x - y);
					};
				}
				var v200:Map<Int, Int> = new Map<Int, Int>();
			};
		}
		v192 &= fn10(new A5(v192), v194);
	}
	public static function fn25(a26:Array<Bool>, a27:Array<Int>, a28:Int):Int {
		H.tick();
		H.out("o201 " + Std.string(H.at(a27, (a26).indexOf(true), 0)));
		H.out("o202 " + Std.string(E0.E0B((({x4: 0xEB3D} : S3)).x4)));
		var v203:S3 = ({x4: 230} : S3);
		a28++;
		switch ((-(a27).length)) {
			case 0: {
				var v204 = (v203).x4;
			};
			case 1 | 4: {
				{
					Main.fn19();
					H.out("o205 " + Std.string(new Box(a28)));
				}
			};
			case _: {
				var v206 = (a27).contains(a28);
			};
		}
		final lf207:(Int) -> Int = function(p208:Int):Int {
			H.tick();
			final v209:(String) -> Int = (p210:String) -> a28;
			return (++a28);
		};
		function lf211(n212:Int):Int {
			H.tick();
			return n212 <= 0 ? 0x546 : (lf211(n212 - 1) + ((new Map<Int, Int>()).exists(a28) ? H.at([a28, a28], 100, 0) : (((["k0" => n212, "k1" => 35, "k2" => n212] : Map<String, Int>)).get("\\") ?? 0)));
		}
		H.out("lf211 " + lf211(1));
		return (-80);
	}
	public static function fn29(a30:Int):Int {
		H.tick();
		var v213:E0 = E0.E0A;
		var v214:Int = (new A5(a30)).twice;
		var v215:Array<E0> = ([a30, a30]).map((v216:Int) -> (v213 : E0));
		var w217 = 0;
while (w217 < 4 && (([v214, a30, a30]).contains(v214) || true)) {
			w217++;
			H.tick();
			if (false) return v214;
			H.out("o218 " + Std.string(({x4: 76} : S3)));
			var w219 = 0;
while (w219 < 2 && true) {
				w219++;
				H.tick();
				var v220:A5 = new A5(v214);
				var v221:Int = a30;
				H.out("o222 " + Std.string(v214));
			}
		}
		return (((Std.parseInt("A-B-C") ?? 0) - 20) | (v214 >> (v214 & 31)));
	}
	public static function section0():Void {
		H.tick();
		var v269:Int = (-(Std.parseInt("A-B-C") ?? 0));
		Main.fn18();
		v269 = ((v269 -= 1) * 225);
		var v270:S3 = ({x4: v269} : S3);
		if (((([] : Array<Int>)).length < v269)) {
			for (i271 in 0...0) {
				H.tick();
				H.out("o272 " + Std.string(({x4: i271} : S3)));
				v269 = 0xC484;
			}
			var v273:Map<Int, (Int, Bool) -> Int> = new Map<Int, (Int, Bool) -> Int>();
			v269 = H.id(v269);
		} else {
			if (([v269, v269, 71]).contains(v269)) {
				final v274:Bool = true;
				H.out("o275 " + Std.string(([] : Array<Bool>)));
			} else {
				var v276 = true;
				H.out("o277 " + Std.string(([E0.E0A, E0.E0C(9)] : Array<E0>)));
			}
		}
	}
	public static function section1():Void {
		H.tick();
		fn15((new A5(118)).twice, E0.E0B((Std.parseInt("42") ?? 0)));
		var v278:Int = (Std.string(false)).ext32();
		((v278++)).ext36();
		var v279:S3 = ({x4: v278} : S3);
		var v280:E0 = ((([4]).contains(v278) ? E0.E0B(v278) : E0.E0B(v278)) : E0);
		final v281:Array<Int> = ({ var v282 = v278; [v282, 293, v278]; });
		switch ((~H.at([v278], v278, 0))) {
			case 0: {
				fn15(v278, v280);
			};
			case 1 | 6: {
				v278 = (Std.parseInt(Std.string(v278)) ?? 0);
			};
			case _: {
				H.out("o283 " + Std.string(v278));
				H.out("o284 " + Std.string(v278));
			};
		}
	}
	public static function section2():Void {
		H.tick();
		for (i285 in 0...3) {
			H.tick();
			for (i286 in 0...H.lim(i285)) {
				H.tick();
				var v287:Array<Map<String, Int>> = ([] : Array<Map<String, Int>>);
				H.out("o288 " + Std.string(false));
			}
			for (k289 => v290 in new Map<String, Int>()) {
				H.tick();
				var v291 = true;
				var v292:A5 = new A5(118);
				var v293:A5 = new A5(v290);
			}
			var v294:Array<Int> = [0xFFFFFFFF];
		}
		final v295:Map<String, Int> = (["k0" => 146, "k1" => Type.enumIndex(E0.E0B(0x1CAA)), "k2" => 217] : Map<String, Int>);
		var v296:Array<Int> = ([110]).filter(v297 -> true);
		for (i298 in 0...2) {
			H.tick();
			var w299 = 0;
do {
				w299++;
				H.tick();
				fn10(new A5(0x4259), new A5(i298));
				var v300:Int = i298;
			} while (w299 < 2 && true);
		}
		(191).ext36();
		if ((false ? true : false)) {
			var w301 = 0;
while (w301 < 5 && true) {
				w301++;
				H.tick();
				final v302 = 243;
			}
		} else {
			final v303 = (({x4: 0xFE84} : S3)).x4;
			H.out("o304 " + Std.string(E0.E0A));
		}
		var v305 = H.id(211);
		H.out("o306 " + ({ var sb307 = new StringBuf(); sb307.add("  pad  "); sb307.addChar(87); sb307.toString(); }));
		Main.fn18();
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
