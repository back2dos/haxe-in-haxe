package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class Ext {
	public static function ext32(a31:String):Int {
		H.tick();
		H.out("o223 " + Std.string(new Box<E0>(E0.E0A)));
		final v224 = 255;
		H.out("o225 " + Std.string((if (([172, v224, 280]).contains((-1987902270))) 0x7FFFFFFF else ((v224 : A5) : Int))));
		final v226:(Int, Int) -> Int = function(p227:Int, p228:Int):Int {
			H.tick();
			H.out("o229 " + Std.string(p227));
			var v230:Bool = true;
			return Lambda.count([117, 249], v231 -> false);
		};
		return ((v224 & ((65535 : A5)).get()) >>> (v224 & 31));
	}
	public static function ext34(a33:String):Bool {
		H.tick();
		var v232 = Main.fn19();
		H.out("o233 " + Std.string(E0.E0C((({x4: 214} : S3)).x4)));
		if (((new A5(0x80000000)).twice != (({x4: 126} : S3)).x4)) {
			for (k235 => x234 in [0xFFFFFFFF]) {
				H.tick();
				H.out("o236 " + Std.string(k235));
			}
		}
		Ext.ext32('-${Std.string(v232)}');
		return v232;
	}
	public static function ext36(a35:Int):Int {
		H.tick();
		switch (E0.E0B(Lambda.fold(([] : Array<Int>), (v237:Int, v238:Int) -> (a35 += 3), 0))) {
			case E0A: {
				for (k240 => x239 in ["42", "zz"]) {
					H.tick();
					H.out("o241 " + Std.string(k240));
				}
				Main.fn19();
			};
			case E0B(c242): {
				if (false) {
					var v243:Array<Int> = [c242, 1190602764];
				} else {
					a35 += a35;
				}
				var v244:Array<Bool> = ([] : Array<Bool>);
			};
			case E0C(c245): {
				for (i246 in 0...H.lim(a35)) {
					H.tick();
					Main.fn18();
					H.out("o247 " + Std.string(({x4: i246} : S3)));
					a35 <<= (a35 & 7);
				}
			};
			case _: {
				for (i248 in 0...H.lim(244)) {
					H.tick();
					a35 &= a35;
					H.out("o249 " + Std.string((new A5(i248) : Int)));
					H.out("o250 " + Std.string((-868817489)));
				}
			};
		}
		for (x251 in [true, true]) {
			H.tick();
			var v252:Array<Int> = [0x80000000, a35];
			for (i253 in 0...H.lim(a35)) {
				H.tick();
				var v254:A5 = new A5(i253);
				final v255:Int = a35;
				var v256:Bool = true;
			}
		}
		switch (a35) {
			case 0: {
				for (i257 in 0...H.lim(a35)) {
					H.tick();
					var v258:Map<String, Int> = (["k0" => a35, "k1" => a35, "k2" => a35] : Map<String, Int>);
					H.out("o259 " + Std.string(({x4: a35} : S3)));
					var v260:Bool = false;
				}
				if (true) {
					a35 = H.id(a35);
					var v261:E0 = E0.E0A;
				}
			};
			case 1 | 5: {
				{
					var v262:A5 = new A5(a35);
					H.out("o263 " + Std.string(new Box<S3>(({x4: a35} : S3))));
					var v264:Array<Array<A5>> = ([([v262, v262] : Array<A5>), ([] : Array<A5>), ([new A5(a35), new A5(a35), v262] : Array<A5>)] : Array<Array<A5>>);
				}
				if (false) {
					var v265:S3 = ({x4: 110} : S3);
				} else {
					var v266:Int = 928955986;
				}
			};
			case _: {
				for (i267 in 2...5) {
					H.tick();
					final v268:E0 = E0.E0A;
				}
			};
		}
		a35 <<= (((new A5(a35) : Int) >> (145 & 31)) & 7);
		return (([] : Array<Int>)).indexOf((a35 & a35));
	}
}
