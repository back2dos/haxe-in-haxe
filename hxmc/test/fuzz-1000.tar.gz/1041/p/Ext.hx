package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext63(a61:Array<Int>, a62:Bool):Bool {
		H.tick();
		C8.f10 = H.cap(C8.f10 + StringTools.replace("ünï", "b", ""));
		final v276:String = "x,y,z";
		final v277:Int = (a62 ? Reflect.compare(v276, v276) : (({x3: a62, x4: 45, x5: 65} : S2)).x5);
		var v278 = v276;
		H.out("o279 " + Std.string(((v276).charCodeAt((v276).length) ?? -1)));
		var v280 = v278;
		return a62;
	}
}
