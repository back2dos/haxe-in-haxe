package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

abstract A6(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A6, b:A6):A6
		return new A6(a.get() + b.get());

	@:op(A * B) public static function mul(a:A6, b:A6):A6
		return new A6(a.get() * b.get());

	@:op(-A) public static function neg(a:A6):A6
		return new A6(-a.get());
}

class C8 {
	public static var f9:Bool = true;
	public static var f10:String = "ab";
	public function new(a11:Int) {}
}
