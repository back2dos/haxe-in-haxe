import H;
import p.M1;
using p.Ext;
using StringTools;

typedef S0 = {x1:String};

typedef S2 = {x3:Bool, x4:Int, x5:Int};

enum abstract K7(Int) to Int {
	var K7A = 1;
	var K7B = 4;
}

class C12 extends C8 {
	public var cb13:(Int) -> Int;
	public function new(a14:Bool, a15:Int) {
		super(a15);
		this.cb13 = (p64:Int) -> p64;
	}
	public function m16():Void {
		H.tick();
		var v65:A6 = new A6((Std.parseInt(Std.string((-1444992822))) ?? 0));
		H.out("o66 " + Std.string(65535));
		if (StringTools.endsWith(C8.f10, "hello world")) {
			for (i67 in 0...2) {
				H.tick();
				var v68:C8 = new C8(0x4A06);
				final v69 = 271;
			}
			final v70:(Int, Bool) -> Void = function(p71:Int, p72:Bool):Void {
				H.tick();
				H.out("o73 " + Std.string(284));
				var v74:Map<Int, Int> = new Map<Int, Int>();
				H.out("o75 " + "hello world");
			};
			var v76:K7 = K7.K7A;
		}
	}
	public function m17():Void {
		H.tick();
		final v77:Int = (("\x41\x42").charCodeAt(251) ?? -1);
		if ((C8.f9 ? StringTools.contains("a\rb", "ünï") : false)) {
			H.out("o78 " + Std.string(("\u{1F600}").lastIndexOf("x,y,z")));
		}
		var v79 = "q";
	}
	public function m18():Bool {
		H.tick();
		for (i80 in 0...2) {
			H.tick();
			final v81:C12 = new C12(false, 246);
			var v82:Bool = false;
			H.out("o83 " + Std.string(new C12(v82, i80)));
		}
		switch (Std.isOfType(new C12(true, 630172546), C8)) {
			case true: {
				m16();
				var v84:C8 = new C12(false, 989055624);
			};
			case false: {
				{
					var v85:String = "\n";
					H.out("o86 " + Std.string(87));
					(new C12(true, 0xB19)).m16();
				}
				H.out("o87 " + Std.string(new C19()));
			};
		}
		var v88:Map<String, Int> = new Map<String, Int>();
		if (((-568764829) <= ("\t").length)) {
			for (i89 in 2...4) {
				H.tick();
				var v90:String = "\n";
			}
			var v91:S2 = ({x4: 100, x5: 40, x3: false} : S2);
			try {
				if (Std.isOfType(new C12(true, (-508285920)), C12)) throw "boom";
				(new C12(true, (-1))).m16();
			} catch (ex92:String) {
				H.out("caught String " + ex92);
				H.out("o93 " + Std.string(true));
				final v94:C32 = new C32(false, ex92);
			} catch (ex95:Int) {
				H.out("caught Int " + ex95);
				var v96 = ex95;
				H.out("o97 " + Std.string(ex95));
			} catch (ex98:Err) {
				H.out("caught Err " + ex98.errCode);
				var v99:A6 = (195 : A6);
				var v100:A6 = v99;
			} catch (ex101:Dynamic) {
				H.out("caught " + H.exn(ex101));
				var v102:C12 = new C12(false, 231);
			}
		} else {
			function lf103(n104:Int):Int {
				H.tick();
				return n104 <= 0 ? n104 : (lf103(n104 - 1) + 0x7FFFFFFF);
			}
			H.out("lf103 " + lf103(3));
			if (false) return false;
		}
		var v105:C8 = new C8((K7.K7A : Int));
		return !C8.f9;
	}
}

class C19 {
	public var f20:String;
	public var f21:Int;
	public function new() {
		this.f20 = ("\\").toLowerCase();
		this.f21 = 0x7FFFFFFF;
	}
	public function m22(a23:String, ?a24:Null<String>):K7 {
		H.tick();
		if (true) {
			H.out("o106 " + Std.string(StringTools.contains(a23, a23)));
		}
		final v107 = (StringTools.hex((167) & 0xFFFF, 4)).toLowerCase();
		final v108:(String, String) -> Int = (p109:String, p110:String) -> 0x73C2;
		var v111:Map<String, Int> = (["k0" => 4] : Map<String, Int>);
		this.f21 = 205;
		var v112 = 71;
		return K7.K7A;
	}
	public function m25(a26:Int):String {
		H.tick();
		switch (a26) {
			case 0: {
				if (Std.isOfType(new C32(false, "ünï"), C32)) {
					this.f21 = a26;
				}
				final v113 = ("x,y,z").lastIndexOf("");
			};
			case 1 | 4: {
				H.out("o114 " + Std.string(((103 : A6)).get()));
			};
			case _: {
				H.out("o115 " + Std.string(a26));
				var v116 = Std.string(143);
			};
		}
		for (i117 in 0...2) {
			H.tick();
			a26 -= i117;
			final v118 = true;
			var v119:C8 = new C8(i117);
		}
		H.out("o120 " + Std.string((a26 + (("-7").charCodeAt(a26) ?? -1))));
		return (((({x3: false, x4: a26, x5: a26} : S2)).x5 + "\u{1F600}")).replace("a", "b");
	}
	public static inline function m27(a28:Bool):Int {
		H.tick();
		H.out("o121 " + Std.string(((((([-3 => 0x80EA, 4 => 85] : Map<Int, Int>)).get(290) ?? 0) : A6) : Int)));
		H.out("o122 " + Std.string((new A6(65535)).twice));
		var v123 = true;
		if (true) {
			(new C12(a28, 24)).m18();
			var v124:C19 = new C19();
		}
		try {
			H.out("o125 " + Std.string(v123));
			for (i126 in 2...3) {
				H.tick();
				var v127:String = "  pad  ";
			}
			if (a28) throw ("42").substring((237 & 7), 1);
		} catch (ex128:Err) {
			H.out("caught Err " + ex128.errCode);
			final v129:Map<String, Bool> = (["k0" => a28, "k1" => v123, "k2" => a28] : Map<String, Bool>);
		} catch (ex130:haxe.Exception) {
			H.out("caught " + H.exn(ex130));
			var v131:K7 = K7.K7A;
		}
		return ((StringTools.lpad("x,y,z", "*", 1)).toUpperCase()).length;
	}
	public static function m29(a30:Int, a31:String):String {
		H.tick();
		var w132 = 0;
while (w132 < 3 && (cast (false) : Bool)) {
			w132++;
			H.tick();
			H.out("o133 " + Std.string((new A6(a30) : Int)));
		}
		Main.fn42(Main.fn44());
		H.out("o134 " + Std.string(47));
		var v135 = (178 != a30);
		var v136:Bool = (a30 <= 104);
		try {
			if ((a30 <= Lambda.count([0x80000000, a30, a30], v137 -> false))) throw "boom";
			{
				a30++;
				a30 *= a30;
			}
			switch (K7.K7A) {
				case K7.K7A: {
					var v138 = a31;
					final v139:C8 = new C8(a30);
				};
				case K7.K7B: {
					Main.fn44(v135);
					H.out("o140 " + Std.string(a30));
				};
			}
		} catch (ex141:String) {
			H.out("caught String " + ex141);
			{ var dyn142:Dynamic = ({x1: a31} : S0); H.out("dyn " + Std.string(dyn142.x1) + " " + Std.string(Reflect.field(dyn142, "x1"))); }
		} catch (ex143:Int) {
			H.out("caught Int " + ex143);
			final v144:() -> Bool = () -> v136;
			var v145:Map<String, (Int, Int) -> Bool> = new Map<String, (Int, Int) -> Bool>();
		} catch (ex146:Err) {
			H.out("caught Err " + ex146.errCode);
			if ((([-3 => a31, 4 => a31] : Map<Int, String>)).exists(18)) {
				var v147:Int = 0xFFFFFFFF;
			}
			function lf148(n149:Int):Int {
				H.tick();
				return n149 <= 0 ? n149 : (lf148(n149 - 1) + 126);
			}
			H.out("lf148 " + lf148(5));
		} catch (ex150:Dynamic) {
			H.out("caught " + H.exn(ex150));
			H.out("o151 " + Std.string(a30));
		}
		switch ((switch (a30) {
			case 0: v136;
			case 3 | 6: Std.isOfType(new C32(v136, a31), C32);
			case _: false;
		})) {
			case true: {
				var v152 = StringTools.lpad(a31, "*", 0);
				H.out("o153 " + Std.string(Reflect.compare("Haxe", "zz")));
			};
			case false: {
				final v154 = Std.string(v135);
				if (true) {
					var v155:Map<String, String> = new Map<String, String>();
					Main.fn44(v136);
				} else {
					H.out("o156 " + Std.string(a30));
					a30 = 223;
				}
			};
		}
		return a31;
	}
}

class C32 {
	public final f33:Bool;
	var _f34:Int;

	public var f34(get, set):Int;

	function get_f34():Int
		return _f34;

	function set_f34(v:Int):Int
		return _f34 = v;
	public var f35:String;
	public var cb36:(Int) -> Int;
	public function new(a37:Bool, a38:String) {
		this.f33 = false;
		this._f34 = 109;
		this.f35 = a38;
		this.cb36 = (p157:Int) -> p157;
	}
	public function m39():Void {
		H.tick();
		var v158 = 78;
		var v159 = "zz";
		var v160:String = this.f35;
		Ext.ext63(({ var v161 = v160; ([] : Array<Int>); }), Std.isOfType(new C19(), C19));
		function lf162(n163:Int):Int {
			H.tick();
			return n163 <= 0 ? v158 : (lf162(n163 - 1) + (this.f34 + n163));
		}
		H.out("lf162 " + lf162(3));
		if (false) {
			H.out("o164 " + Std.string(this.f34));
		} else {
			for (i165 in 0...0) {
				H.tick();
				this.f34 = i165;
				final v166 = 161;
			}
		}
	}
	public function m40(a41:Bool):String {
		H.tick();
		this.f34 = (this.f33 ? 161 : this.f34);
		m39();
		var w167 = 0;
while (w167 < 5 && a41) {
			w167++;
			H.tick();
			var v168:Bool = false;
			H.out("o169 " + "\\");
			var w170 = 0;
while (w170 < 4 && v168) {
				w170++;
				H.tick();
				var v171:S2 = ({x3: v168, x4: 8, x5: 65535} : S2);
				this.f34 *= 145;
			}
		}
		H.out("o172 " + Std.string(Main.fn44()));
		for (i173 in 0...H.lim(((new Map<String, Int>()).get("k3") ?? 0))) {
			H.tick();
			H.out("o174 " + Std.string(a41));
			if (C8.f9) {
				final v175:S2 = ({x5: 193, x4: i173, x3: a41} : S2);
				Main.fn46(i173);
				if (false) break;
			}
			if (false) continue;
		}
		return '${"\"q\""}';
	}
}

class Main {
	public static function fn42(a43:Int):Bool {
		H.tick();
		final v176:Map<String, S2> = (["k0" => ({x3: false, x4: a43, x5: 71} : S2), "k1" => ({x3: true, x4: a43, x5: a43} : S2)] : Map<String, S2>);
		if ((a43 == (new A6(a43)).get())) {
			H.out("o177 " + Std.string(0xE74));
			var v178:String = ("\n").toUpperCase();
		}
		a43--;
		return true;
	}
	public static function fn44(?a45:Null<Bool>):Int {
		H.tick();
		if ((new C12(true, 206)).m18()) {
			final v179:String = Std.string(138);
			var v180 = StringTools.startsWith(v179, "  pad  ");
		} else {
			var v181 = Lambda.count([(-1853309520), 263, 212], v182 -> StringTools.contains("hello world", "ünï"));
		}
		{
			if (StringTools.contains("ünï", "  pad  ")) {
				H.out("o183 " + "abc");
				var v184 = "0";
			}
			var v185:S0 = ({x1: "42"} : S0);
		}
		{
			final v186:Bool = (Std.downcast((new C19() : C19), C19) != null);
		}
		var v187:S2 = ({x3: false, x4: (-8), x5: 38044822} : S2);
		var v188:String = C8.f10;
		C8.f9 = true;
		try {
			if (false) throw new Err(((v188).lastIndexOf(v188) + 8));
			switch ((v188).substring(5, (198109228 & 7))) {
				case "a" | "b": {
					var v189:C12 = new C12(true, 264);
					final v190:Int = 79;
				};
				case "Haxe": {
					var v191 = false;
					H.out("o192 " + Std.string(194));
				};
				case _: {
					var v193:C19 = new C19();
					final v194:String = v188;
				};
			}
			Main.fn42((K7.K7A : Int));
			var v195:Map<Int, Bool> = new Map<Int, Bool>();
		} catch (ex196:Dynamic) {
			H.out("caught " + H.exn(ex196));
			switch (Std.string(278)) {
				case "a" | "b": {
					final v197:(String) -> Void = function(p198:String):Void {
						H.tick();
						var v199:Int = 22;
					};
				};
				case "Haxe": {
					var v200:Map<String, Bool> = (["k0" => false, "k1" => false, "k2" => false] : Map<String, Bool>);
					var v201:A6 = new A6((-2147483647));
				};
				case "": {
					var v202:C19 = new C19();
					H.out("o203 " + v188);
				};
				case _: {
					final v204:() -> Int = () -> 0x4F88;
				};
			}
		}
		var w205 = 0;
while (w205 < 5 && ((v188).charAt(3) <= Std.string((-1236658353)))) {
			w205++;
			H.tick();
			var v206:Map<String, Int> = new Map<String, Int>();
			final lf207:(Int, String) -> Void = function(p208:Int, p209:String):Void {
				H.tick();
				var v210:C12 = new C12(false, p208);
				var v211:C12 = v210;
			};
		}
		return 52;
	}
	public static function fn46(...r47:Int):Void {
		H.tick();
		final v212:() -> Void = function():Void {
			H.tick();
			H.out("o213 " + "\\");
			H.out("o214 " + Std.string(276));
			var v215:S0 = ({x1: "Haxe"} : S0);
		};
		final v216 = "q";
		try {
			if (("A-B-C" >= C8.f10)) throw "boom";
			var v217:S0 = ({x1: "\\"} : S0);
		} catch (ex218:Err) {
			H.out("caught Err " + ex218.errCode);
			H.out("o219 " + Std.string((([-3 => ({x4: 8, x3: false, x5: 206} : S2), 4 => ({x3: true, x5: (-2147483647), x4: 21} : S2)] : Map<Int, S2>)).exists(18)));
			H.out("o220 " + Std.string(70));
		} catch (ex221:haxe.Exception) {
			H.out("caught " + H.exn(ex221));
			switch (("\x41\x42").substring(-2, -1)) {
				case "a" | "b": {
					H.out("o222 " + Std.string(90));
				};
				case "Haxe": {
					var v223:Bool = true;
				};
				case "": {
					H.out("o224 " + Std.string(false));
				};
				case _: {
					var v225:Int = 0x7FFFFFFF;
					v225 = H.id(v225);
				};
			}
		}
	}
	public static function fn48(a49:A6, a50:Int, a51:String = "d"):Bool {
		H.tick();
		(new C12(true, a50)).m18();
		(new C19()).m25(201);
		fn42((new A6(a50) : Int));
		C19.m27(C8.f9);
		for (i226 in 0...3) {
			H.tick();
			a50 = i226;
			a50 = (--a50);
		}
		for (i227 in 0...1) {
			H.tick();
			{
				var v228 = true;
				if (v228) continue;
			}
			var v229:String = Std.string(false);
		}
		return (((({x3: false, x4: 111, x5: a50} : S2)).x5 - 173) <= (C8.f9 ? 99 : (a50 -= 1)));
	}
	public static function fn52(a53:String, a54:Bool, a55:Int):Bool {
		H.tick();
		a55 = H.id(a55);
		H.out("o230 " + Std.string((a55 + a55)));
		for (i231 in 0...2) {
			H.tick();
			function lf232(n233:Int):Int {
				H.tick();
				return n233 <= 0 ? 193 : (lf232(n233 - 1) + a55);
			}
			H.out("lf232 " + lf232(5));
		}
		var w234 = 0;
while (w234 < 2 && fn48(new A6(a55), (({x3: a54, x4: a55, x5: a55} : S2)).x4)) {
			w234++;
			H.tick();
			H.out("o235 " + Std.string(a55));
			H.out("o236 " + Std.string(new C19()));
			if (a54) {
				a55 = 279;
			} else {
				var v237 = a55;
				var v238:Int = v237;
			}
		}
		return ((a54 && true) && (Std.downcast((new C32(a54, "\n") : C32), C32) != null));
	}
	public static function fn56(a57:Int):Void {
		H.tick();
		final v239:(Int, Int) -> Void = function(p240:Int, p241:Int):Void {
			H.tick();
			var v242:Bool = true;
			fn44();
		};
		try {
			final v243:String = "x,y,z";
			H.out("o244 " + Std.string(false));
			if (false) throw "boom";
		} catch (ex245:String) {
			H.out("caught String " + ex245);
			final lf246:() -> Void = function():Void {
				H.tick();
				var v247:String = ex245;
			};
			H.out("o248 " + Std.string(66));
		} catch (ex249:Int) {
			H.out("caught Int " + ex249);
			var v250 = a57;
			H.out("o251 " + Std.string(a57));
		} catch (ex252:Err) {
			H.out("caught Err " + ex252.errCode);
			final v253:S2 = ({x3: true, x4: a57, x5: 1112106374} : S2);
		} catch (ex254:Dynamic) {
			H.out("caught " + H.exn(ex254));
			final lf255:(String) -> Void = function(p256:String):Void {
				H.tick();
				var v257 = a57;
				var v258:Int = v257;
			};
		}
		var v259:Map<Int, Bool> = ((switch (("zz").substring(-2, 3)) {
			case "a" | "b": new Map<Int, Bool>();
			case "Haxe": ([-3 => true, 4 => true, 11 => false] : Map<Int, Bool>);
			case "": new Map<Int, Bool>();
			case _: ([-3 => false, 4 => false, 11 => false] : Map<Int, Bool>);
		}) : Map<Int, Bool>);
		{
			a57 *= a57;
			var v260:K7 = K7.K7B;
			var v261:C12 = new C12(false, a57);
		}
		Main.fn46(29);
		C19.m27((Lambda.count([0x58E, a57, (-2147483647)], v262 -> StringTools.endsWith("\n", "abc")) >= ((new Map<String, Int>()).get("") ?? 0)));
	}
	public static function fn58(a59:Int, a60:String):Void {
		H.tick();
		H.out("o263 " + Std.string(180));
		a59 = 72;
		var w264 = 0;
while (w264 < 5 && false) {
			w264++;
			H.tick();
			var v265 = StringTools.endsWith(a60, a60);
			var v266:Int = a59;
			for (i267 in 2...3) {
				H.tick();
				final v268:(Int) -> String = function(p269:Int):String {
					H.tick();
					var v270:C8 = new C12(v265, a59);
					C19.m27(v265);
					return "ünï";
				};
			}
		}
		Main.fn48((a59 : A6), (new A6(a59)).twice);
		if ((true && false)) {
			var v271:S2 = ({x3: false, x5: a59, x4: a59} : S2);
			var w272 = 0;
while (w272 < 5 && C8.f9) {
				w272++;
				H.tick();
				H.out("o273 " + Std.string(a59));
				var v274 = a60;
				var v275:String = "0";
			}
		}
		a59 = (((["k0" => 43, "k1" => a59] : Map<String, Int>)).get("k3") ?? 0);
	}
	public static function section0():Void {
		H.tick();
		H.out("o281 " + Std.string((cast (false) : Bool)));
		for (i282 in 0...H.lim(0xBE28)) {
			H.tick();
			var v283 = "q";
			var v284:String = "q";
			var v285:String = Std.string(i282);
		}
		var v286:Int = fn44();
		var v287:C32 = new C32(true, Std.string(v286));
		if ((new C12(false, 256)).m18()) {
			(new C12(false, (-1))).m16();
			v286 *= 293;
		} else {
			H.out("o288 " + Std.string((++v286)));
			function lf289(n290:Int):Int {
				H.tick();
				return n290 <= 0 ? v286 : (lf289(n290 - 1) + 118);
			}
			H.out("lf289 " + lf289(2));
		}
		final v291:(String) -> Int = function(p292:String):Int {
			H.tick();
			var v293:A6 = (v286 : A6);
			var v294:K7 = K7.K7A;
			return 147;
		};
	}
	public static function section1():Void {
		H.tick();
		fn48(((265 : A6) + new A6(213)), fn44((new Map<Int, K7>()).exists(18)), Std.string((("x,y,z").charCodeAt(204) ?? -1)));
		for (i295 in 0...2) {
			H.tick();
			for (i296 in 0...4) {
				H.tick();
				fn42(i296);
				var v297:Map<String, String> = new Map<String, String>();
				C8.f9 = true;
			}
			switch (K7.K7B) {
				case K7.K7A: {
					var v298:C12 = new C12(true, i295);
					final v299:(String, Bool) -> Void = function(p300:String, p301:Bool):Void {
						H.tick();
						final v302:Map<Int, (Int, Bool) -> String> = new Map<Int, (Int, Bool) -> String>();
					};
				};
				case K7.K7B: {
					H.out("o303 " + Std.string(i295));
				};
			}
			H.out("o304 " + Std.string(true));
		}
		var v305:Bool = (C8.f10 >= "日本語");
		if ((true && v305)) {
			var w306 = 0;
while (w306 < 2 && false) {
				w306++;
				H.tick();
				var v307:Map<String, String> = new Map<String, String>();
				var v308:S0 = ({x1: "a"} : S0);
			}
		}
		var v309 = ({ var v310 = ("a").replace("a", "b"); 73; });
		fn44();
		final v311 = v305;
		(new C32(true, "ünï")).m39();
		{
			C8.f9 = false;
		}
	}
	public static function section2():Void {
		H.tick();
		var v312:A6 = ((switch (StringTools.lpad("x,y,z", "*", 2)) {
			case "a" | "b": new A6(0xFFFFFFFF);
			case "Haxe": new A6(149);
			case "": new A6(0x80000000);
			case _: new A6(25);
		}) : A6);
		(new C12(C8.f9, (v312).get())).m16();
		var v313:A6 = (v312 * new A6(236));
		v312 = new A6((({x3: true, x4: 175, x5: 80} : S2)).x5);
		var v314 = (K7.K7B : Int);
		var v315:Int = v314;
		{
			H.out("o316 " + Std.string(v315));
			final lf317:() -> Void = function():Void {
				H.tick();
				v314 += 197;
				var v318:S0 = ({x1: "  pad  "} : S0);
			};
		}
	}
	public static function section3():Void {
		H.tick();
		var v319 = (false ? "abc" : ("zz").substr((46 & 7), (2 & 7)));
		var v320:S2 = ((switch (false) {
			case true: ({x3: true, x4: 96, x5: (-15)} : S2);
			case false: ({x3: false, x4: 41, x5: 61} : S2);
		}) : S2);
		for (i321 in 0...1) {
			H.tick();
			var v322:String = C8.f10;
			var w323 = 0;
while (w323 < 5 && Std.isOfType(new C32(true, v319), C32)) {
				w323++;
				H.tick();
				var v324 = i321;
				fn56(i321);
				final v325:(Int, String) -> String = (p326:Int, p327:String) -> "\n";
			}
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
