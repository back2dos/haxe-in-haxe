package p;

import Main;
import H;

class Ext {
	public static function ext31(a30:Int):E0 {
		H.tick();
		a30 = (new Box(a30)).value;
		if ((false || (E1.E1A).match(E1A))) {
			if ((([-3 => new A9(a30), 4 => (0x7FFFFFFF : A9), 11 => new A9(223)] : Map<Int, A9>)).exists(4)) {
				var v117:Map<Int, Int> = ([-3 => a30] : Map<Int, Int>);
				var v118:Box<() -> Int> = new Box<() -> Int>(Main.fn12);
			} else {
				final v119:Bool = false;
			}
			var v120:Int = 0x80000000;
			Main.fn23(function(p121:Int):Void {
				H.tick();
				H.out("o122 " + Std.string(E1.E1A));
			}, a30, (({x5: false, x3: 233, x4: a30} : S2)).x4);
		} else {
			{
				Main.fn12();
				Main.fn12();
			}
			H.out("o123 " + Std.string(24));
		}
		H.out("o124 " + Std.string((new A9(a30) : Int)));
		if (true) {
			var v125:Array<Int> = [a30, a30];
			var v126:Array<Int> = [a30];
			var v127 = 203;
		} else {
			var v128 = 0xEDEA;
			final v129:Map<Int, Bool> = new Map<Int, Bool>();
		}
		Main.fn11();
		{
			a30 -= a30;
			var v130 = a30;
		}
		var v131:Float = Math.max(1e3, 7.0);
		H.out("o132 " + Std.string(H.apply(a30, (v133:Float) -> ([a30, a30] : Array<Null<Int>>))));
		H.out("o134 " + Std.string(281));
		return (cast (E0.E0A) : E0);
	}
	public static function ext33(a32:Int):Int {
		H.tick();
		var v135:Array<K10> = ([K10.K10C, K10.K10C, K10.K10B] : Array<K10>);
		var v136:E0 = ({ var v137 = a32; E0.E0A; });
		final v138:Box<Bool> = new Box((([-3 => a32] : Map<Int, Int>)).exists(11));
		try {
			if (!false) throw "boom";
			var v139:A9 = (a32 : A9);
		} catch (ex140:Err) {
			H.out("caught Err " + ex140.errCode);
			H.out("o141 " + Std.string(false));
		} catch (ex142:haxe.Exception) {
			H.out("caught " + H.exn(ex142));
			switch (H.id([a32, a32, 0x4D2])) {
				case []: {
					a32 = H.id(a32);
				};
				case [c143]: {
					final v144:Array<S2> = ([({x3: c143, x4: a32, x5: false} : S2), ({x3: (-1598324531), x4: a32, x5: false} : S2), ({x4: c143, x5: true, x3: 283} : S2)] : Array<S2>);
					var v145:Bool = true;
				};
				case [_, c146]: {
					Ext.ext31(c146);
				};
				case _: {
					var v147 = a32;
					Main.fn18(new A9(v147));
				};
			}
		}
		a32 &= 88;
		H.out("o148 " + Std.string(((new A9(0x80000000) : Int) <= a32)));
		H.out("o149 " + Std.string(([a32]).map((v150:Int) -> (E1.E1A : E1))));
		if ((E1.E1A).match(E1A)) {
			Main.fn12();
			H.out("o151 " + Std.string(a32));
			a32 = (--a32);
		} else {
			H.out("o152 " + Std.string(E0.E0A));
		}
		final v153:Float = 1e-7;
		return 242;
	}
	public static function ext35(a34:String):String {
		H.tick();
		final v154 = Type.enumIndex(E0.E0A);
		final v155:Array<Box<Int>> = ([new Box(v154), new Box(96), new Box(v154)] : Array<Box<Int>>);
		if (!false) return a34;
		return a34;
	}
}
