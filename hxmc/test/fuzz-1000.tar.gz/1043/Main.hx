import H;
using p.Ext;

enum E0 {
	E0A;
}

enum E1 {
	E1A;
}

typedef S2 = {x3:Int, x4:Int, x5:Bool};

typedef S6 = {x7:Float, x8:Bool};

abstract A9(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A9, b:A9):A9
		return new A9(a.get() + b.get());

	@:op(A * B) public static function mul(a:A9, b:A9):A9
		return new A9(a.get() * b.get());

	@:op(-A) public static function neg(a:A9):A9
		return new A9(-a.get());
}

enum abstract K10(Int) to Int {
	var K10A = 1;
	var K10B = 4;
	var K10C = 7;
}

class Main {
	public static function fn11():Float {
		H.tick();
		final v36:Int = (true ? Math.floor(1e3) : Lambda.fold([184], (v37:Int, v38:Int) -> Lambda.fold([v38, v38], (v39:Int, v40:Int) -> (Std.parseInt("0") ?? 0), 0), 0));
		var v41:Map<String, Int> = new Map<String, Int>();
		var v42:Array<Int> = (new Box<Array<Int>>(([] : Array<Int>))).value;
		return v36;
	}
	public static function fn12():Int {
		H.tick();
		if ((236960171 > Reflect.compare(203, 0xD97))) {
			try {
				var v43:Map<Int, Bool> = ([-3 => true, 4 => true, 11 => true] : Map<Int, Bool>);
				H.out("o44 " + Std.string(false));
				if ((E1A).match(E1A)) throw "boom";
			} catch (ex45:Err) {
				H.out("caught Err " + ex45.errCode);
				var v46:E0 = E0A;
			} catch (ex47:haxe.Exception) {
				H.out("caught " + H.exn(ex47));
				var v48:Map<Int, Int> = new Map<Int, Int>();
				final v49:(Bool) -> Int = function(p50:Bool):Int {
					H.tick();
					final v51:Bool = p50;
					return 0x61DF;
				};
			}
			if (([722840060]).contains(0x7FFFFFFF)) {
				var v52:Bool = false;
				var v53:E1 = E1.E1A;
			}
			final v54:(Float, Bool) -> Bool = function(p55:Float, p56:Bool):Bool {
				H.tick();
				fn11();
				return true;
			};
		} else {
			H.out("o57 " + Std.string(((([-3 => 1802272622, 4 => 1293358012] : Map<Int, Int>)).get(212) ?? 0)));
			switch (E1A) {
				case E1A: {
					Main.fn11();
				};
			}
		}
		Main.fn11();
		var v58:Array<E0> = ([222]).map((v59:Int) -> (E0.E0A : E0));
		H.out("o60 " + Std.string(!false));
		var v61:Map<String, Int> = (["k0" => (["0"]).indexOf("0"), "k1" => (((["k0" => (-1714805529)] : Map<String, Int>)).get("k1") ?? 0)] : Map<String, Int>);
		var v62:Map<String, Float> = (["k0" => 2.5e-3] : Map<String, Float>);
		var v63:E1 = (((E0.E0A).match(E0A) ? E1A : E1.E1A) : E1);
		var v64 = Reflect.compare((({x3: 185, x4: 14, x5: true} : S2)).x4, (-1193279918));
		final v65:() -> Int = () -> 1167901604;
		return (((Std.parseInt(Std.string(v64)) ?? 0) * (Std.parseInt(Std.string(v64)) ?? 0)) >> (((v63).match(E1A) ? (v64 -= 1) : v64) & 31));
	}
	public static function fn13(a14:Float, a15:Int, a16:Int, ...r17:Int):String {
		H.tick();
		switch (E1A) {
			case E1A: {
				if (Math.isNaN(a15)) {
					var v66:Bool = false;
					var v67 = 13;
				}
			};
		}
		final v68 = a15;
		Main.fn11();
		++a15;
		fn12();
		var v69:Bool = ((-19) != v68);
		H.out("o70 " + Std.string(!v69));
		a15 += v68;
		return (Std.string(v69) + (Type.enumIndex(E0.E0A) - Math.ceil(a15)));
	}
	public static function fn18(a19:A9):E0 {
		H.tick();
		final v71:Array<Int> = ([] : Array<Int>);
		v71.pop();
		H.out("o72 " + Std.string(new Box<E1>(E1A)));
		fn11();
		var v73:Box<S6> = ({ var v74 = (a19 : Int); new Box<S6>(({x7: v74, x8: true} : S6)); });
		if (true) {
			if ((v71).contains(65535)) return E0A;
		} else {
			{
				final v75:() -> Int = () -> 0xB277;
				fn11();
			}
			final v76:Float = 7.0;
		}
		switch (E1A) {
			case E1A: {
				var v77:Int = 70;
				H.out("o78 " + Std.string(new Box(v77)));
			};
			case _: {
				if (true) {
					H.out("o79 " + Std.string(100.75));
					var v80:Array<Bool> = [false];
					Main.fn13(2.5e-3, 250, 27);
				}
			};
		}
		return (new Box<E0>(E0.E0A)).value;
	}
	public static function fn20(a21:Int, a22:Array<Int>):Bool {
		H.tick();
		a21 <<= (a21 & 7);
		try {
			if ((switch ((a21 -= 1)) {
				case 0: true;
				case 2 | 6: true;
				case c81 if (c81 > 10): false;
				case _: false;
			})) throw new Err((({x4: 52, x3: a21, x5: true} : S2)).x3);
			a21 = (a21 -= 1);
		} catch (ex82:Err) {
			H.out("caught Err " + ex82.errCode);
			var v83:S2 = ({x3: a21, x4: a21, x5: true} : S2);
		} catch (ex84:haxe.Exception) {
			H.out("caught " + H.exn(ex84));
			var v85:A9 = new A9(a21);
		}
		try {
			a21 = 280;
			var v86:Bool = ((["k0" => a21, "k1" => a21, "k2" => a21] : Map<String, Int>)).exists("k1");
			if (false) {
				a21 -= a21;
				final v87:S6 = ({x8: v86, x7: 100.75} : S6);
			} else {
				final v88:Bool = v86;
			}
			if (v86) throw "";
		} catch (ex89:Dynamic) {
			H.out("caught " + H.exn(ex89));
			fn12();
		}
		var v90:Int = fn12();
		var v91:Int = (a21 = 5);
		Main.fn18((219 : A9));
		var v92:Int = (v91 * a21);
		var v93:Float = (new Box<Float>(a21)).get();
		return H.apply(Math.floor(0x6BE8), (v94:Int) -> (E0.E0A).match(E0A));
	}
	public static function fn23(a24:(Int) -> Void, ...r25:Int):Int {
		H.tick();
		var v95:Box<Int> = ((switch ((({x3: 91, x4: 187, x5: true} : S2)).x3) {
			case 0: new Box(45);
			case 2 | 4: new Box(136);
			case _: new Box(0xAEBB);
		}) : Box<Int>);
		Main.fn11();
		H.out("o96 " + Std.string(Main.fn12()));
		return (Std.parseInt(' = ${Std.string(H.at(r25.toArray(), 76, 0))}<${"q"}') ?? 0);
	}
	public static function fn26(a27:Int, a28:Int):Array<Int> {
		H.tick();
		var v97:Float = a28;
		Main.fn11();
		switch (([true, false, false]).indexOf((E1A).match(E1A))) {
			case 0: {
				{
					H.out("o98 " + Std.string(false));
					final v99 = a27;
				}
			};
			case 2 | 4: {
				final v100:() -> Float = () -> 7.0;
				H.out("o101 " + Std.string(a28));
			};
			case c102 if (c102 > 10): {
				switch (E0.E0A) {
					case E0A: {
						H.out("o103 " + Std.string(({x5: true, x3: c102, x4: a28} : S2)));
						var v104:Int = a27;
					};
				}
			};
			case _: {
				final v105:Null<Int> = 9;
			};
		}
		final v106:Int = 33;
		var v107:Array<Int> = ([] : Array<Int>);
		fn13((1e3 - v106), (73 << ((a27 += 3) & 31)), a27);
		try {
			if (Main.fn20(Reflect.compare(7, a28), [a27, a28, a27])) throw '<${Std.string(E1.E1A)}';
			var v108 = (a28 -= 1);
		} catch (ex109:Dynamic) {
			H.out("caught " + H.exn(ex109));
			H.out("o110 " + Std.string(a28));
		}
		return v107;
	}
	public static function fn29():Array<E0> {
		H.tick();
		var v111 = (((new Map<String, Int>()).get("zz") ?? 0) <= 201);
		H.out("o112 " + Std.string((((true ? new A9(66) : new A9(1271437083)) : A9) : Int)));
		H.out("o113 " + "x,y,z");
		H.out("o114 " + Std.string([v111, v111]));
		var v115:Map<String, Bool> = (["k0" => v111, "k1" => false, "k2" => false] : Map<String, Bool>);
		if ((E1A).match(E1A)) return (([E0.E0A] : Array<E0>)).copy();
		return (({ var v116 = (new Map<String, Int>()).exists("k0"); ([] : Array<E0>); })).slice(2, ((Math.ceil(1.7976931348623157e308) * (Std.parseInt(Std.string(25)) ?? 0)) & 7));
	}
	public static function section0():Void {
		H.tick();
		final v156:Int = (169 + (new A9(102)).twice);
		var v157:Box<Int> = new Box(Reflect.compare(v156, 0x3C8F));
		var v158:Array<Int> = ((switch (v156) {
			case 0: ([] : Array<Int>);
			case 1 | 6: [v156];
			case c159 if (c159 > 10): [c159, v156, 44];
			case _: [v156];
		}) : Array<Int>);
		final v160:Array<Float> = (((E0A).match(E0A) ? ([v156] : Array<Float>) : ([(-2.5), v156] : Array<Float>)) : Array<Float>);
		final v161:Float = v156;
		var v162 = fn23(function(p163:Int):Void {
			H.tick();
			var v164:A9 = (v156 : A9);
			var v165:Map<String, Int> = (["k0" => 48] : Map<String, Int>);
			H.out("o166 " + Std.string(({x5: true, x3: p163, x4: (-65045039)} : S2)));
		});
	}
	public static function section1():Void {
		H.tick();
		final v167:Bool = ((new A9(79)).twice > (({x3: 279, x4: 0x4A60, x5: false} : S2)).x4);
		fn13(0x6065, 33, ((({x3: 48, x4: 296, x5: v167} : S2)).x3 ^ Reflect.compare(65535, (-1517459585))), H.id((-854393647)));
		var v168:Map<String, Array<Int>> = ((switch (K10.K10A) {
			case K10.K10A: (["k0" => ([] : Array<Int>), "k1" => [110]] : Map<String, Array<Int>>);
			case K10.K10B: new Map<String, Array<Int>>();
			case K10.K10C: new Map<String, Array<Int>>();
			case _: new Map<String, Array<Int>>();
		}) : Map<String, Array<Int>>);
		var v169:Box<Array<E1>> = new Box<Array<E1>>(([E1A, E1A, E1.E1A] : Array<E1>));
		final v170 = 292;
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
