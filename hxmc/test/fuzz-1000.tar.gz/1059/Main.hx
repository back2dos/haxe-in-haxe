import H;

typedef S0 = {x1:Bool, x2:Int};

typedef S3 = {x4:Float, x5:Int, x6:Float};

enum abstract K7(Int) to Int {
	var K7A = 1;
	var K7B = 4;
}

class Main {
	public static function fn8(a9:S3, a10:Float, a11:Int = 2):Int {
		H.tick();
		H.out("o32 " + Std.string(294));
		var v33 = ((Std.parseInt("x,y,z") ?? 0) ^ a11);
		var v34:S0 = ({x1: true, x2: 83} : S0);
		var v35 = (switch (106) {
			case 0: true;
			case 2 | 4: false;
			case _: true;
		});
		{ var dyn36:Dynamic = ({x1: true, x2: 129} : S0); H.out("dyn " + Std.string(dyn36.x1) + " " + Std.string(Reflect.field(dyn36, "x1"))); }
		final lf37:(Int, Int) -> Int = (p38:Int, p39:Int) -> (Std.parseInt(Std.string(p38)) ?? 0);
		return (new Box<Int>(134)).get();
	}
	public static function fn12(a13:Bool = true):Int {
		H.tick();
		final lf40:(Int) -> Void = function(p41:Int):Void {
			H.tick();
			var v42:S3 = ({x4: p41, x5: p41, x6: p41} : S3);
		};
		H.out("o43 " + Std.string((new Box<S3>(({x4: 100.75, x5: 27, x6: 0.30000000000000004} : S3))).get()));
		fn8(((a13 ? ({x4: 1.25, x5: 0x16EC, x6: 7.0} : S3) : ({x6: 1e3, x4: 100.75, x5: 39} : S3)) : S3), 200, 281);
		var v44:Null<Int> = fn8(({x6: 0.1, x4: 100.75, x5: 178} : S3), 1e3, 194);
		final v45:Float = Math.sqrt(Math.abs(39));
		H.out("o46 " + Std.string(0x34AC));
		return ((cast (6) : Int) >>> (201 & 31));
	}
	public static function fn14(a15:Int, a16:Bool, a17:Int):Int {
		H.tick();
		H.out("o47 " + Std.string(a17));
		{
			var v48:Int = 123736973;
			var w49 = 0;
while (w49 < 2 && false) {
				w49++;
				H.tick();
				final v50:Box<Box<S3>> = new Box<Box<S3>>(new Box<S3>(({x4: v48, x5: 0x560C, x6: 100.75} : S3)));
				var v51 = v48;
				++a15;
			}
			a16 = false;
		}
		final v52 = (true ? false : a16);
		return ((-a17) << (16 & 31));
	}
	public static function fn18():Bool {
		H.tick();
		H.out("o53 " + Std.string(0xFFFFFFFF));
		H.out("o54 " + Std.string((switch (258) {
			case 0: false;
			case 3 | 4: true;
			case _: false;
		})));
		fn8(({x5: 0x63FC, x6: 123456.789, x4: 3.0} : S3), 123456.789, Main.fn12());
		H.out("o55 " + Std.string((Reflect.compare(298, 78) >>> (0x7828 & 31))));
		return (!true && (152 == 135));
	}
	public static function fn19(a20:Int, a21:Int):Int {
		H.tick();
		var w56 = 0;
while (w56 < 1 && (221740449 == a20)) {
			w56++;
			H.tick();
			var w57 = 0;
do {
				w57++;
				H.tick();
				var v58:Null<Int> = a20;
			} while (w57 < 3 && true);
			if (true) {
				var v59:Null<Int> = a20;
			} else {
				Main.fn12();
				final v60:Float = a21;
			}
		}
		Main.fn12();
		switch (true) {
			case true: {
				Main.fn14(a21, false, a20);
				var v61:Int = a20;
			};
			case false: {
				fn8(({x5: a21, x6: a20, x4: 3.0} : S3), a21, a20);
				var w62 = 0;
while (w62 < 1 && false) {
					w62++;
					H.tick();
					H.out("o63 " + Std.string(false));
				}
			};
		}
		Main.fn18();
		return Main.fn12(true);
	}
	public static function fn22(a23:Float, a24:Int, a25:String = "d"):Int {
		H.tick();
		var v64 = 59;
		H.out("o65 " + Std.string(((switch (K7.K7B) {
			case K7.K7A: ({x1: false, x2: (-552694651)} : S0);
			case K7.K7B: ({x2: 0x7FFFFFFF, x1: false} : S0);
		}) : S0)));
		var v66:Int = 39;
		for (i67 in 0...1) {
			H.tick();
			v64 -= i67;
			switch (({x4: 100.75, x5: 234, x6: a24} : S3)) {
				case {x4: c68}: {
					v66 = H.id(v66);
				};
			}
			if (false) {
				v64 ^= i67;
				final v69:Int = a24;
				H.out("o70 " + Std.string(v66));
			} else {
				var v71:Int = a24;
				H.out("o72 " + Std.string(55));
			}
		}
		var v73:Bool = (v64 <= Lambda.count(([] : Array<Int>), v74 -> true));
		var v75 = (({x5: 0x682, x6: v64, x4: v64} : S3)).x5;
		var v76 = v66;
		switch (K7.K7A) {
			case K7.K7A: {
				var v77 = (K7.K7B : Int);
				a23 = v76;
			};
			case K7.K7B: {
				if (v73) return v76;
			};
			case _: {
				var w78 = 0;
while (w78 < 1 && true) {
					w78++;
					H.tick();
					Main.fn12();
					a24 += v66;
					fn19(v76, v64);
				}
			};
		}
		return Main.fn12();
	}
	public static function fn26():Int {
		H.tick();
		Main.fn12((true || true));
		final v79:() -> Void = function():Void {
			H.tick();
			var v80:Box<Bool> = new Box(true);
			H.out("o81 " + Std.string(178));
			var v82:Int = 197;
		};
		function lf83(n84:Int):Int {
			H.tick();
			return n84 <= 0 ? H.apply(n84, (v85:Int) -> 181) : (lf83(n84 - 1) + Lambda.fold([171], (v86:Int, v87:Int) -> 148, 0));
		}
		H.out("lf83 " + lf83(0));
		H.out("o88 " + Std.string((Lambda.count([0xFFFFFFFF], v89 -> Math.isNaN(v89)) ^ 0xFFFFFFFF)));
		switch (K7.K7B) {
			case K7.K7A: {
				fn8(({x5: 182, x4: 3.0, x6: 0.30000000000000004} : S3), 49185638);
			};
			case K7.K7B: {
				if (true) return Math.floor(0.5);
			};
		}
		var v90:Int = (~82);
		v90 *= (K7.K7A : Int);
		var w91 = 0;
while (w91 < 3 && (true ? Math.isNaN(1e-7) : false)) {
			w91++;
			H.tick();
			switch (({x1: true, x2: 9} : S0)) {
				case {x1: true}: {
					if (false) continue;
				};
				case {x1: c92}: {
					var v93 = 0xCE65;
				};
			}
		}
		return fn8(({x5: Reflect.compare(v90, v90), x6: v90, x4: v90} : S3), fn8(({x4: v90, x5: v90, x6: v90} : S3), 2.5e-3, v90), (v90 ^ Math.floor(v90)));
	}
	public static function fn27(a28:Bool, a29:Int):Bool {
		H.tick();
		H.out("o94 " + Std.string(((switch (59) {
			case 0: a29;
			case 1 | 6: 7.0;
			case c95 if (c95 > 10): Std.parseFloat("-0.25");
			case _: 0.5;
		}) : Float)));
		switch (a29) {
			case 0: {
				final v96:K7 = K7.K7B;
				a29 = 297;
			};
			case 3 | 5: {
				if (a28) return a28;
			};
			case _: {
				var v97 = false;
				switch (K7.K7A) {
					case K7.K7A: {
						final v98:S0 = ({x1: a28, x2: a29} : S0);
					};
					case K7.K7B: {
						H.out("o99 " + Std.string(a28));
						H.out("o100 " + Std.string(({x2: a29, x1: v97} : S0)));
					};
					case _: {
						H.out("o101 " + Std.string(a29));
					};
				}
			};
		}
		{
			var v102 = Math.ceil(a29);
		}
		H.out("o103 " + "zz");
		return (80 < (243 - Math.ceil(a29)));
	}
	public static function fn30(a31:Float):Int {
		H.tick();
		var v104:Bool = (false || true);
		switch ((~Math.round(a31))) {
			case 0: {
				if (v104) {
					var v105:Box<(Int, Float) -> Int> = new Box<(Int, Float) -> Int>(function(p106:Int, p107:Float):Int {
						H.tick();
						var v108:Int = p106;
						Main.fn12(v104);
						H.out("o109 " + Std.string(p106));
						return 213;
					});
					var v110 = 874053551;
				} else {
					var v111:K7 = K7.K7B;
					var v112:Float = 1e3;
				}
			};
			case 3 | 6: {
				var v113 = Math.ceil(a31);
			};
			case c114 if (c114 > 10): {
				var v115:Float = a31;
			};
			case _: {
				var v116:Int = (({x4: a31, x5: 283, x6: 2.5e-3} : S3)).x5;
			};
		}
		var v117 = (0x36DF * 66);
		switch (v117) {
			case 0: {
				v117 = 95;
				for (i118 in 1...4) {
					H.tick();
					H.out("o119 " + Std.string(v117));
					v117 ^= i118;
				}
			};
			case 1 | 6: {
				var v120 = false;
			};
			case c121 if (c121 > 10): {
				v117 = c121;
				v117 *= c121;
			};
			case _: {
				H.out("o122 " + Std.string(Reflect.compare(v117, v117)));
			};
		}
		return v117;
	}
	public static function section0():Void {
		H.tick();
		var v123 = Main.fn22(Std.parseFloat("12.5"), 1, Std.string(true));
		if (false) {
			H.out("o124 " + Std.string(({x2: v123, x1: false} : S0)));
			switch (({x1: true, x2: 52} : S0)) {
				case {x1: true}: {
					final v126:Float = v123;
					H.out("o127 " + Std.string(v123));
				};
				case {x1: c125}: {
					final v128:() -> Int = () -> v123;
					var v129 = (-17);
				};
			}
		} else {
			Main.fn18();
		}
		switch (false) {
			case true: {
				Main.fn30(7.0);
			};
			case false: {
				function lf130(n131:Int):Int {
					H.tick();
					return n131 <= 0 ? n131 : (lf130(n131 - 1) + (K7.K7B : Int));
				}
				H.out("lf130 " + lf130(4));
			};
		}
		if ((true ? true : false)) {
			for (i132 in 0...0) {
				H.tick();
				final v133 = v123;
				var v134:Int = i132;
				var v135:Float = 1.25;
			}
			var v136 = false;
		} else {
			var v137:Null<Int> = 113;
		}
		switch (({ var v138 = v123; v123; })) {
			case 0: {
				v123 *= (Std.parseInt(Std.string(v123)) ?? 0);
				v123 = H.id(v123);
			};
			case 2 | 6: {
				var w139 = 0;
do {
					w139++;
					H.tick();
					H.out("o140 " + Std.string((K7.K7B : Int)));
				} while (w139 < 4 && Math.isNaN(v123));
			};
			case _: {
				switch (49) {
					case 0: {
						final v141:(Int, Int) -> Int = (p142:Int, p143:Int) -> (-2032273697);
						H.out("o144 " + Std.string(v123));
					};
					case 1 | 5: {
						final v145:Int = 184;
					};
					case _: {
						v123 += v123;
						H.out("o146 " + Std.string(v123));
					};
				}
			};
		}
	}
	public static function section1():Void {
		H.tick();
		H.out("o147 " + Std.string(Reflect.compare(20, Math.round(3.0))));
		final v148:Int = (false ? Math.ceil(0.5) : (-19));
		if (!Math.isNaN(123456.789)) {
			var v149:S3 = ({x4: 3.0, x5: v148, x6: (-2.5)} : S3);
		}
	}
	public static function section2():Void {
		H.tick();
		var v150 = (Std.parseInt(Std.string(127)) ?? 0);
		var v151:Bool = (false && false);
		H.out("o152 " + Std.string(({x1: true, x2: 0xC4DD} : S0)));
		H.out("o153 " + Std.string(v150));
		var v154:Int = (v150 + 250);
		H.out("o155 " + Std.string(v150));
		v154 = (if (v151) Lambda.fold([v150, v150, v154], (v156:Int, v157:Int) -> 164, 0) else (({x4: v150, x5: v154, x6: v154} : S3)).x5);
		{
			v154 = H.id(v154);
		}
	}
	public static function section3():Void {
		H.tick();
		{
			for (i158 in 2...3) {
				H.tick();
				var v159:Bool = false;
				var v160 = i158;
				v159 = H.id(v159);
			}
			var v161:Float = 1.25;
		}
		Main.fn27((0 >= 0x80000000), (20 & (-2147483647)));
		var v162 = (new Box(false)).get();
		if (Main.fn18()) {
			H.out("o163 " + Std.string(true));
			final v164:() -> Int = function():Int {
				H.tick();
				fn14(247, v162, 94);
				Main.fn19(245, 136);
				var v165 = (-869318889);
				return v165;
			};
			final v166:(Int, Float) -> Void = function(p167:Int, p168:Float):Void {
				H.tick();
				final v169 = p167;
				H.out("o170 " + Std.string(v169));
			};
		} else {
			if (false) {
				var v171:K7 = K7.K7A;
			}
			var v172:Int = 34;
		}
		var v173 = false;
		fn18();
		H.out("o174 " + "日本語");
		var v175 = ({ var v176 = 179; v176; });
		v175 = (Math.ceil(v175) & (K7.K7B : Int));
	}
	public static function section4():Void {
		H.tick();
		H.out("o177 " + Std.string((105 >= (-635803623))));
		var v178 = 0x9826;
		v178 |= v178;
		if ((true || true)) {
			v178 = H.id(v178);
		}
		++v178;
		{
			var v179:S0 = ({x1: false, x2: 246} : S0);
		}
		H.out("o180 " + Std.string(({x1: true, x2: 290} : S0)));
		H.out("o181 " + Std.string(new Box<Int>(v178)));
		H.out("o182 " + Std.string(v178));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		try section4() catch (e:Dynamic) H.out("section4 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
