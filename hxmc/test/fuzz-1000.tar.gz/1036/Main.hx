import H;
import p.M1;
import p.q.M2;
using p.Ext;

enum E0 {
	E0A;
}

typedef S1 = {x2:Int};

abstract A7(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A7, b:A7):A7
		return new A7(a.get() + b.get());

	@:op(A * B) public static function mul(a:A7, b:A7):A7
		return new A7(a.get() * b.get());

	@:op(-A) public static function neg(a:A7):A7
		return new A7(-a.get());
}

class Main {
	public static inline function fn9():S3 {
		H.tick();
		var v30 = (true && Math.isNaN(123456.789));
		var v31:Map<Int, Int> = new Map<Int, Int>();
		for (k32 => v33 in new Map<String, Int>()) {
			H.tick();
			var v34:Map<String, Int> = (["k0" => v33] : Map<String, Int>);
			if (v30) {
				var v35:Int = 0xADF0;
			}
			var w36 = 0;
while (w36 < 2 && v30) {
				w36++;
				H.tick();
				var v37:Int = 0x77B7;
				var v38:Int = v37;
				var v39:K8 = K8.K8B;
			}
		}
		var v40 = (cast ((K8.K8C : Int)) : Int);
		if (v30) {
			var v41:Float = v40;
		}
		var v42:Map<String, Float> = new Map<String, Float>();
		return ({x6: (v40 >>> ((({x6: 67, x5: 199, x4: 214} : S3)).x6 & 31)), x4: (Lambda.fold([288, v40, 211], (v43:Int, v44:Int) -> 284, 0) % H.nz(191)), x5: H.apply(v30, (v45:Bool) -> (({x4: 136, x5: 52, x6: v40} : S3)).x5)} : S3);
	}
	public static function fn10():Int {
		H.tick();
		var v46:Float = Math.fceil(0x5772);
		var v47:Map<Int, Int> = new Map<Int, Int>();
		var v48:Bool = false;
		v46 = 0.1;
		final v49 = Lambda.count(([] : Array<Int>), v50 -> true);
		Main.fn9();
		final v51:Int = 183;
		var v52:Map<Int, Float> = (cast (new Map<Int, Float>()) : Map<Int, Float>);
		return ((210 : A7) : Int);
	}
	public static function fn11(a12:A7, a13:Bool, a14:Int):E0 {
		H.tick();
		final v53:Map<String, Int> = (["k0" => a14, "k1" => a14, "k2" => Reflect.compare(65535, 0x561D)] : Map<String, Int>);
		var v54 = (0x74FE < Lambda.count([a14], v55 -> true));
		final v56:Map<Int, Int> = ([-3 => a14] : Map<Int, Int>);
		return E0.E0A;
	}
	public static function fn15():S3 {
		H.tick();
		if ((true || Math.isNaN(7.0))) {
			var v57:Map<String, Int> = (["k0" => 0x7FFFFFFF] : Map<String, Int>);
		}
		if ((new Map<Int, Bool>()).exists(-3)) {
			if (true) {
				H.out("o58 " + Std.string(1.25));
				var v59:Bool = true;
				var v60:K8 = K8.K8C;
			} else {
				var v61:Float = 100.75;
			}
			Main.fn10();
		}
		var v62 = (13 >> (0xC3F1 & 31));
		var w63 = 0;
while (w63 < 2 && (v62 != 100.75)) {
			w63++;
			H.tick();
			try {
				final v64:() -> Int = Main.fn10;
				var v65:Float = v62;
				H.out("o66 " + Std.string(v62));
				if (Math.isNaN((-2.5))) throw 16;
			} catch (ex67:Dynamic) {
				H.out("caught " + H.exn(ex67));
				final v68 = v62;
			}
			for (i69 in 2...H.lim((v62 += 3))) {
				H.tick();
				H.out("o70 " + Std.string(false));
				H.out("o71 " + Std.string(false));
				final v72:A7 = (i69 : A7);
			}
		}
		if (!true) {
			H.out("o73 " + Std.string(({x2: v62} : S1)));
			var v74 = false;
		} else {
			H.out("o75 " + Std.string(((new Map<Int, Int>()).get(v62) ?? 0)));
		}
		H.out("o76 " + Std.string(Lambda.count(([] : Array<Int>), v77 -> (new Map<Int, Int>()).exists(4))));
		final v78:Box<S3> = new Box<S3>(({x4: v62, x5: v62, x6: v62} : S3));
		var v79:Bool = (v62 == (Std.parseInt(Std.string(v62)) ?? 0));
		function lf80(n81:Int):Int {
			H.tick();
			return n81 <= 0 ? Main.fn10() : (lf80(n81 - 1) + (-1));
		}
		H.out("lf80 " + lf80(2));
		return ({x4: (182 + Math.ceil(0.1)), x6: (true ? v62 : 77), x5: (v79 ? v62 : 253)} : S3);
	}
	public static function fn16(a17:Int, a18:Int, a19:E0):Bool {
		H.tick();
		a17 = H.id(a17);
		Main.fn9();
		var v82:S1 = ({x2: a17} : S1);
		return ((E0A).match(E0A) || false);
	}
	public static function fn20():Int {
		H.tick();
		fn15();
		if (true) return (false ? Math.floor(1.25) : 220);
		{
			H.out("o83 " + Std.string(Type.enumIndex(E0.E0A)));
			final v84:() -> Int = () -> 1247548383;
			fn9();
		}
		return 193;
	}
	public static function fn21(a22:Bool, a23:Null<Int>):Void {
		H.tick();
		if ((159 == 226)) {
			{
				H.out("o85 " + Std.string((-986477047)));
				var v86:Float = 2.5e-3;
			}
			var v87:Map<String, Null<Int>> = new Map<String, Null<Int>>();
			var v88:Float = (-13);
		} else {
			H.out("o89 " + Std.string(null));
		}
		try {
			if (a22) throw ("ab" + Type.enumIndex(E0A));
			Main.fn9();
			var v90:Box<Bool> = new Box(a22);
		} catch (ex91:Err) {
			H.out("caught Err " + ex91.errCode);
			{
				var v92:Int = 0x206B;
				fn20();
				var v93 = a22;
			}
		} catch (ex94:haxe.Exception) {
			H.out("caught " + H.exn(ex94));
			{
				var v95:Int = 46;
				v95 *= 68;
			}
			var v96:Map<Int, Bool> = ([-3 => a22] : Map<Int, Bool>);
		}
		Main.fn20();
		{ var dyn97:Dynamic = ({x4: 0xD962, x5: (Std.parseInt("Haxe") ?? 0), x6: Reflect.compare(532894692, 0x7FFFFFFF)} : S3); H.out("dyn " + Std.string(dyn97.x4) + " " + Std.string(Reflect.field(dyn97, "x4"))); }
	}
	public static function fn24():Void {
		H.tick();
		H.out("o98 " + Std.string(E0A));
		Main.fn21(true, 259);
		var v99:Float = H.apply(278, (v100:Int) -> v100);
		H.out("o101 " + Std.string(237));
		var v102:E0 = fn11(new A7(82), ((["k0" => 44] : Map<String, Int>)).exists("q"), 216);
		for (i103 in 0...3) {
			H.tick();
			for (i104 in 0...4) {
				H.tick();
				final v105:S1 = ({x2: i104} : S1);
				var v106:S1 = v105;
			}
		}
		final v107:A7 = new A7((new A7(60)).twice);
	}
	public static function fn25(a26:Int, a27:Int = -2):Int {
		H.tick();
		if (false) {
			var v108:Float = 3.0;
			H.out("o109 " + Std.string(Math.isNaN(a26)));
			v108 = 100.75;
		}
		var v110:Bool = false;
		H.out("o111 " + Std.string((new Box(263)).value));
		fn24();
		H.out("o112 " + Std.string(280));
		var v113:Map<Int, Int> = new Map<Int, Int>();
		final v114:Map<Int, Float> = ([-3 => Math.pow(a27, 2)] : Map<Int, Float>);
		final v115:Float = Main.fn20();
		a27 = 47;
		return 274;
	}
	public static function section0():Void {
		H.tick();
		H.out("o125 " + Std.string(Ext.ext29(Std.string(698615547))));
		if ((123456.789 == 161)) {
			var v126:Null<Int> = 0xFFFFFFFF;
		}
		final v127:(Int) -> Int = (p128:Int) -> p128;
		var v129 = (((new Map<String, Int>()).get("k1") ?? 0) | (({x4: (-3), x5: 0x7EFC, x6: 210} : S3)).x5);
		var v130:Int = ((E0.E0A).match(E0A) ? (({x4: v129, x5: v129, x6: v129} : S3)).x6 : Reflect.compare(v129, v129));
	}
	public static function section1():Void {
		H.tick();
		{ var dyn131:Dynamic = ({x2: 899678340} : S1); H.out("dyn " + Std.string(dyn131.x2) + " " + Std.string(Reflect.field(dyn131, "x2"))); }
		function lf132(n133:Int):Int {
			H.tick();
			return n133 <= 0 ? ("-7").ext29() : (lf132(n133 - 1) + Ext.ext29(Std.string(false)));
		}
		H.out("lf132 " + lf132(4));
		fn16(((K8.K8A : Int) << ((K8.K8B : Int) & 31)), (117 | 111), Main.fn11(new A7(150), true, 280));
		var v134:S3 = ({x6: 56, x5: 152, x4: (((["k0" => 294] : Map<String, Int>)).get("k1") ?? 0)} : S3);
		H.out("o135 " + Std.string(fn20()));
		for (k136 => v137 in (["k0" => ((([-3 => 290, 4 => 550556723] : Map<Int, Int>)).get(-3) ?? 0)] : Map<String, Int>)) {
			H.tick();
			H.out("o138 " + Std.string(1e-7));
		}
		if ((2.5e-3 > 3.0)) {
			var v139:Float = Math.PI;
			var w140 = 0;
while (w140 < 3 && true) {
				w140++;
				H.tick();
				H.out("o141 " + Std.string(E0A));
				final v142 = 136;
			}
		} else {
			fn21(false, 0x3285);
			var v143 = ((218 : A7)).twice;
		}
	}
	public static function section2():Void {
		H.tick();
		try {
			var w144 = 0;
while (w144 < 5 && false) {
				w144++;
				H.tick();
				var v145:Map<Int, Int> = ([-3 => 1886146983, 4 => (-9), 11 => (-14)] : Map<Int, Int>);
				H.out("o146 " + Std.string(({x2: 0xC903} : S1)));
				var v147 = 64;
			}
			if ((((new Map<Int, Int>()).get(11) ?? 0) >= (Std.parseInt("a") ?? 0))) throw new Err((0x7FFFFFFF & (({x4: 1066230, x5: 219, x6: 221} : S3)).x6));
		} catch (ex148:Err) {
			H.out("caught Err " + ex148.errCode);
			try {
				if ((E0A).match(E0A)) throw 23;
				H.out("o149 " + Std.string(new Box((-2147483647))));
			} catch (ex150:String) {
				H.out("caught String " + ex150);
				H.out("o151 " + Std.string(E0.E0A));
			} catch (ex152:Int) {
				H.out("caught Int " + ex152);
				fn16(152, ex152, E0A);
			} catch (ex153:Err) {
				H.out("caught Err " + ex153.errCode);
				var v154:E0 = E0.E0A;
			} catch (ex155:Dynamic) {
				H.out("caught " + H.exn(ex155));
				var v156:S3 = ({x4: 276, x5: (-10), x6: (-2147483647)} : S3);
			}
		} catch (ex157:haxe.Exception) {
			H.out("caught " + H.exn(ex157));
			var v158:Int = 159;
		}
		Main.fn10();
		var v159:Map<String, String> = (cast ((["k0" => "0"] : Map<String, String>)) : Map<String, String>);
		var v160 = ((new Map<String, Int>()).get("A-B-C") ?? 0);
		if ((true || false)) {
			Main.fn20();
			if ((new Map<Int, Int>()).exists(11)) {
				v160 = H.id(v160);
				Main.fn11((v160 : A7), true, v160);
				Main.fn10();
			}
			var v161 = v160;
		}
		final v162:Int = v160;
		Main.fn11((new A7(v160) * (v160 : A7)), (v160 != v160), H.id(Std.int(v162)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
