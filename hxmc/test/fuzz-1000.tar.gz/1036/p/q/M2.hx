package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;

class M2 {}

typedef S3 = {x4:Int, x5:Int, x6:Int};

enum abstract K8(Int) to Int {
	var K8A = 1;
	var K8B = 4;
	var K8C = 7;
}
