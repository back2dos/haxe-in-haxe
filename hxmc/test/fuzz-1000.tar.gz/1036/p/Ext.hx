package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class Ext {
	public static function ext29(a28:String):Int {
		H.tick();
		var v116:Int = 181;
		var v117 = ((E0.E0A).match(E0A) || (E0.E0A).match(E0A));
		var v118:E0 = ({ var v119 = Std.string(3.0); E0.E0A; });
		var v120:Float = Math.abs(Math.PI);
		if (((([-3 => new A7(v116), 4 => new A7(v116), 11 => new A7(89)] : Map<Int, A7>)).exists(v116) ? true : false)) {
			final v121:Bool = v117;
			Main.fn15();
		} else {
			var v122 = 137;
		}
		v116 = Main.fn10();
		final v123:Map<String, Int> = (["k0" => (({x5: v116, x6: v116, x4: v116} : S3)).x6, "k1" => 65535, "k2" => (-17)] : Map<String, Int>);
		H.out("o124 " + Std.string(268));
		return v116;
	}
}
