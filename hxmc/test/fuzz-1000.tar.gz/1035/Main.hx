import H;
import p.M1;
using p.Ext;
using StringTools;

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

enum abstract K6(Int) to Int {
	var K6A = 1;
	var K6B = 4;
}

class Main {
	public static function fn7(a8:Float):Int {
		H.tick();
		var v24:K6 = K6.K6A;
		var v25:String = (cast (String.fromCharCode(65 + ((0xB0A7) & 15))) : String);
		a8 = H.id(a8);
		var v26:A5 = ((Std.parseInt(v25) ?? 0) : A5);
		var v27 = (133 <= (-2147483647));
		H.out("o28 " + Std.string(((v25).toLowerCase()).lastIndexOf(StringTools.hex((250) & 0xFFFF, 4))));
		if (v27) return (StringTools.endsWith(v25, "a\rb") ? Reflect.compare("ünï", v25) : (v24 : Int));
		return (if ((switch ((v25).length) {
			case 0: v27;
			case 1 | 5: (E0.E0A).match(E0A);
			case _: StringTools.contains(v25, v25);
		})) (v26 : Int) else (Std.int(a8) - (({x4: 230} : S3)).x4));
	}
	public static inline function fn9(a10:Float):String {
		H.tick();
		fn7(Main.fn7(23));
		var v29:Float = fn7(129);
		var v30 = "ünï";
		return '-${v30}${Std.string((2.5e-3 >= 1.25))}<${((v30).toUpperCase()).toLowerCase()}';
	}
	public static function fn11(a12:Float):Void {
		H.tick();
		H.out("o31 " + Std.string((false ? 126 : (({x4: 162} : S3)).x4)));
		switch (K6.K6B) {
			case K6.K6A: {
				H.out("o32 " + Std.string(true));
				switch ((("0").charCodeAt(225) ?? -1)) {
					case 0: {
						Main.fn9((-2.5));
					};
					case 2 | 6: {
						var v33 = 240;
					};
					case _: {
						H.out("o34 " + Std.string(false));
					};
				}
			};
			case K6.K6B: {
				if (true) {
					var v35 = 204;
					H.out("o36 " + Std.string(a12));
					final v37:Float = v35;
				} else {
					H.out("o38 " + Std.string(195));
					var v39:Map<Int, String> = ([-3 => "a\rb", 4 => "\t"] : Map<Int, String>);
				}
				var v40 = Std.string(a12);
			};
		}
		var v41:String = ("é").charAt((288 & 7));
		H.out("o42 " + Std.string(false));
		var v43:S3 = ({x4: 273} : S3);
		H.out("o44 " + Std.string(H.id(123456.789)));
		var v45:S3 = ({x4: 213} : S3);
		final v46:Map<String, String> = (((new Map<Int, Bool>()).exists(-3) ? new Map<String, String>() : new Map<String, String>()) : Map<String, String>);
		final lf47:() -> Void = function():Void {
			H.tick();
			final v48:() -> Int = Main.fn7.bind(0.1);
			var v49:S3 = v43;
			if (false) {
				var v50:String = "\\";
			} else {
				var v51:Map<String, Int> = (["k0" => 0xFFFFFFFF, "k1" => 233] : Map<String, Int>);
			}
		};
	}
	public static function fn13(a14:(Int) -> Int):String {
		H.tick();
		switch ((cast (("é").lastIndexOf("a")) : Int)) {
			case 0: {
				H.out("o52 " + Std.string(("Haxe").indexOf("abc")));
			};
			case 3 | 5: {
				fn11(249);
			};
			case _: {
				H.out("o53 " + Std.string((K6.K6A : Int)));
				Main.fn7(Std.parseFloat("3"));
			};
		}
		var v54:Float = Math.ffloor(0.5);
		switch (E0.E0A) {
			case E0A: {
				H.out("o55 " + Std.string((new A5(153) : Int)));
				var v56:Bool = StringTools.contains("a\rb", "-7");
			};
			case E0B: {
				if (false) {
					v54 = H.id(v54);
				} else {
					var v57 = 237;
					fn9(v54);
				}
				var v58:K6 = K6.K6B;
			};
		}
		return "ab";
	}
	public static function fn15(a16:S3):Int {
		H.tick();
		H.out("o59 " + Std.string(({ var v60 = 297; E0.E0B; })));
		H.out("o61 " + Std.string((174 % H.nz(Math.floor(123456.789)))));
		var v62:Int = (new A5(104)).get();
		v62 *= v62;
		switch (fn13((p63:Int) -> p63)) {
			case "a" | "b": {
				try {
					final v64:Float = 1.25;
					H.out("o65 " + "日本語");
					var v66:Int = (-1544262638);
					if (Math.isNaN(v64)) throw 90;
				} catch (ex67:Dynamic) {
					H.out("caught " + H.exn(ex67));
					v62 *= 252991572;
				}
			};
			case "Haxe": {
				var v68 = v62;
				v68--;
			};
			case _: {
				var v69 = true;
				{ var dyn70:Dynamic = ({x4: v62} : S3); H.out("dyn " + Std.string(dyn70.x4) + " " + Std.string(Reflect.field(dyn70, "x4"))); }
			};
		}
		var v71:Map<String, Map<String, String>> = new Map<String, Map<String, String>>();
		var v72:K6 = ((true ? K6.K6A : K6.K6A) : K6);
		v62--;
		return (((Std.string(v62)).replace("a", "b")).charCodeAt((v62 % H.nz((Std.parseInt("\n") ?? 0)))) ?? -1);
	}
	public static function fn17():String {
		H.tick();
		try {
			if (true) throw new Err(188);
			fn11(7.0);
			if (StringTools.startsWith("x,y,z", "\\")) {
				var v73:Int = 0x2D8E;
				(v73).ext23();
				v73 *= 0x7FFFFFFF;
			}
			if (StringTools.endsWith("-7", "abc")) {
				var v74:Float = 0.5;
				H.out("o75 " + Std.string(102));
			}
		} catch (ex76:Dynamic) {
			H.out("caught " + H.exn(ex76));
			H.out("o77 " + Std.string(155));
			try {
				if (false) throw Std.string(E0.E0B);
				var v78:Float = 5e-324;
				Main.fn13((p79:Int) -> 288);
			} catch (ex80:String) {
				H.out("caught String " + ex80);
				var v81:Map<String, Float> = (["k0" => 1.25, "k1" => 0.1, "k2" => 0.30000000000000004] : Map<String, Float>);
				H.out("o82 " + Std.string(true));
			} catch (ex83:Int) {
				H.out("caught Int " + ex83);
				final v84:(Int) -> Int = function(p85:Int):Int {
					H.tick();
					var v86:String = "\\";
					return p85;
				};
				var v87:Int = (-2091163765);
			} catch (ex88:Err) {
				H.out("caught Err " + ex88.errCode);
				H.out("o89 " + Std.string(0xD370));
				H.out("o90 " + Std.string(false));
			} catch (ex91:Dynamic) {
				H.out("caught " + H.exn(ex91));
				H.out("o92 " + Std.string(({x4: 75} : S3)));
				H.out("o93 " + Std.string(0x2FC8));
			}
		}
		final v94 = (true || false);
		H.out("o95 " + Std.string(true));
		return '<${Std.string((K6.K6A : Int))}';
	}
	public static function fn18():Int {
		H.tick();
		var v96:Float = (224 - (K6.K6B : Int));
		switch (((({x4: 605044722} : S3)).x4 % H.nz((Std.parseInt(Std.string(189)) ?? 0)))) {
			case 0: {
				fn7(v96);
				final v97:(Int) -> Float = (p98:Int) -> v96;
			};
			case 3 | 4: {
				var v99:String = "日本語";
				H.out("o100 " + v99);
			};
			case c101 if (c101 > 10): {
				var v102 = (([-3 => true, 4 => true] : Map<Int, Bool>)).exists(-3);
			};
			case _: {
				var v103 = ((217 : A5)).get();
				var v104:String = ("\x41\x42").substr(5, 4);
			};
		}
		switch ((0xF3A6).ext23()) {
			case 0: {
				fn11((-2.5));
				H.out("o105 " + Std.string((("x,y,z").charCodeAt(17) ?? -1)));
			};
			case 1 | 5: {
				if (false) {
					([210, (-447162309), 0x6EDE]).ext21(({x4: 265} : S3));
					var v106:Box<Int> = new Box(12);
					Main.fn7(7.0);
				}
				var v107:K6 = K6.K6A;
			};
			case c108 if (c108 > 10): {
				var v109 = Type.enumIndex(E0.E0A);
			};
			case _: {
				H.out("o110 " + Std.string((({x4: 234} : S3)).x4));
			};
		}
		return (((true ? [296] : [37]) : Array<Int>)).ext21(({x4: 100} : S3));
	}
	public static function section0():Void {
		H.tick();
		H.out("o134 " + Std.string((([] : Array<Int>)).ext21(({x4: 0xFFFFFFFF} : S3))));
		H.out("o135 " + Std.string(E0.E0A));
		switch (K6.K6B) {
			case K6.K6A: {
				final v136 = 231;
			};
			case K6.K6B: {
				var v137:Float = 3.0;
			};
		}
		var v138 = ((("").charCodeAt(0x80000000) ?? -1) - 37);
		var v139:Box<Float> = (cast (new Box<Float>(v138)) : Box<Float>);
		var v140:String = "-7";
		var v141 = v138;
		var v142:Map<String, Int> = new Map<String, Int>();
	}
	public static function section1():Void {
		H.tick();
		Main.fn11(123456.789);
		switch (({ var v143 = 80; ("42").charAt((v143 & 7)); })) {
			case "a" | "b": {
				var v144:Null<Int> = 22;
				final v145:Map<String, Null<Int>> = (["k0" => v144, "k1" => v144, "k2" => 297] : Map<String, Null<Int>>);
			};
			case "Haxe": {
				var v146:S3 = ({x4: 227} : S3);
				{
					H.out("o147 " + "\"q\"");
					fn17();
					var v148 = 213;
				}
			};
			case "": {
				H.out("o149 " + "0");
				H.out("o150 " + Std.string(true));
			};
			case _: {
				var v151 = Math.floor(0.5);
			};
		}
		var v152 = 116;
		if (("é" > "\t")) {
			Main.fn11(7.0);
			Main.fn9(0.5);
			var v153:String = Std.string(v152);
		}
		H.out("o154 " + Std.string(E0.E0A));
		Main.fn13(function(p155:Int):Int {
			H.tick();
			var v156:Float = 1.25;
			return 190;
		});
		var v157 = ("" >= StringTools.replace("a", ",", "42"));
		if (StringTools.startsWith(String.fromCharCode(65 + ((v152) & 15)), ("  pad  ").toLowerCase())) {
			var v158 = v157;
		} else {
			v152 *= v152;
			var v159 = (("q").charCodeAt(v152) ?? -1);
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
