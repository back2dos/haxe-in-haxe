package p;

import Main;
import H;
import p.M1;
using p.Ext;
using StringTools;

class M1 {}

enum E0 {
	E0A;
	E0B;
}

typedef S3 = {x4:Int};
