package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext21(a19:Array<Int>, a20:S3):Int {
		H.tick();
		var v111 = Std.string((E0.E0A).match(E0B));
		final v112:Map<String, String> = new Map<String, String>();
		final v113:Int = (282 % H.nz((("\\").charCodeAt(171) ?? -1)));
		final v114:String = v111;
		var v115:A5 = new A5(183);
		var v116 = Reflect.compare(Math.floor(v113), (Std.parseInt(Std.string(v113)) ?? 0));
		return (({x4: (-1507414148)} : S3)).x4;
	}
	public static function ext23(a22:Int):Int {
		H.tick();
		var v117:Map<String, Float> = new Map<String, Float>();
		Main.fn13((p118:Int) -> 75);
		a22 = ((-2147483647) * (a22--));
		final v119:Null<Int> = (K6.K6B : Int);
		H.out("o120 " + Std.string(73));
		H.out("o121 " + Std.string((--a22)));
		if (("" < StringTools.lpad("0", "*", 5))) {
			var v122:Box<String> = new Box<String>("-7");
			var v123:Null<Int> = v119;
			switch ((new A5(a22)).twice) {
				case 0: {
					H.out("o124 " + Std.string(E0.E0B));
					H.out("o125 " + Std.string(false));
				};
				case 2 | 6: {
					H.out("o126 " + Std.string(a22));
					H.out("o127 " + Std.string(a22));
				};
				case c128 if (c128 > 10): {
					Main.fn13((p129:Int) -> c128);
					var v130:String = "\"q\"";
				};
				case _: {
					H.out("o131 " + Std.string(true));
				};
			}
		}
		var v132:Map<Int, String> = ([-3 => ("").substring((110 & 7), 1), 4 => "q"] : Map<Int, String>);
		var v133:Null<Int> = Main.fn7(32);
		return a22;
	}
}
