package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class Ext {
	public static function ext38(a37:Int):Int {
		H.tick();
		H.out("o179 " + Std.string(a37));
		Main.fn21();
		a37 *= (a37 & Reflect.compare(a37, a37));
		var v180:Array<Bool> = ([false, false, true]).copy();
		for (i181 in 0...2) {
			H.tick();
			var v182:Map<Int, Int> = new Map<Int, Int>();
			final v183:() -> Bool = () -> true;
			Main.fn21();
		}
		a37 <<= (((Std.parseInt("\"q\"") ?? 0) & a37) & 7);
		a37 += ((a37 += 3) >>> (a37 & 31));
		Main.fn25(a37);
		return 65535;
	}
	public static function ext40(a39:Array<Int>):Int {
		H.tick();
		final v184 = (25 == ([true, false]).indexOf(false));
		for (i185 in 0...3) {
			H.tick();
			H.out("o186 " + Std.string(221));
			switch (H.id(a39)) {
				case []: {
					var v187:Int = i185;
				};
				case [c188]: {
					var v189:Int = (-9);
					Main.fn25(0xF229);
				};
				case [_, c190]: {
					var v191:Map<String, Bool> = (["k0" => v184, "k1" => v184] : Map<String, Bool>);
					var v192:K1 = K1.K1C;
				};
				case _: {
					(new C12(181)).m18(v184, 248);
				};
			}
			var v193:Array<Int> = [i185, 230];
		}
		Main.fn21();
		{
			H.out("o194 " + Std.string(65535));
		}
		var v195 = (120 * Type.enumIndex(E0.E0A));
		H.out("o196 " + Std.string(Type.enumIndex(E0.E0A)));
		return ((v195 - v195) + v195);
	}
}
