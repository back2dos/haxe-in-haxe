package p;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;

class M1 {}

interface I2 {
	function m3():Int;
}

class C9 implements I2 {
	public function new(a10:E0, a11:Int) {}
	public function m3():Int {
		H.tick();
		(new C12(Lambda.fold([204], (v41:Int, v42:Int) -> (((["k0" => v41, "k1" => (-1308264399)] : Map<String, Int>)).get("k3") ?? 0), 0))).m18(!true, Type.enumIndex(E0.E0A));
		H.out("o43 " + Std.string((Reflect.compare(256, 60) >>> (([97, 385430057, 265]).indexOf(122) & 31))));
		var v44:Int = ((Std.parseInt("\\") ?? 0) | (K1.K1B : Int));
		H.out("o45 " + Std.string((204 | ([v44]).indexOf(v44))));
		Main.fn22(E0.E0A, function(p46:Int):Bool {
			H.tick();
			H.out("o47 " + Std.string(([E0.E0A] : Array<E0>)));
			var v48:Int = v44;
			return false;
		});
		v44 -= 298;
		try {
			if ((true || ([v44]).contains(v44))) throw new Err(((-1716347310) | v44));
			if (false) {
				final v49:Int = v44;
				H.out("o50 " + Std.string(true));
				(new C12(v44)).m18(true, 0x2669);
			} else {
				v44 += v44;
				H.out("o51 " + Std.string(v44));
			}
		} catch (ex52:Dynamic) {
			H.out("caught " + H.exn(ex52));
			var w53 = 0;
do {
				w53++;
				H.tick();
				H.out("o54 " + Std.string(v44));
				var v55 = 156;
				var v56:Array<Bool> = [false, true];
			} while (w53 < 1 && ((["k0" => 293] : Map<String, Int>)).exists("k3"));
		}
		v44 = (67 & v44);
		return (v44 << (Main.fn22(E0.E0A, (p57:Int) -> true) & 31));
	}
}
