package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;
using p.Ext;

class M2 {}

enum abstract K1(Int) to Int {
	var K1A = 1;
	var K1B = 4;
	var K1C = 7;
}

class C12 extends C9 {
	public var f13:Array<Int>;
	public var cb14:(Int) -> Int;
	public function new(a15:Int) {
		super(E0.E0A, (a15 += 3));
		this.f13 = [a15, 132, a15];
		this.cb14 = function(p58:Int):Int {
			H.tick();
			final v59:Array<Int> = ([] : Array<Int>);
			final v60:() -> Void = function():Void {
				H.tick();
				final v61:(String) -> Int = function(p62:String):Int {
					H.tick();
					v59.unshift(a15);
					H.out("o63 " + Std.string(a15));
					return a15;
				};
				var v64:I2 = new C9(E0.E0A, p58);
				var v65:Int = 86;
			};
			return p58;
		};
	}
	public function m16():String {
		H.tick();
		try {
			if ((([] : Array<Int>)).contains(Lambda.fold(([] : Array<Int>), (v66:Int, v67:Int) -> ([v66, 35]).indexOf(280), 0))) throw ((E0.E0A).match(E0A) ? "-7" : "abc");
			final v68:Int = 148;
			H.out("o69 " + Std.string(0xFFFFFFFF));
			final v70:E0 = E0.E0A;
		} catch (ex71:Dynamic) {
			H.out("caught " + H.exn(ex71));
			final v72:K1 = K1.K1A;
			H.out("o73 " + Std.string((E0.E0A).match(E0A)));
		}
		if ((E0.E0A).match(E0A)) {
			switch (K1.K1A) {
				case K1.K1A: {
					H.out("o74 " + Std.string(E0.E0A));
				};
				case K1.K1B: {
					var v75 = 51;
					this.m3();
				};
				case K1.K1C: {
					H.out("o76 " + Std.string(25));
				};
			}
		} else {
			var v77 = 0x80000000;
		}
		var v78:E0 = E0.E0A;
		var v79:Map<Int, I2> = ([-3 => new C12(105), 4 => new C12(39), 11 => new C9(v78, 276)] : Map<Int, I2>);
		H.out("o80 " + Std.string((62 + Reflect.compare(246, 276))));
		return (cast ('x${Std.string(true)}x${"0"} = ${Std.string(false)}') : String);
	}
	public function m17():Int {
		H.tick();
		final v81:Map<String, Int> = (["k0" => 189, "k1" => H.at(this.f13, 207, 0), "k2" => (K1.K1C : Int)] : Map<String, Int>);
		H.out("o82 " + Std.string(Reflect.compare(31, (K1.K1A : Int))));
		H.out("o83 " + Std.string((false ? 0xD749 : 31)));
		var v84:Int = (Std.parseInt(Std.string(H.at(([] : Array<Int>), 45, 0))) ?? 0);
		{ var dyn85:Dynamic = (v84 | 213); H.out("dyn " + Std.string(dyn85 + 1)); }
		v84 = 278;
		Main.fn25(H.at([v84, v84], v84, 0), v84);
		return (v84++);
	}
	public function m18(a19:Bool, a20:Int):Void {
		H.tick();
		a20 = (a20 >> (0xFFFFFFFF & 31));
		H.out("o86 " + Std.string(([for (i87 in 0...3) new C12(i87)] : Array<C12>)));
		for (i88 in 2...6) {
			H.tick();
			var v89 = (this.f13).length;
		}
		final v90:() -> Void = function():Void {
			H.tick();
			var v91:K1 = K1.K1A;
			var v92:C12 = new C12(0x13AD);
		};
		a20 = 0xD9E5;
		try {
			H.out("o93 " + Std.string(a20));
			if (a19) throw new Err((if (false) a20 else 283));
		} catch (ex94:String) {
			H.out("caught String " + ex94);
			a20 = (--a20);
			var v95:E0 = E0.E0A;
		} catch (ex96:Int) {
			H.out("caught Int " + ex96);
			H.out("o97 " + Std.string(E0.E0A));
		} catch (ex98:Err) {
			H.out("caught Err " + ex98.errCode);
			final v99:Int = 0x80000000;
			for (k101 => x100 in [a19, true]) {
				H.tick();
				H.out("o102 " + Std.string(v99));
			}
		} catch (ex103:Dynamic) {
			H.out("caught " + H.exn(ex103));
			H.out("o104 " + Std.string(E0.E0A));
		}
	}
}
