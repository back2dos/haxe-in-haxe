import H;
import p.M1;
import p.q.M2;
using p.Ext;

enum E0 {
	E0A;
}

interface I4 {
	function m5(a6:Int):Bool;
	function m7(a8:Int):Bool;
}

class Main {
	public static function fn21():Int {
		H.tick();
		var v105:E0 = ({ var v106 = true; E0.E0A; });
		final v107:C12 = new C12(26);
		for (i108 in 0...2) {
			H.tick();
			var v109 = i108;
		}
		H.out("o110 " + Std.string((switch (63) {
			case 0: 38;
			case 1 | 5: 0xE2EC;
			case _: H.at(([] : Array<Int>), 268, 0);
		})));
		final v111:E0 = E0A;
		return ((Lambda.fold(([] : Array<Int>), (v112:Int, v113:Int) -> Type.enumIndex(E0A), 0) << (Type.enumIndex(E0.E0A) & 31)) + (~((([-3 => 0x7747, 4 => 91, 11 => 0x7FFFFFFF] : Map<Int, Int>)).get(-3) ?? 0)));
	}
	public static function fn22(a23:E0, a24:(Int) -> Bool):Int {
		H.tick();
		var v114 = fn21();
		try {
			if ((false ? false : false)) throw new Err(v114);
			var v115:Int = H.at([v114, v114], v114, 0);
			final v116:Int = v115;
			H.out("o117 " + Std.string((-11)));
		} catch (ex118:Dynamic) {
			H.out("caught " + H.exn(ex118));
			H.out("o119 " + Std.string(v114));
		}
		if (((([-3 => v114, 4 => v114] : Map<Int, Int>)).exists(65535) ? (Std.downcast((new C12(73) : I2), C12) != null) : false)) {
			H.out("o120 " + Std.string(false));
			H.out("o121 " + Std.string((([] : Array<Int>)).contains(87)));
		}
		final v122:Map<String, C9> = new Map<String, C9>();
		return v114;
	}
	public static inline function fn25(...r26:Int):Bool {
		H.tick();
		final v123:E0 = E0A;
		var v124:Array<E0> = ((true ? ([v123] : Array<E0>) : ([] : Array<E0>)) : Array<E0>);
		switch (K1.K1C) {
			case K1.K1A: {
				if (false) {
					final v125:E0 = E0.E0A;
				} else {
					var v126:I2 = new C9(v123, 35);
				}
			};
			case K1.K1B: {
				(new C12(215)).m18(false, (Std.parseInt("q") ?? 0));
				var v127:E0 = E0A;
			};
			case K1.K1C: {
				final v128 = 992287690;
			};
			case _: {
				try {
					if ((r26.toArray()).contains(20)) throw Std.string(E0A);
					var v129:Array<E0> = v124;
					final v130:Int = 199;
					Main.fn22(v123, (p131:Int) -> true);
				} catch (ex132:Err) {
					H.out("caught Err " + ex132.errCode);
					var v133:Map<String, Bool> = (["k0" => true] : Map<String, Bool>);
				} catch (ex134:haxe.Exception) {
					H.out("caught " + H.exn(ex134));
					var v135 = (-11);
					final v136:Array<Int> = [44, v135, 150];
				}
				try {
					var v137 = 0x5B00;
					final v138 = 119;
					if (true) throw "A-B-C";
				} catch (ex139:Dynamic) {
					H.out("caught " + H.exn(ex139));
					var v140:Map<String, Bool> = new Map<String, Bool>();
					(new C12(96)).m18(true, 35);
				}
			};
		}
		final lf141:() -> String = function():String {
			H.tick();
			for (i142 in 0...2) {
				H.tick();
				r26.toArray().remove(i142);
				final v143:Bool = true;
				var v144:C12 = new C12(i142);
			}
			return "\\";
		};
		return (((Std.parseInt(Std.string(69)) ?? 0) ^ Lambda.fold(r26.toArray(), (v145:Int, v146:Int) -> 151, 0)) <= (["0", "\x41\x42"]).length);
	}
	public static function fn27(a28:Array<Int>, a29:String):String {
		H.tick();
		var v147:Bool = Main.fn25();
		final lf148:(Int) -> Int = (p149:Int) -> 100;
		(new C12((a28).indexOf(1746470981))).m17();
		var w150 = 0;
while (w150 < 4 && Main.fn25(2035882440, 205)) {
			w150++;
			H.tick();
			var w151 = 0;
while (w151 < 3 && v147) {
				w151++;
				H.tick();
				var v152:E0 = E0.E0A;
				var v153 = 186;
				(new C12(0xFFFFFFFF)).m18(v147, 582861669);
			}
			{
				var v154:Int = 47;
				H.out("o155 " + Std.string(167));
				v154++;
			}
		}
		return "é";
	}
	public static function fn30(a31:Array<Int>):Bool {
		H.tick();
		var v156 = ((new Map<String, Int>()).get("日本語") ?? 0);
		v156 = (v156 | (Std.parseInt(Std.string(v156)) ?? 0));
		{
			if (true) return false;
			for (k158 => x157 in ([] : Array<Int>)) {
				H.tick();
				var v159:Array<Array<Int>> = ([a31, a31] : Array<Array<Int>>);
				v156 = x157;
			}
			for (x160 in ["\t", "Haxe"]) {
				H.tick();
				var v161:Map<String, Bool> = new Map<String, Bool>();
				H.out("o162 " + Std.string(([E0A, E0.E0A] : Array<E0>)));
			}
		}
		H.out("o163 " + Std.string((v156 == 267)));
		return ((Std.parseInt((["Haxe", "hello world"]).join(",")) ?? 0) <= Lambda.fold([v156, 287], (v164:Int, v165:Int) -> Reflect.compare(v164, v165), 0));
	}
	public static function fn32(a33:Int, a34:Bool, a35:Int, ...r36:Int):E0 {
		H.tick();
		a35 += Ext.ext38(a33);
		(new C9(E0A, ([true, a34, a34]).indexOf(a34))).m3();
		{ var dyn166:Dynamic = a35; H.out("dyn " + Std.string(dyn166 + 1)); }
		var w167 = 0;
while (w167 < 1 && (a33 > a35)) {
			w167++;
			H.tick();
			var v168 = (-4);
			var v169:E0 = E0A;
		}
		var v170:Array<String> = (cast (["\"q\"", "zz"]) : Array<String>);
		(a35).ext38();
		try {
			if (a34) throw 15;
			Ext.ext40([73]);
			r36.toArray().pop();
		} catch (ex171:Err) {
			H.out("caught Err " + ex171.errCode);
			var v172:Int = (r36.toArray()).length;
		} catch (ex173:haxe.Exception) {
			H.out("caught " + H.exn(ex173));
			for (x174 in r36.toArray()) {
				H.tick();
				H.out("o175 " + Std.string(true));
				a35 = a33;
				var v176:E0 = E0.E0A;
			}
		}
		H.out("o177 " + Std.string((15 >>> ((a35 += 3) & 31))));
		var v178:Bool = true;
		return ((Main.fn25(a33, a33) ? E0.E0A : E0A) : E0);
	}
	public static function section0():Void {
		H.tick();
		fn27(([true]).map((v197:Bool) -> 107), (([] : Array<String>)).join(","));
		var w198 = 0;
while (w198 < 4 && (switch (H.id([292, 129, 254])) {
			case []: false;
			case [c199]: (([] : Array<Int>)).contains(c199);
			case [_, c200]: false;
			case _: ([151, 166]).contains(61);
		})) {
			w198++;
			H.tick();
			(new C9(E0.E0A, 122)).m3();
		}
		H.out("o201 " + Std.string(E0.E0A));
		var v202:Map<String, Bool> = (["k0" => true] : Map<String, Bool>);
		var v203:C9 = new C9(E0.E0A, 9);
		H.out("o204 " + Std.string(Main.fn21()));
		var v205:E0 = E0A;
		final v206:(Int) -> Void = function(p207:Int):Void {
			H.tick();
			var v208 = 79;
			v208 ^= v208;
		};
		(new C12(36)).m16();
	}
	public static function section1():Void {
		H.tick();
		H.out("o209 " + Std.string(((new Map<Int, Int>()).get(11) ?? 0)));
		var v210:Map<String, Int> = (["k0" => 13] : Map<String, Int>);
		H.out("o211 " + Std.string(((-110945472) <= H.at(([] : Array<Int>), 1001493059, 0))));
		(((Std.isOfType(null, I4) ? new C9(E0.E0A, 191) : new C12((-1117935072))) : C9)).m3();
		if ((E0.E0A).match(E0A)) {
			Main.fn21();
		}
		var v212 = (if (true) Reflect.compare(185, 79) else H.at([287, 249], 65535, 0));
	}
	public static function section2():Void {
		H.tick();
		try {
			fn22(E0A, function(p213:Int):Bool {
				H.tick();
				H.out("o214 " + Std.string(E0A));
				var v215:Map<String, String> = (["k0" => "hello world", "k1" => "hello world", "k2" => ""] : Map<String, String>);
				Ext.ext40([p213, p213]);
				return false;
			});
			if (false) {
				var v216:Array<Bool> = [true];
				var v217:Map<Int, Map<String, Int>> = new Map<Int, Map<String, Int>>();
			} else {
				H.out("o218 " + Std.string(new C12(41)));
			}
			if (false) throw "boom";
		} catch (ex219:String) {
			H.out("caught String " + ex219);
			var v220 = ((new Map<Int, Int>()).get(18) ?? 0);
			{
				var v221:I2 = new C9(E0.E0A, v220);
			}
		} catch (ex222:Int) {
			H.out("caught Int " + ex222);
			switch (H.id(([] : Array<Int>))) {
				case []: {
					H.out("o223 " + Std.string(0xEF40));
				};
				case [c224]: {
					H.out("o225 " + Std.string(22));
				};
				case [_, c226]: {
					var v227 = c226;
					var v228 = 262;
				};
				case _: {
					var v229:E0 = E0.E0A;
				};
			}
			var v230 = H.at(([] : Array<Int>), 40, 0);
		} catch (ex231:Err) {
			H.out("caught Err " + ex231.errCode);
			var v232:Map<String, Array<Bool>> = (["k0" => [false, true, true]] : Map<String, Array<Bool>>);
			var v233:Int = (Std.parseInt("") ?? 0);
		} catch (ex234:Dynamic) {
			H.out("caught " + H.exn(ex234));
			if (true) {
				var v235:Map<Int, Int> = new Map<Int, Int>();
				final v236 = 54;
				var v237:Int = v236;
			} else {
				H.out("o238 " + Std.string(new C9(E0.E0A, 187)));
			}
			try {
				var v239:Int = 84;
				if ((Std.downcast((new C12(73) : C12), C12) != null)) throw "ab";
			} catch (ex240:String) {
				H.out("caught String " + ex240);
				var v241 = true;
				H.out("o242 " + Std.string(E0.E0A));
			} catch (ex243:Int) {
				H.out("caught Int " + ex243);
				var v244:C12 = new C12(218);
			} catch (ex245:Err) {
				H.out("caught Err " + ex245.errCode);
				var v246:Map<String, Bool> = (["k0" => false, "k1" => true, "k2" => true] : Map<String, Bool>);
			} catch (ex247:Dynamic) {
				H.out("caught " + H.exn(ex247));
				var v248:Array<E0> = ([E0A] : Array<E0>);
				H.out("o249 " + Std.string((-17)));
			}
		}
		switch (E0A) {
			case E0A: {
				final v250:Int = (([] : Array<Int>)).indexOf(264);
			};
		}
		var v251 = Lambda.count([251], v252 -> false);
		H.out("o253 " + Std.string(fn25()));
		if (Main.fn25(v251, H.at([208], v251, 0))) {
			var v254:C12 = new C12(197);
			v251--;
			v251 = (++v251);
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
