package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

enum E3 {
	E3A;
}

enum abstract K14(Int) to Int {
	var K14A = 1;
	var K14B = 4;
	var K14C = 7;
	var K14D = 10;
}

class C15 {
	public static var f16:Int = 0x2F7A;
	var _f17:Float;

	public var f17(get, set):Float;

	function get_f17():Float
		return _f17;

	function set_f17(v:Float):Float
		return _f17 = v;
	public var cb18:(Int) -> Int;
	public function new(a19:Int) {
		this._f17 = a19;
		this.cb18 = (p62:Int) -> 276;
	}
}

class C20 {
	public var f21:E4;
	public var f22:String;
	public static var f23:Int = 128;
	public var cb24:(Int) -> Int;
	public function new(a25:Int) {
		this.f21 = E4.E4A;
		this.f22 = "\u{1F600}";
		this.cb24 = function(p63:Int):Int {
			H.tick();
			H.out("o64 " + Std.string(true));
			a25 = 0x7FFFFFFF;
			C15.f16 = p63;
			return a25;
		};
	}
	public function m26():Bool {
		H.tick();
		var v65 = (Type.enumIndex(E0.E0B(false, 94)) << ((K14.K14B : Int) & 31));
		(new C46(v65)).m44();
		for (i66 in 0...0) {
			H.tick();
			var w67 = 0;
while (w67 < 5 && true) {
				w67++;
				H.tick();
				final v68:Int = i66;
				var v69:S7 = ({x8: (-2.5)} : S7);
			}
			v65 = C20.f23;
			(new C46(i66)).m44();
		}
		H.out("o70 " + Std.string(v65));
		H.out("o71 " + Std.string((v65 < v65)));
		return C20.m29(Main.fn54(), ({ var v72 = v65; v65; }));
	}
	public function m27(a28:A13):String {
		H.tick();
		for (i73 in 0...H.lim((Std.parseInt(Std.string(((new Map<Int, Int>()).get(18) ?? 0))) ?? 0))) {
			H.tick();
			Main.fn55(K14.K14D);
		}
		var w74 = 0;
while (w74 < 4 && C20.m29(0.1, 174)) {
			w74++;
			H.tick();
			var v75:Bool = true;
		}
		var w76 = 0;
while (w76 < 4 && (E4.E4A).match(E4B)) {
			w76++;
			H.tick();
			(new C46(1.25)).m45();
			var v77 = (a28 : Int);
		}
		var v78:Map<String, Int> = (["k0" => Type.enumIndex(E0.E0A), "k1" => Math.ceil(100.75)] : Map<String, Int>);
		{
			H.out("o79 " + Std.string(277));
			switch ((Std.parseInt(Std.string(0x3211)) ?? 0)) {
				case 0: {
					H.out("o80 " + Std.string(true));
				};
				case 3 | 6: {
					final v81:S7 = ({x8: 123456.789} : S7);
					(new C46(0.1)).m44();
				};
				case _: {
					H.out("o82 " + Std.string(E0.E0A));
					H.out("o83 " + Std.string(({x10: 188, x11: false, x12: false} : S9)));
				};
			}
			var v84 = 1570224221;
		}
		return "\n";
	}
	public static function m29(a30:Float, a31:Int):Bool {
		H.tick();
		var v85:Float = a30;
		var v86:Bool = (switch (a31) {
			case 0: false;
			case 3 | 6: false;
			case _: true;
		});
		H.out("o87 " + 'x${Std.string((a31 += 3))} = ${Std.string(true)}x${Std.string(false)}');
		C20.f23 += ((new Map<String, Int>()).get("k1") ?? 0);
		return (((E4.E4B).match(E4B) && false) ? v86 : (28 >= ((new Map<Int, Int>()).get(-3) ?? 0)));
	}
	public function m32(a33:Bool, ?a34:Null<Float>):Int {
		H.tick();
		for (i88 in 0...H.lim(130)) {
			H.tick();
			H.out("o89 " + Std.string((K14.K14B : Int)));
		}
		var v90 = (new A13(165)).get();
		if (a33) {
			var v91:Bool = true;
			if (v91) {
				H.out("o92 " + Std.string(v90));
				var v93 = 148;
			} else {
				H.out("o94 " + Std.string(0x40C3));
				H.out("o95 " + "\t");
			}
			var v96:C46 = new C46(v90);
		} else {
			if (false) {
				var v97:Int = v90;
				H.out("o98 " + Std.string(v90));
				H.out("o99 " + Std.string(v97));
			} else {
				C20.m29(v90, v90);
				v90 = H.id(v90);
			}
			switch (K14.K14B) {
				case K14.K14A: {
					var v100:Map<String, Map<Int, E3>> = new Map<String, Map<Int, E3>>();
				};
				case K14.K14B: {
					C20.m29(0.5, v90);
					var v101:C46 = new C46(v90);
				};
				case K14.K14C: {
					C20.f23 = v90;
				};
				case K14.K14D: {
					final v102 = v90;
					C20.f23 = v102;
				};
			}
		}
		return v90;
	}
}

class C35 extends C15 {
	public function new(a36:Bool) {
		super(C20.f23);
	}
	public function m37(?a38:Null<Float>):Int {
		H.tick();
		final v103 = (-534809437);
		switch (K14.K14A) {
			case K14.K14A: {
				if ((E3A).match(E3A)) return 222;
				switch (K14.K14A) {
					case K14.K14A: {
						var v104:Map<Int, Float> = ([-3 => v103, 4 => 123456.789] : Map<Int, Float>);
						H.out("o105 " + Std.string(false));
					};
					case K14.K14B: {
						C20.f23 *= 70;
						C20.f23 ^= v103;
					};
					case K14.K14C: {
						C15.f16 = v103;
					};
					case K14.K14D: {
						H.out("o106 " + Std.string(v103));
					};
				}
			};
			case K14.K14B: {
				var v107:K14 = K14.K14B;
				C15.f16 <<= (v103 & 7);
			};
			case K14.K14C: {
				if ((E3A).match(E3A)) {
					H.out("o108 " + Std.string(0x7FFFFFFF));
					var v109:C46 = new C46(v103);
				}
			};
			case K14.K14D: {
				Main.fn54();
			};
		}
		H.out("o110 " + Std.string(Math.abs((-2.5))));
		var w111 = 0;
while (w111 < 1 && (0x80000000 != v103)) {
			w111++;
			H.tick();
			var w112 = 0;
while (w112 < 2 && (Std.downcast((new C46(v103) : C15), C42) != null)) {
				w112++;
				H.tick();
				var v113:Map<String, Bool> = (["k0" => true] : Map<String, Bool>);
				(new C20(27)).m32(true, v103);
			}
			C15.f16 = v103;
			var v114:C20 = new C20(268);
		}
		if (!true) {
			switch (v103) {
				case 0: {
					H.out("o115 " + Std.string(new C20(v103)));
				};
				case 1 | 5: {
					H.out("o116 " + Std.string(({x8: v103} : S7)));
					final v117:() -> Bool = () -> true;
				};
				case c118 if (c118 > 10): {
					H.out("o119 " + Std.string(250));
					var v120:Null<Int> = v103;
				};
				case _: {
					(new C42()).m44();
					H.out("o121 " + Std.string(false));
				};
			}
			var v122:Null<Int> = (-17);
		}
		final v123:Bool = (E4.E4A).match(E4A);
		var v124:C15 = new C15(v103);
		return C15.f16;
	}
}
