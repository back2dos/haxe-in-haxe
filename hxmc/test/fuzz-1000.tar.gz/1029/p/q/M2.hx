package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

typedef S9 = {x10:Int, x11:Bool, x12:Bool};

class C46 extends C42 {
	public function new(a47:Float) {
		super();
	}
	override public function m44():Float {
		H.tick();
		switch (true) {
			case true: {
				(new C20(0xFFFFFFFF)).m32(Std.isOfType(new C15(8), C35));
			};
			case false: {
				(new C20(175)).m32(true, 2.5e-3);
			};
		}
		switch ((false ? Lambda.count([0x558C], v137 -> false) : 215)) {
			case 0: {
				final v138:() -> Int = () -> 194;
			};
			case 1 | 5: {
				var v139:A13 = (0x82B : A13);
			};
			case _: {
				H.out("o140 " + Std.string((K14.K14B : Int)));
				var v141:E0 = E0.E0A;
			};
		}
		C20.f23 = Std.int(7.0);
		C20.f23 = Reflect.compare(C20.f23, (-1700555028));
		H.out("o142 " + Std.string(({x10: Math.round(1.25), x11: Math.isNaN(0.30000000000000004), x12: Std.isOfType(new C46(1e-7), C42)} : S9)));
		return (this.f17 * (Std.int(1e21) | C20.f23));
	}
	override public function m45():E4 {
		H.tick();
		H.out("o143 " + Std.string((((switch (E3.E3A) {
			case E3A: K14.K14C;
		}) : K14) : Int)));
		C15.f16 = (267 ^ 0x7FFFFFFF);
		C20.f23 = (new C20(69)).m32(true);
		var v144:Map<Int, Bool> = ([-3 => true, 4 => (E4.E4A).match(E4B), 11 => false] : Map<Int, Bool>);
		if ((switch (Reflect.compare(110, 90)) {
			case 0: (Std.downcast((new C20(65535) : C20), C20) != null);
			case 2 | 4: true;
			case c145 if (c145 > 10): (E3.E3A).match(E3A);
			case _: false;
		})) {
			var v146:Map<String, Int> = (["k0" => 230, "k1" => 15] : Map<String, Int>);
			if (false) {
				var v147:Int = 349053405;
				H.out("o148 " + Std.string(59));
			}
			if (true) {
				C20.f23 = 0x9D7C;
			} else {
				var v149 = 541127028;
			}
		}
		final v150:() -> Void = function():Void {
			H.tick();
			H.out("o151 " + Std.string(({x8: 100.75} : S7)));
		};
		{
			final v152:(Bool, Int) -> Int = (p153:Bool, p154:Int) -> p154;
		}
		return E4.E4B;
	}
	public function m48():Void {
		H.tick();
		var v155:Map<String, C35> = (((Std.downcast((new C20(264302873) : C20), C20) != null) ? new Map<String, C35>() : new Map<String, C35>()) : Map<String, C35>);
		C15.f16 |= Math.round(0.1);
		{
			var v156:Map<Int, Int> = ([-3 => 101, 4 => 217, 11 => 65535] : Map<Int, Int>);
		}
		for (i157 in 0...3) {
			H.tick();
			final v158:Map<String, Bool> = new Map<String, Bool>();
			switch (E0.E0A) {
				case E0A: {
					var v159:S9 = ({x12: true, x10: i157, x11: false} : S9);
					C20.f23 = 256;
				};
				case E0B(c160, 0 | 3): {
					m44();
					C15.f16 = 210;
				};
				case _: {
					C20.m29(i157, i157);
				};
			}
		}
		switch (E0.E0B((E3.E3A).match(E3A), (K14.K14B : Int))) {
			case E0A: {
				H.out("o161 " + Std.string((new A13((-2147483647)) : Int)));
			};
			case _: {
				C15.f16 = Lambda.count([204, 0x812D], v162 -> Math.isNaN(1e3));
				H.out("o163 " + Std.string(true));
			};
		}
		switch (((K14.K14C : Int) != Lambda.count([0x848D, 246], v164 -> (E3.E3A).match(E3A)))) {
			case true: {
				this.f17 = 100.75;
				final v165:S7 = ({x8: 7.0} : S7);
			};
			case false: {
				C15.f16 = Std.int((-2.5));
			};
		}
	}
	public static function m49():Float {
		H.tick();
		if ((false && true)) {
			var v166 = 235;
		} else {
			final v167:K14 = K14.K14B;
			var w168 = 0;
while (w168 < 5 && false) {
				w168++;
				H.tick();
				var v169:Int = 56;
				H.out("o170 " + Std.string(v169));
			}
		}
		for (i171 in 0...4) {
			H.tick();
			H.out("o172 " + Std.string(new C46(i171)));
			C15.f16 ^= i171;
		}
		final v173:C39 = new C39();
		final v174:(Bool) -> String = function(p175:Bool):String {
			H.tick();
			C20.f23 = 154;
			return "  pad  ";
		};
		switch (E4.E4B) {
			case E4A: {
				C15.f16 <<= (0x7BB4 & 7);
			};
			case _: {
				if (Std.isOfType(new C46(7.0), C15)) return 100.75;
				final v176:Int = 160;
			};
		}
		return 123456.789;
	}
	public function m50():Float {
		H.tick();
		var v177:Bool = (2.5e-3 < 1e21);
		H.out("o178 " + Std.string(100.75));
		var w179 = 0;
do {
			w179++;
			H.tick();
			{
				H.out("o180 " + Std.string(233));
				(new C20(70)).m32(v177);
				H.out("o181 " + Std.string(1e3));
			}
			++C20.f23;
		} while (w179 < 2 && (cast (v177) : Bool));
		var v182:C15 = new C42();
		return this.m44();
	}
}
