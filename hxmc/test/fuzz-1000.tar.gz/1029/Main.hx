import H;
import p.M1;
import p.q.M2;

enum E0 {
	E0A;
	E0B(a1:Bool, a2:Int);
}

enum E4 {
	E4A;
	E4B;
}

typedef S7 = {x8:Float};

abstract A13(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A13, b:A13):A13
		return new A13(a.get() + b.get());

	@:op(A * B) public static function mul(a:A13, b:A13):A13
		return new A13(a.get() * b.get());

	@:op(-A) public static function neg(a:A13):A13
		return new A13(-a.get());
}

class C39 {
	public var f40:Bool;
	public var cb41:(Int) -> Int;
	public function new() {
		this.f40 = (new Map<String, S7>()).exists("k3");
		this.cb41 = function(p125:Int):Int {
			H.tick();
			H.out("o126 " + Std.string(p125));
			C20.f23 <<= (p125 & 7);
			var v127:Null<Int> = p125;
			return 103;
		};
	}
}

class C42 extends C35 {
	public var cb43:(Int) -> Int;
	public function new() {
		super(false);
		this.cb43 = (p128:Int) -> p128;
	}
	public function m44():Float {
		H.tick();
		C20.f23 <<= ((Reflect.compare(158, 173) % H.nz((K14.K14D : Int))) & 7);
		(new C20(123)).m32((false ? true : (new Map<String, E3>()).exists("\"q\"")), (-1049923810));
		final v129:A13 = new A13(Reflect.compare(52, 71));
		H.out("o130 " + Std.string(((Std.parseInt(Std.string(133)) ?? 0) & Type.enumIndex(E0A))));
		final v131:Map<String, S9> = (["k0" => ({x10: (-16), x11: false, x12: true} : S9)] : Map<String, S9>);
		var w132 = 0;
while (w132 < 2 && Std.isOfType(new C46(0.5), C46)) {
			w132++;
			H.tick();
			H.out("o133 " + Std.string(new C42()));
		}
		C15.f16 <<= (0xE1F8 & 7);
		var v134:K14 = ((switch (K14.K14C) {
			case K14.K14A: K14.K14C;
			case K14.K14B: K14.K14D;
			case K14.K14C: K14.K14D;
			case K14.K14D: K14.K14B;
			case _: K14.K14A;
		}) : K14);
		return (Math.max(100.75, 1e-7) * (-1774328900));
	}
	public function m45():E4 {
		H.tick();
		H.out("o135 " + Std.string((292 - 287)));
		H.out("o136 " + Std.string((K14.K14A : Int)));
		(new C46((-2.5))).m44();
		return ((switch (E3.E3A) {
			case E3A: E4A;
		}) : E4);
	}
}

class Main {
	public static function fn51(a52:Bool, a53:Int):Void {
		H.tick();
		var v183:K14 = K14.K14C;
		var v184:K14 = v183;
		H.out("o185 " + Std.string((switch (E0.E0A) {
			case E0A: a53;
			case E0B(c186, c187): C15.f16;
			case _: (Std.parseInt(Std.string(241)) ?? 0);
		})));
	}
	public static function fn54():Int {
		H.tick();
		var v188 = C20.f23;
		v188++;
		C20.f23 ^= (new C20(v188)).m32(Math.isNaN(v188), 169);
		return C20.f23;
	}
	public static function fn55(a56:K14):Float {
		H.tick();
		switch (a56) {
			case K14.K14A: {
				final v189 = C20.f23;
			};
			case K14.K14B: {
				H.out("o190 " + Std.string(false));
			};
			case K14.K14C: {
				final v191:Map<String, Int> = (["k0" => 247, "k1" => 72, "k2" => 0x7FFFFFFF] : Map<String, Int>);
			};
			case K14.K14D: {
				if (Std.isOfType(new C42(), C42)) {
					var v192 = 266;
					final v193:K14 = K14.K14A;
					H.out("o194 " + Std.string(v192));
				} else {
					H.out("o195 " + Std.string(true));
				}
			};
			case _: {
				Main.fn51(true, Reflect.compare((-2147483647), 33));
			};
		}
		if ((138 > 0x6238)) {
			var v196:Float = 75;
		} else {
			C20.f23 &= 481499028;
			H.out("o197 " + Std.string(E4.E4A));
		}
		H.out("o198 " + Std.string((false ? true : (new Map<String, Bool>()).exists("\u{1F600}"))));
		C15.f16 = (0xCEF9 % H.nz(C15.f16));
		return (((new A13(170)).get() % H.nz(C20.f23)) / 100.75);
	}
	public static function fn57(a58:C20, a59:Int, a60:Float):Int {
		H.tick();
		C20.f23 *= ((new Map<Int, Int>()).get(18) ?? 0);
		final v199 = (a59 == C20.f23);
		for (i200 in 2...2) {
			H.tick();
			H.out("o201 " + Std.string(Type.enumIndex(E3.E3A)));
			final v202:(Int, Bool) -> String = (p203:Int, p204:Bool) -> "";
			for (i205 in 0...4) {
				H.tick();
				H.out("o206 " + Std.string(true));
			}
		}
		var v207:Int = (false ? C15.f16 : C15.f16);
		H.out("o208 " + Std.string((K14.K14A : Int)));
		H.out("o209 " + Std.string(((false ? E4B : E4B) : E4)));
		{ var dyn210:Dynamic = ({x10: 234, x11: v199, x12: false} : S9); H.out("dyn " + Std.string(dyn210.x10) + " " + Std.string(Reflect.field(dyn210, "x10"))); }
		return ((Std.isOfType(new C46(1.7976931348623157e308), C46) && true) ? (v207 >> (C15.f16 & 31)) : (0x80000000 + (({x11: v199, x10: v207, x12: v199} : S9)).x10));
	}
	public static function fn61():Void {
		H.tick();
		var v211:C35 = new C35(Std.isOfType(new C20(147), C20));
		if ((new C20(144)).m26()) {
			var v212:Float = C15.f16;
			var v213:S7 = ({x8: v212} : S7);
		}
		(((switch (E3.E3A) {
			case E3A: new C46(1e3);
		}) : C46)).m44();
		switch (({x8: 100.75} : S7)) {
			case {x8: c214}: {
				H.out("o215 " + Std.string((new A13(0x7FFFFFFF) : Int)));
			};
		}
		if ((switch (40) {
			case 0: true;
			case 2 | 6: false;
			case _: false;
		})) {
			var v216:K14 = K14.K14B;
			final v217 = ((["k0" => new C46((-2.5)), "k1" => new C46(0.5)] : Map<String, C42>)).exists("k2");
			if (false) {
				final v218:Map<String, Int> = (["k0" => 34, "k1" => 202, "k2" => (-2147483647)] : Map<String, Int>);
				var v219:Map<Int, Int> = new Map<Int, Int>();
				(new C46(1e3)).m50();
			}
		}
		{ var dyn220:Dynamic = ({x10: (Std.parseInt(Std.string(141)) ?? 0), x11: true, x12: false} : S9); H.out("dyn " + Std.string(dyn220.x10) + " " + Std.string(Reflect.field(dyn220, "x10"))); }
	}
	public static function section0():Void {
		H.tick();
		var v221 = true;
		for (k222 => v223 in (cast (new Map<String, Int>()) : Map<String, Int>)) {
			H.tick();
			for (i224 in 0...1) {
				H.tick();
				C20.f23 = 1940800445;
				var v225 = 23;
			}
			var v226:E3 = E3.E3A;
			C20.f23++;
		}
		final v227:(Int, Int) -> Bool = function(p228:Int, p229:Int):Bool {
			H.tick();
			var v230:C46 = new C46(p228);
			return false;
		};
	}
	public static function section1():Void {
		H.tick();
		if ((Std.int(1e-7) != Math.ceil(0.1))) {
			(new C46(7.0)).m50();
			final v231 = (Std.parseInt(Std.string(38)) ?? 0);
			Main.fn61();
		}
		final v232:(Int) -> Int = (p233:Int) -> (new A13((-855413078))).twice;
		var v234 = (C20.f23 << ((({x12: true, x10: (-4), x11: true} : S9)).x10 & 31));
		for (k235 => v236 in new Map<String, Int>()) {
			H.tick();
			H.out("o237 " + Std.string(v234));
			final v238:A13 = new A13(v234);
			{
				var v239 = v236;
				var v240:Map<String, Int> = new Map<String, Int>();
				if (true) continue;
			}
		}
		(new C42()).m44();
		final v241:E3 = E3.E3A;
		C15.f16 = fn57(new C20(v234), 0xED6D, v234);
		switch (E3.E3A) {
			case E3A: {
				for (i242 in 0...1) {
					H.tick();
					var v243:Int = v234;
					fn51(false, v243);
				}
			};
			case _: {
				C20.f23 = v234;
			};
		}
	}
	public static function section2():Void {
		H.tick();
		var w244 = 0;
while (w244 < 4 && (false || true)) {
			w244++;
			H.tick();
			if (false) {
				H.out("o245 " + Std.string(171));
			} else {
				var v246 = 73;
				v246 = 870802122;
			}
			for (i247 in 0...1) {
				H.tick();
				H.out("o248 " + Std.string(208));
				if (false) break;
				final v249 = 88;
			}
			if (false) {
				H.out("o250 " + Std.string((K14.K14D : Int)));
			}
		}
		final v251:K14 = K14.K14B;
		if (true) {
			C15.f16 |= Math.round(7.0);
			H.out("o252 " + Std.string(164));
		} else {
			for (i253 in 0...H.lim(((([-3 => 219, 4 => 3, 11 => 38] : Map<Int, Int>)).get(-3) ?? 0))) {
				H.tick();
				H.out("o254 " + Std.string(i253));
			}
		}
		C20.f23 = 237;
		for (i255 in 1...2) {
			H.tick();
			var v256 = i255;
			if ((new Map<String, Bool>()).exists("k2")) {
				var v257:S9 = ({x10: v256, x11: false, x12: true} : S9);
			} else {
				H.out("o258 " + Std.string(i255));
			}
		}
		var v259:C42 = new C46(0.1);
		(new C20(Lambda.fold([18, 134], (v260:Int, v261:Int) -> Math.round(v260), 0))).m26();
		if ((true && Std.isOfType(new C39(), C39))) {
			final v262:C15 = new C42();
			(v259).m44();
		}
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
