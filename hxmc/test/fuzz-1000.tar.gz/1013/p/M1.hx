package p;

import Main;
import H;
import p.M1;
import p.q.M2;

class M1 {}

enum E2 {
	E2A;
	E2B;
}

typedef S3 = {x4:Bool};

abstract A5(Int) from Int to Int {
	public inline function new(i:Int)
		this = i;

	public function get():Int
		return this;

	public var twice(get, never):Int;

	function get_twice():Int
		return this * 2;

	@:op(A + B) public static function add(a:A5, b:A5):A5
		return new A5(a.get() + b.get());

	@:op(A * B) public static function mul(a:A5, b:A5):A5
		return new A5(a.get() * b.get());

	@:op(-A) public static function neg(a:A5):A5
		return new A5(-a.get());
}

class C27 {
	public function new(a28:Int, a29:Float) {}
	public function m30(a31:Bool, a32:Int):Bool {
		H.tick();
		for (i156 in 0...H.lim(Math.round(a32))) {
			H.tick();
			for (i157 in 0...1) {
				H.tick();
				H.out("o158 " + Std.string(i156));
			}
			var v159:Float = 1e21;
			for (x160 in ([] : Array<Bool>)) {
				H.tick();
				var v161 = a32;
				final v162:Map<Int, Int> = ([-3 => v161, 4 => i156] : Map<Int, Int>);
			}
		}
		if ((C35.f37 >= a32)) {
			H.out("o163 " + Std.string((new A5(a32) : Int)));
		}
		H.out("o164 " + Std.string(E0.E0C));
		return true;
	}
	public function m33(a34:Int):Int {
		H.tick();
		for (i165 in 0...4) {
			H.tick();
			C35.f37 = H.at(([] : Array<Int>), a34, 0);
		}
		H.out("o166 " + Std.string(E2A));
		var v167 = (-19);
		return (((Std.isOfType(new C27(v167, a34), C27) ? new C18() : new C18()) : C18)).m19();
	}
}
