package p.q;

import Main;
import H;
import p.M1;
import p.q.M2;

class M2 {}

enum abstract K6(Int) to Int {
	var K6A = 1;
	var K6B = 4;
}

class C7 {
	public function new(a8:Int) {}
	public function m9(a10:E0):Float {
		H.tick();
		for (i74 in 0...H.lim((((["k0" => 286, "k1" => 290, "k2" => 173] : Map<String, Int>)).get("é") ?? 0))) {
			H.tick();
			var v75:Map<Int, Bool> = new Map<Int, Bool>();
			if (Math.isNaN(i74)) {
				var v76:Bool = true;
				C35.f36 = i74;
				var v77:Array<C27> = ([] : Array<C27>);
			}
		}
		var v78:Null<Int> = (((new Map<Int, Int>()).exists(284) ? 276 : C35.f37) : Null<Int>);
		Main.fn44();
		final v79:Float = C35.f36;
		var v80:Float = (100.75 - C35.f36);
		if ((C35.f37 != ([288, 223, 0xC10E]).length)) {
			H.out("o81 " + Std.string(([155, 45, 97]).indexOf((-490677181))));
		} else {
			C35.f37 = (-494134186);
			H.out("o82 " + Std.string(({x4: true} : S3)));
		}
		if ((v79 > 0x6C01)) {
			var v83:Int = 0x5EA3;
			if ((([] : Array<Int>)).contains(v83)) {
				C35.f37 *= v83;
			}
		}
		var v84:Array<Float> = (([v79, v80, v80] : Array<Float>)).slice(((K6.K6B : Int) & 7), (68 & 7));
		for (i85 in 1...2) {
			H.tick();
			for (x86 in [i85, (-18), i85]) {
				H.tick();
				final v87:Float = x86;
			}
			{
				C35.f36 = i85;
				H.out("o88 " + Std.string(0xFFFFFFFF));
				C35.f37 = i85;
			}
		}
		return (C35.f37 / v79);
	}
	public function m11(a12:Bool, ...r13:Int):Void {
		H.tick();
		if ((a12 ? true : a12)) {
			C35.f37++;
		} else {
			var w89 = 0;
while (w89 < 1 && (r13.toArray()).contains(0x655F)) {
				w89++;
				H.tick();
				final v90:Array<Int> = r13.toArray();
				var v91 = 199;
				var v92:Null<Int> = v91;
			}
		}
		H.out("o93 " + Std.string((true ? (new A5(27)).get() : 95)));
		{
			var v94 = true;
			final v95:Null<Int> = null;
		}
	}
	public static function m14():Int {
		H.tick();
		H.out("o96 " + Std.string(new C35()));
		H.out("o97 " + Std.string((((["k0" => 2, "k1" => 187, "k2" => (-12)] : Map<String, Int>)).get("k2") ?? 0)));
		var v98:Array<Bool> = [((["k0" => 270, "k1" => 93] : Map<String, Int>)).exists("-7"), true, true];
		var v99:Array<String> = [(([] : Array<String>)).join("|")];
		(new C27(H.at([114, (-1890084677), 300], 0x80000000, 0), 0x80000000)).m30(false, 233);
		var v100:Array<Int> = Main.fn45(E2.E2A, (new A5(23)).twice, true);
		if ((new C27((-24966526), (-2.5))).m30(false, 98)) {
			H.out("o101 " + Std.string(269));
		}
		var v102 = 239;
		(new C7(Type.enumIndex(E2.E2A))).m9(E0.E0A);
		return (["\"q\"", "A-B-C", ([true, true, false]).join("")]).length;
	}
	public function m15(a16:E2, a17:Int):Float {
		H.tick();
		for (i103 in 1...H.lim(0x80000000)) {
			H.tick();
			Main.fn42(a17);
			if ((new Map<String, C27>()).exists("42")) continue;
		}
		H.out("o104 " + Std.string((([a17]).length <= 141299856)));
		H.out("o105 " + Std.string(0.1));
		var v106 = (false ? a17 : a17);
		H.out("o107 " + Std.string((new A5((new A5(v106)).twice) : Int)));
		C35.f37 = v106;
		var v108:Float = C35.f36;
		var w109 = 0;
do {
			w109++;
			H.tick();
			var v110:Array<Float> = ([123456.789, v106] : Array<Float>);
		} while (w109 < 4 && (86 == a17));
		var v111:Map<String, Int> = (["k0" => (new A5(v106)).twice] : Map<String, Int>);
		return Math.max(v106, a17);
	}
}

class C35 {
	public static var f36:Int = 123;
	public static var f37:Int = (-19);
	public var f38:Int;
	public function new() {
		this.f38 = Math.round(3.0);
	}
	public function m39():Float {
		H.tick();
		{
			var v168:Int = C35.f37;
			var v169:E2 = E2.E2A;
			var w170 = 0;
while (w170 < 4 && (([-3 => false, 4 => true] : Map<Int, Bool>)).exists(4)) {
				w170++;
				H.tick();
				(new C18()).m11(true);
				H.out("o171 " + Std.string(v169));
				H.out("o172 " + Std.string(v168));
			}
		}
		this.f38 = (Type.enumIndex(E0.E0C) - Reflect.compare((-523803411), 1594158413));
		H.out("o173 " + Std.string(0x7FFFFFFF));
		var v174:Array<Int> = [225];
		final v175:Map<Int, Int> = new Map<Int, Int>();
		H.out("o176 " + Std.string(((-new A5(233)) : Int)));
		(new C27(123, 1e21)).m30((new C27(228, 1.25)).m30(false, Type.enumIndex(E2.E2B)), (this.f38 | Type.enumIndex(E0.E0A)));
		H.out("o177 " + Std.string((((v174).contains(51) ? new C27(0xE6AB, 0.30000000000000004) : new C27(0x7FFFFFFF, 0.30000000000000004)) : C27)));
		(new C7(204)).m11((66 != C35.f36), 0x1DAA);
		return (new A5((-1615741114)) : Int);
	}
	public static function m40():Int {
		H.tick();
		for (k178 => v179 in (["k0" => Math.ceil(1e3), "k1" => 237, "k2" => Math.floor(0.5)] : Map<String, Int>)) {
			H.tick();
			for (i180 in 0...2) {
				H.tick();
				var v181:S3 = ({x4: false} : S3);
				H.out("o182 " + Std.string(({x4: false} : S3)));
				final v183 = i180;
			}
			H.out("o184 " + Std.string(false));
		}
		H.out("o185 " + Std.string(C35.m41()));
		H.out("o186 " + Std.string(({x4: false} : S3)));
		{
			final v187:Array<Float> = ([3.0, 2.5e-3] : Array<Float>);
			var w188 = 0;
while (w188 < 2 && true) {
				w188++;
				H.tick();
				H.out("o189 " + Std.string(1.7976931348623157e308));
				C35.m41();
			}
			var v190:Array<Int> = ([] : Array<Int>);
		}
		return 0x8F20;
	}
	public static inline function m41():Int {
		H.tick();
		H.out("o191 " + Std.string(false));
		H.out("o192 " + Std.string(!true));
		{
			var v193:C7 = new C18();
			(new C18()).m11(true, 0x346A);
			final v194 = ((([-3 => 0x7F15, 4 => 171, 11 => 248] : Map<Int, Int>)).get(11) ?? 0);
		}
		H.out("o195 " + Std.string(new C18()));
		H.out("o196 " + Std.string((false ? (-12) : (Std.parseInt(Std.string(2034516724)) ?? 0))));
		final v197 = (true ? 0xDCA6 : (K6.K6B : Int));
		(new C18()).m11(((Std.parseInt("\u{1F600}") ?? 0) != 0x9E2D));
		var v198:Bool = (new C27(v197, 123456.789)).m30(false, v197);
		var v199:E0 = E0.E0A;
		return 294;
	}
}
