import H;
import p.M1;
import p.q.M2;

enum E0 {
	E0A;
	E0B(a1:Int);
	E0C;
}

class C18 extends C7 {
	public function new() {
		super(0x80000000);
	}
	override public function m9(a10:E0):Float {
		H.tick();
		var v112:K6 = K6.K6B;
		H.out("o113 " + Std.string(((-18) == 132)));
		final v114:E0 = a10;
		for (x115 in (([(-2.5)] : Array<Float>)).concat(([] : Array<Float>))) {
			H.tick();
			C35.f36 <<= (Type.enumIndex(E0B(0x80000000)) & 7);
			for (i116 in 1...4) {
				H.tick();
				var v117:Map<Int, Int> = ([-3 => i116, 4 => i116, 11 => i116] : Map<Int, Int>);
				H.out("o118 " + Std.string(i116));
				var v119 = false;
			}
		}
		{
			H.out("o120 " + Std.string(C35.f37));
		}
		H.out("o121 " + Std.string((Math.ceil(1.25) << (227 & 31))));
		return Math.min(Math.max(126, 296), (100.75 * 1e100));
	}
	override public function m11(a12:Bool, ...r13:Int):Void {
		H.tick();
		H.out("o122 " + Std.string((K6.K6A : Int)));
		H.out("o123 " + Std.string(147));
		final lf124:() -> Void = function():Void {
			H.tick();
			final v125:Int = C35.f36;
			H.out("o126 " + Std.string(Type.enumIndex(E0B(v125))));
			var v127:K6 = K6.K6A;
		};
		H.out("o128 " + Std.string((274 > C35.f36)));
		final v129:Float = 0x7FFFFFFF;
		C35.f36++;
	}
	public function m19():Int {
		H.tick();
		H.out("o130 " + Std.string((new C27(296, (-2.5))).m30(true, 25)));
		var w131 = 0;
while (w131 < 4 && false) {
			w131++;
			H.tick();
			if (([0x15D0]).contains(156)) {
				(new C27(294, 3.0)).m30(false, 0x9FAE);
			} else {
				H.out("o132 " + Std.string(E0C));
				var v133 = true;
			}
			final v134 = Std.int(3.0);
		}
		var w135 = 0;
while (w135 < 5 && !true) {
			w135++;
			H.tick();
			H.out("o136 " + Std.string(C35.f37));
			C35.f36 *= (K6.K6A : Int);
		}
		if (Math.isNaN(100.75)) {
			var v137:Null<Int> = 0x3A5F;
		} else {
			{
				H.out("o138 " + Std.string(61));
				H.out("o139 " + Std.string(new C7(103)));
			}
			var v140:Float = 7.0;
		}
		var v141:Array<Bool> = Main.fn42((Std.parseInt("\u{1F600}") ?? 0));
		final v142:Null<Int> = C35.m41();
		var v143:S3 = ({x4: (new Map<String, Float>()).exists("k1")} : S3);
		Main.fn57(E0.E0C);
		C35.f36 |= 45;
		return (if (((([2.5e-3, 1.25] : Array<Float>)).length >= Std.int(0.5))) (Std.isOfType(new C35(), C35) ? ([225, 48]).length : 213) else (C35.f37 % H.nz(([0xA9B6, 85]).indexOf(187))));
	}
	public function m20(a21:Int, a22:Int, ...r23:Int):S3 {
		H.tick();
		var v144:Map<String, Int> = ((true ? new Map<String, Int>() : new Map<String, Int>()) : Map<String, Int>);
		a21 += (48 >>> (Math.round(1e100) & 31));
		a21 -= Type.enumIndex(E0.E0B(a21));
		var v145:Int = (231 >>> (a21 & 31));
		H.out("o146 " + Std.string(260));
		if ((3.0 > (-2.5))) {
			v145 = 111;
			var w147 = 0;
while (w147 < 4 && true) {
				w147++;
				H.tick();
				var v148:Array<C18> = ([new C18(), new C18(), new C18()] : Array<C18>);
				final v149:E2 = E2.E2B;
				C35.m41();
			}
		} else {
			(new C7(a22)).m15(E2.E2A, C35.f36);
		}
		for (i150 in 0...0) {
			H.tick();
			a21 *= ((v144).get("k0") ?? 0);
			H.out("o151 " + Std.string(C35.f37));
		}
		final v152:C7 = new C7(v145);
		return ({x4: false} : S3);
	}
	public function m24(a25:Float, a26:Array<Float>):E0 {
		H.tick();
		H.out("o153 " + Std.string((97 - (new A5(106)).twice)));
		var w154 = 0;
while (w154 < 4 && false) {
			w154++;
			H.tick();
			C35.f36 = H.id(C35.f36);
			var v155:Array<Int> = ([] : Array<Int>);
		}
		Main.fn45(E2.E2A, 71, (([(-1406716207), 0x7FFFFFFF, 1845250499]).contains(273) ? false : true));
		return E0.E0C;
	}
}

class Main {
	public static function fn42(a43:Int):Array<Bool> {
		H.tick();
		var v200:Array<A5> = ([new A5(254), new A5(272), new A5(a43)] : Array<A5>);
		final v201:Map<String, Int> = new Map<String, Int>();
		if ((C35.f36 != 164)) return ([false]).slice(5, -1);
		if (Std.isOfType(new C27(a43, a43), C27)) return [true];
		final lf202:(Bool) -> Int = function(p203:Bool):Int {
			H.tick();
			C35.f37 = C35.f36;
			C35.m41();
			var v204:E0 = E0B(0x80000000);
			return ((Std.parseInt("q") ?? 0) >>> (0x80000000 & 31));
		};
		var v205:Int = 4;
		for (i206 in 0...4) {
			H.tick();
			var v207:Int = v205;
			v207 = H.at([59, i206, a43], i206, 0);
		}
		return ([] : Array<Bool>);
	}
	public static function fn44():Array<Bool> {
		H.tick();
		H.out("o208 " + Std.string(128));
		var v209:Float = Math.fceil(1e-7);
		C35.f36 = ((Std.downcast((new C35() : C35), C35) != null) ? ([205]).length : 473671478);
		var v210:C18 = new C18();
		H.out("o211 " + Std.string((v209 >= v209)));
		{
			H.out("o212 " + Std.string(0xA195));
		}
		return [((K6.K6B : Int) >= 170), (v209 <= 1.25), (188 != 64)];
	}
	public static function fn45(a46:E2, a47:Int, a48:Bool):Array<Int> {
		H.tick();
		C35.f37 = (Std.parseInt(Std.string(a47)) ?? 0);
		var v213 = C35.m41();
		(new C18()).m11((new C27(v213, 1e3)).m30(true, 0x80000000), v213);
		H.out("o214 " + Std.string(([for (i215 in [v213, a47]) if (true) K6.K6A] : Array<K6>)));
		return [for (i216 in 0...0) (i216 - Std.int(a47))];
	}
	public static function fn49(a50:Float, a51:Int):Int {
		H.tick();
		for (x217 in [for (i218 in 0...0) i218]) {
			H.tick();
			H.out("o219 " + Std.string(new C27(x217, 123456.789)));
		}
		C35.f36++;
		var v220:Array<Int> = (([] : Array<Int>)).copy();
		var v221:Float = a50;
		var v222:Array<Float> = ([123456.789, 0.5, v221] : Array<Float>);
		var v223:Int = a51;
		var v224:S3 = ({x4: true} : S3);
		(new C35()).m39();
		var v225 = (true ? 850016570 : Type.enumIndex(E0.E0A));
		return v225;
	}
	public static function fn52(a53:Float, a54:Int, a55:Int, ...r56:Int):E0 {
		H.tick();
		if (!(r56.toArray()).contains(a54)) return E0.E0A;
		var w226 = 0;
while (w226 < 2 && (34 < a55)) {
			w226++;
			H.tick();
			for (k227 => v228 in (["k0" => a54, "k1" => a54] : Map<String, Int>)) {
				H.tick();
				H.out("o229 " + Std.string(new C27(a54, a53)));
				final v230 = v228;
				var v231:Array<Bool> = [true, false];
			}
			(new C18()).m11(true, 198, a54);
		}
		var v232:A5 = (new A5(a55) + new A5(a55));
		Main.fn42((a55 - 209));
		C35.m41();
		C35.f37 = (H.at(r56.toArray(), a54, 0) & a54);
		for (x233 in r56.toArray()) {
			H.tick();
			(new C27(a55, a54)).m30(((["k0" => a54, "k1" => a55, "k2" => a55] : Map<String, Int>)).exists("k3"), Math.floor(x233));
			C35.f37 |= x233;
			H.out("o234 " + Std.string(({x4: false} : S3)));
		}
		return E0.E0B(a54);
	}
	public static function fn57(a58:E0):Array<E0> {
		H.tick();
		H.out("o235 " + Std.string(((((["k0" => E2.E2A] : Map<String, E2>)).exists("k0") ? ([] : Array<Int>) : [269, 131, 200]) : Array<Int>)));
		var v236:Null<Int> = null;
		if ((new C27(65535, 3.0)).m30(false, 71)) {
			C35.m41();
			(new C18()).m11(Math.isNaN(1.7976931348623157e308));
		} else {
			final v237:Array<Int> = [0xC015, 0x5457, (-17)];
		}
		return ([for (i238 in Main.fn45(E2.E2A, 0x52D2, ([288, 176, 64]).contains((-16)))) if ((Std.downcast((new C35() : C35), C35) != null)) E0.E0C] : Array<E0>);
	}
	public static function fn59(a60:Int, a61:Int):Bool {
		H.tick();
		var v239:Int = (([] : Array<Int>)).indexOf(Math.floor(a61));
		var v240:Array<Int> = Main.fn45(E2.E2B, (Std.parseInt(Std.string(v239)) ?? 0), true);
		a60 = C35.f37;
		(new C18()).m20(Main.fn49(100.75, 225), C35.m41(), v239, 0xF2CC);
		H.out("o241 " + Std.string((v239 < 0x910C)));
		return ((~51) >= (-11));
	}
	public static function fn62(a63:Int, a64:Bool):Null<Int> {
		H.tick();
		H.out("o242 " + Std.string((1e3 * 41)));
		var v243:Array<C35> = (([new C35(), new C35(), new C35()] : Array<C35>)).concat(([new C35()] : Array<C35>));
		var v244 = (Math.isNaN(a63) ? false : Std.isOfType(new C18(), C18));
		return null;
	}
	public static function fn65(a66:C7):Int {
		H.tick();
		var v245 = ((K6.K6B : Int) % H.nz(26));
		var w246 = 0;
do {
			w246++;
			H.tick();
			final lf247:(Int, Int) -> Void = function(p248:Int, p249:Int):Void {
				H.tick();
				Main.fn42(p248);
				H.out("o250 " + Std.string(93));
				(new C18()).m11(true);
			};
			final lf251:(Float) -> Int = (p252:Float) -> Type.enumIndex(E2.E2A);
			fn52(v245, H.at([v245, v245], v245, 0), C35.f37);
		} while (w246 < 2 && (true && ([243, 226]).contains(v245)));
		for (k253 => v254 in new Map<String, Int>()) {
			H.tick();
			(a66).m11(true, v245);
			if (true) {
				var v255:Float = v245;
				if (true) continue;
				H.out("o256 " + Std.string(v245));
			}
			var v257:Map<String, String> = new Map<String, String>();
		}
		var v258:Map<Int, Int> = new Map<Int, Int>();
		return (new C18()).m19();
	}
	public static function fn67(a68:E2, a69:Array<Int>):Int {
		H.tick();
		C35.f36 <<= ((new C27(214, 1e-7)).m33(83) & 7);
		H.out("o259 " + Std.string((([({x4: false} : S3)] : Array<S3>)).concat(([] : Array<S3>))));
		var v260:Float = ((false ? 1e3 : 1e3) : Float);
		fn45(a68, 252, (new C27(218833037, v260)).m30((a69).contains(165), (((["k0" => 240, "k1" => 89] : Map<String, Int>)).get("k0") ?? 0)));
		for (x261 in [Std.string(E2.E2A), "\"q\"", "日本語"]) {
			H.tick();
			for (i262 in 0...1) {
				H.tick();
				var v263 = 2019593937;
				var v264:Float = 7.0;
			}
			(new C18()).m9(E0C);
		}
		C35.f36 = 0x8C69;
		return Type.enumIndex(E0B(Reflect.compare(0x80000000, 272)));
	}
	public static function fn70(a71:Float, a72:Int, a73:Bool):Float {
		H.tick();
		H.out("o265 " + Std.string(a72));
		a73 = true;
		for (i266 in 0...0) {
			H.tick();
			var w267 = 0;
while (w267 < 4 && false) {
				w267++;
				H.tick();
				H.out("o268 " + Std.string(a72));
				H.out("o269 " + Std.string(168));
				C35.m40();
			}
			H.out("o270 " + Std.string(new C18()));
		}
		var v271:Array<Int> = [for (i272 in 0...1) 241];
		var v273:Float = a71;
		var v274:K6 = ((a73 ? K6.K6A : K6.K6A) : K6);
		v274 = H.id(v274);
		var v275:C7 = new C18();
		if (fn59(Math.floor(v273), Type.enumIndex(E0.E0A))) return (a72 + a72);
		return (a72 + 237);
	}
	public static function section0():Void {
		H.tick();
		H.out("o276 " + Std.string((([E2.E2A] : Array<E2>)).slice(0, 4)));
		Main.fn62((Math.round(0.30000000000000004) >> (C35.f37 & 31)), (new C27(9, 100.75)).m30(false, Reflect.compare(0xFFFFFFFF, (-1025531978))));
		var v277:Float = C35.f37;
		H.out("o278 " + Std.string((Std.int(v277) | 1378217746)));
		v277 = H.id(v277);
		var v279:Float = (new C18()).m19();
	}
	public static function section1():Void {
		H.tick();
		for (i280 in 2...H.lim(((Std.parseInt(Std.string(0x80000000)) ?? 0) >> (278 & 31)))) {
			H.tick();
			Main.fn52(i280, i280, i280);
		}
		for (k281 => v282 in new Map<String, Int>()) {
			H.tick();
			C35.m41();
			for (i283 in 0...2) {
				H.tick();
				fn44();
			}
			var v284:S3 = ({x4: false} : S3);
		}
		var v285:S3 = ({x4: Math.isNaN(1.25)} : S3);
		final v286:Bool = (Reflect.compare(179, 236) == 245);
		var w287 = 0;
while (w287 < 3 && ([(-924184348)]).contains(28)) {
			w287++;
			H.tick();
			H.out("o288 " + Std.string(E0C));
		}
		for (i289 in 1...H.lim(Type.enumIndex(E0.E0C))) {
			H.tick();
			final v290 = Math.isNaN(3.0);
			var v291:K6 = K6.K6B;
			{ var dyn292:Dynamic = v285; H.out("dyn " + Std.string(dyn292.x4) + " " + Std.string(Reflect.field(dyn292, "x4"))); }
		}
		var v293 = C35.f37;
		for (i294 in 0...0) {
			H.tick();
			++v293;
			H.out("o295 " + Std.string((K6.K6A : Int)));
		}
		var v296:Array<Bool> = fn44();
	}
	public static function section2():Void {
		H.tick();
		var v297 = ((new A5(103)).twice & Type.enumIndex(E2.E2A));
		var v298 = v297;
		final v299:Float = (1.25 * 0.5);
		Main.fn44();
		H.out("o300 " + "Haxe");
		var v301:Bool = (true ? true : false);
		Main.fn67(E2.E2B, ({ var v302 = Math.floor(1.7976931348623157e308); ([] : Array<Int>); }));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
