import H;
import p.M1;
using p.Ext;
using StringTools;

class Main {
	public static function fn3(a4:String, a5:Map<Int, String>):Int {
		H.tick();
		var v27:Map<String, Float> = (["k0" => 123456.789, "k1" => (-2.5), "k2" => Std.parseFloat("3")] : Map<String, Float>);
		for (i28 in 0...2) {
			H.tick();
			var v29:Map<Int, Int> = new Map<Int, Int>();
			var v30:Bool = StringTools.contains("zz", a4);
			if (v30) {
				H.out("o31 " + "-7");
				var v32:Float = i28;
			}
		}
		a4 = H.cap(a4 + (true ? "Haxe" : Std.string(false)));
		var v33:Float = (1.25 / (-2.5));
		return 140;
	}
	public static function fn6():Float {
		H.tick();
		var v34:Map<Int, String> = new Map<Int, String>();
		switch ((switch (false) {
			case true: (Std.parseInt(Std.string((-2147483647))) ?? 0);
			case false: 65535;
		})) {
			case 0: {
				var v35 = 260;
				Main.fn3(StringTools.lpad("\x41\x42", "*", 6), ([-3 => "zz", 4 => "a\rb", 11 => "A-B-C"] : Map<Int, String>));
			};
			case 1 | 6: {
				final v36:Map<String, String> = new Map<String, String>();
			};
			case _: {
				for (i37 in 0...4) {
					H.tick();
					if (true) break;
				}
				var v38:String = "日本語";
			};
		}
		H.out("o39 " + Std.string(259));
		H.out("o40 " + Std.string(0x6A1C));
		if ((209 >= ("\n").indexOf("  pad  "))) {
			if ((new Map<String, Bool>()).exists("k2")) return 129;
		}
		Main.fn3("ünï", (((new Map<Int, Int>()).exists(18) ? new Map<Int, String>() : v34) : Map<Int, String>));
		Main.fn3(("a" + StringTools.trim("\n")), v34);
		H.out("o41 " + Std.string((Std.parseInt(Std.string(Reflect.compare(127, 0x80000000))) ?? 0)));
		H.out("o42 " + (true ? ("x,y,z").substring(4, -1) : ("é").toUpperCase()));
		return (Main.fn3(("hello world").toUpperCase(), ([-3 => "a\rb"] : Map<Int, String>)) + 1e3);
	}
	public static function fn7():Int {
		H.tick();
		var v43 = Std.string(false);
		var v44:Int = 271;
		final v45:Int = 888503469;
		var v46:String = (true ? StringTools.hex((51) & 0xFFFF, 4) : "ab");
		var v47:Float = 123456.789;
		if (false) return (v44 * Math.floor(0.5));
		return v45;
	}
	public static function fn8(...r9:Int):Int {
		H.tick();
		var v48:String = (switch ((Std.parseInt(Std.string(0x61A9)) ?? 0)) {
			case 0: ("\u{1F600}").substr((237 & 7), (160 & 7));
			case 2 | 5: Std.string(65535);
			case _: "\x41\x42";
		});
		H.out("o49 " + Std.string(true));
		var v50 = (true ? "x,y,z" : v48);
		var v51 = !true;
		return 114;
	}
	public static function fn10(a11:String, a12:Int, a13:Bool):Int {
		H.tick();
		var w52 = 0;
do {
			w52++;
			H.tick();
			var v53:S0 = ({x1: a12, x2: 80} : S0);
		} while (w52 < 1 && false);
		H.out("o54 " + '<${Std.string(a13)}-${("ab").toLowerCase()}');
		H.out("o55 " + Std.string((a12--)));
		fn3('<${("\\").charAt((a12 & 7))}', ([-3 => a11] : Map<Int, String>));
		final v56 = 0xB54;
		a12 = (false ? Math.round(a12) : (({x1: 124, x2: 74} : S0)).x1);
		H.out("o57 " + Std.string(((new Map<Int, Null<Int>>()).exists(18) && false)));
		a12 = (a12++);
		return v56;
	}
	public static function fn14():Float {
		H.tick();
		final v58 = ((new Map<String, Int>()).get("k1") ?? 0);
		for (i59 in 2...4) {
			H.tick();
			var v60 = "日本語";
		}
		var v61 = (false ? String.fromCharCode(65 + ((v58) & 15)) : ("x,y,z").substr((v58 & 7), 2));
		H.out("o62 " + Std.string(Math.floor(105)));
		([298, v58, 12]).ext20();
		var v63:Null<Int> = ((v61).charCodeAt((-19)) ?? -1);
		fn10(StringTools.hex((0x41E4) & 0xFFFF, 4), (Math.ceil(v58) % H.nz(("0").length)), (false && true));
		var v64:Bool = (Math.isNaN(v58) || Math.isNaN(v58));
		var v65:String = '${(v61).toUpperCase()}';
		return 1e3;
	}
	public static function fn15(a16:Float, a17:String, a18:Int = 7):Float {
		H.tick();
		for (i66 in 0...0) {
			H.tick();
			switch (65535) {
				case 0: {
					a18 *= 162;
				};
				case 2 | 4: {
					fn3("A-B-C", new Map<Int, String>());
				};
				case _: {
					var v67:Map<String, Int> = (["k0" => 218] : Map<String, Int>);
				};
			}
		}
		if (true) {
			for (i68 in 1...5) {
				H.tick();
				var v69:Map<String, Float> = new Map<String, Float>();
				H.out("o70 " + a17);
				var v71 = a17;
			}
			H.out("o72 " + Std.string(a18));
		} else {
			if (false) {
				a16 = 1e-7;
				Main.fn7();
			}
		}
		H.out("o73 " + a17);
		var v74:Int = (-1141829668);
		if ((Std.string(a18) >= a17)) return ((switch (v74) {
			case 0: 2.5e-3;
			case 1 | 4: v74;
			case _: a16;
		}) : Float);
		H.out("o75 " + a17);
		if (false) {
			var v76:S0 = ({x1: v74, x2: v74} : S0);
		} else {
			for (i77 in 2...H.lim(v74)) {
				H.tick();
				var v78:String = a17;
				var v79:Map<String, Int> = new Map<String, Int>();
				var v80:Bool = true;
			}
		}
		return 7.0;
	}
	public static function section0():Void {
		H.tick();
		fn15((3.0 / (-508076937)), ((((["k0" => 65535, "k1" => 275, "k2" => 56] : Map<String, Int>)).get("k0") ?? 0) + String.fromCharCode(65 + ((280) & 15))));
		for (i99 in 0...0) {
			H.tick();
			try {
				var v100:Bool = true;
				var v101:Float = i99;
				H.out("o102 " + Std.string(i99));
				if (true) throw "boom";
			} catch (ex103:String) {
				H.out("caught String " + ex103);
				var v104 = 117;
			} catch (ex105:Int) {
				H.out("caught Int " + ex105);
				final v106 = i99;
				if (true) continue;
			} catch (ex107:Err) {
				H.out("caught Err " + ex107.errCode);
				final v108:Float = 1.25;
				H.out("o109 " + "a");
			} catch (ex110:Dynamic) {
				H.out("caught " + H.exn(ex110));
				var v111:Int = 285;
				var v112:Map<String, Int> = (["k0" => i99] : Map<String, Int>);
			}
			var v113:String = "\n";
			H.out("o114 " + "\n");
		}
		Main.fn6();
		var v115:Bool = Ext.ext23(([] : Array<Int>), Std.string(false));
		H.out("o116 " + Std.string((false ? (Std.parseInt(Std.string(263)) ?? 0) : (Std.parseInt("x,y,z") ?? 0))));
	}
	public static function section1():Void {
		H.tick();
		var v117:Float = 1e3;
		H.out("o118 " + Std.string(66));
		var v119:S0 = ({x1: (("a").charCodeAt(138) ?? -1), x2: ("0").lastIndexOf("\"q\"")} : S0);
		var v120 = Main.fn8((("A-B-C").charCodeAt(0x1183) ?? -1));
		H.out("o121 " + Std.string(0x78E8));
		H.out("o122 " + Std.string((v120 | 73)));
		var w123 = 0;
while (w123 < 5 && (new Map<Int, String>()).exists(11)) {
			w123++;
			H.tick();
			if (true) {
				H.out("o124 " + Std.string(v120));
				(([] : Array<Int>)).ext23("a\rb");
				H.out("o125 " + Std.string(v120));
			} else {
				var v126:Int = 109;
				++v126;
			}
			var v127:Float = 0.5;
			var w128 = 0;
do {
				w128++;
				H.tick();
				H.out("o129 " + "  pad  ");
				fn6();
				var v130 = true;
			} while (w128 < 4 && false);
		}
	}
	public static function section2():Void {
		H.tick();
		H.out("o131 " + "\"q\"");
		switch (fn3(("hello world").replace("a", "b"), ([-3 => "\t", 4 => "Haxe"] : Map<Int, String>))) {
			case 0: {
				var v132 = Std.int((-2.5));
				H.out("o133 " + Std.string(true));
			};
			case 3 | 5: {
				switch ("  pad  ") {
					case "a" | "b": {
						fn15(1e-7, "\\", 223);
						var v134 = "0";
					};
					case "Haxe": {
						var v135:String = "\u{1F600}";
						var v136:Map<String, Bool> = (["k0" => true, "k1" => false, "k2" => true] : Map<String, Bool>);
					};
					case "": {
						var v137:Float = 123456.789;
					};
					case _: {
						var v138:Int = 21;
					};
				}
			};
			case c139 if (c139 > 10): {
				var v140 = "0";
			};
			case _: {
				for (i141 in 0...3) {
					H.tick();
					var v142 = i141;
					var v143:Map<String, S0> = new Map<String, S0>();
				}
				try {
					var v144 = "42";
					Ext.ext23([136], "0");
					Ext.ext26(137, v144);
					if (true) throw "boom";
				} catch (ex145:String) {
					H.out("caught String " + ex145);
					fn6();
				} catch (ex146:Int) {
					H.out("caught Int " + ex146);
					H.out("o147 " + Std.string(ex146));
				} catch (ex148:Err) {
					H.out("caught Err " + ex148.errCode);
					var v149 = "-7";
				} catch (ex150:Dynamic) {
					H.out("caught " + H.exn(ex150));
					var v151:Int = 144;
					fn6();
				}
			};
		}
		var v152:Map<Int, Float> = new Map<Int, Float>();
		fn15((1e-7 * (Std.parseInt(Std.string(1946225488)) ?? 0)), "é", (263 | Lambda.fold([65535], (v153:Int, v154:Int) -> (Std.parseInt(Std.string(53)) ?? 0), 0)));
	}
	public static function section3():Void {
		H.tick();
		var v155:Int = Reflect.compare("zz", Std.string(77));
		var v156:Map<String, Bool> = new Map<String, Bool>();
		{
			for (i157 in 0...H.lim(52)) {
				H.tick();
				var v158:String = "ünï";
				fn7();
			}
			H.out("o159 " + "\u{1F600}");
		}
		switch (({x2: Reflect.compare(v155, v155), x1: (-282009966)} : S0)) {
			case {x1: 1 | 2}: {
				var v161:String = StringTools.hex((31) & 0xFFFF, 4);
				for (i162 in 0...1) {
					H.tick();
					var v163 = false;
				}
			};
			case {x1: c160}: {
				H.out("o164 " + StringTools.trim("a"));
				H.out("o165 " + "é");
			};
		}
		H.out("o166 " + Std.string((Std.int((-2.5)) & 0x7FFFFFFF)));
		var v167 = ((({x2: v155, x1: v155} : S0)).x1 <= 132);
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		try section2() catch (e:Dynamic) H.out("section2 threw " + H.exn(e));
		try section3() catch (e:Dynamic) H.out("section3 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
