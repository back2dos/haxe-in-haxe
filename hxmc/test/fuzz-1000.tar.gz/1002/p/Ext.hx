package p;

import Main;
import H;
import p.M1;
using StringTools;

class Ext {
	public static function ext20(a19:Array<Int>):Int {
		H.tick();
		try {
			var v81:S0 = ({x1: 253, x2: 278} : S0);
			var v82:Map<Int, Bool> = new Map<Int, Bool>();
			if (false) throw 0;
		} catch (ex83:Dynamic) {
			H.out("caught " + H.exn(ex83));
			var w84 = 0;
while (w84 < 1 && StringTools.endsWith("ab", "Haxe")) {
				w84++;
				H.tick();
				var v85:Map<String, String> = (["k0" => "x,y,z"] : Map<String, String>);
				var v86:Int = 90;
			}
		}
		var v87 = Main.fn10(Std.string(0.30000000000000004), 185, StringTools.endsWith("abc", "q"));
		final v88:Int = (v87 >> (("ünï").indexOf("é") & 31));
		v87 = (switch ((v87 = 5)) {
			case 0: (("q").charCodeAt(v87) ?? -1);
			case 2 | 6: Reflect.compare("\t", "abc");
			case _: 274;
		});
		var w89 = 0;
while (w89 < 4 && ("abc" < StringTools.replace("zz", " ", "0"))) {
			w89++;
			H.tick();
			var v90 = 292;
			switch (({x2: v90, x1: 236} : S0)) {
				case {x1: 1 | 2}: {
					Main.fn10("42", v90, true);
				};
				case {x1: c91}: {
					var v92:Int = v88;
				};
			}
			if (true) break;
		}
		H.out("o93 " + Std.string(3.0));
		for (i94 in 0...1) {
			H.tick();
			if (StringTools.endsWith("a\rb", "42")) {
				H.out("o95 " + Std.string(v88));
			}
			H.out("o96 " + "42");
			Main.fn6();
		}
		Main.fn10("a", (61 ^ 75), ((new Map<Int, String>()).exists(4) ? ((["k0" => "\t", "k1" => "zz", "k2" => ""] : Map<String, String>)).exists("k3") : true));
		return (v88 >>> ((++v87) & 31));
	}
	public static function ext23(a21:Array<Int>, a22:String):Bool {
		H.tick();
		H.out("o97 " + Std.string(Main.fn8()));
		if ((Math.isNaN(3.0) && true)) return (([-3 => 7.0, 4 => 0.5, 11 => 1e-7] : Map<Int, Float>)).exists(-3);
		var v98 = (false ? StringTools.contains(a22, "é") : true);
		return (1559438261 != 87);
	}
	public static function ext26(a24:Int, a25:String):Float {
		H.tick();
		a24 = (65535 ^ Reflect.compare("\u{1F600}", a25));
		Main.fn8();
		a24 |= (switch (a25) {
			case "a" | "b": 135;
			case "Haxe": (a24--);
			case _: (-526297169);
		});
		return ((a24 * Std.parseFloat("-0.25")) - Main.fn7());
	}
}
