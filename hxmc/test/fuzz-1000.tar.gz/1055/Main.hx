import H;
import p.M1;
import p.q.M2;

class Main {
	public static function fn0(a1:Int, a2:Int):Int {
		H.tick();
		var v30:Map<String, Int> = (["k0" => a1, "k1" => H.at([a2], a1, 0)] : Map<String, Int>);
		H.out("o31 " + Std.string(a2));
		a2 = (if (([a1, a2]).contains(a2)) 97 else a2);
		var v32:Int = a1;
		final v33:(Int, Float) -> Int = function(p34:Int, p35:Float):Int {
			H.tick();
			final v36:Int = a1;
			v32 = v36;
			a1++;
			return (--a2);
		};
		if (!false) {
			H.out("o37 " + Std.string(([] : Array<Int>)));
			var v38:Map<String, Float> = (["k0" => a2, "k1" => a1, "k2" => a2] : Map<String, Float>);
		}
		var v39:Int = (-10);
		H.out("o40 " + Std.string(((([v32, a1, v39]).contains(v32) ? new Box(false) : new Box(true)) : Box<Bool>)));
		return Reflect.compare(v39, v39);
	}
	public static function fn3(a4:Float, a5:Int):Float {
		H.tick();
		H.out("o41 " + Std.string(([a5]).slice((1541369805 & 7), (Std.int(a5) & 7))));
		if (false) {
			H.out("o42 " + Std.string(1e3));
			if (false) {
				H.out("o43 " + Std.string(new Box<Int>(a5)));
				final v44:Float = a5;
			} else {
				var v45:Null<Int> = a5;
			}
		} else {
			if (true) {
				H.out("o46 " + Std.string(a5));
				Main.fn0(a5, a5);
			}
		}
		a5 = 23;
		H.out("o47 " + Std.string(a5));
		H.out("o48 " + Std.string(Math.fceil(a5)));
		fn0(fn0((Std.parseInt(Std.string(a5)) ?? 0), a5), (new Box(a5)).get());
		var v49:Map<Int, (Bool, String) -> Void> = new Map<Int, (Bool, String) -> Void>();
		var v50:Int = ((([] : Array<Int>)).indexOf(267) - 26);
		if (false) {
			if (Math.isNaN(a4)) return 1e3;
			H.out("o51 " + Std.string(0x6BE));
			a5 = 226;
		} else {
			var v52:Float = Math.PI;
		}
		return Math.sqrt(Math.abs(((false ? 1e3 : 1.7976931348623157e308) : Float)));
	}
	public static function fn6(a7:Int, a8:Int, a9:Int):Int {
		H.tick();
		var v53:Array<Int> = [([171]).indexOf(a8)];
		if ((Std.parseFloat("a\rb") < a7)) return ((-1319694030) % H.nz(Std.int(a7)));
		fn3(1e3, ((Std.parseInt("") ?? 0) % H.nz((v53).indexOf((-1)))));
		return (cast (a8) : Int);
	}
	public static function fn10(a11:Bool):Void {
		H.tick();
		var v54:Float = 100.75;
		H.out("o55 " + Std.string((49 % H.nz(H.at([89, 114, 31], 206, 0)))));
		var v56 = 8;
	}
	public static function fn12(a13:Map<Int, Null<Int>>, a14:Int, a15:String):Array<Int> {
		H.tick();
		var v57:Array<Null<Int>> = ([] : Array<Null<Int>>);
		var v58:Array<Int> = ([16, a14]).slice((1574489882 & 7), (Reflect.compare(a14, a14) & 7));
		if ((false || false)) return ([75, 190]).map((v59:Int) -> 135);
		return [Lambda.count([a14], v60 -> (new Map<String, Int>()).exists("k2"))];
	}
	public static function fn16(a17:Float):Void {
		H.tick();
		var v61:Array<Int> = ([236]).map((v62:Int) -> v62);
		H.out("o63 " + Std.string((0xFFFFFFFF - 71)));
		H.out("o64 " + Std.string(Main.fn6(48, (-19), Lambda.fold(v61, (v65:Int, v66:Int) -> Math.floor(v66), 0))));
		var v67:Null<Int> = fn0(205, Std.int(a17));
		Main.fn0(((([] : Array<Float>)).length % H.nz(178)), Math.round(1e3));
		var v68:Array<Int> = [0x67C5];
		if (true) {
			var v69:Int = 156;
		}
		H.out("o70 " + Std.string(Main.fn0(18, ((new Map<String, Int>()).get("k0") ?? 0))));
	}
	public static function fn18(a19:Bool):Float {
		H.tick();
		H.out("o71 " + Std.string((cast ([a19]) : Array<Bool>)));
		fn3(((a19 ? Std.parseFloat("3") : 3.0) : Float), 0x54A);
		var v72:Map<String, Int> = new Map<String, Int>();
		H.out("o73 " + Std.string(((true ? 0.5 : 1e21) : Float)));
		final v74:Bool = a19;
		final lf75:(Int) -> Void = function(p76:Int):Void {
			H.tick();
			var v77:Array<Int> = ([] : Array<Int>);
			function lf78(n79:Int):Int {
				H.tick();
				return n79 <= 0 ? (([0.5, n79] : Array<Float>)).length : (lf78(n79 - 1) + p76);
			}
			H.out("lf78 " + lf78(5));
			H.out("o80 " + Std.string(117));
		};
		var v81:Bool = v74;
		var v82:Array<Int> = fn12(([-3 => 108] : Map<Int, Null<Int>>), 109, "zz");
		return (164 - Lambda.count(v82, v83 -> false));
	}
	public static function fn20(a21:Int, a22:Array<Int>, a23:Map<String, Bool>):Void {
		H.tick();
		var v84:Bool = (false ? true : false);
		H.out("o85 " + Std.string((a21 < (++a21))));
		if (!v84) {
			var v86 = Lambda.count(a22, v87 -> false);
			if (v84) {
				var v88:Int = 48;
				final v89:() -> Int = () -> 84;
				var v90:Float = v88;
			}
			a21 -= 0xB2E9;
		} else {
			var v91:Array<Int> = [(-1103978770), a21];
		}
		var v92:Int = (-7);
		var v93:Float = a21;
	}
	public static function fn24(a25:Int, a26:Bool):Void {
		H.tick();
		H.out("o94 " + Std.string(Std.int(1e3)));
		H.out("o95 " + Std.string(a26));
		final v96:Int = ((a25++) * a25);
		final v97:Map<String, Array<Int>> = (["k0" => [891012099, v96, v96], "k1" => [a25], "k2" => [a25]] : Map<String, Array<Int>>);
		if ((a25 <= v96)) {
			H.out("o98 " + Std.string(true));
			if ((new Map<String, Int>()).exists("k1")) {
				final v99:Array<Int> = ([] : Array<Int>);
			} else {
				final v100:Array<Float> = ([] : Array<Float>);
				var v101 = v96;
			}
		}
	}
	public static function fn27(a28:Int, a29:Int):Int {
		H.tick();
		H.out("o102 " + Std.string((a28 % H.nz(((([-3 => a29, 4 => a28] : Map<Int, Int>)).get(4) ?? 0)))));
		Main.fn12(new Map<Int, Null<Int>>(), a29, "ünï");
		if (true) {
			var v103:Float = 3.0;
		}
		var v104 = a29;
		v104 = ((([] : Array<Int>)).contains(202) ? H.at(([] : Array<Int>), v104, 0) : Lambda.count(([] : Array<Int>), v105 -> false));
		var v106:Float = (Reflect.compare(a28, a29) - a29);
		{
			var v107 = Std.int(a29);
			final v108 = a29;
		}
		function lf109(n110:Int):Int {
			H.tick();
			return n110 <= 0 ? H.apply(true, (v111:Bool) -> n110) : (lf109(n110 - 1) + v104);
		}
		H.out("lf109 " + lf109(4));
		++a29;
		return ((true ? (a28 -= 1) : Math.floor(1e3)) - Reflect.compare(a28, (-2)));
	}
	public static function section0():Void {
		H.tick();
		final lf112:(Int) -> Int = (p113:Int) -> Reflect.compare(81, 58);
		var v114 = lf112((Std.parseInt(Std.string(0xC39C)) ?? 0));
		var v115:Array<Int> = [for (i116 in 0...4) (v114--)];
		var v117:Int = (v114 * 276);
		final v118:Int = v117;
		if ((140 <= v114)) {
			v117 = 20;
			var v119 = (new Map<String, Int>()).exists("ünï");
		} else {
			Main.fn10((new Map<String, Int>()).exists("k0"));
			H.out("o120 " + Std.string(Lambda.fold(v115, (v121:Int, v122:Int) -> 298, 0)));
		}
		v117 = (v114--);
		var v123:Box<Int> = new Box(H.at(v115, v118, 0));
	}
	public static function section1():Void {
		H.tick();
		var v124:Null<Int> = null;
		var v125:Int = Main.fn6((Std.parseInt(Std.string(0x80000000)) ?? 0), Lambda.count(([] : Array<Int>), v126 -> (([-3 => 2.5e-3] : Map<Int, Float>)).exists(-3)), 200);
		H.out("o127 " + Std.string(1035760029));
		fn12((cast (new Map<Int, Null<Int>>()) : Map<Int, Null<Int>>), ([131]).indexOf((Std.parseInt(Std.string(v125)) ?? 0)), "\t");
		fn12(([-3 => v125, 4 => null, 11 => v125] : Map<Int, Null<Int>>), v125, ("Haxe" + Math.isNaN(v125)));
		var v128:Array<Float> = ([for (i129 in [(-237179964), v125, v125]) if (([v125, v125]).contains(v125)) 1e-7] : Array<Float>);
		final v130 = Math.floor(v125);
		var v131:Array<Int> = fn12(new Map<Int, Null<Int>>(), Reflect.compare(v125, 16), "\\");
		var v132:Null<Int> = fn6(v130, v125, Lambda.count(v131, v133 -> (v131).contains(v133)));
	}
	public static function main():Void {
		H.out("start");
		try section0() catch (e:Dynamic) H.out("section0 threw " + H.exn(e));
		try section1() catch (e:Dynamic) H.out("section1 threw " + H.exn(e));
		H.out("fuel " + H.fuel);
	}
}
